
class Player {
	public String name;
	public int num;

	Player(String name) {
		this.name = "Player" + name;
		this.num = 0;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void addNum(int num) {
		this.num += num;
	}

	public int getNum() {
		return this.num;
	}

}
