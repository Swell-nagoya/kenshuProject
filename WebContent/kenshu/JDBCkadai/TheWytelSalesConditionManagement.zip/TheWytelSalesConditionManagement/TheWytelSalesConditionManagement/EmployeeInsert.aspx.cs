﻿using System;
using System.Data;
using System.Drawing;
using TheWytelSalesConditionManagement.Util;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class EmployeeInsert : System.Web.UI.Page
    {
        Dao.Mst001_EmployeeDao empDao = new Dao.Mst001_EmployeeDao();
        Dao.Mst002_CompanyDao companyDao = new Dao.Mst002_CompanyDao();
        string empId = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString.Count != 0)
            {
                empId = Request.QueryString.Get(0);
            }
            if (IsPostBack)
            {
                return;
            }

            //要員情報があれば表示
            SetToPageData();
        }

        /// <summary>
        /// 要員情報表示
        /// </summary>
        protected void SetToPageData()
        {
            Mst001_Employee emp = empDao.GetMst001_EmployeeById(empId);
            if (String.IsNullOrEmpty(emp.emp_id) == false)
            {
                txtFirstName.Text = emp.emp_name_first;
                txtLastName.Text = emp.emp_name_last;
                txtAge.Text = emp.age.ToString();
                txtCompany.Text = emp.company_id;
                sexDdl.Text = emp.sex;
                txtComment.Text = emp.comment;
            }
        }

        /// <summary>
        /// 登録ボタン押下時イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void empInsertBtn_Click(object sender, EventArgs e)
        {
            //入力チェック
            if (Utility.IsNum(txtAge.Text.ToString()) == false)
            {
                txtAge.Text = string.Empty;
                alert.Text = MessageConst.ERR_NOTNUMBER;
                alert.ForeColor = Color.Red;
                return;
            }

            try
            {
                Mst001_Employee emp = SetEmployeeParams();

                string selectQuery = empDao.CreateGetEmpByIdQuery();

                DataTable dt = new DataTable();
                using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
                using (MySqlDataAdapter adapter = new MySqlDataAdapter())
                {
                    //select delete insert
                    adapter.SelectCommand = new MySqlCommand(selectQuery, con);
                    adapter.SelectCommand.Parameters.AddWithValue(DbConst.MST001_EMP_ID, emp.emp_id); 
                    adapter.Fill(dt);
                }

                //デリート
                DbEmpDelete(dt, emp);

                //インサート
                DbEmpInsert(emp);

                lblFinInsert.Text = MessageConst.MSG_FININSERT;
            } catch (Exception){
                Console.WriteLine(MessageConst.ERR_EMPINSERT);
            }
        }

        //TODO:Daoに入れよう
        /// <summary>
        /// 重複の削除
        /// </summary>
        /// <param name="datatable"></param>
        /// <param name="emp"></param>
        private void DbEmpDelete(DataTable datatable, Mst001_Employee emp)
        {
            if (datatable.Rows.Count != 0)
            {
                string deleteQuery = empDao.CreateDeleteQueryByEmpId();
                using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
                {
                    MySqlCommand deleteCommand = new MySqlCommand(deleteQuery, con);
                    deleteCommand = empDao.SetDataToBindQuery(emp, deleteCommand);
                    deleteCommand.Connection.Open();
                    deleteCommand.Transaction = deleteCommand.Connection.BeginTransaction();
                    int effectRecordNumber = deleteCommand.ExecuteNonQuery();
                    if (effectRecordNumber == 0)
                    {
                        deleteCommand.Transaction.Rollback();
                        return;
                    }
                    deleteCommand.Transaction.Commit();
                    deleteCommand.Connection.Close();
                }
            }
        }

        /// <summary>
        /// 新規登録
        /// </summary>
        /// <param name="emp"></param>
        private void DbEmpInsert(Mst001_Employee emp)
        {
            string insertQuery = empDao.CreateInsertQuery();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionproperty"]))
            {
                MySqlCommand insertCommand = new MySqlCommand(insertQuery, con);
                insertCommand = empDao.SetDataToBindQuery(emp, insertCommand);
                insertCommand.Connection.Open();
                insertCommand.Transaction = insertCommand.Connection.BeginTransaction();
                int effectRecordNumber = insertCommand.ExecuteNonQuery();
                if (effectRecordNumber == 0)
                {
                    insertCommand.Transaction.Commit();
                    return;
                }
                insertCommand.Transaction.Commit();
                insertCommand.Connection.Close();
            }
        }

        /// <summary>
        /// 要員情報 設定
        /// </summary>
        /// <returns></returns>
        private Mst001_Employee SetEmployeeParams()
        {
            Mst001_Employee emp = new Mst001_Employee();
            DateTime now = DateTime.Now;
            emp.emp_id = String.IsNullOrEmpty(empId) ? DbConst.MST001_EMP_ID_FRONT + now.Year + now.Month + now.Date + now.Hour + now.Second + now.Minute : empId;//TODO:ランダム
            emp.company_id = txtCompany.Text.ToString();
            emp.emp_name_last = txtLastName.Text.ToString();
            emp.emp_name_first = txtFirstName.Text.ToString();
            emp.sex = sexDdl.SelectedItem.Text.ToString();
            emp.age = int.Parse(txtAge.Text.ToString());
            emp.comment = txtComment.Text.ToString();
            emp.last_update_date = now;
            emp.last_update_user = DbConst.USER_TEST;
            return emp;
        }
    }
}