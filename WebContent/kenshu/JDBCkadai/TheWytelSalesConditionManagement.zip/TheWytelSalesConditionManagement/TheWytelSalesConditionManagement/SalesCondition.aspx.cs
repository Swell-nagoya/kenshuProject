﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Util;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using TheWytelSalesConditionManagement.Dao;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class SaleConditon : System.Web.UI.Page
    {
        Mst001_EmployeeDao empDao = new Mst001_EmployeeDao();
        Mst003_ProjectDao proDao = new Mst003_ProjectDao();
        Trn001_SalesConditionDao salesDao = new Trn001_SalesConditionDao();
        Mst001_Employee emp = new Mst001_Employee();
        Mst003_Projects pro = new Mst003_Projects();
        Trn001_SalesCondition sales = new Trn001_SalesCondition();

        //HOME画面からのユーザーID,プロジェクトID
        public static string empId = "";
        public static string projectId = "";

        /// <summary>
        /// ロードイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (IsPostBack)
            {
                return;
            }
            
            //セッションの値を取得する
            if (Session[DbConst.MST001_EMP_ID] != null && Session[DbConst.MST003_PROJECT_ID] != null)
            {
                empId = Session[DbConst.MST001_EMP_ID].ToString();
                projectId = Session[DbConst.MST003_PROJECT_ID].ToString();
            }
            
            //プロパティ表示設定
            SetControlStyle();

            //プロジェクト情報の取得
            DataTable dt = GetProjectData();

            //プロジェクトのドロップダウンリスト作成

            foreach (DataRow row in dt.Rows)
            {
                ddlProject.Items.Add(row[DbConst.MST003_PROJECT_NAME].ToString());
            }

            //営業状況登録画面の項目値(プロジェクト基準)を設定
            SetSalesConditionProp(dt);
        }

        /// <summary>
        /// プロジェクト情報取得クエリ作成
        /// </summary>
        /// <returns></returns>
        private DataTable GetProjectData()
        {
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = proDao.CreateListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);
            }
            return dt;
        }

        /// <summary>
        /// 更新ボタン押下時イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void UpdateBtn_Click(object sender, EventArgs e)
        {
            //ラベルクリア
            lblAgeAlert.Text = String.Empty;
            lblSalesAlert.Text = String.Empty;

            //入力チェック
            if(!Utility.IsNum(txtAge.Text.ToString())){
                txtAge.Text = String.Empty;
                lblAgeAlert.Text = MessageConst.ERR_NOTNUMBER;
                return;
            } else if(!Utility.IsNum(txtYearsOfService.Text.ToString())){
                txtYearsOfService.Text = String.Empty;
                lblSalesAlert.Text = MessageConst.MSG_YEAR + MessageConst.ERR_NOTNUMBER;
                return;
            }

            Mst001_EmployeeDao empDao = new Mst001_EmployeeDao();
            
            //【要員情報更新】
            //取得したデータに画面の情報を設定
            Mst001_Employee newEmp = SetEmployeeParams();
            string query = empDao.CreateInsertQuery();

            DataTable projDt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {

                //IDに対応した要員情報の取得
                DataTable dataTable = new DataTable();
                string selectQuery = empDao.CreateGetEmpByIdQuery();
                adapter.SelectCommand = new MySqlCommand(selectQuery, con);
                adapter.SelectCommand = empDao.SetDataToBindQuery(newEmp, adapter.SelectCommand);
                adapter.Fill(dataTable);

                //IDでプロジェクト情報の取得
                adapter.SelectCommand = new MySqlCommand(proDao.CreateListQueryByProjectName(), con);
                adapter.SelectCommand.Parameters.AddWithValue(DbConst.MST003_PROJECT_NAME, ddlProject.SelectedItem.Text.ToString());
                adapter.Fill(projDt);

                MySqlCommand deleteCommand = new MySqlCommand(empDao.CreateDeleteQueryByEmpId(), con);
                deleteCommand.Parameters.AddWithValue(DbConst.MST001_EMP_ID, newEmp.emp_id);
                deleteCommand.Connection.Open();
                deleteCommand.Transaction = deleteCommand.Connection.BeginTransaction();
                int effectRecordNumber = deleteCommand.ExecuteNonQuery();
                if (dataTable.Rows.Count != 0 && effectRecordNumber == 0)
                {
                    deleteCommand.Transaction.Rollback();
                    deleteCommand.Connection.Close();
                    return;
                }
                deleteCommand.Transaction.Commit();
                deleteCommand.Connection.Close();

                //MySqlCommand updateCmd = new MySqlCommand(query, con);
                //updateCmd = empDao.SetDataToBindQuery(newEmp, updateCmd);
                //updateCmd.Connection.Open();
                //updateCmd.Transaction = updateCmd.Connection.BeginTransaction();
                //int effectRecord = updateCmd.ExecuteNonQuery();
                //if (effectRecord == 0)
                //{
                //    updateCmd.Transaction.Rollback();
                //    updateCmd.Connection.Close();
                //    return;
                //}
                //updateCmd.Transaction.Commit();
                //updateCmd.Connection.Close();
            }

            //案件情報更新
            //案件名から案件IDを取得
            string projId = projDt.Rows[0][DbConst.MST003_PROJECT_ID].ToString();
            Mst003_Projects project = proDao.GetMst003_ProjectId(projId);
            
            //クエリ作成
            ProjectUpdate(project);

            //営業状況トランの削除
            //DbSalesPreparation(newEmp, project);
            
            //営業状況トランの登録
            DbSalesRegistration(newEmp, project);

            //登録完了メッセージ表示
            lblSalesAlert.Text = MessageConst.MSG_FINISH;
        }



        /// <summary>
        /// プロジェクトパラメータ設定
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        private Mst003_Projects SetProjectParameter(string projId, Mst003_Projects project)
        {
            project.project_id = project.project_id == null ? projId : project.project_id;
            project.project_name = ddlProject.SelectedItem.Text.ToString();
            project.sales_charge = txtSalesMan.Text.ToString();
            //project.pay_site = int.Parse(ddlPaySite.SelectedItem.Text.ToString());
            //project.settles = "固定".Equals(ddlSettle.SelectedItem.Text.ToString()) ? 1 : 2;
            project.near_station = txtProjectTransportation.Text;
            project.last_update_date = DateTime.Now;
            project.last_update_user = DbConst.USER_TEST;

            return project;
        }

        /// <summary>
        /// プロジェクト更新クエリ作成
        /// </summary>
        /// <param name="project"></param>
        private void ProjectUpdate(Mst003_Projects project)
        {
            string updateQuery = proDao.CreateUpdateQuery();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            {
                MySqlCommand updateCmd = new MySqlCommand(updateQuery, con);
                updateCmd = proDao.SetDataToProject(project, updateCmd);
                updateCmd.Connection.Open();
                updateCmd.Transaction = updateCmd.Connection.BeginTransaction();
                int effectRecoedNumber = updateCmd.ExecuteNonQuery();
                if (effectRecoedNumber == 0)
                {
                    updateCmd.Transaction.Rollback();
                    return;
                }
                updateCmd.Transaction.Commit();
                updateCmd.Connection.Close();
            }
        }

        /// <summary>
        /// 営業状況トランの準備
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="project"></param>
        private void DbSalesPreparation(Mst001_Employee employee, Mst003_Projects project)
        {
            DataTable dataTable = new DataTable();
            Trn001_SalesCondition salesCondition = SetSalesParams(employee, project);
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                string selectQuery = salesDao.CreateSalesListBySaleIdQuery(txtSalesId.Text.ToString());
                adapter.SelectCommand = new MySqlCommand(selectQuery, con);
                adapter.SelectCommand.Parameters.AddWithValue(DbConst.TRN001_SALES_ID, txtSalesId.Text.ToString());
                adapter.Fill(dataTable);
            }
            salesCondition.sales_id = dataTable.Rows[0][DbConst.TRN001_SALES_ID].ToString();

            //削除
            DbSalersDelete(dataTable);
            
            //登録
            DbSalesRegistration(employee, project);
        }

        /// <summary>
        /// 社員トランの削除
        /// </summary>
        /// <param name="dataTable"></param>
        private void DbSalersDelete(DataTable dataTable)
        {
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            {
                string deleteQuery = salesDao.CreateDeleteQuery(txtSalesId.Text.ToString());
                MySqlCommand deleteCommand = new MySqlCommand(deleteQuery, con);

                if (dataTable.Rows.Count != 0)
                {
                    deleteCommand.Connection.Open();
                    deleteCommand.Transaction = deleteCommand.Connection.BeginTransaction();
                    int effectRecoedNumber = deleteCommand.ExecuteNonQuery();
                    if (effectRecoedNumber == 0)
                    {
                        deleteCommand.Transaction.Rollback();
                        return;
                    }
                    deleteCommand.Transaction.Commit();
                    deleteCommand.Connection.Close();
                }
            }
        }

        /// <summary>
        /// 営業トランの登録
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="project"></param>
        private void DbSalesRegistration(Mst001_Employee employee, Mst003_Projects project)
        {
            Trn001_SalesCondition salesCondition = SetSalesParams(employee, project);
            Trn001_SalesConditionDao salesDao = new Trn001_SalesConditionDao();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            {
                string insertSalesQuery = salesDao.CreateInsertSalesQuery(salesCondition);
                MySqlCommand insertCmd = new MySqlCommand(insertSalesQuery, con);
                insertCmd = salesDao.SetDataToBindQuery(salesCondition, insertCmd);
                insertCmd.Connection.Open();
                insertCmd.Transaction = insertCmd.Connection.BeginTransaction();
                int effeRecoednumber = insertCmd.ExecuteNonQuery();
                if (effeRecoednumber == 0)
                {
                    insertCmd.Transaction.Rollback();
                    return;
                }
                insertCmd.Transaction.Commit();
                insertCmd.Connection.Close();
            }
        }

        /// <summary>
        /// 営業状況情報 設定
        /// </summary>
        /// <param name="newEmp"></param>
        /// <param name="project"></param>
        /// <returns></returns>
        private Trn001_SalesCondition SetSalesParams(Mst001_Employee newEmp, Mst003_Projects project)
        {
            Trn001_SalesCondition salesCondition = new Trn001_SalesCondition();
            salesCondition.sales_id = DbConst.TRN001_SALES_ID_FRONT + DateTime.Now.ToString("yyyyMMddHHmmss");//TODO:ランダム
            salesCondition.employee_id = newEmp.emp_id;
            salesCondition.end_term = new DateTime();
            salesCondition.years_of_service = txtYearsOfService.Text.ToString();
            salesCondition.month_of_service = ddlMonthOfService.SelectedItem.Text.ToString();
            salesCondition.parallel_flg = 0;
            salesCondition.project_id = project.project_id;
            salesCondition.near_station = txtProjectTransportation.Text.ToString();
            salesCondition.admission_day = txtAdmissionDay.Text.ToString();
            salesCondition.exit_day = txtExitDay.Text.ToString();
            salesCondition.last_update_date = DateTime.Now;
            salesCondition.last_update_user = DbConst.USER_TEST;
            return salesCondition;
        }

        /// <summary>
        /// 要員情報 設定
        /// </summary>
        /// <returns></returns>
        private Mst001_Employee SetEmployeeParams()
        {
            Mst001_Employee newEmp = new Mst001_Employee();
            newEmp.emp_id = Session[DbConst.MST001_EMP_ID] == null ? DbConst.MST001_EMP_ID_FRONT + System.Web.Security.Membership.GeneratePassword(5, 0) : Session[DbConst.MST001_EMP_ID].ToString();
            newEmp.company_id = emp.company_id;
            newEmp.emp_name_last = txtNameLast.Text.ToString();
            newEmp.emp_name_first = txtNameFirst.Text.ToString();
            newEmp.sex = ddlSex.SelectedItem.Text.ToString();
            //TODO try catch
            newEmp.age = int.Parse(Server.HtmlEncode(txtAge.Text));
            newEmp.comment = Server.HtmlEncode(txtComment.Text);
            return newEmp;
        }

        /// <summary>
        /// 営業状況画面の項目値を設定
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private void SetSalesConditionProp(DataTable dt)
        {
            Mst001_Employee emp = new Mst001_Employee();
            Mst003_Projects pro = new Mst003_Projects();

            //Id情報が入っている場合
            if (String.IsNullOrEmpty(dt.Rows[0][DbConst.MST003_PROJECT_ID].ToString()) == false)
            {
                //各種情報のセット
                emp = empDao.GetMst001_EmployeeById(empId.ToString());
                pro = proDao.GetMst003_ProjectId(dt.Rows[0][DbConst.MST003_PROJECT_ID].ToString());
                ddlProject.SelectedValue = pro.project_name;

                //プロジェクト情報と要員情報を取得する
                if (String.IsNullOrEmpty(emp.emp_id) == false)
                {
                    dt = GetSalesListData(emp.emp_id.ToString(), pro.project_id.ToString());
                    //取得した情報で項目値を設定する
                    SetListParams(dt);

                    //取得出来ないとき
                    PropListMake(emp, pro);
                }
            }
        }

        
        /// <summary>
        /// 営業状況一覧取得
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="projectId"></param>
        /// <returns></returns>
        private DataTable GetSalesListData(string empId, string projectId)
        {
            Trn001_SalesCondition sales = new Trn001_SalesCondition();
            DataTable dt = new DataTable();
            
            string salesQuery = salesDao.CreateSalesListByIdQuery(empId, projectId);
            sales.employee_id = empId;
            sales.project_id = projectId;
            
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                adapter.SelectCommand = new MySqlCommand(salesQuery, con);
                salesDao.SetDataToBindQuery(sales, adapter.SelectCommand);
                adapter.Fill(dt);
            }
            return dt;
        }
        
        /// <summary>
        /// 営業状況の項目値設定
        /// </summary>
        /// <param name="dt"></param>
        private void SetListParams(DataTable dt)
        {
            if (dt.Rows.Count != 0)
            {
                txtYearsOfService.Text = dt.Rows[0][DbConst.TRN001_SALES_YEAR].ToString();
                ddlMonthOfService.SelectedValue = dt.Rows[0][DbConst.TRN001_SALES_MONTH].ToString();
                txtSalesMan.Text = dt.Rows[0][DbConst.TRN001_SALES_CHARGE].ToString();
                txtAdmissionDay.Text = dt.Rows[0][DbConst.TRN001_SALES_ADMISSION_DAY].ToString();
                txtExitDay.Text = dt.Rows[0][DbConst.TRN001_SALES_EXIT].ToString();
                txtSalesId.Text = dt.Rows[0][DbConst.TRN001_SALES_ID].ToString();
            }
        }

        /// <summary>
        /// 各要素にデータ設定
        /// </summary>
        /// <param name="emp"></param>
        /// <param name="pro"></param>
        private void PropListMake(Mst001_Employee emp, Mst003_Projects pro)
        {
            if (emp == null || pro == null)
            {
                return;
            }
            txtNameFirst.Text = emp.emp_name_first.ToString();
            txtNameLast.Text = emp.emp_name_last.ToString();
            ddlSex.Text = emp.sex;
            txtAge.Text = emp.age.ToString();
            txtComment.Text = emp.comment.ToString();
            ddlProject.SelectedValue = pro.project_name;
            txtProjectTransportation.Text = pro.near_station.ToString();
            txtProjectTransportation.Text = pro.near_station.ToString();
        }

        /// <summary>
        /// コントロールのスタイルを設定
        /// </summary>
        private void SetControlStyle()
        {
            NameFirstLbl.Style.Add("margin-left", "128px");
            SexLbl.Style.Add("margin-left", "132px");
            AgeLbl.Style.Add("margin-left", "39px");
            ProjectTransportationLbl.Style.Add("margin-left", "154px");
            AdmissionDayLbl.Style.Add("margin-left", "90px");
            ExitDayLbl.Style.Add("margin-left", "114px");
        }

    }
}
