﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Const
{
    public static class DbConst
    {
        public const string LASTUPDATE_USER = "LASTUPDATE_USER";
        public const string LASTUPDATE_DATE = "LASTUPDATE_DATE";
        public const string USER_TEST = "test";

        public const string MST001_EMP_ID = "EMP_ID";
        public const string MST001_EMP_NAME_FIRST = "EMP_NAME_FIRST";
        public const string MST001_EMP_NAME_LAST = "EMP_NAME_LAST";
        public const string MST001_EMP_SEX = "SEX";
        public const string MST001_EMP_AGE = "AGE";
        public const string MST001_EMP_COMMENT = "COMMENT";
        public const string MST001_EMP_ID_FRONT = "EMP";

        public const string MST002_COMP_ID = "COMPANY_ID";
        public const string MST002_COMP_NAME = "COMP_NAME";
        public const string MST002_COMP_ADDRESS = "COMP_ADDRESS";
        public const string MST002_COMP_PHONE_NUMBER = "COMP_PHONE_NUMBER";
        public const string MST002_COMMENT = "COMMENT";
        public const string MST002_COMP_DELETE_FLG = "FLG_DELETE";
        public const string MST002_GET_COMP_ID = "compId";

        public const string MST003_PROJECT_ID = "PROJECT_ID";
        public const string MST003_PROJECT_NAME = "PROJECT_NAME";
        public const string MST003_PROJECT_COMPANY = "COMPANY_ID";
        public const string MST003_PROJECT_SALES = "SALES_CHARGE";
        public const string MST003_PROJECT_STATION = "NEAR_STATION";
        public const string MST003_PROJECT_SITE = "PAY_SITE";
        public const string MST003_PROJECT_PRICE_UP = "UPPER_UNIT_PRICE";
        public const string MST003_PROJECT_PRICE_LOW = "LOWER_UNIT_PRICE";
        public const string MST003_PROJECT_UPPER_TIME_HIGH = "UPPER_HIGH_LIMIT";
        public const string MST003_PROJECT_UPPER_TIME_LOW = "UPPER_LOW_LIMIT";
        public const string MST003_PROJECT_LOWER_TIME_HIGH = "LOWER_HIGH_LIMIT";
        public const string MST003_PROJECT_LOWER_TIME_LOW = "LOWER_LOW_LOMIT";
        public const string MST003_PROJECT_SETTLES = "SETTLES";
        public const string MST003_USER_NAME_FRONT = "PROJ";
        public const string MST003_SETTLES = "固定";

        public const string TRN001_SALES_ID = "SALES_ID";
        public const string TRN001_SALES_EMPLOYEE_ID = "EMPLOYEE_ID";
        public const string TRN001_SALES_STATUS_CD = "STATUS_CD";
        public const string TRN001_SALES_END_TERM = "EMD_TERM";
        public const string TRN001_SALES_YEAR = "YEARS_OF_SERVICE";
        public const string TRN001_SALES_MONTH = "MONTH_OF_SERVICE";
        public const string TRN001_SALES_PARALLEL_FLG = "PARALLEL_FLG";
        public const string TRN001_SALES_NEAR_STATION = "NEAR_STATION";
        public const string TRN001_SALES_WORKST_DATE = "WORKST_DATE";
        public const string TRN001_SALES_WORKED_DATE = "WORKED_DATE";
        public const string TRN001_SALES_ADMISSION_DAY = "ADMISSION_DAY";
        public const string TRN001_SALES_EXIT = "EXIT_DAY";

        public const string TRN001_SALES_ID_FRONT = "SALES";

        public const string TRN001_SALES_CHARGE = "SALES_CHARGE";

    }
}