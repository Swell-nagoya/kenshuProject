﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Const
{
    public class ModeConst
    {
        //画面側CommandName
        public const string CMD_EDIT = "Edit";
        public const string CMD_DELETE = "Delete";

        //画面モード
        public const string INSERT = "登録";
        public const string UPDATE = "更新";
        public const string DELETE = "削除";

    }
}