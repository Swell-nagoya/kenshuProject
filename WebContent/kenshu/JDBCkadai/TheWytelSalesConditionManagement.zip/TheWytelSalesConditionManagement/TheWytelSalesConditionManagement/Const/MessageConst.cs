﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Const
{
    public static class MessageConst
    {
        public const string MSG_FININSERT = "登録が完了しました。";
        public const string MSG_FINISH = "完了しました。";
        public const string MSG_YEAR = "勤続年数には";
        public const string MSG_NOT_FOUND = "検索結果0件";
        //public const string MSG_PROJECT_NOT_FOUND = "検索結果0件";
        //public const string MSG_COMPANY_NOT_FOUND = "検索結果0件";
        
        public const string ERR_EMPINSERT = "要員登録時にエラーが発生しました。";
        public const string ERR_NOTCOMPANY = "会社名未入力です。";
        public const string ERR_NOTADDRESS = "住所未入力です";
        public const string ERR_NOTNUMBER = "数字を入力して下さい";

        public const string DT1_COLUMN_NAME_FIRST = "苗字";
        public const string DT1_COLUMN_NAME_LAST = "名前";
        public const string DT1_COLUMN_NAME_SEX = "性別";
        public const string DT1_COLUMN_NAME_AGE = "年齢";
        public const string DT1_COLUMN_NAME_COMMENT = "コメント";

        public const string DT2_COLUMN_NAME_COMPANY = "会社名";
        public const string DT2_COLUMN_NAME_COMPANY_ADDRESS = "会社住所";
        public const string DT2_COLUMN_NAME_COMPANY_PHONE_NUMBER = "会社連絡先";
        public const string DT2_COLUMN_NAME_COMPANY_COMMENT = "備考";

        public const string DT3_COLUMN_NAME_PROJECT = "案件名";
        public const string DT3_COLUMN_NAME_COMPANY = "会社名";
        public const string DT3_COLUMN_NAME_SALES = "担当営業";
        public const string DT3_COLUMN_NAME_STATION = "最寄駅";
        public const string DT3_COLUMN_NAME_SITE = "支払いサイト";
        public const string DT3_COLUMN_NAME_PRICE_UP = "上位会社への単金";
        public const string DT3_COLUMN_NAME_PRICE_LOW = "下位会社への単金";
    }
}