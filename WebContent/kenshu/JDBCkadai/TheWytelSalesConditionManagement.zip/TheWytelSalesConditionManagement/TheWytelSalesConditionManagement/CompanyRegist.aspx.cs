﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Entity;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Util;

namespace TheWytelSalesConditionManagement
{
    public partial class CompanyRegist : System.Web.UI.Page
    {

        Dao.Mst002_CompanyDao companyDao = new Dao.Mst002_CompanyDao();
        public static string compId = "";
        public static string cmdAction = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }

            //各テキストボックス設定
            SetCompData();
        }

        /// <summary>
        /// 登録ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRegistComp_Click(object sender, EventArgs e)
        {
            //入力内容保存
            Mst002_Company compData = new Mst002_Company();
            int result = 0;

            try
            {
                compData.comp_name = txtCompanyName.Text; //会社名
                compData.comp_address = txtCompAddress.Text; //住所
                compData.comp_phone_number = txtCompPhoneNum.Text; //TEL

                if (Utility.LengthCheck(txtComment.Text, 256))
                {
                    compData.comment = txtComment.Text; //コメント
                }
                else
                {
                    Console.WriteLine(MessageConst.ERR_COMPREGIST);
                    return;
                }

                switch (btnRegistComp.Text)
                {
                    case ModeConst.INSERT:
                        compData.company_id = DateTime.Now.ToString("yyyyMMddHHmmss");//会社ID(現在日時)
                        result = companyDao.RegistCompany(compData, ModeConst.INSERT);
                        break;

                    case ModeConst.UPDATE:
                        compData.company_id = Session["comp_id"].ToString();//会社ID
                        result = companyDao.RegistCompany(compData, ModeConst.UPDATE);
                        break;

                    case ModeConst.DELETE:
                        result = companyDao.DeleteCompany(Session["comp_id"].ToString());
                        break;
                }

                if (result != 0)
                {
                    //会社一覧画面へ遷移
                    Response.Redirect("CompanyList.aspx");
                }
            }
            catch(Exception)
            {
                Console.WriteLine(MessageConst.ERR_COMPREGIST);
            }
        }

        /// <summary>
        /// 各コントロールへデータをセットする
        /// </summary>
        private void SetCompData()
        {
            try
            {
                if (compId != "")
                {
                    switch (cmdAction)
                    {
                        case ModeConst.UPDATE:
                            btnRegistComp.Text = ModeConst.UPDATE;
                            break;
                        case ModeConst.DELETE:
                            txtCompanyName.ReadOnly = true;
                            txtCompAddress.ReadOnly = true;
                            txtCompPhoneNum.ReadOnly = true;
                            txtComment.ReadOnly = true;
                            btnRegistComp.Text = ModeConst.DELETE;
                            break;
                    }
                    //会社IDから取得
                    Mst002_Company compData = companyDao.GetMst002_CompanyById(compId);

                    txtCompanyName.Text = compData.comp_name;
                    txtCompAddress.Text = compData.comp_address;
                    txtCompPhoneNum.Text = compData.comp_phone_number.Replace("-","");
                    txtComment.Text = compData.comment;

                    //ここでセッションに持たせる
                    Session["comp_id"] = compId;
                    compId = "";
                }
                cmdAction = "";
            }
            catch
            {
                Console.WriteLine(MessageConst.ERR_GETCOMPDATA);
            }
        }

        /// <summary>
        /// 会社情報 設定（削除予定）
        /// </summary>
        /// <returns></returns>
        private Mst002_Company SetCompanyParams()
        {
            Mst002_Company newComp = new Mst002_Company();
            newComp.company_id = Session["compId"] == null ? "COMP" + System.Web.Security.Membership.GeneratePassword(5, 0) : Session["comp_id"].ToString();
            newComp.comp_name = txtCompanyName.Text;
            newComp.comp_address = txtCompAddress.Text;
            newComp.comp_phone_number = txtCompPhoneNum.Text;
            newComp.comment = txtComment.Text;
            return newComp;
        }
    }
}