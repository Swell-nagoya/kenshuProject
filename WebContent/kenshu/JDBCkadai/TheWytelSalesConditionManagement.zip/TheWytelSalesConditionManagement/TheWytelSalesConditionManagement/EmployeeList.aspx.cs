﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Dao;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class EmployeeList : System.Web.UI.Page
    {

        private static List<Mst001_Employee> empIdList = new List<Mst001_Employee>();

        /// <summary>
        /// ロード処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }

            DataTable dt = MakeEmpList();

            //画面カラム設定
            SetEmployeeList(dt);

            dgEmp.DataSource = dt;
            dgEmp.DataBind();
        }


        /// <summary>
        /// 従業員情報取得クエリ
        /// </summary>
        /// <returns></returns>
        private DataTable MakeEmpList()
        {
            
            Mst001_EmployeeDao empDao = new Mst001_EmployeeDao();
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = empDao.CreateEmpListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);

                //IDを保持
                empIdList.Clear();
                foreach (DataRow rows in dt.Rows)
                {
                    Mst001_Employee tmp = new Mst001_Employee();
                    tmp.emp_id = rows["EMP_ID"].ToString();
                    empIdList.Add(tmp);
                }
            }
            return dt;
        }

        /// <summary>
        /// テーブル設定
        /// </summary>
        /// <param name="dt"></param>
        private void SetEmployeeList(DataTable dt)
        {
            //カラム設定
            dt.Columns[DbConst.MST001_EMP_NAME_FIRST].ColumnName = MessageConst.DT1_COLUMN_NAME_FIRST;
            dt.Columns[DbConst.MST001_EMP_NAME_LAST].ColumnName = MessageConst.DT1_COLUMN_NAME_LAST;
            dt.Columns[DbConst.MST001_EMP_SEX].ColumnName = MessageConst.DT1_COLUMN_NAME_SEX;
            dt.Columns[DbConst.MST001_EMP_AGE].ColumnName = MessageConst.DT1_COLUMN_NAME_AGE;
            dt.Columns[DbConst.MST001_EMP_COMMENT].ColumnName = MessageConst.DT1_COLUMN_NAME_COMMENT;

            //ID列削除
            dt.Columns.Remove(dt.Columns[DbConst.MST001_EMP_ID]);
        }


        protected void dgEmp_SelectedIndexChanged(object sender, EventArgs e)
        {
            //要員情報詳細画面へ遷移
            //Response.Redirect("EmployeeInsert.aspx?emp_id=" + Mst001_Employee.EmpIdList[dgEmp.SelectedIndex]);
            Response.Redirect("EmployeeInsert.aspx?emp_id=" + empIdList[dgEmp.SelectedIndex].emp_id);
        }


        /// <summary>
        /// 営業状況ボタンクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sales_Clicked(object sender, DataGridCommandEventArgs e)
        {
            Mst003_ProjectDao projDao = new Mst003_ProjectDao();
            SaleConditon.empId = empIdList[e.Item.ItemIndex].emp_id;

            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = projDao.CreateListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);
            }
            if (dt.Rows.Count == 0)
            {
                //0件の場合
                lblAlert.Text = MessageConst.MSG_NOT_FOUND;
                return;
            }

            //営業状況登録画面へ遷移
            Response.Redirect("SalesCondition.aspx");
        }
    }
}