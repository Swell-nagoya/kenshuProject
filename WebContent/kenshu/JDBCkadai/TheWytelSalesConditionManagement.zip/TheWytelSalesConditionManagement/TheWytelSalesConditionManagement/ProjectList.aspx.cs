﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Const;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class ProjectList : System.Web.UI.Page
    {
        Dao.Mst003_ProjectDao projectDao = new Dao.Mst003_ProjectDao();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }

            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = projectDao.CreateListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);

                //カラム設定
                SetProjectListColumn(dt);
            }
            dgProject.DataSource = new DataView(dt);
            DataBind();
        }

        /// <summary>
        /// カラム設定
        /// </summary>
        /// <param name="dt"></param>
        private static void SetProjectListColumn(DataTable dt)
        {
            dt.Columns[DbConst.MST003_PROJECT_NAME].ColumnName = MessageConst.DT3_COLUMN_NAME_PROJECT;
            dt.Columns[DbConst.MST003_PROJECT_COMPANY].ColumnName = MessageConst.DT3_COLUMN_NAME_COMPANY;
            dt.Columns[DbConst.MST003_PROJECT_SALES].ColumnName = MessageConst.DT3_COLUMN_NAME_SALES;
            dt.Columns[DbConst.MST003_PROJECT_STATION].ColumnName = MessageConst.DT3_COLUMN_NAME_STATION;
            dt.Columns[DbConst.MST003_PROJECT_SITE].ColumnName = MessageConst.DT3_COLUMN_NAME_SITE;
            dt.Columns[DbConst.MST003_PROJECT_PRICE_UP].ColumnName = MessageConst.DT3_COLUMN_NAME_PRICE_UP;
            dt.Columns[DbConst.MST003_PROJECT_PRICE_LOW].ColumnName = MessageConst.DT3_COLUMN_NAME_PRICE_LOW;

            //ID列削除
            dt.Columns.Remove(dt.Columns[DbConst.MST003_PROJECT_ID]);
        }
    }
}