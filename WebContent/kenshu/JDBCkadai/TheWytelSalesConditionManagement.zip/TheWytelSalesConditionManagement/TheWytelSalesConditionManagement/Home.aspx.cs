﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using TheWytelSalesConditionManagement.Dao;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class Home : System.Web.UI.Page
    {
        private static List<Mst001_Employee> empIdList;
        private static List<Mst003_Projects> projIdList;

        /// <summary>
        /// ロードイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Trn001_SalesConditionDao salesDao = new Trn001_SalesConditionDao();
            if (IsPostBack)
            {
                return;
            }

            DataTable dt = new DataTable();

            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = salesDao.CreateSalesListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);

                //IDを保持
                empIdList = new List<Mst001_Employee>();
                projIdList = new List<Mst003_Projects>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    empIdList.Add(new Mst001_Employee());
                    projIdList.Add(new Mst003_Projects());
                    empIdList[i].emp_id = dt.Rows[i]["EMP_ID"].ToString();
                    projIdList[i].project_id = dt.Rows[i]["PROJECT_ID"].ToString();
                }

                //表示するカラムの設定
                dispListColums(dt);

            }
            datagrid.DataSource = new DataView(dt);
            datagrid.DataBind();
        }

        /// <summary>
        /// 表示するカラムの設定
        /// </summary>
        /// <param name="dt"></param>
        private void dispListColums(DataTable dt)
        {
            //カラム設定
            dt.Columns["EMP_NAME_LAST"].ColumnName = "苗字";
            dt.Columns["EMP_NAME_FIRST"].ColumnName = "名前";
            dt.Columns["AGE"].ColumnName = "年齢";
            dt.Columns["YEARS_OF_SERVICE"].ColumnName = "勤務年数";
            dt.Columns["MONTH_OF_SERVICE"].ColumnName = "勤務月数";
            dt.Columns["SALES_CHARGE"].ColumnName = "担当営業";
            dt.Columns["ADMISSION_DAY"].ColumnName = "入場日";
            dt.Columns["EXIT_DAY"].ColumnName = "退場日";

            //非表示するカラム設定
            removeListData(dt);
        }

        /// <summary>
        /// 表示させないためにデータを消す
        /// </summary>
        /// <param name="dt"></param>
        private void removeListData(DataTable dt)
        {
            //ID列削除
            dt.Columns.Remove(dt.Columns["EMP_ID"]);
            dt.Columns.Remove(dt.Columns["PROJECT_ID"]);
            dt.Columns.Remove(dt.Columns["SALES_ID"]);
            dt.Columns.Remove(dt.Columns["END_TERM"]);
        }

        /// <summary>
        /// 行選択ボタン押下時イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void datagrid_SelectedIndexChanged(object sender, EventArgs e)
        {
            //対象要員の情報を設定
            Session[DbConst.MST001_EMP_ID] = empIdList[datagrid.SelectedIndex].emp_id;
            Session[DbConst.MST003_PROJECT_ID] = projIdList[datagrid.SelectedIndex].project_id;

            //要員情報詳細画面へ遷移
            Response.Redirect("SalesCondition.aspx");

        }
    }
}
