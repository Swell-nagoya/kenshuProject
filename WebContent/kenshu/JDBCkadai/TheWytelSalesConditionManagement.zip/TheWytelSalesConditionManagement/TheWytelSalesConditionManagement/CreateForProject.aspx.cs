﻿using System;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using TheWytelSalesConditionManagement.Util;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class CreateForProject : System.Web.UI.Page
    {
        Dao.Mst002_CompanyDao companyDao = new Dao.Mst002_CompanyDao();
        Dao.Mst003_ProjectDao projectDao = new Dao.Mst003_ProjectDao();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
        }

        /// <summary>
        /// 案件登録ボタン押下時イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ProjectInsertBtn_Click(object sender, EventArgs e)
        {
            //入力チェック
            if(!Utility.IsNum(txtUpperPrice.Text.ToString()))
            {
                lblUpperPriceAlert.Text = MessageConst.ERR_NOTNUMBER;
                return;
            }
            else if (!Utility.IsNum(txtLowerPrice.Text.ToString()))
            {
                lblLowerPriceAlert.Text = MessageConst.ERR_NOTNUMBER;
                return;
            }

            InsertProjeact();
        }

        /// <summary>
        /// 新規プロジェクト登録
        /// </summary>
        private void InsertProjeact()
        {
            Mst003_Projects project = SetProjectParams();
            string query = projectDao.CreateInsertQuery(project);
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionproperty"]))
            {
                MySqlCommand insertCmd = new MySqlCommand(query, con);
                insertCmd = projectDao.SetDataToProject(project, insertCmd);
                insertCmd.Connection.Open();
                insertCmd.Transaction = insertCmd.Connection.BeginTransaction();
                int effectRecordNumber = insertCmd.ExecuteNonQuery();
                if (effectRecordNumber == 0)
                {
                    insertCmd.Transaction.Rollback();
                    return;
                }
                insertCmd.Transaction.Commit();
                insertCmd.Connection.Close();
            }
        }

        /// <summary>
        /// プロジェクト情報 設定
        /// </summary>
        /// <returns></returns>
        private Mst003_Projects SetProjectParams()
        {
            Mst003_Projects project = new Mst003_Projects();
            project.project_id = DbConst.MST003_USER_NAME_FRONT + DateTime.Now.ToString().Replace("/", "").Replace(" ", "").Replace(":", "");
            project.project_name = txtProjectName.Text.ToString();
            project.company_id = txtProjComp.Text.ToString();
            project.sales_charge = txtSalesMan.Text.ToString();
            project.pay_site = int.Parse(ddlPaySite.SelectedItem.Text.ToString());
            project.settles = DbConst.MST003_SETTLES.Equals(ddlSettle.SelectedItem.Text.ToString()) ? 1 : 2;
            project.near_station = txtNearStation.Text.ToString();
            project.upper_unit_price = int.Parse(txtUpperPrice.Text.ToString());
            project.lower_unit_price = int.Parse(txtLowerPrice.Text.ToString());
            project.last_update_date = DateTime.Now;
            project.last_update_user = DbConst.USER_TEST;
            return project;
        }
    }
}