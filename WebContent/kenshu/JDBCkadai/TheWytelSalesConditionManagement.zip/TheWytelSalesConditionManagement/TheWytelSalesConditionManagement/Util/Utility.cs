﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Util
{
    /// <summary>
    /// どこでも使える用クラス(入力チェックとか)
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// 数値チェック
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static bool IsNum(string text)
        {
            int d;
            return int.TryParse(text, out d) ? true : false;
        }

    }
}