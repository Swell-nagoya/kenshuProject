﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Dao;
using TheWytelSalesConditionManagement.Entity;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace TheWytelSalesConditionManagement
{
    public partial class CompanyList : System.Web.UI.Page
    {
        Mst002_CompanyDao compDao = new Mst002_CompanyDao();
        Mst002_Company compData = new Mst002_Company();

        /// <summary>
        /// ロード処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }

            DataTable dt = CompListToMake();
            //画面カラム設定
            SetCompanyListColumn(dt);
            dgCmp.DataSource = new DataView(dt);
            DataBind();
        }

        /// <summary>
        /// 会社情報取得クエリ
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private DataTable CompListToMake()
        {
            DataTable dt = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = compDao.CreateCompListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);

                //IDを保持
                foreach(DataRow rows in dt.Rows)
                {
                    compData.CompIdList.Add(rows[DbConst.MST002_COMP_ID].ToString());
                }
            }
            return dt;
        }

        /// <summary>
        /// テーブル設定
        /// </summary>
        /// <param name="dt"></param>
        private void SetCompanyListColumn(DataTable dt)
        {
            //表示
            dt.Columns[DbConst.MST002_COMP_NAME].ColumnName = MessageConst.DT2_COLUMN_NAME_COMPANY;
            dt.Columns[DbConst.MST002_COMP_ADDRESS].ColumnName = MessageConst.DT2_COLUMN_NAME_COMPANY_ADDRESS;
            dt.Columns[DbConst.MST002_COMP_PHONE_NUMBER].ColumnName = MessageConst.DT2_COLUMN_NAME_COMPANY_PHONE_NUMBER;
            dt.Columns[DbConst.MST002_COMMENT].ColumnName = MessageConst.DT2_COLUMN_NAME_COMPANY_COMMENT;
            //非表示
            dt.Columns.Remove(dt.Columns[DbConst.MST002_COMP_ID]);
            dt.Columns.Remove(dt.Columns[DbConst.MST002_COMP_DELETE_FLG]);
            dt.Columns.Remove(dt.Columns[DbConst.LASTUPDATE_USER]);
            dt.Columns.Remove(dt.Columns[DbConst.LASTUPDATE_DATE]);
        }

        /// <summary>
        /// 会社情報変更ボタンクリックイベント
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void DgCmp_EditCommand(object source, DataGridCommandEventArgs e)
        {
            DgCmp_EditSQL(e);
            
            //会社登録画面へ遷移
            Response.Redirect("RegisterCompany.aspx?compId=" + compData.CompIdList[e.Item.ItemIndex]);
        }

        /// <summary>
        /// 会社情報変更クエリ作成
        /// </summary>
        /// <param name="e"></param>
        protected void DgCmp_EditSQL(DataGridCommandEventArgs e)
        {
            //クリックした列のIDを取得
            DataTable dt = CompListToMake();
            string compId = compData.CompIdList[e.Item.ItemIndex];
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                string query = compDao.CreateCompListToIdQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.SelectCommand.Parameters.AddWithValue(DbConst.MST002_COMP_ID, compId);
                adapter.Fill(dt);
            }
        }

        /// <summary>
        /// 会社情報削除ボタンクリックイベント
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void DgCmp_DeleteCommand(object source, DataGridCommandEventArgs e)
        {
            DgCmp_DeleteSQL(e);
            //自身呼び出し
            Response.Redirect("CompanyList.aspx");
        }

        /// <summary>
        /// 論理削除クエリ実行
        /// </summary>
        /// <param name="e"></param>
        protected void DgCmp_DeleteSQL(DataGridCommandEventArgs e)
        {
            DataTable dt = CompListToMake();

            Mst002_Company companyParams = SetCompanyParams(dt, e);
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            {
                string query = compDao.CompBuildFlg();
                MySqlCommand dgCmdDelete = new MySqlCommand(query, con);
                dgCmdDelete = compDao.SetDataToBindQuery(companyParams, dgCmdDelete);
                dgCmdDelete.Connection.Open();
                dgCmdDelete.Transaction = dgCmdDelete.Connection.BeginTransaction();
                int effectRecoedNumber = dgCmdDelete.ExecuteNonQuery();
                if (effectRecoedNumber == 0)
                {
                    dgCmdDelete.Transaction.Rollback();
                    return;
                }
                dgCmdDelete.Transaction.Commit();
                dgCmdDelete.Connection.Close();
            }
        }

        /// <summary>
        /// 会社情報を取得
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private Mst002_Company SetCompanyParams(DataTable dt, DataGridCommandEventArgs e)
        {
            Mst002_Company comp = new Mst002_Company();
            comp.company_id = dt.Rows[e.Item.ItemIndex][DbConst.MST002_COMP_ID].ToString();
            comp.comp_name = dt.Rows[e.Item.ItemIndex][DbConst.MST002_COMP_NAME].ToString();
            comp.comp_address = dt.Rows[e.Item.ItemIndex][DbConst.MST002_COMP_ADDRESS].ToString();
            comp.comp_phone_number = dt.Rows[e.Item.ItemIndex][DbConst.MST002_COMP_PHONE_NUMBER].ToString();
            comp.comp_comment = dt.Rows[e.Item.ItemIndex][DbConst.MST002_COMMENT].ToString();
            
            return comp;
        }
    }
}