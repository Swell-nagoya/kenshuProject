﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Entity
{
    public class Mst001_Employee
    {
        public string emp_id { get; set; }
        public string company_id { get; set; }
        public string emp_name_last { get; set; }
        public string emp_name_first { get; set; }
        public string sex { get; set; }
        public int age { get; set; }
        public string comment { get; set; }
        public string last_update_user { get; set; }
        public DateTime last_update_date { get; set; }
    }
}