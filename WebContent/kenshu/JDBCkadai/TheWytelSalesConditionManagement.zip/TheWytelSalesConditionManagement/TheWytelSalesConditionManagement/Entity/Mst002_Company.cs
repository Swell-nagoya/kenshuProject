﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Entity
{
    public class Mst002_Company
    {
        public string company_id { get; set; }
        public string comp_name { get; set; }
        public string comp_address { get; set; }
        public string comp_phone_number { get; set; }
        public string comment { get; set; }
        public string last_update_user { get; set; }
        public DateTime last_update_date { get; set; }
    }
}