﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Entity
{
    public class Trn001_SalesCondition
    {
        public string sales_id { get; set; }
        public string employee_id { get; set; }
        public int status_id { get; set; }
        public DateTime? end_term { get; set; }
        public string years_of_service { get; set; }
        public string month_of_service { get; set; }
        public int parallel_flg { get; set; }
        public string project_id { get; set; }
        public string near_station { get; set; }
        public DateTime workst_date { get; set; }
        public DateTime worked_date { get; set; }
        public string admission_day { get; set; }
        public string exit_day { get; set; }
        public string last_update_user { get; set; }
        public DateTime last_update_date { get; set; }
    }
}