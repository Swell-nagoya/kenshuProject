﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheWytelSalesConditionManagement.Entity
{
    public class Mst003_Projects
    {
        public string project_id { get; set; }
        public string project_name { get; set; }
        public string company_id { get; set; }
        public string sales_charge { get; set; }
        public string emp_id { get; set; }
        public int pay_site { get; set; }
        public int upper_unit_price { get; set; }
        public int lower_unit_price { get; set; }
        public int upper_high_limit { get; set; }
        public int upper_low_limit { get; set; }
        public int lower_high_limit { get; set; }
        public int lower_low_limit { get; set; }
        public int settles { get; set; }
        public string near_station { get; set; }
        public string admission_day { get; set; }
        public string exit_day { get; set; }
        public string last_update_user { get; set; }
        public DateTime last_update_date { get; set; }
    }
}