﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using TheWytelSalesConditionManagement.Util;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement
{
    public partial class RegisterCompany : System.Web.UI.Page
    {
        Dao.Mst002_CompanyDao compDao = new Dao.Mst002_CompanyDao();
        
        //CompanyListで取得する会社ID
        private static string compId = String.Empty;

        /// <summary>
        /// ロード処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }
            //ID値の取得
            if (Request.QueryString.Count != 0)
            {
                compId = Request.QueryString.Get(DbConst.MST002_GET_COMP_ID);
            }
            
            DispCompList(compId);
        }

        /// <summary>
        /// 会社情報の表示
        /// </summary>
        protected void DispCompList(string compId)
        {
            Entity.Mst002_Company comp = new Mst002_Company();
            if(String.IsNullOrEmpty(compId))
            {
                comp = compDao.GetMst002_Company();
            }
            else if (String.IsNullOrEmpty(compId) == false)
            {//会社情報があれば表示
                comp = compDao.GetMst002_Company(compId);
                txtCompanyName.Text = comp.comp_name;
                txtCompanyAddress.Text = comp.comp_address;
                txtPhoneNumber.Text = comp.comp_phone_number;
                txtComment.Text = comp.comp_comment;
            }
        }

        /// <summary>
        /// 登録ボタン押下時イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CompInsertBtn_Click(object sender, EventArgs e)
        {
            if (CheckInputItems() == false)
            {
                return;
            }
            
            //登録or更新
            string query = String.Empty;
            if (String.IsNullOrEmpty(compId.ToString()) == false)
            {
                query = compDao.CompInsertQuery();
            }

            query = compDao.CompUpdateQuery();

            //クエリの実行
            AddCompanyData(query);

            //メッセージの表示
            lblcompInsert.Text = MessageConst.MSG_FININSERT;
            
            //ID情報の消去
            compId = String.Empty;

            //画面遷移
            Response.Redirect("CompanyList.aspx");
        }

        /// <summary>
        /// 新規会社or情報追加登録
        /// </summary>
        /// <param name="companyParam"></param>
        protected void AddCompanyData(string query)
        {
            Mst002_Company companyParam = new Mst002_Company();
            //パラメータ設定
            companyParam = SetCompanyParams(compId);
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                MySqlCommand command = new MySqlCommand(query, con);
                command = compDao.SetDataToBindQuery(companyParam, command);
                command.Connection.Open();
                command.Transaction = command.Connection.BeginTransaction();
                int effectRecordNumber = command.ExecuteNonQuery();
                if (effectRecordNumber == 0)
                {
                    command.Transaction.Rollback();
                    command.Connection.Close();
                    return;
                }
                command.Transaction.Commit();
                command.Connection.Close();
            }
        }

        /// <summary>
        /// ラベルテキストセット
        /// </summary>
        /// <returns></returns>
        private bool CheckInputItems()
        {
            int boxIndex = 0;
            //入力チェック
            if (String.IsNullOrEmpty(txtCompanyName.Text.ToString()))
            {
                lblCompanyNameAlert.Text = TxtBoxIsNullEnpty(boxIndex);
                
            }
            if (String.IsNullOrEmpty(txtCompanyAddress.Text.ToString()))
            {
                boxIndex = 1;
                lblCompanyAddressAlert.Text = TxtBoxIsNullEnpty(boxIndex);
                
            }
            if ((Utility.IsNum(txtPhoneNumber.Text.ToString())) == false)
            {
                boxIndex = 2;
                lblPhoneNumberAlert.Text = TxtBoxIsNullEnpty(boxIndex);
                return false;
            }
            return true;
        }

        /// <summary>
        /// 企業情報追加Bean登録
        /// </summary>
        /// <param name="compId"></param>
        /// <returns></returns>
        private Mst002_Company SetCompanyParams(string compId)
        {
            Mst002_Company comp = new Mst002_Company();
            if (String.IsNullOrEmpty(compId) == false)
            {
                comp.company_id = compId;                
            }
            comp.company_id = DateTime.Now.ToString().Replace("/", "").Replace(" ", "").Replace(":", "");
            comp.comp_flg_delete = 0;
            comp.comp_name = txtCompanyName.Text.ToString();
            comp.comp_address = txtCompanyAddress.Text.ToString();
            comp.comp_phone_number = txtPhoneNumber.Text.ToString();
            comp.comp_comment = txtComment.Text.ToString();
            comp.last_update_user = DbConst.USER_TEST;
            comp.last_update_date = DateTime.Now;
            
            return comp;
        }

        /// <summary>
        /// 会社名入力判定
        /// </summary>
        /// <returns></returns>
        private string TxtBoxIsNullEnpty(int number)
        {
            Dictionary<int, string> dictionary = new Dictionary<int, string>();
            dictionary.Add(0, MessageConst.ERR_NOTCOMPANY);
            dictionary.Add(1, MessageConst.ERR_NOTADDRESS);
            dictionary.Add(2, MessageConst.ERR_NOTNUMBER);

            return dictionary[number];
        }
    }
}