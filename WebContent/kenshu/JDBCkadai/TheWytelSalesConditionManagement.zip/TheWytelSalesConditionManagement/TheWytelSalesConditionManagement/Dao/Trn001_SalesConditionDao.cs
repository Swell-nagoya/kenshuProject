﻿using System;
using System.Data;
using System.Text;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Entity;
using TheWytelSalesConditionManagement.Const;
using MySql.Data.MySqlClient;
using System.Configuration;


namespace TheWytelSalesConditionManagement.Dao
{
    public class Trn001_SalesConditionDao
    {
        
        /// <summary>
        /// 要員情報の取得
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public Trn001_SalesCondition GetSalesListData(string empId, string projectId)
        {
            DataTable dataTable = new DataTable();
            using (MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query  = String.Empty;
                if((String.IsNullOrEmpty(empId.ToString()) == false
                    && String.IsNullOrEmpty(projectId.ToString())) == false)
                {
                    query = CreateSalesListByIdQuery(empId, projectId);
                }
                else
                {
                    query = CreateSalesListQuery();
                }

                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dataTable);
            }

            Trn001_SalesCondition sales = SetTrn001_Sales(dataTable);
            return sales;
        }

        /// <summary>
        /// データをセットする
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        private Trn001_SalesCondition SetTrn001_Sales(DataTable dataTable)
        {
            Trn001_SalesCondition sales = new Trn001_SalesCondition();
            if (dataTable.Rows.Count != 0)
            {
                DataRow salesData = dataTable.Rows[0];
                sales.sales_id = salesData.Field<string>(DbConst.TRN001_SALES_ID).ToString();
                sales.employee_id = salesData.Field<string>(DbConst.MST001_EMP_ID).ToString();
                
                //キャストエラー検出
                try
                {
                    sales.status_id = salesData.Field<int>(DbConst.TRN001_SALES_STATUS_CD);
                    sales.end_term = salesData.Field<DateTime>(DbConst.TRN001_SALES_END_TERM);
                    sales.parallel_flg = salesData.Field<int>(DbConst.TRN001_SALES_PARALLEL_FLG);
                    sales.workst_date = salesData.Field<DateTime>(DbConst.TRN001_SALES_WORKED_DATE);
                    sales.workst_date = salesData.Field<DateTime>(DbConst.TRN001_SALES_WORKST_DATE);
                    sales.last_update_date = salesData.Field<DateTime>(DbConst.LASTUPDATE_DATE);
                }
                catch
                {
                    throw new Exception();
                }

                sales.years_of_service = salesData.Field<string>(DbConst.TRN001_SALES_YEAR).ToString();
                sales.month_of_service = salesData.Field<string>(DbConst.TRN001_SALES_MONTH).ToString();
                sales.project_id = salesData.Field<string>(DbConst.MST003_PROJECT_ID).ToString();
                sales.admission_day = salesData.Field<string>(DbConst.TRN001_SALES_ADMISSION_DAY).ToString();
                sales.exit_day = salesData.Field<string>(DbConst.TRN001_SALES_EXIT).ToString();
                
                //NULLを取得した場合はテストケースを設定する
                if (String.IsNullOrEmpty(salesData.Field<string>(DbConst.LASTUPDATE_USER)) == false)
                {
                    sales.last_update_user = salesData.Field<string>(DbConst.LASTUPDATE_USER).ToString();
                }
                else
                {
                    sales.last_update_user = DbConst.USER_TEST;
                }
            }
            return sales;
        }

        public string CreateInsertSalesQuery(Trn001_SalesCondition sales)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO");
            sb.Append(" TRN001_SALES_CONDITION(");
            sb.Append(" SALES_ID");
            sb.Append(",EMPLOYEE_ID");
            sb.Append(",STATUS_CD");
            sb.Append(",END_TERM");
            sb.Append(",YEARS_OF_SERVICE");
            sb.Append(",MONTH_OF_SERVICE");
            sb.Append(",PARALLEL_FLG");
            sb.Append(",PROJECT_ID");
            sb.Append(",NEAR_STATION");
            sb.Append(",WORKST_DATE");
            sb.Append(",WORKED_DATE");
            sb.Append(",ADMISSION_DAY");
            sb.Append(",EXIT_DAY");
            sb.Append(",LASTUPDATE_USER");
            sb.Append(",LASTUPDATE_DATE");
            sb.Append(")VALUES(");
            sb.Append("  @sales_id");
            sb.Append(", @employee_id");
            sb.Append(", @status_id");
            sb.Append(", @end_term");
            sb.Append(", @years_of_service");
            sb.Append(", @month_of_service");
            sb.Append(", @parallel_flg");
            sb.Append(", @project_id");
            sb.Append(", @near_station");
            sb.Append(", @workst_date");
            sb.Append(", @worked_date");
            sb.Append(", @admission_day");
            sb.Append(", @exit_day");
            sb.Append(", @last_update_user");
            sb.Append(", @lastupdateDate");
            sb.Append(")");
            return sb.ToString();
        }

        /// <summary>
        /// 営業状況一覧取得クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateSalesListQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT");
            sb.Append(" C.PROJECT_ID");
            sb.Append(" ,C.SALES_CHARGE");
            sb.Append(" ,B.EMP_ID");
            sb.Append(" ,B.EMP_NAME_LAST");
            sb.Append(" ,B.EMP_NAME_FIRST");
            //sb.Append(" ,B.SEX");
            sb.Append(" ,B.AGE");
            sb.Append(" ,A.SALES_ID");
            sb.Append(" ,A.YEARS_OF_SERVICE");
            sb.Append(" ,A.MONTH_OF_SERVICE");
            sb.Append(" ,A.END_TERM ");
            sb.Append(" ,A.ADMISSION_DAY ");
            sb.Append(" ,A.EXIT_DAY ");
            sb.Append("FROM");
            sb.Append(" TRN001_SALES_CONDITION as A ");
            sb.Append("INNER JOIN");
            sb.Append(" MST001_EMPLOYEE as B ");
            sb.Append("ON");
            sb.Append(" B.EMP_ID = A.EMPLOYEE_ID ");
            sb.Append("INNER JOIN");
            sb.Append(" MST003_PROJECT as C ");
            sb.Append("ON");
            sb.Append(" C.PROJECT_ID = A.PROJECT_ID");
            return sb.ToString();
        }

        /// <summary>
        /// 営業状況一覧取得クエリ作成(案件ID・要員ID指定)
        /// </summary>
        /// <returns></returns>
        public string CreateSalesListByIdQuery(string emp_id ,string project_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(CreateSalesListQuery());
            sb.Append(" WHERE");
            sb.Append("  B.EMP_ID = @employee_id");
            sb.Append(" AND");
            sb.Append("  C.PROJECT_ID = @project_id");
            return sb.ToString();
        }

        /// <summary>
        /// 営業状況一覧取得クエリ作成(営業ID指定)
        /// </summary>
        /// <returns></returns>
        public string CreateSalesListBySaleIdQuery(string sales_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(CreateSalesListQuery());
            sb.Append(" WHERE");
            sb.Append("  A.SALES_ID = @sales_id");
            return sb.ToString();
        }

        /// <summary>
        /// 営業状況削除クエリ作成
        /// </summary>
        /// <param name="salesId"></param>
        /// <returns></returns>
        public string CreateDeleteQuery(string salesId)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DELETE FROM ");
            sb.Append(" TRN001_SALES_CONDITION ");
            sb.Append("WHERE");
            sb.Append(" SALES_ID = @sales_id");
            return sb.ToString();

        }

        /// <summary>
        /// クエリ(SALES)のデータを設定する
        /// </summary>
        /// <param name="sales"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public MySqlCommand SetDataToBindQuery(Trn001_SalesCondition sales, MySqlCommand command)
        {
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_ID, sales.sales_id);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_EMPLOYEE_ID, sales.employee_id);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_STATUS_CD, sales.status_id);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_END_TERM, sales.end_term);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_YEAR, sales.years_of_service);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_MONTH, sales.month_of_service);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_PARALLEL_FLG, sales.parallel_flg);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_ID, sales.project_id);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_NEAR_STATION, sales.near_station);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_WORKST_DATE, sales.workst_date);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_WORKED_DATE, sales.worked_date);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_ADMISSION_DAY, sales.admission_day);
            command.Parameters.AddWithValue(DbConst.TRN001_SALES_EXIT, sales.exit_day);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_USER, sales.last_update_user);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_DATE, sales.last_update_date);

            return command;
        }
    }
}