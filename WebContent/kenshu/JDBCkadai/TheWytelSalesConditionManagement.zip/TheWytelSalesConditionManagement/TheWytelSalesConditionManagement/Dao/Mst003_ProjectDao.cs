﻿using System;
using System.Data;
using System.Text;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement.Dao
{
    public class Mst003_ProjectDao
    {
        MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]);

        /// <summary>
        /// プロジェクト情報の取得
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public Mst003_Projects GetMst003_ProjectId(string projectId)
        {
            DataTable dt = new DataTable();
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = SearchToId();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.SelectCommand.Parameters.AddWithValue(DbConst.MST003_PROJECT_ID, projectId);
                adapter.Fill(dt);
            }

            Mst003_Projects pro = SetMst003_Project(dt);
            return pro;
        }

        /// <summary>
        /// 各種データのセット
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        private Mst003_Projects SetMst003_Project(DataTable dataTable)
        {
            Mst003_Projects proj = new Mst003_Projects();
            if (dataTable.Rows.Count != 0)
            {
                DataRow proData = dataTable.Rows[0];
                proj.project_id = proData[0].ToString();
                proj.project_name = proData[1].ToString();
                proj.company_id = proData[2].ToString();
                proj.sales_charge = proData[3].ToString();
                try
                {
                    proj.pay_site = Convert.ToInt32(proData[4]);
                    proj.upper_unit_price = Convert.ToInt32(proData[5]);
                    proj.lower_unit_price = Convert.ToInt32(proData[6]);
                    proj.upper_high_limit = Convert.ToInt32(proData[7]);
                    proj.upper_low_limit = Convert.ToInt32(proData[8]);
                    proj.lower_high_limit = Convert.ToInt32(proData[9]);
                    proj.lower_low_limit = Convert.ToInt32(proData[10]);
                    proj.settles = Convert.ToInt32(proData[11]);
                    proj.last_update_date = Convert.ToDateTime(proData[14].ToString());
                }
                catch
                {
                    throw new Exception();
                }
                proj.near_station = proData[12].ToString();
                proj.last_update_user = proData[13].ToString();
                
            }
            
            return proj;
        }

        /// <summary>
        /// IDで情報を検索するクエリ作成
        /// </summary>
        /// <returns></returns>
        public string SearchToId(){
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT * ");
            sb.Append("FROM ");
            sb.Append("MST003_PROJECT ");
            sb.Append("WHERE ");
            sb.Append("PROJECT_ID = @project_id");
            return sb.ToString();
        }

        /// <summary>
        /// 案件一覧情報取得クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateListQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT ");
            sb.Append("  PROJECT_ID");
            sb.Append(" ,PROJECT_NAME");
            sb.Append(" ,COMPANY_ID");
            sb.Append(" ,SALES_CHARGE");
            sb.Append(" ,NEAR_STATION ");
            sb.Append(" ,PAY_SITE ");
            sb.Append(" ,UPPER_UNIT_PRICE ");
            sb.Append(" ,LOWER_UNIT_PRICE ");
            sb.Append("FROM ");
            sb.Append(" MST003_PROJECT");

            return sb.ToString();
        }

        /// <summary>
        /// 案件一覧情報取得クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateListQueryByProjectName()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT ");
            sb.Append("PROJECT_ID");
            sb.Append(" ,PROJECT_NAME");
            sb.Append(" ,COMPANY_ID");
            sb.Append(" ,SALES_CHARGE");
            sb.Append(" ,NEAR_STATION");
            sb.Append(" ,PAY_SITE");
            sb.Append(" ,UPPER_UNIT_PRICE");
            sb.Append(" ,LOWER_UNIT_PRICE ");
            sb.Append("FROM");
            sb.Append(" MST003_PROJECT ");
            sb.Append("WHERE");
            sb.Append(" PROJECT_NAME = @project_name");
            return sb.ToString();
        }

        /// <summary>
        /// 案件マスタ登録クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateInsertQuery(Mst003_Projects project)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO");
            sb.Append(" MST003_PROJECT(");
            sb.Append(" PROJECT_ID");
            sb.Append(",PROJECT_NAME");
            sb.Append(",COMPANY_ID");
            sb.Append(",SALES_CHARGE");
            sb.Append(",PAY_SITE");
            sb.Append(",NEAR_STATION");
            sb.Append(",UPPER_UNIT_PRICE");
            sb.Append(",LOWER_UNIT_PRICE");
            sb.Append(",UPPER_HIGH_LIMIT");
            sb.Append(",UPPER_LOW_LIMIT");
            sb.Append(",LOWER_HIGH_LIMIT");
            sb.Append(",LOWER_LOW_LIMIT");
            sb.Append(",SETTLES");
            sb.Append(",LASTUPDATE_USER");
            sb.Append(",LASTUPDATE_DATE");
            sb.Append(")VALUES(");
            sb.Append("  @project_id");
            sb.Append(", @project_name");
            sb.Append(", @company_id");
            sb.Append(", @sales_charge");
            sb.Append(", @pay_site");
            sb.Append(", @near_station");
            sb.Append(", @upper_unit_price");
            sb.Append(", @lower_unit_price");
            sb.Append(", @upper_high_limit");
            sb.Append(", @upper_low_limit");
            sb.Append(", @lower_high_limit");
            sb.Append(", @lower_low_limit");
            sb.Append(", @settles");
            sb.Append(", @last_update_user");
            sb.Append(", @lastupdateDate");
            sb.Append(")");
            return sb.ToString();
        }

        /// <summary>
        /// 案件マスタ登録クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateUpdateQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE ");
            sb.Append(" MST003_PROJECT ");
            sb.Append("SET ");
            sb.Append(" PROJECT_NAME = @project_name ");
            //sb.Append(",COMPANY_ID = @company_id ");
            //sb.Append(",SALES_CHARGE = @sales_charge ");
            //sb.Append(",PAY_SITE = @pay_site ");
            //sb.Append(",NEAR_STATION = @near_station ");
            //sb.Append(",UPPER_UNIT_PRICE = @upper_unit_price ");
            //sb.Append(",LOWER_UNIT_PRICE = @lower_unit_price ");
            //sb.Append(",UPPER_HIGH_LIMIT = @upper_high_limit ");
            //sb.Append(",UPPER_LOW_LIMIT = @upper_low_limit ");
            //sb.Append(",LOWER_HIGH_LIMIT = @lower_high_limit ");
            //sb.Append(",LOWER_LOW_LIMIT = @lower_low_limit ");
            //sb.Append(",SETTLES = @settles ");
            //sb.Append(",LASTUPDATE_USER = @last_update_user ");
            //sb.Append(",LASTUPDATE_DATE = @lastupdateDate ");
            sb.Append("WHERE");
            sb.Append(" PROJECT_ID = @project_id ");     
            return sb.ToString();
        }

        /// <summary>
        /// 案件削除クエリ作成
        /// </summary>
        /// <param name="salesId"></param>
        /// <returns></returns>
        public string CreateDeleteQuery(string projectId)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DELETE FROM ");
            sb.Append(" MST003_PROJECT ");
            sb.Append("WHERE");
            sb.Append(" PROJECT_ID = @project_id");
            return sb.ToString();

        }

        /// <summary>
        /// クエリにデータをセット
        /// </summary>
        /// <param name="project"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public MySqlCommand SetDataToProject(Mst003_Projects project, MySqlCommand command)
        {
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_ID, project.project_id);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_NAME, project.project_name);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_COMPANY, project.company_id);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_SALES, project.sales_charge);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_SITE, project.pay_site);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_PRICE_UP, project.upper_unit_price);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_PRICE_LOW, project.lower_unit_price);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_UPPER_TIME_HIGH, project.upper_high_limit);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_UPPER_TIME_LOW, project.upper_low_limit);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_LOWER_TIME_HIGH, project.lower_high_limit);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_SETTLES, project.settles);
            command.Parameters.AddWithValue(DbConst.MST003_PROJECT_STATION, project.near_station);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_USER, project.last_update_user);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_DATE, DateTime.Now);

            return command;
        }
 
    }
}