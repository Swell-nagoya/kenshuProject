﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement.Dao
{
    public class Mst002_CompanyDao
    {
        /// <summary>
        /// 会社情報取得
        /// </summary>
        /// <returns></returns>
        public Mst002_Company GetMst002_Company()
        {
            MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]);
            DataTable dt = new DataTable();
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = CreateCompListQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.Fill(dt);
            }

            //各種データセット
            Mst002_Company comp = SetMst002_Company(dt);
            return comp;
        }

        /// <summary>
        /// 会社IDから情報を取得
        /// </summary>
        /// <param name="compId"></param>
        /// <returns></returns>
        public Mst002_Company GetMst002_Company(string compId)
        {
            MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]);
            DataTable dt = new DataTable();
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = CreateCompListToIdQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.SelectCommand.Parameters.AddWithValue(DbConst.MST002_COMP_ID, compId);
                adapter.Fill(dt);
            }
            Mst002_Company comp = SetMst002_Company(dt);
            return comp;
        }

        /// <summary>
        /// 各種データのセット
        /// </summary>
        /// <param name="datatable"></param>
        /// <returns></returns>
        private Mst002_Company SetMst002_Company(DataTable datatable)
        {
            Mst002_Company comp = new Mst002_Company();
            if (datatable.Rows.Count == 0)
            {
                return comp;
            }

            //TODO: NULL チェック保留中(金)
            DataRow companyData = datatable.Rows[0];
            comp.company_id = companyData.Field<string>(DbConst.MST002_COMP_ID).ToString();
            comp.comp_name = companyData.Field<string>(DbConst.MST002_COMP_NAME).ToString();
            comp.comp_address = companyData.Field<string>(DbConst.MST002_COMP_ADDRESS).ToString();
            comp.comp_phone_number = companyData.Field<string>(DbConst.MST002_COMP_PHONE_NUMBER).ToString();
            comp.comp_comment = companyData.Field<string>(DbConst.MST002_COMMENT).ToString();
            try
            {
                comp.comp_flg_delete = companyData.Field<int>(DbConst.MST002_COMP_DELETE_FLG);
                comp.last_update_date = companyData.Field<DateTime>(DbConst.LASTUPDATE_DATE);
            }
            catch
            {
                throw new Exception();
            }
            if (String.IsNullOrEmpty(companyData.Field<string>(DbConst.LASTUPDATE_USER)) == false)
            {
                comp.last_update_user = companyData.Field<string>(DbConst.LASTUPDATE_USER).ToString();
            }
            else
            {
                comp.last_update_user = DbConst.USER_TEST;
            }
            return comp;
        }

        /// <summary>
        /// 会社情報取得クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateCompListQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT ");
            sb.Append(" COMPANY_ID");
            sb.Append(" ,COMP_NAME");
            sb.Append(" ,COMP_ADDRESS");
            sb.Append(" ,COMP_PHONE_NUMBER");
            sb.Append(" ,COMMENT");
            sb.Append(" ,FLG_DELETE ");
            sb.Append(" ,LASTUPDATE_USER");
            sb.Append(" ,LASTUPDATE_DATE ");
            sb.Append("FROM");
            sb.Append(" MST002_COMPANY ");
            sb.Append("WHERE");
            sb.Append(" FLG_DELETE = '0'");
            return sb.ToString();
        }

        /// <summary>
        /// 情報変更用
        /// 会社情報取得クエリ作成
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        public string CreateCompListToIdQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT ");
            sb.Append(" COMPANY_ID");
            sb.Append(" ,COMP_NAME");
            sb.Append(" ,COMP_ADDRESS");
            sb.Append(" ,COMP_PHONE_NUMBER");
            sb.Append(" ,COMMENT");
            sb.Append(" ,FLG_DELETE ");
            sb.Append(" ,LASTUPDATE_USER");
            sb.Append(" ,LASTUPDATE_DATE ");
            sb.Append("FROM ");
            sb.Append(" MST002_COMPANY ");
            sb.Append("WHERE");
            sb.Append(" COMPANY_ID = @company_id ");
            return sb.ToString();
        }

        /// <summary>
        /// 会社一覧情報登録クエリ作成
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        public string CompInsertQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO");
            sb.Append(" MST002_COMPANY(");
            sb.Append(" COMPANY_ID");
            sb.Append(" ,COMP_NAME");
            sb.Append(" ,COMP_ADDRESS");
            sb.Append(" ,COMP_PHONE_NUMBER");
            sb.Append(" ,COMMENT");
            sb.Append(" ,FLG_DELETE");
            sb.Append(" ,LASTUPDATE_USER");
            sb.Append(" ,LASTUPDATE_DATE");
            sb.Append(")VALUES(");
            sb.Append("  @company_id");
            sb.Append(", @comp_name ");
            sb.Append(", @comp_address ");
            sb.Append(", @comp_phone_number ");
            sb.Append(", @comment ");
            sb.Append(", @flg_delete ");
            sb.Append(", @lastUpdate_User");
            sb.Append(", @lastUpdate_Date");
            sb.Append(")");
            return sb.ToString();
        }
        
        /// <summary>
        /// 削除フラグ設定クエリ作成
        /// </summary>
        /// <param name="companyId"></param>
        /// <returns></returns>
        public string CompBuildFlg()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE");
            sb.Append(" MST002_COMPANY ");
            sb.Append("SET");
            sb.Append(" FLG_DELETE = 1 ");
            sb.Append("WHERE");
            sb.Append(" COMPANY_ID = @company_id ");
            return sb.ToString();
        }

        /// <summary>
        /// 会社更新クエリ作成
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        public string CompUpdateQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("UPDATE");
            sb.Append(" MST002_COMPANY ");
            sb.Append("SET");
            sb.Append(" COMP_NAME = @comp_name ");
            sb.Append(" ,COMP_ADDRESS = @comp_address ");
            sb.Append(" ,COMP_PHONE_NUMBER = @comp_phone_number ");
            sb.Append(" ,COMMENT = @comment ");
            sb.Append(" ,FLG_DELETE = @flg_delete ");
            sb.Append(" ,LASTUPDATE_USER = @lastUpdate_User");
            sb.Append(" ,LASTUPDATE_DATE = @lastUpdate_Date ");
            sb.Append("WHERE");
            sb.Append(" COMPANY_ID = @company_id ");
            return sb.ToString();
        }

        /// <summary>
        /// クエリのデータを設定する
        /// </summary>
        /// <param name="company"></param>
        /// <param name="command"></param>
        public MySqlCommand SetDataToBindQuery(Mst002_Company company, MySqlCommand command)
        {
            command.Parameters.AddWithValue(DbConst.MST002_COMP_ID, company.company_id);
            command.Parameters.AddWithValue(DbConst.MST002_COMP_NAME,company.comp_name);
            command.Parameters.AddWithValue(DbConst.MST002_COMP_ADDRESS, company.comp_address);
            command.Parameters.AddWithValue(DbConst.MST002_COMP_PHONE_NUMBER, company.comp_phone_number);
            command.Parameters.AddWithValue(DbConst.MST002_COMMENT, company.comp_comment);
            command.Parameters.AddWithValue(DbConst.MST002_COMP_DELETE_FLG,company.comp_flg_delete);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_USER, company.last_update_user);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_DATE, DateTime.Now);
            return command;
        }
    }
}