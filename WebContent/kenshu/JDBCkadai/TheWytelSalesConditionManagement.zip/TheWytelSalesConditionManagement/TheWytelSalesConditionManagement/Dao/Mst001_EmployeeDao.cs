﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TheWytelSalesConditionManagement.Const;
using TheWytelSalesConditionManagement.Entity;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace TheWytelSalesConditionManagement.Dao
{
    public class Mst001_EmployeeDao
    {
        

        /// <summary>
        /// 従業員情報取得(ID指定)
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        public Mst001_Employee GetMst001_EmployeeById(string empId)
        {
            DataTable dt = new DataTable();
            MySqlConnection con = new MySqlConnection(ConfigurationManager.AppSettings["connectionProperty"]);
            using (MySqlDataAdapter adapter = new MySqlDataAdapter())
            {
                con.Open();
                string query = CreateGetEmpByIdQuery();
                adapter.SelectCommand = new MySqlCommand(query, con);
                adapter.SelectCommand.Parameters.AddWithValue(DbConst.MST001_EMP_ID, empId);
                adapter.Fill(dt);
            }

            Mst001_Employee emp = SetMst001_Employee(dt);
            
            return emp;
        }

        /// <summary>
        /// 各種データのセット
        /// </summary>
        /// <param name="datatable"></param>
        /// <returns></returns>
        private Mst001_Employee SetMst001_Employee(DataTable datatable)
        {
            Mst001_Employee emp = new Mst001_Employee();
            if (datatable.Rows.Count != 0)
            {
                DataRow empData = datatable.Rows[0];
                emp.emp_id = empData.Field<string>(DbConst.MST001_EMP_ID).ToString();
                emp.company_id = empData.Field<string>(DbConst.MST002_COMP_ID);
                emp.emp_name_last = empData.Field<string>(DbConst.MST001_EMP_NAME_LAST).ToString();
                emp.emp_name_first = empData.Field<string>(DbConst.MST001_EMP_NAME_FIRST).ToString();
                emp.sex = empData.Field<string>(DbConst.MST001_EMP_SEX).ToString();
                emp.comment = empData.Field<string>(DbConst.MST001_EMP_COMMENT).ToString();
                try
                {
                    emp.age = int.Parse(empData[5].ToString());
                    emp.last_update_date = new DateTime();
                }
                catch
                {
                    throw new Exception();
                }
                if (String.IsNullOrEmpty(empData.Field<String>(DbConst.LASTUPDATE_USER)) == false)
                {
                    emp.last_update_user = empData.Field<String>(DbConst.LASTUPDATE_USER).ToString();
                }
                else
                {
                    emp.last_update_user = DbConst.USER_TEST;
                }
            }
            return emp;
        }


        /// <summary>
        /// 従業員情報取得クエリ作成
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        public string CreateGetEmpByIdQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT");
            sb.Append(" * ");
            sb.Append("FROM");
            sb.Append(" MST001_EMPLOYEE ");
            sb.Append("WHERE");
            sb.Append(" EMP_ID = @emp_id");
            return sb.ToString();
        }

        /// <summary>
        /// 従業員マスタ登録クエリ作成
        /// </summary>
        /// <returns></returns>
        public string CreateInsertQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO");
            sb.Append(" MST001_EMPLOYEE(");
            sb.Append(" EMP_ID");
            sb.Append(",COMPANY_ID");
            sb.Append(",EMP_NAME_LAST");
            sb.Append(",EMP_NAME_FIRST");
            sb.Append(",SEX");
            sb.Append(",AGE");
            sb.Append(",COMMENT");
            sb.Append(",LASTUPDATE_USER");
            sb.Append(",LASTUPDATE_DATE");
            sb.Append(")VALUES(");
            sb.Append(" @emp_id");
            sb.Append(",@company_id");
            sb.Append(",@emp_name_last");
            sb.Append(",@emp_name_first");
            sb.Append(",@sex");
            sb.Append(",@age");
            sb.Append(",@comment");
            sb.Append(",@lastupdate_User");
            sb.Append(",@lastupdate_Date");
            sb.Append(")");
            return sb.ToString();
        }

        public string CreateEmpListQuery()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT");
            sb.Append(" EMP_ID");
            sb.Append(" ,EMP_NAME_LAST");
            sb.Append(" ,EMP_NAME_FIRST");
            sb.Append(" ,SEX");
            sb.Append(" ,AGE");
            sb.Append(" ,COMMENT ");
            sb.Append("FROM");
            sb.Append(" MST001_EMPLOYEE");
            return sb.ToString();
        }

        /// <summary>
        /// 従業員削除クエリ作成
        /// </summary>
        /// <param name="salesId"></param>
        /// <returns></returns>
        public string CreateDeleteQueryByEmpId()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DELETE FROM ");
            sb.Append(" MST001_EMPLOYEE ");
            sb.Append("WHERE");
            sb.Append(" EMP_ID = @emp_id");
            return sb.ToString();
        }

        /// <summary>
        /// クエリのデータを設定する
        /// </summary>
        /// <param name="employee"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public MySqlCommand SetDataToBindQuery(Mst001_Employee employee, MySqlCommand command)
        {
            command.Parameters.AddWithValue(DbConst.MST001_EMP_ID, employee.emp_id);
            command.Parameters.AddWithValue(DbConst.MST002_COMP_ID, employee.company_id);
            command.Parameters.AddWithValue(DbConst.MST001_EMP_NAME_LAST, employee.emp_name_last);
            command.Parameters.AddWithValue(DbConst.MST001_EMP_NAME_FIRST, employee.emp_name_first);
            command.Parameters.AddWithValue(DbConst.MST001_EMP_SEX, employee.sex);
            command.Parameters.AddWithValue(DbConst.MST001_EMP_AGE, employee.age);
            command.Parameters.AddWithValue(DbConst.MST001_EMP_COMMENT, employee.comment);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_USER, employee.last_update_user);
            command.Parameters.AddWithValue(DbConst.LASTUPDATE_DATE, employee.last_update_date);

            return command;
        }
    }
}