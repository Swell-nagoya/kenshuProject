﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Remoting;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Logging.Export;
using Taurus.Util;

namespace Taurus {
	/// <summary>
	/// 同期型エントリーポイント
	/// </summary>
	public class EntryPointSync {

		/// <summary>
		/// サイレントモード
		/// </summary>
		public static bool SilentMode { get; private set; } = false;

		/// <summary>
		/// プログラム開始地点
		/// </summary>
		/// <param name="args">引数</param>
		public static void Main(string[] args) {
			

			// サイレントモードで立ち上げるか否か
			// コンソール使わなくなる
			if (args.Any(e => e == "--silent")) {
				SilentMode = true;
			}

			// ログファイル吐き出し用
			LogExportBase FileOut = new FileExport(new DirectoryInfo(Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "Log"));

			// サイレントモードだとコンソール使わない
			if (SilentMode) {
				Logger.Start(FileOut);
			} else {
				Logger.Start(new ConsoleExport(), FileOut);
			}


			try {
				// 通信用オブジェクト公開開始
				Manipulator.Transponder.StartTransmit();

				// プロセスIDを記録する
				Manipulator.Transponder.RemoteInstance.ProcessID = Process.GetCurrentProcess().Id;

				// 起動したことを知らせる
				Manipulator.Transponder.RemoteInstance.IsRunning = true;

				// メイン処理ここから
				Logger.Important("TAURUS 開始");
				
				// メインロジック生成
				Network.Server.MainLogicSync Logic = Network.Server.MainLogicSync.Instance;

				// レッツストップウォッチ
				var timer = Stopwatch.StartNew();

				// 停止要求を受けるもしくは非サイレントモード時にqキーが入力されるまで停止しない
				// メイン処理が死んでも止まる
				while (Logic.Update()) {

					// ちょい待ち
					Thread.Sleep(5);

					// 停止要求を受けた
					if (Manipulator.Transponder.RemoteInstance.StopRequire) {
						break;
					}


					// 非サイレントモードで入力されたキーがQなら終了
					if (!SilentMode && Console.KeyAvailable && Console.ReadKey().KeyChar == 'q') {
						break;
					}

				
				}

				// 停止指示
				Logic.Abort();

				// 停止を待機
				while (Logic.Update()) { Thread.Sleep(1); }

				// メイン処理ここまで
			} catch (Exception e) {

				// どっかでコケたらエラーに吐く
				Logger.Alert(e);
			}

			Logger.Important("TAURUS 終了");

			// サイレントモードと停止要求発行時以外は何かキーを押すまで待機
			if (!SilentMode || !Manipulator.Transponder.RemoteInstance.StopRequire) {
				Console.WriteLine();
				Console.WriteLine("何かキーを押してください");
				Console.ReadKey();
			}


			Logger.End();
		}
	}
}