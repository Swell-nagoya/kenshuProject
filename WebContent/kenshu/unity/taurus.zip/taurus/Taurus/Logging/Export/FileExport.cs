﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Logging.Export {
	/// <summary>
	/// ログ出力基底クラス
	/// </summary>
	public class FileExport : LogExportBase {

		/// <summary>
		/// ログの拡張子
		/// </summary>
		public const string LOG_EXTENSION = ".log";

		/// <summary>
		/// 圧縮ファイルの拡張子
		/// </summary>
		public const string COMPRESSION_EXTENSION = ".zip";

		/// <summary>
		/// ログファイルのサイズ制限(1M)
		/// </summary>
		public const long LOGFILE_LIMIT = 1024 * 2014;

		/// <summary>
		/// LOGはBOMなしUTF8で書きましょう
		/// </summary>
		public readonly static Encoding LogEncoding = new UTF8Encoding(false);

		/// <summary>
		/// 圧縮するか否か
		/// </summary>
		private bool IsCompression = true;

		/// <summary>
		/// 現在のログファイルのログサイズ
		/// </summary>
		private long NowLogSize = 0;

		/// <summary>
		/// 書き出すべきディレクトリ
		/// </summary>
		private readonly DirectoryInfo Dir;

		/// <summary>
		/// ログ吐き出し先
		/// </summary>
		private FileInfo LogFile;

		/// <summary>
		/// 書き出し先ストリーム
		/// </summary>
		private StreamWriter outStream = null;

		/// <summary>
		/// 圧縮するコンストラクタ
		/// </summary>
		/// <param name="LogDir">ログ出力先</param>
		public FileExport(DirectoryInfo LogDir) : this(LogDir, true) { }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="LogDir">ログ出力先</param>
		/// <param name="IsCompression">圧縮するか否か</param>
		public FileExport(DirectoryInfo LogDir, bool IsCompression) {
			Dir = LogDir;
			this.IsCompression = IsCompression;


			// ディレクトリチェック
			if (!Dir.Exists) { Dir.Create(); }

			// 圧縮チェック
			if (IsCompression) {

				// ログファイル内にログがあるか確認
				var LogFiles = Dir.GetFiles().Where(e => e.Extension == LOG_EXTENSION).ToArray();

				if (LogFiles.Any()) {
					// 全部ZIPに固める
					Parallel.ForEach(LogFiles, async (e) => {
						await LogComplession(e).ConfigureAwait(false);
					});
				}
			}


		}

		/// <summary>
		/// 書き出し
		/// </summary>
		/// <param name="Message">書き出すべきメッセージ</param>
		public async override Task Write(IEnumerable<MessageAndLevel> Message) {

			// 書き出すべきログファイルがなければ or ログが巨大化したら新しいのを作る
			if (LogFile == null || NowLogSize > LOGFILE_LIMIT) {
				await NextLog().ConfigureAwait(false);
				NowLogSize = 0;
			}


			// 書き出しサイズ計算
			NowLogSize += Message.Sum(e => e.Message.Length);

			// ストリームチェック
			if (outStream == null) {
				outStream = new StreamWriter(LogFile.Open(FileMode.Append, FileAccess.Write), LogEncoding);
			}

			// 順番に書く
			foreach (var log in Message) {
				await outStream.WriteLineAsync(log.Message).ConfigureAwait(false);
			}


			// 焼く
			await outStream.FlushAsync().ConfigureAwait(false);

		}

		/// <summary>
		/// ログファイル圧縮
		/// </summary>
		/// <param name="Log">圧縮するべきファイル</param>
		private async Task LogComplession(FileInfo Log) {

			// 圧縮すべきファイルを決定
			var ExportFile = new FileInfo(Log.FullName + COMPRESSION_EXTENSION);

			// ZIPでｵｯﾍﾟﾝ
			using (var zip = new ZipArchive(ExportFile.OpenWrite(), ZipArchiveMode.Create, false)) {

				// 圧縮率高めでエントリ生成
				var entry = zip.CreateEntry(Log.Name, CompressionLevel.Optimal);

				// 書き出しストリームを用意
				using (var Write = entry.Open()) {

					// ログファイルもオープン
					using (var ReadLog = Log.OpenRead()) {

						// ログファイルをZIPに転写
						await ReadLog.CopyToAsync(Write).ConfigureAwait(false);

						// 圧縮情報を追記しないと気が済まない
						using (var FooderWriter = new StreamWriter(Write, LogEncoding, 256, true)) {

							var time = DateTime.Now;

							await FooderWriter.WriteLineAsync(@"ゴクゴク! ＿ ｡Ｕ Ｕ").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　　／／ Ｕ｡Ｕ|｡").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　 ｜｜　ｏ∴｡∴").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　 ｜ Ｖ∴ ｡Ｕ|。").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　 ∧　ＶＵ｡∴|ｏ").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　/　＼ Ｖ∴｡Ｕノ|").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　 ｜ (ﾟ)Ｙ￣￣￣ ノ").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　 ｜　　 ￣￣￣厂").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　＼　　　　 /").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync(@"　　　 /　　　　｜").ConfigureAwait(false);
							await FooderWriter.WriteLineAsync($"このファイルは{time.ToString(@"yyy/MM/dd HH:mm")}に圧縮されました").ConfigureAwait(false);

						}

					}

					// 書き出し
					await Write.FlushAsync().ConfigureAwait(false);
				}
			}

			// 完了したら圧縮してないログを消す
			Log.Delete();

		}

		/// <summary>
		/// ログファイル切り替え
		/// </summary>
		/// <returns>同期用のTask</returns>
		private async Task NextLog() {

			var time = DateTime.Now;

			// あれば古いストリーム破棄
			outStream?.Dispose();
			outStream = null;

			// 新しいファイルを生成
			LogFile = new FileInfo(string.Format("{0}{1}{2:yyyy}{2:MM}{2:dd}{2:HH}{2:mm}{2:ss}{3}", Dir.FullName, Path.AltDirectorySeparatorChar, time, LOG_EXTENSION));

			// ヘッダ書き出し
			using (var Header = new StreamWriter(LogFile.Open(FileMode.Append, FileAccess.Write), LogEncoding)) {
				await Header.WriteLineAsync(@"オエーー!!!!　＿＿_").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　　　 ＿＿_／　　 ヽ").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　　 ／　 ／　／⌒ヽ|").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　　/ (ﾟ)/　／ /").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　 /　　 ﾄ､/｡⌒ヽ。").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　彳　　 ＼＼ﾟ｡∴｡ｏ").ConfigureAwait(false);
				await Header.WriteLineAsync(@"`／　　　　＼＼｡ﾟ｡ｏ").ConfigureAwait(false);
				await Header.WriteLineAsync(@"/　　　　 /⌒＼Ｕ∴)").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　　　　 ｜　　ﾞＵ｜").ConfigureAwait(false);
				await Header.WriteLineAsync(@"　　　　 ｜　 ∴｡||").ConfigureAwait(false);
				await Header.WriteLineAsync($"{time.ToString(@"yyy/MM/dd HH:mm")}からのログです").ConfigureAwait(false);
			}


		}

		/// <summary>
		/// 解放
		/// </summary>
		public override void Dispose() {

			// 何か開いていたら開放する
			outStream?.Dispose();
			outStream = null;

		}
	}
}


