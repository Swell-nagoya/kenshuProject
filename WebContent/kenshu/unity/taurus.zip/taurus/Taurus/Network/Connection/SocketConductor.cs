﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using Taurus.Network.Common;
using Taurus.Util;

namespace Taurus.Network.Connection {
	/// <summary>
	/// ソケット一個分を制御する用の何か
	/// </summary>
	public class SocketConductor : IDisposable {

		#region 定数

		/// <summary>
		/// 生存報告シグナル
		/// </summary>
		public static readonly Tuple<Message, Action> livingSignal = Tuple.Create<Message, Action>(new Message() { SignalType = Signal.LIVING_SIG }, null);

		/// <summary>
		/// GUIDの大きさ(バイト)
		/// </summary>
		const int GUIDsize = 16;

		#endregion

		/// <summary>
		/// 送信キュー
		/// </summary>
		private ConcurrentQueue<Tuple<Message, Action>> SendQueue = new ConcurrentQueue<Tuple<Message, Action>>();

		/// <summary>
		/// 受信キュー
		/// </summary>
		private ConcurrentQueue<Message> ReceiveQueue = new ConcurrentQueue<Message>();

		/// <summary>
		/// ソケット
		/// </summary>
		public readonly Socket Socket;

		/// <summary>
		/// ソケット制御用ラッパー
		/// </summary>
		public readonly SocketUtil Com;

		/// <summary>
		/// 稼働中であるか否か
		/// </summary>
		public bool IsAlive { get; set; } = true;

		/// <summary>
		/// エンティティID
		/// </summary>
		public Guid EntityID { get; private set; } = default(Guid);

		/// <summary>
		/// 制御用コルーチン
		/// </summary>
		private IEnumerator routinre;

		/// <summary>
		/// ソケットからの待機要求
		/// </summary>
		private SocketWaiter waiter;

		/// <summary>
		/// リモートエンドポイント
		/// </summary>
		public readonly EndPoint Remote;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="soc">制御対象のソケット</param>
		public SocketConductor(Socket socket) {
			this.Socket = socket;
			Remote = socket.RemoteEndPoint;
			Com = new SocketUtil(socket);
			routinre = Handshake();
		}

		/// <summary>
		/// 送受信処理
		/// </summary>
		public void Invoke() {
			// ソケットが正常稼働していなければ処理しない
			if (!IsAlive) { return; }


			// ソケットが死んでいないかチェック
			if ((!Com?.IsAlive) ?? true) {
				// エラーを吐いて死ぬ
				Logger.Warning($"ソケットが停止しました {Com?.LastDetectedError} [{Remote}]");
				Dispose();
				return;
			}

			// ルーチンが存在するかチェック
			if (routinre == null) {
				// エラーを吐いて死ぬ
				Logger.Warning($"処理が停止しました {Com.LastDetectedError} [{Remote}]");
				Dispose();
				return;
			}

			// 待機する必要があれば待機する
			if ((!waiter?.IsCompleat) ?? false) {
				return;
			}

			// コルーチン実行
			if (!routinre.MoveNext()) {
				// 終わったら捨てる
				routinre = null;
				return;
			}

			// 待機インスタンスもらえるかも
			waiter = routinre.Current as SocketWaiter;

		}

		/// <summary>
		/// ハンドシェイクルーチン
		/// </summary>
		/// <returns></returns>
		private IEnumerator Handshake() {

			// ハンドシェイク受信
			// バッファ長 + GUIDがもらえる
			var handshakeReceive = Com.Receive(Config.HandShakeSignalToServer.Length + GUIDsize);

			// 受信完了を待機
			yield return handshakeReceive;

			// ハンドシェイクとGUIDを抽出
			var handshake = new ArraySegment<byte>(handshakeReceive.Buffer, 0, Config.HandShakeSignalToServer.Length);
			var guid = new ArraySegment<byte>(handshakeReceive.Buffer, Config.HandShakeSignalToServer.Length, GUIDsize);

			// ハンドシェイクチェック
			if (!handshake.SequenceEqual(Config.HandShakeSignalToServer)) {
				Logger.Warning($"ハンドシェイク失敗 [{Remote}]");
				Dispose();
				yield break;
			}

			// GUID解析
			EntityID = new Guid(guid.ToArray());

			// GUIDチェック
			if (EntityID == default(Guid)) {
				Logger.Warning($"GUID解析失敗 [{Remote}]");
				Dispose();
				yield break;
			}

			// 問題がなさそうなので返答を行う
			yield return Com.Send(Config.HandShakeSignalToClient);


			Logger.Log($"ハンドシェイク完了 {EntityID.ToString()} > [{Remote}]");


			// 次のコルーチンに差し替え
			routinre = Communicator();
			yield return null;
		}

		/// <summary>
		/// 仲良くする
		/// </summary>
		/// <returns></returns>
		private IEnumerator Communicator() {
			//　送受信タイムアウト用
			var sendtime = DateTime.Now;
			var receivetime = DateTime.Now;

			var livingTimer = DateTime.Now;

			// 送受信コルーチン
			IEnumerator receive = null;
			IEnumerator send = null;

			while (true) {
				// 受信処理

				if (receive?.MoveNext() ?? false) {
					// 受信処理中はタイムアウトチェック
					if (sendtime.IsTimeOutMs(Config.TcpTimeout)) {
						Logger.Warning($"タイムアウトしました(受信) {EntityID.ToString()} > [{Remote}]");
						// 死亡
						yield break;
					}
				} else {
					// 受信ルーチンを開始してタイマーリセット
					receive = WaitWrapper(ReceiveRoutine());
					sendtime = DateTime.Now;
				}


				// 送信処理
				if (send?.MoveNext() ?? false) {
					// 送信処理中もタイムアウトチェック
					if (sendtime.IsTimeOutMs(Config.TcpTimeout)) {
						Logger.Warning($"タイムアウトしました(送信)  {EntityID.ToString()} > [{Remote}]");
						// 死亡
						yield break;
					}
				} else {
					

					// 送信キューから一軒取り出し
					if (SendQueue.TryDequeue(out Tuple<Message, Action> msgs)) {

						// 投げつける
						send = WaitWrapper(SendRoutine(msgs));
						sendtime = DateTime.Now;
						livingTimer = DateTime.Now;

					} else {

						// 送信キューが空だけど生存を確認しなければならない場合は生存シグナルを投げつけようとする
						if (sendtime.IsTimeOutMs(Config.AliveSignalInterval)) {
							send = WaitWrapper(SendRoutine(livingSignal));
							sendtime = DateTime.Now;
							livingTimer = DateTime.Now;
						}
					}
				}


				yield return null;
			}
		}

		/// <summary>
		/// 受信処理
		/// </summary>
		/// <returns>コルーチン</returns>
		private IEnumerator ReceiveRoutine() {

			// ヘッダを受信
			var header = Com.Receive(Message.HEADER_SIZE);
			yield return header;

			// ヘッダ解析
			Message.HeaderParse(header.Buffer, 0, out int payloadSize, out ushort seq, out Signal Signal);

			byte[] payload = null;

			// 必要であれば受信処理
			if (payloadSize > 0) {

				// 読み出し
				var payloadReader = Com.Receive(payloadSize);
				yield return payloadReader;
				payload = payloadReader.Buffer;

			}

			// 受信したメッセージチェック
			if (Signal == Signal.LIVING_SIG) {
				// 生存報告だけであれば何かする必要はない
				yield break;
			}

			// それ以外はキューに追加
			ReceiveQueue.Enqueue(
				new Message {
					Payload = payload ?? new byte[0],
					SignalType = Signal
				});

			yield break;
		}

		/// <summary>
		/// 送信処理
		/// </summary>
		/// <param name="msgs">送るべきメッセージ</param>
		/// <returns>コルーチン</returns>
		private IEnumerator SendRoutine(Tuple<Message, Action> msgs) {


			// 送信待機
			yield return Com.Send(msgs.Item1.ToByteArray());

			// 完了通知
			msgs.Item2?.Invoke();
		}

		/// <summary>
		/// 待機する必要がある場合待機するコルーチン
		/// </summary>
		/// <param name="waitRoutine">待機対象のルーチン</param>
		/// <returns>べんりなコルーチン</returns>
		public static IEnumerator WaitWrapper(IEnumerator waitRoutine) {


			// ルーチンが燃え尽きるまで待機
			while (waitRoutine.MoveNext()) {

				// 更に待たなければならないかチェック
				if (waitRoutine.Current is SocketWaiter waiter) {
					// 完了を待機
					while (!waiter.IsCompleat) {

						yield return null;
					}
				} else {
					// 待たなくていい
					yield return null;
				}
			}

		}

		/// <summary>
		/// メッセージをキューに入れる
		/// </summary>
		/// <param name="msg">送るべきメッセージ</param>
		/// <param name="compleat">完了通知</param>
		public void EnqueueSendMessage(Message msg, Action compleat = null) => SendQueue.Enqueue(Tuple.Create(msg, compleat));

		/// <summary>
		/// メッセージをキューから取り出そうとする
		/// </summary>
		/// <param name="msg">取り出したメッセージ</param>
		/// <returns>成功時true</returns>
		public bool TryeGetMessage(out Message msg) => ReceiveQueue.TryDequeue(out msg);

		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。
					Logger.Log($"切断しました [{Remote}]");
					Socket.Dispose();

				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。
				IsAlive = false;
				disposedValue = true;
			}
		}

		// TODO: 上の Dispose(bool disposing) にアンマネージ リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
		// ~SocketConductor() {
		//   // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
		//   Dispose(false);
		// }

		// このコードは、破棄可能なパターンを正しく実装できるように追加されました。
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			// GC.SuppressFinalize(this);
		}
		#endregion
	}

}
