﻿namespace Taurus.Network.Connection {
	/// <summary>
	/// 読み取り待機
	/// </summary>
	public class ReceiveWaiter : SocketWaiter {

		/// <summary>
		/// 受信バッファ
		/// </summary>
		public byte[] Buffer { get; private set; } = null;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="soc">ソケット制御インスタンス</param>
		/// <param name="readSize">読み込むべきサイズ</param>
		public ReceiveWaiter(SocketUtil soc, int readSize) {
			// 生成直後に読み取り処理を発火
			soc.Receive(readSize, ReadCompleat);
		}

		/// <summary>
		/// 読み取り完了
		/// </summary>
		/// <param name="buffer">読み取った値</param>
		private void ReadCompleat(byte[] buffer) {
			// バッファに記載してフラグセット
			Buffer = buffer;
			IsCompleat = true;
		}
	}

}
