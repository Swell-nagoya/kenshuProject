﻿using Taurus.Util;

namespace Taurus.Network.Connection {
	/// <summary>
	/// 待つ奴
	/// </summary>
	public abstract class SocketWaiter {

		/// <summary>
		/// 完了したか否か
		/// </summary>
		public bool IsCompleat { get; protected set; } = false;
	}

}
