﻿using System;
using System.Net.Sockets;

namespace Taurus.Network.Connection {
	/// <summary>
	/// ソケットで便利な奴
	/// </summary>
	public class SocketUtil {

		/// <summary>
		/// ソケット置き場
		/// </summary>
		private Socket soc;
		
		/// <summary>
		/// 生存チェック
		/// </summary>
		public bool IsAlive { get; private set; } = true;

		/// <summary>
		/// 最後に検出したエラー
		/// </summary>
		public SocketError LastDetectedError { get; private set; }

		/// <summary>
		/// ソケット制御インスタンス
		/// </summary>
		/// <param name="socket">制御対象</param>
		public SocketUtil(Socket socket) {
			soc = socket;
		}

		/// <summary>
		/// 受信する
		/// </summary>
		/// <param name="readSize">受信したい量</param>
		/// <returns>受信待機インスタンス</returns>
		public ReceiveWaiter Receive(int readSize) {
			return new ReceiveWaiter(this, readSize);
		}

		/// <summary>
		/// 送信する
		/// </summary>
		/// <param name="bin">送信内容</param>
		/// <returns>送信待機用インスタンス</returns>
		public SendWaiter Send(byte[] bin) {
			return new SendWaiter(this, bin);
		}

		/// <summary>
		/// ソケットから指定量読み出す
		/// </summary>
		/// <param name="readSize">読み出しサイズ</param>
		/// <param name="compleat">完了時コールバック</param>
		public void Receive(int readSize, Action<byte[]> compleat) {

			// 受信用のインスタンスを生成
			var arg = new SocketAsyncEventArgs();

			// 受信用バッファ生成
			arg.SetBuffer(new byte[readSize], 0, readSize);

			// コールバック関数を指定
			arg.Completed += (_, e) => ReceiveInternal(e, compleat);

			// 受信実行
			if (!soc.ReceiveAsync(arg)) {
				// 非同期で処理が完了したらイベント叩かれないので自分で呼ぶ
				ReceiveInternal(arg, compleat);
			}

		}

		/// <summary>
		/// 受信処理(内部用)
		/// </summary>
		/// <param name="arg">受信を統括してる引数インスタンス</param>
		/// <param name="compleat">完了時コールバック</param>
		private void ReceiveInternal(SocketAsyncEventArgs arg, Action<byte[]> compleat) {
			// ソケットに問題が発生したので終了処理
			if (arg.SocketError != SocketError.Success) {
				Abort(arg.SocketError);
				return;
			}

			// 読み出し量が足りているかチェック
			if (arg.BytesTransferred + arg.Offset < arg.Buffer.Length) {

				// 足りていないのでバッファをずらしてもう一度読み出し実行
				arg.SetBuffer(arg.Offset + arg.BytesTransferred, arg.Buffer.Length - (arg.BytesTransferred + arg.Offset));

				try {

					// 読み出し再チャレンジ
					if (!soc.ReceiveAsync(arg)) {
						ReceiveInternal(arg, compleat);
					}

				} catch (Exception) {
					// 失敗した
					Abort(SocketError.Shutdown);
				}
				return;
			}
			// 必要量の読み込みが完了したので返す
			compleat?.Invoke(arg.Buffer);

		}

		/// <summary>
		/// ソケットに指定量書き出す
		/// なお非同期で行われる模様
		/// </summary>
		/// <param name="sendBuffer">送信バッファ 送信処理が完了する前に変更を行うと送信データがおかしくなるので注意</param>
		/// <param name="compleat">完了時コールバック</param>
		public void Send(byte[] sendBuffer, Action compleat) {

			// 送信用のインスタンスを生成
			var arg = new SocketAsyncEventArgs();

			// 送信用バッファ登録
			arg.SetBuffer(sendBuffer, 0, sendBuffer.Length);

			// コールバック関数を指定
			arg.Completed += (_, e) => SendInternal(e, compleat);

			// 送信実行
			if (!soc.SendAsync(arg)) {
				// 非同期で処理が完了したらイベント叩かれないので自分で呼ぶ
				SendInternal(arg, compleat);
			}
		}

		/// <summary>
		/// 送信処理(内部用)
		/// </summary>
		/// <param name="arg">受信を統括してる引数インスタンス</param>
		/// <param name="compleat">完了時コールバック</param>
		private void SendInternal(SocketAsyncEventArgs arg, Action compleat) {
			// ソケットに問題が発生したので終了処理
			if (arg.SocketError != SocketError.Success) {
				Abort(arg.SocketError);
				return;
			}

			// 書き出し量が十分かチェック
			if (arg.BytesTransferred + arg.Offset < arg.Buffer.Length) {

				// 足りていないのでバッファをずらしてもう一度書き出し実行
				arg.SetBuffer(arg.Offset + arg.BytesTransferred, arg.Buffer.Length - (arg.BytesTransferred + arg.Offset));

				try {
					// 次を書こう
					if (!soc.SendAsync(arg)) {
						SendInternal(arg, compleat);
					}

				} catch (Exception) {
					// 失敗した
					Abort(SocketError.Shutdown);
				}

				return;
			}

			// 書き出し処理
			compleat?.Invoke();
		}

		/// <summary>
		/// 解放ロック用
		/// </summary>
		private object disposableLock = new object();

		/// <summary>
		/// 死亡処理
		/// </summary>
		/// <param name="error">発生したエラー内容</param>
		private void Abort(SocketError error) {

			lock (disposableLock) {

				// 既に死んでいないか確認する
				if (IsAlive) {
					IsAlive = false;

					// エラーを記録する
					LastDetectedError = error;

					// ソケット殺す
					soc.Dispose();
				}
			}
		}
	}
}
