﻿namespace Taurus.Network.Connection {
	/// <summary>
	/// 書き出し待機
	/// </summary>
	public class SendWaiter : SocketWaiter {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="soc">ソケット制御インスタンス</param>
		/// <param name="sendBuf">送るべき内容</param>
		public SendWaiter(SocketUtil soc, byte[] sendBuf) {
			// レッツ送信
			soc.Send(sendBuf, () => IsCompleat = true);
		}
	}
}
