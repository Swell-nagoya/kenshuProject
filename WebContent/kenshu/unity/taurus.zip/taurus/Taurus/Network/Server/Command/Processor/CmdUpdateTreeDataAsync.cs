﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ツリーデータのノードデータ一件更新
	/// </summary>
	[ByteCommandBinding(OrderPattern.UPDATE_TREE_DATA)]
	public class CmdUpdateTreeDataAsync : CommandProcessorBaseAsync<UpdateTreeData> {

		/// <summary>
		/// ノードデータ一件更新
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(UpdateTreeData Payload, CancellationToken token) {

			try {
				// セーブ情報参照
				await DBInterface.UpdateTreeDataAsync(User.DbUserInfo, Payload.Datas).ConfigureAwait(false);
			} catch (Exception e) {
				// なんか例外が出たら失敗
				Logger.Alert(e);
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}
			return CreateOKResponce();
		}
	}
}

