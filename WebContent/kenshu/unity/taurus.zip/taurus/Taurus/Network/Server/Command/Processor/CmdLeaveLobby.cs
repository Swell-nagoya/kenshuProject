﻿using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ロビーから出たい
	/// </summary>
	[ByteCommandBinding(OrderPattern.LEAVE_LOBBY)]
	public class CmdLeaveLobby : CommandProcessorBase {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect() {

			// ロビーに入っていることを確認
			if (User.JoinedLobby == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}

			// すでにルームに入っている場合は抜ける
			if (User.JoinedRoom != null) {
				User.JoinedRoom.Leave(User);
			}

			// ロビーから抜ける
			User.JoinedLobby.Leave(User);

			// よさげ
			return CreateOKResponce();
		}
	}
}

