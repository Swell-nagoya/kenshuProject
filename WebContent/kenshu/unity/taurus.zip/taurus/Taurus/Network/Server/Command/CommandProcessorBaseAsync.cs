﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command {
	/// <summary>
	/// 非同期で処理するべきコマンドの抽象クラス
	/// </summary>
	public abstract class CommandProcessorBaseAsync : CommandProcessorBase {
		
		/// <summary>
		/// 処理を非同期で実行
		/// </summary>
		/// <returns></returns>
		protected abstract Task<OrderResponceBase> InternalExectAsync(CancellationToken token);

		/// <summary>
		/// 非同期実行
		/// </summary>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>返答すべき内容</returns>
		public async Task<OrderResponceBase> ExectAsync(CancellationToken token) {
			return await InternalExectAsync(token).ConfigureAwait(false);
		}

		/// <summary>
		/// 非同期メソッドを同期的に実行(非推奨)
		/// キャンセルできません
		/// </summary>
		/// <returns>返答すべき内容</returns>
		protected override OrderResponceBase InternalExect() {
			return Task.Run(async () => await InternalExectAsync(CancellationToken.None).ConfigureAwait(false)).Result;
		}
	}


	/// <summary>
	/// 非同期でペイロードを必要とする場合のコマンド処理
	/// </summary>
	public abstract class CommandProcessorBaseAsync<T> : CommandProcessorBaseAsync where T : OrderPayloadBase {


		/// <summary>
		/// キャスト試行
		/// </summary>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>返答するべき内容</returns>
		protected sealed override async Task<OrderResponceBase> InternalExectAsync(CancellationToken token) {

			if (Order.OrderData is T Payload) {
				// キャスト可能なので普通に続行
				return await InternalExectAsync(Payload, token).ConfigureAwait(false);
			} else {
				// キャストできないのでペイロードがおかしい
				return CreateResponce(OrderResponcePattern.FAILED_CAUSE_UNKNOWN);
			}
		}

		/// <summary>
		/// ペイロードを引数に持つタイプの実行メソッド
		/// </summary>
		/// <param name="Payload">送られてきたペイロード</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>返答すべき内容</returns>
		protected abstract Task<OrderResponceBase> InternalExectAsync(T Payload, CancellationToken token);

	}
}
