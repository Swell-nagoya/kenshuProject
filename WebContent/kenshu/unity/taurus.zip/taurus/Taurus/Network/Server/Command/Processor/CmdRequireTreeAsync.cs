﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ツリーデータインデックス情報参照
	/// </summary>
	[ByteCommandBinding(OrderPattern.REQUIRE_TREE)]
	public class CmdRequireTreeAsync : CommandProcessorBaseAsync {

		/// <summary>
		/// ツリー参照
		/// </summary>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(CancellationToken token) {


			// セーブ情報参照
			var treeMap = await DBInterface.ReadTreeMapAsync(User.DbUserInfo).ConfigureAwait(false);


			// 失敗してないか調べる
			if (treeMap == null) {
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}

			// 返す
			return CreateOKResponce<RequireTreeResponce>(e => e.Infos = treeMap);
		}
	}
}

