﻿using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.Network;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ロビーと自分の情報を生成してほしい
	/// </summary>
	[ByteCommandBinding(OrderPattern.GET_LOBBYS_AND_ME)]
	public class CmdGetLobbysAndMe : CommandProcessorBase {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect() {

			// 返答インスタンス生成
			var ret = CreateOKResponce<GetLobbysAndMeResponce>();

			// 値を格納
			ret.Data = new LobbysAndYouInfo() {

				// お前の情報
				You = User.CreateInfo(),

				// ロビーの情報
				LobbyInfo = Logic.Lobbys.
				// アプリケーションIDとデベロッパIDが同一なもののみ参照
				Where(e => e.DBInfo.application_id == User.DbUserInfo.application_id).
				Where(e => e.DBInfo.developer_id == User.DbUserInfo.developer_id).

				// info作ってキャストして配列にする
				Select(e => e.CreateInfo())
				.Cast<LobbyInfo>().ToArray()
			};

			// 返す
			return ret;

		}

	}
}

