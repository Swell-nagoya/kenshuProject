﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// バイナリセーブデータ書き込み
	/// </summary>
	[ByteCommandBinding(OrderPattern.SAVE_WRITE)]
	public class CmdSaveWriteAsync : CommandProcessorBaseAsync<SaveDataWriteOrder> {

		/// <summary>
		/// セーブ書き込み
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(SaveDataWriteOrder Payload, CancellationToken token) {
			// レッツ書き出し
			if (await DBInterface.DataWrite(User.DbUserInfo.application_id, User.DbUserInfo.developer_id, User.DbUserInfo.user_id, Payload.Page, Payload.Data).ConfigureAwait(false)) {
				return CreateOKResponce();
			} else {
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}
		}
	}
}

