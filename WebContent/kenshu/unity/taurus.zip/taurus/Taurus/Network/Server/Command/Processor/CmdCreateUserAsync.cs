﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// アカウント生成
	/// </summary>
	[ByteCommandBinding(OrderPattern.CREATE_USER)]
	public class CmdCreateUserAsync : CommandProcessorBaseAsync<CreateUserOrder> {

		/// <summary>
		/// コマンドの実行にログインを要求しない
		/// </summary>
		public override bool IsLoginRequire => false;

		/// <summary>
		/// ログイン実行
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(CreateUserOrder Payload, CancellationToken token) {
			// 新規ユーザー作成に必要な情報を作成
			AppIdAndDevIdPair CreateTmp = new AppIdAndDevIdPair() { ApplicationID = Payload.AppId, DeveloperID = Payload.DevID };

			// 作る
			var Result = await DBInterface.CreateUserAsync(CreateTmp).ConfigureAwait(false);

			// 生成チェック
			if (Result == null) {
				// たぶんアプリケーション情報が見つからない
				return CreateResponce(OrderResponcePattern.FAILED_TARGET_NOT_FOUND);
			}

			// ログイン情報は覚えておく
			User.DbUserInfo = Result.DbUser;

			// 必要な情報を返す
			return CreateOKResponce<CreateUserResponce>((e) => e.login = Result.LoginInfo);

		}
	}
}

