﻿using System;
using System.Linq;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.Network.Common;

namespace Taurus.Network.Server {

	/// <summary>
	/// ルーム一個を管理する
	/// </summary>
	public class RoomManagera : UserGroupBase {

		/// <summary>
		///  親となるロビー
		/// </summary>
		public readonly LobbyManagera Parrent;

		/// <summary>
		/// ルーム情報
		/// </summary>
		public readonly byte[] Details;

		/// <summary>
		/// 部屋作成
		/// </summary>
		/// <param name="Parrent">親のロビー</param>
		/// <param name="Info">ルーム情報</param>
		private RoomManagera(LobbyManagera Parrent, CreateRoomOrder Info) {
			this.Parrent = Parrent;
			Details = Info.Details;

			Logger.Log($"ルーム作成:{EntityID}");

		}

		/// <summary>
		/// ユーザー追加
		/// </summary>
		/// <param name="User">追加するべきユーザー</param>
		public override Message[] Add(IRemoteUser User) {


			// 参加させる
			User.JoinedRoom = this;

			// まだ入れそうなので入る
			return base.Add(User);
		}


		/// <summary>
		/// ユーザー追い出し
		/// </summary>
		/// <param name="User">追い出すべきユーザー</param>
		public override void Leave(IRemoteUser User) {
			base.Leave(User);
			User.JoinedRoom = null;

			// 人数チェック
			if (!GetUserInfoes().Any()) {
				// ルームから人がいなくなったのでルームは滅びる
				Logger.Log($"ルームが無人になったため破棄します:{EntityID}");

				Parrent.RemoveRoom(this);
			}
		}

		/// <summary>
		/// ユーザー参加
		/// </summary>
		/// <param name="client">増えた奴</param>
		protected override Message UserJoinMessage(UserEntityInfo client) {
			return Message.CreateMessages(client, Signal.ROOM_ADD_USER);
		}

		/// <summary>
		/// ユーザー退場
		/// </summary>
		/// <param name="client">減った奴</param>
		protected override Message UserLeaveMessage(UserEntityInfo client) {
			return Message.CreateMessages(client, Signal.ROOM_DEL_USER);
		}

		/// <summary>
		/// ルーム内ブロードキャスト
		/// </summary>
		protected override Signal BroadcastSignal => Signal.ROOM_BROADCAST;

		/// <summary>
		/// ルーム作成
		/// </summary>
		/// <param name="Parrent">親のロビー</param>
		/// <param name="Info">ルーム情報</param>
		/// <returns>生成したインスタンス or 失敗時null</returns>
		public static RoomManagera Create(LobbyManagera Parrent, CreateRoomOrder Info) {
			// nullチェック
			if (Parrent == null || Info == null) {
				return null;
			}

			// パラメーターチェック
			if (Info.IsParamFailed()) {	
				return null;
			}

			// 生成
			return new RoomManagera(Parrent, Info);
		}

		/// <summary>
		/// 情報作成
		/// </summary>
		/// <returns>生成された情報</returns>
		public override UserGroupInfoBase CreateInfo() {
			

			return new RoomInfo() {
				EntityID = EntityID,
				Details = Details,
				MaxUsers = 65535, // TODO:DBに焼け
				NowUsers = GetUserCount()
			};
		}
	}
}