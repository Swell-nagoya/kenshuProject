﻿using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// 同じロビーの仲間を探す
	/// </summary>
	[ByteCommandBinding(OrderPattern.GET_LOBBY_PLAYERS)]
	public class CmdGetLobbyPlayers : CommandProcessorBase {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect() {

			// ロビーのメンバー一覧を返す
			if (User.JoinedLobby != null) {
				return CreateOKResponce<UserGroupResponce>((e) => e.Users = User.JoinedLobby.GetUserInfoes());


			} else {
				// ロビーにはいってないから無理
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}
		}
	}
}
