﻿using System;
using System.Collections.Generic;
using Taurus.Data.Network.Info;
using Taurus.DB;
using Taurus.Network.Common;
using Taurus.Util;

namespace Taurus.Network.Server {
	/// <summary>
	/// リモートユーザーが実装するべき要素
	/// </summary>
	public interface IRemoteUser : IEntityID, IDisposable {

		/// <summary>
		/// 生存しているか否か
		/// </summary>
		bool IsAlive { get; }

		/// <summary>
		/// DB上での情報
		/// </summary>
		d_user DbUserInfo { get; set; }

		/// <summary>
		/// 接続中のロビー
		/// </summary>
		LobbyManagera JoinedLobby { get; set; }

		/// <summary>
		/// 接続中のルーム
		/// </summary>
		RoomManagera JoinedRoom { get; set; }

		/// <summary>
		/// 自身の情報を生成する
		/// </summary>
		/// <returns></returns>
		UserEntityInfo CreateInfo();

		/// <summary>
		/// クライアントに対して送信するべきメッセージを追加する
		/// </summary>
		/// <param name="isFastSend">急いで送信するべきか否か</param>
		/// <param name="msg">追加するべきメッセージ</param>
		void EnqueueMessage(Message msg, bool isFastSend = false);

		/// <summary>
		/// 送信メッセージキューに複数メッセージを入れる
		/// </summary>
		/// <param name="isFastSend">急いで送信するべきか否か</param>
		/// <param name="msgs">送信メッセージ</param>
		void EnqueueMessage(IEnumerable<Message> msgs, bool isFastSend = false);
	}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      }
