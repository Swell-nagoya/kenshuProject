﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data;
using Taurus.Data.Network;
using Taurus.Data.Network.Info;
using Taurus.Network.Common;

namespace Taurus.Network.Server {

	/// <summary>
	/// ユーザーが集まるクラスの土台
	/// </summary>
	public abstract class UserGroupBase : IDisposable {

		/// <summary>
		/// エンティティID
		/// </summary>
		public readonly Guid EntityID = Guid.NewGuid();
		
		/// <summary>
		/// ブロードキャスト時の発行元情報
		/// </summary>
		protected abstract Signal BroadcastSignal { get; }

		/// <summary>
		/// インフォ作成
		/// </summary>
		/// <returns>生成された情報</returns>
		public abstract UserGroupInfoBase CreateInfo();

		/// <summary>
		/// ユーザー一覧
		/// </summary>
		private readonly List<IRemoteUser> Users = new List<IRemoteUser>();

		/// <summary>
		/// ユーザーがこのグループに参加したときの振る舞い
		/// </summary>
		/// <param name="client">送信するべきメッセージ</param>
		protected abstract Message UserJoinMessage(UserEntityInfo client);

		/// <summary>
		/// ユーザーがこのグループから脱退したときの振る舞い
		/// </summary>
		/// <param name="info">逃げたユーザー情報</param>
		/// <param name="client">送信するべきメッセージ</param>
		protected abstract Message UserLeaveMessage(UserEntityInfo client);

		/// <summary>
		/// ユーザーを参加させる
		/// </summary>
		/// <param name="User"></param>
		public virtual Message[] Add(IRemoteUser User) {
			
			lock (Users) {
				Users.Add(User);

				// 全体通知
				BroadcastMessage(UserJoinMessage(User.CreateInfo()), User);

				// ユーザー参加情報を全部投げる
				return Users.Select(e => UserJoinMessage(e.CreateInfo())).ToArray();
				

			}
			
		}

		/// <summary>
		/// ユーザーを削除する
		/// </summary>
		/// <param name="User">削除するユーザー</param>
		public virtual void Leave(IRemoteUser User) {
			lock (Users) {
				// 削除できたらお知らせ
				if (Users.Remove(User)) {
					BroadcastMessage(UserLeaveMessage(User.CreateInfo()), User);
				}
			}
		}


		/// <summary>
		/// 切断されたユーザーを整理する
		/// </summary>
		public void CleanUser() {
			IRemoteUser[] Deads;
			lock (Users) {
				// 死んだユーザー一覧を生成
				Deads = Users.Where(e => !e.IsAlive).ToArray();
			}

			// 削除指示
			foreach (var user in Deads) {
				Leave(user);
			}
		}

		/// <summary>
		/// 現在の全てのユーザー情報参照
		/// </summary>
		/// <returns>これを発動した瞬間ユーザー情報を配列で返す</returns>
		public UserEntityInfo[] GetUserInfoes() {
			lock (Users) {
				// 配列で返す
				return Users.Select(e => e.CreateInfo()).ToArray();
			}
		}

		/// <summary>
		/// ユーザーの数を数える
		/// GetUsers().Lengthよりも早くて省メモリ！ステキ！！
		/// </summary>
		/// <returns>ユーザー数</returns>
		public int GetUserCount() {
			lock (Users) {
				// 配列で返す
				return Users.Count();
			}
		}


		/// <summary>
		/// メッセージ全体送信
		/// </summary>
		/// <param name="msgbin">送信するべきメッセージ</param>
		/// <param name="User">送信元</param>
		public void BroadcastMessage(Message msg, IRemoteUser User = null) {


			// 自分以外の全てのユーザーに対して処理
			lock (Users) {
				foreach (var target in Users.Where(e => e != User)) {
					// 生きていれば送信
					if (target.IsAlive) {
						target.EnqueueMessage(msg);
					}
				}
			}
		}

		/// <summary>
		/// メッセージ全体送信
		/// </summary>
		/// <param name="msgbin">送信するべきメッセージ</param>
		/// <param name="User">送信元</param>
		public void BroadcastMessage(byte[] msg, IRemoteUser User) {
			
			// 相手に向けて送信
			Message send = Message.CreateMessages(
				new ToEntityMessage() { From = User.EntityID, Message = msg, To = EntityID },
				BroadcastSignal
				);

			// 自分以外の全てのユーザーに対して処理
			lock (Users) {
				foreach (var target in Users.Where(e => e != User)) {
					// 生きていれば送信
					if (target.IsAlive) {
						target.EnqueueMessage(send);
					}
				}
			}
		}


		/// <summary>
		/// UserのEntityIDを指定してメッセージ送信
		/// </summary>
		/// <param name="msg">送信するデータ</param>
		/// <param name="To">相手のID</param>
		/// <param name="From">送信元</param>
		public bool SendMessage(byte[] msg, Guid To, RemoteClientSync From) {
			lock (Users) {

				// ユーザーを検索する
				IRemoteUser tmp = Users.Find(e => e.EntityID.Equals(To));

				if (tmp == null || !tmp.IsAlive) {
					// 見つからなかった
					return false;
				} else {
					// メッセージ送信
					tmp.EnqueueMessage(Message.CreateMessages<ToEntityMessage>(new ToEntityMessage() { From = From.EntityID, To = To, Message = msg }, Signal.RCEIVE_TO_ENTITY));
					return true;
				}

			}
		}

		/// <summary>
		/// 接続人数取得
		/// </summary>
		/// <returns>接続人数</returns>
		public int JoinnerCount() {
			lock (Users) {
				return Users.Count();
			}
		}

		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。

					// 全ユーザーを追い払う
					lock (Users) {
						foreach (var user in Users) {
							Leave(user);
						}
					}

				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。

				disposedValue = true;
			}
		}

		// TODO: 上の Dispose(bool disposing) にアンマネージ リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
		// ~UserGroupBase() {
		//   // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
		//   Dispose(false);
		// }

		// このコードは、破棄可能なパターンを正しく実装できるように追加されました。
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			// GC.SuppressFinalize(this);
		}
		#endregion

	}
}
