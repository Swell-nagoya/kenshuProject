﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// バイナリセーブデータ読み出し
	/// </summary>
	[ByteCommandBinding(OrderPattern.SAVE_READ)]
	public class CmdSaveReadAsync : CommandProcessorBaseAsync<LoadPageOrder> {

		/// <summary>
		/// セーブ読み出し
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(LoadPageOrder Payload, CancellationToken token) {
			// セーブデータ参照
			var Save = await DBInterface.DataRead(User.DbUserInfo.application_id, User.DbUserInfo.developer_id, Payload.UserID, Payload.Page).ConfigureAwait(false);

			// そんなものが実在するか確認
			if (Save == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_FOUND);
			}

			// あったから返そうか
			return CreateOKResponce<SaveLoadResponce>(e => e.Data = Save);
		}
	}
}

