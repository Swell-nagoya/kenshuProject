﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ツリーデータのインデックス更新
	/// </summary>
	[ByteCommandBinding(OrderPattern.UPDATE_TREE)]
	public class CmdUpdateTreeAsync : CommandProcessorBaseAsync<UpdateTreeMap> {

		/// <summary>
		/// ツリーノードデータ更新
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(UpdateTreeMap Payload, CancellationToken token) {

			try {
				// セーブ情報書き出し
				await DBInterface.UpdateTreeMapAsync(User.DbUserInfo, Payload.Tree).ConfigureAwait(false);

			} catch (Exception e) {
				// なんか例外が出たら失敗
				Logger.Alert(e);
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}

			return CreateOKResponce();
		}
	}
}

