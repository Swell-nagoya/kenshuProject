﻿using System;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	// <summary>
	/// ロビーから現在の待ち時間をダウンロードする(ﾜﾝｵﾌ)
	/// </summary>
	[ByteCommandBinding(OrderPattern.WAITTIME_GET_LOBBY)]
	public class CmdWaitTimeGetLobby : CommandProcessorBase {

		/// <summary>
		/// 待ち時間ダウンロード
		/// </summary>
		/// <returns>クライアントへの返答内容</returns>
		protected override OrderResponceBase InternalExect() {
			// ロビー接続チェック
			if (User.JoinedLobby == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}

			// 値を返す
			return CreateOKResponce<GetLobbyWaitTimeResponce>(e => e.AverageMyWaitTime = new TimeSpan(User.JoinedLobby.AverageWaitTime));

		}
	}
}

