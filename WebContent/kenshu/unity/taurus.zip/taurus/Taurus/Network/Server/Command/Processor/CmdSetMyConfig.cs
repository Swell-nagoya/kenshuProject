﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.DB.Util;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// 自分の情報を書き換える
	/// </summary>
	[ByteCommandBinding(OrderPattern.SET_MYCONFIG)]
	public class CmdSetMyConfig : CommandProcessorBaseAsync<SetMyConfig> {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>返すべきメッセージ</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(SetMyConfig Payload, CancellationToken token) {

			// 自分の事か確認
			if (Payload.Config.UserID == User.DbUserInfo.user_id) {

				// 値を設定
				User.DbUserInfo.SetParam(Payload.Config);

				// DB焼き
				var update = await DBInterface.UserUpdateAsync(User.DbUserInfo).ConfigureAwait(false);

				// 正常に終わらなかったらエラーを返す
				if (!update) {
					return CreateResponce(OrderResponcePattern.FAILED_CAUSE_UNKNOWN);
				}

			} else {
				// 自分以外のデータを弄れない
				return CreateResponce(OrderResponcePattern.FAILED_FORBIDDEN);
			}

			// 問題がなければ成功
			return CreateOKResponce();
		}

	}

}
