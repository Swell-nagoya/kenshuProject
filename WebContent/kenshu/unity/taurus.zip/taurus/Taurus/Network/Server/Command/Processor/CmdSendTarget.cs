﻿using System.Linq;
using Taurus.Data.Network;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// 何かにメッセージを送る
	/// </summary>
	[ByteCommandBinding(OrderPattern.SEND_TARGET)]
	public class CmdSendTarget : CommandProcessorBase<TransmitMessageToEntityOrder> {

		/// <summary>
		/// メッセージ送信
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override OrderResponceBase InternalExect(TransmitMessageToEntityOrder Payload) {
			// Global空間からエンティティを探す
			var target = Logic.Users.
				Where(e => e.EntityID == Payload.TargetEntityID).
				Where(e => e.DbUserInfo.application_id == User.DbUserInfo.application_id).
				Where(e => e.DbUserInfo.developer_id == User.DbUserInfo.developer_id).
				FirstOrDefault();

			if (target != null) {
				// 対象を発見したので送信
				target.EnqueueMessage(Message.CreateMessages(new ToEntityMessage() { From = User.EntityID, To = target.EntityID, Message = Payload.Message }, Signal.RCEIVE_TO_ENTITY));
				return CreateOKResponce();
			} else {
				// 対象が見つからない
				return CreateResponce(OrderResponcePattern.FAILED_TARGET_NOT_FOUND);
			}

		}
	}
}

