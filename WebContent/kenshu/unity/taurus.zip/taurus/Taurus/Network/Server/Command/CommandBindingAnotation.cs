﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command {

	/// <summary>
	/// コマンドとして登録する属性
	/// </summary>
	[AttributeUsage(AttributeTargets.Class)]
	public class ByteCommandBindingAttribute: Attribute {

		/// <summary>
		/// コマンド引数
		/// </summary>
		public readonly byte Command;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="command">適応対象のコマンド</param>
		public ByteCommandBindingAttribute(byte command) {
			this.Command = command;
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="command">適応対象のコマンド</param>
		public ByteCommandBindingAttribute(OrderResponcePattern command) {
			this.Command = (byte)command;
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="command">適応対象のコマンド</param>
		public ByteCommandBindingAttribute(OrderPattern command) {
			this.Command = (byte)command;
		}
	}
}
