﻿using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ロビーで叫びたい
	/// </summary>
	[ByteCommandBinding(OrderPattern.BROADCAST_LOBBY)]
	public class CmdBloadCastLobby : CommandProcessorBase<TransmitMessageOrder> {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect(TransmitMessageOrder Payload) {
			// ロビー接続チェック
			if (User.JoinedLobby == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}

			// ロビーにメッセージ送信
			User.JoinedLobby.BroadcastMessage(Payload.Message, User);
			return CreateOKResponce();

		}
	}
}

