﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// サポートチケット一件送信
	/// </summary>
	[ByteCommandBinding(OrderPattern.COMMIT_SUPPORT_TICKET)]
	public class CmdCommitSupportTicketAsync : CommandProcessorBaseAsync<CommitSupportOrder> {

		/// <summary>
		/// サポートチケット一件送信
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(CommitSupportOrder Payload, CancellationToken token) {


			try {
				// セーブ情報参照
				var index = await DBInterface.SupportTicketCommitAsync(User.DbUserInfo, Payload.Message).ConfigureAwait(false);

				// 成功
				return CreateOKResponce<CreateSupportTicketResponce>(e => e.TicketID = index);
			} catch (Exception) {
				// よーわからんが失敗
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}
		}
	}
}

