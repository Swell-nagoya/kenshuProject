﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;
using Taurus.Network.Server.Command.Processor;

namespace Taurus.Network.Server.Command {

	/// <summary>
	/// コマンド生成の工場
	/// </summary>
	public static partial class CommandProcessorFactory {

		/// <summary>
		/// 生成パターン
		/// </summary>
		private static readonly ReadOnlyDictionary<OrderPattern, Func<CommandProcessorBase>> FactoryPattern;
		
		/// <summary>
		/// インスタンス生成
		/// </summary>
		/// <param name="order">命令</param>
		/// <param name="user">ユーザー用インスタンス</param>
		/// <returns>実行するべきコマンド処理用インスタンス</returns>
		public static CommandProcessorBase Create(Order order, IRemoteUser user) {

			// 生成するべきコマンドを検索
			if (FactoryPattern.TryGetValue(order.OrderData.Pattern, out var func)) {
				// プロセッサ生成して初期化後に返す
				var processor = func.Invoke();
				processor.Init(user, order);
				return processor;
			}

			// 見つからなかった場合所定の応答を行う
			var unknownPocessor = new CmdUnknown();
			unknownPocessor.Init(user, order);
			return unknownPocessor;

		}
	}


}
