﻿  
/*
* このコードは自動生成してますので触るべからず
* 要素を追加したい場合は対象にByteCommandBinding属性を付けた後
* [ビルド] -> [すべてのT4テンプレートの変換]を実行してください
* By Kento Suzuki
*/

using System;
using System.Collections.Generic;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command {

	/// <summary>
	/// 初期化処理分離
	/// </summary>
	public static partial class CommandProcessorFactory {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		static CommandProcessorFactory() {
			// マッピング作る
			var tmp = new Dictionary<OrderPattern, Func<CommandProcessorBase>>() {
				{ OrderPattern.BROADCAST_GLOBAL , ()=> new Taurus.Network.Server.Command.Processor.CmdBloadCastGlobal() },
				{ OrderPattern.BROADCAST_LOBBY , ()=> new Taurus.Network.Server.Command.Processor.CmdBloadCastLobby() },
				{ OrderPattern.BROADCAST_ROOM , ()=> new Taurus.Network.Server.Command.Processor.CmdBloadCastRoom() },
				{ OrderPattern.COMMIT_SUPPORT_TICKET , ()=> new Taurus.Network.Server.Command.Processor.CmdCommitSupportTicketAsync() },
				{ OrderPattern.CREATE_ROOM , ()=> new Taurus.Network.Server.Command.Processor.CmdCreateRoom() },
				{ OrderPattern.CREATE_USER , ()=> new Taurus.Network.Server.Command.Processor.CmdCreateUserAsync() },
				{ OrderPattern.GET_LOBBYS_AND_ME , ()=> new Taurus.Network.Server.Command.Processor.CmdGetLobbysAndMe() },
				{ OrderPattern.GET_LOBBY_PLAYERS , ()=> new Taurus.Network.Server.Command.Processor.CmdGetLobbyPlayers() },
				{ OrderPattern.GET_ROOMS , ()=> new Taurus.Network.Server.Command.Processor.CmdGetRooms() },
				{ OrderPattern.JOIN_LOBBY , ()=> new Taurus.Network.Server.Command.Processor.CmdJoinLobby() },
				{ OrderPattern.JOIN_ROOM , ()=> new Taurus.Network.Server.Command.Processor.CmdJoinRoom() },
				{ OrderPattern.LEAVE_LOBBY , ()=> new Taurus.Network.Server.Command.Processor.CmdLeaveLobby() },
				{ OrderPattern.LEAVE_ROOM , ()=> new Taurus.Network.Server.Command.Processor.CmdLeaveRoom() },
				{ OrderPattern.LOGIN , ()=> new Taurus.Network.Server.Command.Processor.CmdLoginAsync() },
				{ OrderPattern.REQUIRE_TREE , ()=> new Taurus.Network.Server.Command.Processor.CmdRequireTreeAsync() },
				{ OrderPattern.REQUIRE_TREE_DATA , ()=> new Taurus.Network.Server.Command.Processor.CmdRequireTreeDataAsync() },
				{ OrderPattern.REQUIRE_TREE_DATAS , ()=> new Taurus.Network.Server.Command.Processor.CmdRequireTreeDatasAsync() },
				{ OrderPattern.SAVE_INFO , ()=> new Taurus.Network.Server.Command.Processor.CmdSaveInfoAsync() },
				{ OrderPattern.SAVE_READ , ()=> new Taurus.Network.Server.Command.Processor.CmdSaveReadAsync() },
				{ OrderPattern.SAVE_WRITE , ()=> new Taurus.Network.Server.Command.Processor.CmdSaveWriteAsync() },
				{ OrderPattern.SEND_TARGET , ()=> new Taurus.Network.Server.Command.Processor.CmdSendTarget() },
				{ OrderPattern.SET_MYCONFIG , ()=> new Taurus.Network.Server.Command.Processor.CmdSetMyConfig() },
				{ OrderPattern.UNKNOWN , ()=> new Taurus.Network.Server.Command.Processor.CmdUnknown() },
				{ OrderPattern.UPDATE_TREE , ()=> new Taurus.Network.Server.Command.Processor.CmdUpdateTreeAsync() },
				{ OrderPattern.UPDATE_TREE_DATA , ()=> new Taurus.Network.Server.Command.Processor.CmdUpdateTreeDataAsync() },
				{ OrderPattern.WAITTIME_GET_LOBBY , ()=> new Taurus.Network.Server.Command.Processor.CmdWaitTimeGetLobby() },
				{ OrderPattern.WAITTIME_UPLOAD_LOBBY , ()=> new Taurus.Network.Server.Command.Processor.CmdWaitTimeUploadLobby() },
			};

			// パターン登録
			FactoryPattern = new System.Collections.ObjectModel.ReadOnlyDictionary<OrderPattern, Func<CommandProcessorBase>>(tmp);
		}
	}
}
