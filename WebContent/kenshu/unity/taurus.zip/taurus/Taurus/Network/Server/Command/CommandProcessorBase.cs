﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command {


	/// <summary>
	/// 処理するべきコマンドの抽象クラス
	/// </summary>
	public abstract class CommandProcessorBase {

		/// <summary>
		/// ユーザーのインスタンス
		/// </summary>
		protected IRemoteUser User;

		/// <summary>
		/// オーダー内容
		/// </summary>
		protected Order Order;

		/// <summary>
		/// メインロジックの参照
		/// </summary>
		public IMainLogic Logic;

		/// <summary>
		/// この処理を行う上でログインしている必要があるか
		/// </summary>
		public virtual bool IsLoginRequire => true;

		/// <summary>
		/// この内容は急いで送信する必要があるか否か
		/// </summary>
		public virtual bool IsFastResponce => false;

		/// <summary>
		/// 送信するべきメッセージ
		/// 但しOrderResponceの返答の後に行うべし
		/// </summary>
		public IEnumerable<Message> messageBuffer = null;

		/// <summary>
		/// 初期化
		/// </summary>
		/// <param name="order">オーダー</param>
		/// <param name="user">対象のユーザー情報</param>
		internal void Init(IRemoteUser user, Order order) {
			this.User = user;
			this.Order = order;
		}

		/// <summary>
		/// オーダー実行(内部用)
		/// </summary>
		/// <returns>返答するべき内容</returns>
		protected abstract OrderResponceBase InternalExect();

		/// <summary>
		/// オーダー実行
		/// </summary>
		/// <returns>返答すべき内容</returns>
		public OrderResponceBase Exect() {
			return InternalExect();
		}

		/// <summary>
		/// 応答文を生成
		/// </summary>
		/// <typeparam name="T">生成するべき型</typeparam>
		/// <returns>応答用インスタンス</returns>
		internal T CreateResponce<T>(Action<T> init = null) where T : OrderResponceBase, new() {
			return CreateResponce<T>(OrderResponcePattern.UNKNOWN, init);
		}

		/// <summary>
		/// 応答文を生成
		/// </summary>
		/// <typeparam name="T">生成するべき型</typeparam>
		/// <returns>応答用インスタンス</returns>
		internal T CreateResponce<T>(OrderResponcePattern pattern, Action<T> init = null) where T : OrderResponceBase, new() {
			var ret = new T() { EntityID = Order.EntityID, Responce = pattern };
			init?.Invoke(ret);
			return ret;
		}

		/// <summary>
		/// 正常完了した応答文を生成
		/// </summary>
		/// <typeparam name="T">生成するべき型</typeparam>
		/// <param name="init">初期化処理が必要であれば記載する</param>
		/// <returns>応答用インスタンス</returns>
		internal T CreateOKResponce<T>(Action<T> init = null) where T : OrderResponceBase, new() {
			return CreateResponce<T>(OrderResponcePattern.OK, init);
		}

		/// <summary>
		/// 応答文を生成
		/// </summary>
		/// <typeparam name="T">生成するべき型</typeparam>
		/// <returns>応答用インスタンス</returns>
		internal NonParamResponce CreateResponce() {
			return CreateResponce(OrderResponcePattern.UNKNOWN);
		}

		/// <summary>
		/// 応答文を生成
		/// </summary>
		/// <typeparam name="T">生成するべき型</typeparam>
		/// <returns>応答用インスタンス</returns>
		internal NonParamResponce CreateResponce(OrderResponcePattern pattern) {
			return CreateResponce<NonParamResponce>(pattern);
		}

		/// <summary>
		/// 正常完了した応答文を生成
		/// </summary>
		/// <typeparam name="T">生成するべき型</typeparam>
		/// <returns>応答用インスタンス</returns>
		internal NonParamResponce CreateOKResponce() {
			return CreateResponce(OrderResponcePattern.OK);
		}

		/// <summary>
		/// メッセージをキューイング
		/// </summary>
		/// <param name="msg">キューに入れるメッセージ</param>
		/// <returns>nullなら残念</returns>
		internal bool TryEnqueueMessage(Message msg) {

			// nullじゃなきゃとりあえず送れる
			if (msg != null) {
				User.EnqueueMessage(msg);
				return true;
			}
			return false;
		}

		/// <summary>
		/// メッセージをキューイング
		/// </summary>
		/// <param name="msg">キューに入れるメッセージ</param>
		/// <returns>nullなら残念</returns>
		internal bool TryEnqueueMessage(IEnumerable<Message> msg) {

			// nullじゃなきゃとりあえず送れる
			if (msg != null) {

				// 送信予定が空いていれば新規
				if (messageBuffer == null) {
					messageBuffer = msg;
				} else {
					// すでに何かあればその後ろにくっつける
					messageBuffer = messageBuffer.Concat(msg);
				}
				return true;
			}
			return false;
		}

	}
	
	/// <summary>
	/// ペイロードを必要とする場合のコマンド処理
	/// </summary>
	/// <typeparam name="T">要求するペイロード</typeparam>
	public abstract class CommandProcessorBase<T> : CommandProcessorBase where T : OrderPayloadBase {

		/// <summary>
		/// ユーザーから送られてきたデータの検証を行いつつ同期的に続行
		/// </summary>
		/// <returns>返答すべき内容</returns>
		protected sealed override OrderResponceBase InternalExect() {
			
			if (Order.OrderData is T Payload) {
				// キャスト可能なので普通に続行
				return InternalExect(Payload);
			} else {
				// キャストできないのでペイロードがおかしい
				return CreateResponce(OrderResponcePattern.FAILED_CAUSE_UNKNOWN);
			}
		}

		/// <summary>
		/// ユーザーからデータが送られてきた時の処理
		/// </summary>
		/// <param name="Payload">送られてきた内容</param>
		/// <returns>返答すべき内容</returns>
		protected abstract OrderResponceBase InternalExect(T Payload);


	}
	
}
