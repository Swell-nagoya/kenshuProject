﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ツリーデータのノードデータ一件参照
	/// </summary>
	[ByteCommandBinding(OrderPattern.REQUIRE_TREE_DATA)]
	public class CmdRequireTreeDataAsync : CommandProcessorBaseAsync<RequireTreeData> {

		/// <summary>
		/// ツリーノードデータ参照
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(RequireTreeData Payload, CancellationToken token) {

			// セーブ情報参照
			var treeData = await DBInterface.ReadTreeDataAsync(User.DbUserInfo, Payload.IsntanceID).ConfigureAwait(false);

			// 失敗チェック
			if (treeData == null) {
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}

			// 成功
			return CreateOKResponce<RequireTreeDataResponce>(e => e.Data = treeData);
		}
	}
}

