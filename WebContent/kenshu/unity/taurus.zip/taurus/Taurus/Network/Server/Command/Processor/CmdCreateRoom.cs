﻿using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ルーム作成
	/// </summary>
	[ByteCommandBinding(OrderPattern.CREATE_ROOM)]
	public class CmdCreateRoom : CommandProcessorBase<CreateRoomOrder> {

		/// <summary>
		/// ルーム作成
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override OrderResponceBase InternalExect(CreateRoomOrder Payload) {
			// 部屋を作る場合はロビーに入っていなければならない
			if (User.JoinedLobby == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			} else {
				// ルーム作る
				RoomManagera NewRoomIns = User.JoinedLobby.AddRoom(Payload);

				// できたかチェック
				if (TryEnqueueMessage(NewRoomIns?.Add(User))) {
					// クライアントに素敵な情報を返す
					return CreateOKResponce<CreateRoomResponce>(e => e.info = (RoomInfo)NewRoomIns.CreateInfo());
				} else {
					// だめやで
					return CreateResponce(OrderResponcePattern.FAILED_FORBIDDEN);
				}
			}
		}
	}
}

