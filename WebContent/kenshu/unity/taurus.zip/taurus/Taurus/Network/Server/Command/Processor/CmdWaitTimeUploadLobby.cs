﻿using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	// <summary>
	/// ロビーに現在の待ち時間をアップロードする(ｸｿ)
	/// </summary>
	[ByteCommandBinding(OrderPattern.WAITTIME_UPLOAD_LOBBY)]
	public class CmdWaitTimeUploadLobby : CommandProcessorBase<UploadLobbyWaitTime> {

		/// <summary>
		/// 待ち時間アップロード
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override OrderResponceBase InternalExect(UploadLobbyWaitTime Payload) {
			// ロビー接続チェック
			if (User.JoinedLobby == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}

			// 接続してるみたいなので値を設定
			User.JoinedLobby.AddAverageTime(Payload.MyWaitTime.Ticks);
			return CreateOKResponce();
		}
	}
}

