﻿using System.Linq;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ルームに参加したい
	/// </summary>
	[ByteCommandBinding(OrderPattern.JOIN_ROOM)]
	public class CmdJoinRoom : CommandProcessorBase<JoinRoomOrder> {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect(JoinRoomOrder Payload) {
			// ロビー参加チェック
			if (User.JoinedLobby == null) {
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}

			// ルーム参加チェック
			if (User.JoinedRoom != null) {
				return CreateResponce(OrderResponcePattern.FAILED_FORBIDDEN);
			}


			// ルーム検索
			RoomManagera room = User.JoinedLobby.GetRooms().Where(e => e.EntityID == Payload.TargetEntityID).FirstOrDefault();

			// ルーム発見チェック
			if (room != null) {

				// 参加試行し参加失敗をチェック
				if (!TryEnqueueMessage(room.Add(User))) {
					// ルームから拒否された
					return CreateResponce(OrderResponcePattern.FAILED_ROOM_CAPACITY_OVER);
				}

			} else {
				// そのようなルームは存在しない
				return CreateResponce(OrderResponcePattern.FAILED_TARGET_NOT_FOUND);
			}

			// よさげ
			return CreateOKResponce();
		}
	}
}

