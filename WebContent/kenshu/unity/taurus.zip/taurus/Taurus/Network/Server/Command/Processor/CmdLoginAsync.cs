﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ログイン
	/// </summary>
	[ByteCommandBinding(OrderPattern.LOGIN)]
	public class CmdLoginAsync : CommandProcessorBaseAsync<LoginOrder> {

		/// <summary>
		/// コマンドの実行にログインを要求しない
		/// </summary>
		public override bool IsLoginRequire => false;

		/// <summary>
		/// ログイン実行
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(LoginOrder Payload, CancellationToken token) {
			// ログイン状況が不明もしくはすでに指定IDでログインしているやつが居たら中止
			if (MainLogicSync.Instance.Users.Where(e => e.DbUserInfo != null).
				// PK三兄弟を比較
				Where(e => e.DbUserInfo.application_id == Payload.AppId).
				Where(e => e.DbUserInfo.developer_id == Payload.DevID).
				Where(e => e.DbUserInfo.user_id == Payload.UserID).
				Any()) {
				return CreateResponce(OrderResponcePattern.FAILED_FORBIDDEN);
			} else {
				// データベースに問い合わせを行う
				var Result = await DBInterface.UserLoginAsync(Payload).ConfigureAwait(false);

				// ログインチェック
				if (Result == null) {
					// 指定のログイン情報でアクセスできるリソースは存在しない
					return CreateResponce(OrderResponcePattern.FAILED_TARGET_NOT_FOUND);
				}

				// 値を覚えておく
				User.DbUserInfo = Result;

				// 成功
				return CreateOKResponce();
			}
		}
	}
}

