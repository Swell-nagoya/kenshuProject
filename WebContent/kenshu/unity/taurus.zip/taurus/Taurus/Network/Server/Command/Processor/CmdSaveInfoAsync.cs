﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// バイナリセーブデータインデックス参照
	/// </summary>
	[ByteCommandBinding(OrderPattern.SAVE_INFO)]
	public class CmdSaveInfoAsync : CommandProcessorBaseAsync<SaveInfoOrder> {

		/// <summary>
		/// セーブ書き込み
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(SaveInfoOrder Payload, CancellationToken token) {
			// セーブ情報参照
			var info = await DBInterface.DataInfo(User.DbUserInfo.application_id, User.DbUserInfo.developer_id, Payload.TargetUserID).ConfigureAwait(false);

			// 失敗してないか調べる
			if (info == null) {
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}

			return CreateOKResponce<SaveInfoResponce>(e => e.Sequences = info);

		}
	}
}

