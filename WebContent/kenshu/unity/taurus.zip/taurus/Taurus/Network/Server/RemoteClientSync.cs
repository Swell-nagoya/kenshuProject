﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.DB.Util;
using Taurus.Network.Common;
using Taurus.Network.Connection;
using Taurus.Network.Server.Command;
using Taurus.Util;

namespace Taurus.Network.Server {

	/// <summary>
	/// 同期型リモートクライアント
	/// </summary>
	public class RemoteClientSync : IDisposable, IRemoteUser {

		/// <summary>
		/// 生存フラグ
		/// </summary>
		public bool IsAlive { get; private set; } = true;

		/// <summary>
		/// データベース上のユーザー情報
		/// </summary>
		public d_user DbUserInfo { get; set; }

		/// <summary>
		/// 接続中のロビー
		/// </summary>
		public LobbyManagera JoinedLobby { get; set; }

		/// <summary>
		/// 接続中のルーム
		/// </summary>
		public RoomManagera JoinedRoom { get; set; }

		/// <summary>
		/// エンティティなID
		/// </summary>
		public Guid EntityID { get; }

		/// <summary>
		/// タイムアウト用タイマー
		/// </summary>
		private DateTime lastReceiveTime = DateTime.Now;

		/// <summary>
		/// 通信用インスタンス
		/// </summary>
		private SocketConductor Com = null;

		/// <summary>
		/// 送信キュー
		/// </summary>
		private readonly Queue<Message> SendQueue = new Queue<Message>();

		/// <summary>
		/// 受信キュー
		/// </summary>
		private readonly Queue<Message> ReceiveQueue = new Queue<Message>();

		/// <summary>
		/// 緊急送信メッセージ
		/// </summary>
		private Message[] emergencySendMessages = null;

		/// <summary>
		/// メッセージ一つ処理するルーチン
		/// </summary>
		private IEnumerator messageExectRoutine;

		/// <summary>
		/// メッセージ送信ルーチン
		/// </summary>
		private IEnumerator sendRoutine;

		/// <summary>
		/// キャンセル処理用
		/// </summary>
		private CancellationTokenSource abort = new CancellationTokenSource();

		/// <summary>
		/// メッセージ制御用
		/// </summary>
		private MessageSequenceControl msgControl = new MessageSequenceControl();

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="EntityID">EntityのID</param>
		public RemoteClientSync(Guid EntityID) {
			this.EntityID = EntityID;
			sendRoutine = SendFunc();
		}


		/// <summary>
		/// 毎フレーム処理
		/// </summary>
		public void Update() {
			// 生存チェック
			if (!IsAlive) {
				return;
			}

			// 通信用インスタンス生存チェック
			if ((!Com?.IsAlive) ?? true) {

				// 死んでいる状況でアプリケーションタイムアウトを検出したら死ぬ
				if (lastReceiveTime.IsTimeOutMs(Config.AppTimeout)) {
					IsAlive = false;
					return;
				}

				return;
			}


			// 通信インスタンスが格納してる受信キューを吸い上げる
			while (Com.TryeGetMessage(out Message msg)) {
				ReceiveQueue.Enqueue(msg);
			}

			// メッセージ処理ルーチン死亡チェック
			if (((!messageExectRoutine?.MoveNext()) ?? true) && ReceiveQueue.Any()) {

				// 死んでいて作れるのであれば次を作る
				messageExectRoutine = MessageExect(ReceiveQueue.Dequeue());
			}

			// 送信ルーチンもぶん回す
			sendRoutine.MoveNext();


		}


		/// <summary>
		/// メッセージ一件実行
		/// </summary>
		/// <param name="msg">受信したメッセージ</param>
		/// <returns>コルーチン</returns>
		private IEnumerator MessageExect(Message msg) {
			// とにかく何か受信した
			lastReceiveTime = DateTime.Now;


			// 内容に応じて分岐
			switch (msg?.SignalType ?? Signal.UNKNOWN) {

				// オーダー実行
				case Signal.ORDER:

					// オーダーを生成
					var order = (Order)JsonSelializerUtil.Import(msg.Payload);

					// コマンドを生成
					CommandProcessorBase com = CommandProcessorFactory.Create(order, this);

					// メインロジック
					com.Logic = MainLogicSync.Instance;

					// 送り返す用
					OrderResponceBase ret = null;

					// コマンド実行
					if (com is CommandProcessorBaseAsync comAsync) {

						// 時間のかかる処理はTaskに入れて完了待機を行う
						var task = Task.Run(async () => await comAsync.ExectAsync(abort.Token));

						// Taskの完了を待機する
						while (task.IsRunning()) { yield return null; }

						// 完了したので値を取り出す
						ret = task.Result;

					} else {
						// すぐに終わるならすぐやる
						ret = com.Exect();
					}

					// 返すべきメッセージを生成
					Message retmsg = Message.CreateMessages(ret, Signal.ORDER_RESPONCE);


					// 送信するべきメッセージをまとめて送信
					if (com.messageBuffer == null) {

						// 返答のみ
						EnqueueMessage(retmsg, com.IsFastResponce);

					} else {
						// メッセージが付属しているようなのでまとめる
						EnqueueMessage(new Message[] { retmsg }.Concat(com.messageBuffer), com.IsFastResponce);
					}


					yield break;


				// 生存報告
				case Signal.LIVING_SIG:
					// 特に何かしなければならないことはない
					yield break;

				// 切断
				case Signal.CLOSE:
					Logger.Log($"切断要求を受け付けました ({EntityID})");
					IsAlive = false;
					yield break;


				// シーケンス受信承認
				case Signal.SEQUENCE_ACK:
					// メッセージサイズから承認件数を推定
					int seqCount = msg.Payload.Length / Message.MESSAGE_SEQUENCE_NUMBER_SIZE;

					// 承認されたすべてのメッセージを制御インスタンスから消す
					for (int i = 0; i < seqCount; i++) {
						msgControl.Remove(BinaryUtil.ToUInt16(msg.Payload, Message.MESSAGE_SEQUENCE_NUMBER_SIZE * i));
					}

					yield break;

				// その他
				default:
					// 処理できないのでメッセージ出して終わる
					Logger.Caution($"処理できないメッセージを検出したため切断します ({EntityID} > Signal:{(msg?.SignalType ?? Signal.UNKNOWN).ToString()}) [{((byte?)msg?.SignalType)?.ToString("X") ?? "NULL"}]");

					// 捨てる
					Com.Dispose();

					// 通信インスタンスが格納してる受信キューを吸い上げる
					while (Com.TryeGetMessage(out Message tmp)) {
						ReceiveQueue.Enqueue(tmp);
					}

					yield break;
			}
		}

		/// <summary>
		/// 通信用インスタンスをバインド
		/// </summary>
		/// <param name="Com">通信用インスタンス</param>
		public void Bind(SocketConductor Com) {

			// 古いソケットがあるか確認
			if (this.Com != null) {
				// インスタンス解放
				this.Com.Dispose();

				// まだ受理されていないメッセージがあればこの段階で緊急メッセージとして記録する
				emergencySendMessages = msgControl.GetRegestedMessage();

			}

			// 記録する
			this.Com = Com;
		}

		/// <summary>
		/// 送信処理
		/// </summary>
		/// <returns>コルーチン</returns>
		private IEnumerator SendFunc() {

			while (IsAlive) {

				// 通信用インスタンス
				SocketConductor tmpCom;

				// 送信用インスタンスが使用可能になるまで待機
				while ((!(tmpCom = Com)?.IsAlive) ?? true) { yield return null; }


				// 緊急送信メッセージチェック
				if (emergencySendMessages != null) {

					// 緊急送信！
					var msgstmp = emergencySendMessages;
					emergencySendMessages = null;



					// 全件送信キューにぶち込む
					foreach (var msg in msgstmp) {
						Logger.Important($"EMG SEND:{msg.SequenceNumber}");
						tmpCom.EnqueueSendMessage(msg);
					}


				}

				// キューから取り出せるかチェック
				if (SendQueue.Any()) {

					// キューから取り出し
					Message msg = SendQueue.Dequeue();

					// メッセージを記録
					msgControl.Regest(ref msg);

					// 送信中フラグ
					bool isSending = true;

					// 送信開始
					tmpCom.EnqueueSendMessage(msg, () => isSending = false);

					// 送信完了か通信インスタンスの死亡を待機
					while (tmpCom.IsAlive && isSending) { yield return null; }
				}

				// ちょいまち
				yield return null;
			}


			yield break;
		}

		/// <summary>
		/// ユーザー情報を作成
		/// </summary>
		/// <returns>作成された情報</returns>
		public UserEntityInfo CreateInfo() {
			return new UserEntityInfo() {
				EntityID = EntityID,
				UserID = DbUserInfo.user_id,
				About = DbUserInfo.ConvertToAboutUser()
			};
		}

		/// <summary>
		/// 送信メッセージをキューイング
		/// </summary>
		/// <param name="msg">送信するべきメッセージ</param>
		/// <param name="isFastSend">急ぎの用事であるか(無視されます)</param>
		public void EnqueueMessage(Message msg, bool isFastSend = false) {
			SendQueue.Enqueue(msg);
		}

		/// <summary>
		/// 送信メッセージをキューイング
		/// </summary>
		/// <param name="msgs">送信するべきメッセージ</param>
		/// <param name="isFastSend">急ぎの用事であるか(無視されます)</param>
		public void EnqueueMessage(IEnumerable<Message> msgs, bool isFastSend = false) {
			foreach (var msg in msgs) {
				SendQueue.Enqueue(msg);
			}
		}

		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。
					Com?.Dispose();
					IsAlive = false;


					// 接続しているロビーやルームがあれば抜ける
					JoinedRoom?.Leave(this);
					JoinedLobby?.Leave(this);

					Logger.Log($"ユーザーを破棄します [{EntityID.ToString()}]");

				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。

				disposedValue = true;
			}
		}

		// TODO: 上の Dispose(bool disposing) にアンマネージ リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
		// ~RC2() {
		//   // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
		//   Dispose(false);
		// }

		// このコードは、破棄可能なパターンを正しく実装できるように追加されました。
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			// GC.SuppressFinalize(this);
		}


		#endregion


	}
}
