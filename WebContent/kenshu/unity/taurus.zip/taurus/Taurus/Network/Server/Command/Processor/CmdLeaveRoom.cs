﻿using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ルームから出たい
	/// </summary>
	[ByteCommandBinding(OrderPattern.LEAVE_ROOM)]
	public class CmdLeaveRoom : CommandProcessorBase {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect() {
			// 部屋から抜ける
			if (User.JoinedRoom != null) {
				User.JoinedRoom.Leave(User);
			} else {
				// ルームに参加していないがために失敗
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_ROOM);
			}

			// よさげ
			return CreateOKResponce();
		}
	}
}

