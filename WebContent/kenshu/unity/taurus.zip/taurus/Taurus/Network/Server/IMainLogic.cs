﻿using System.Collections.Generic;

namespace Taurus.Network.Server {
	/// <summary>
	/// メインロジックとして利用できるインスタンス
	/// </summary>
	public interface IMainLogic {
		/// <summary>
		/// ロビーの一覧
		/// </summary>
		LobbyManagera[] Lobbys { get; }
		/// <summary>
		/// ユーザーの一覧
		/// </summary>
		IEnumerable<IRemoteUser> Users { get; }
	}
}