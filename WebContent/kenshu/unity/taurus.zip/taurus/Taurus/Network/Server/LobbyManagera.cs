﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Taurus.Data.Network;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server {
	/// <summary>
	/// ロビー制御
	/// </summary>
	public class LobbyManagera : UserGroupBase {

		/// <summary>
		/// 過去何件分の記録まで待ち時間平均に加味するか
		/// </summary>
		private const uint WaitLogSize = 10;

		/// <summary>
		/// 平均待ち時間(内部処理用)
		/// </summary>
		private long AverageWaitTimeInternal = 0;

		/// <summary>
		/// 平均待ち時間
		/// </summary>
		public long AverageWaitTime { get => Interlocked.Read(ref AverageWaitTimeInternal); private set => Interlocked.Exchange(ref AverageWaitTimeInternal, value); }
		/// <summary>
		/// 平均待ち時間計算用
		/// </summary>
		private long[] WaitTimeLog = new long[WaitLogSize];

		/// <summary>
		/// 平均計算カウンタ
		/// </summary>
		private uint WaitTimeLogCounter = 0;
		
		/// <summary>
		/// ルーム一覧
		/// </summary>
		private readonly List<RoomManagera> Rooms = new List<RoomManagera>();

		/// <summary>
		/// データベース上での情報
		/// </summary>
		public readonly m_lobby DBInfo;

		/// <summary>
		/// ブロードキャストするときのsignal
		/// </summary>
		protected override Signal BroadcastSignal => Signal.LOBBY_BROADCAST;


		/// <summary>
		/// ユーザー追加
		/// </summary>
		/// <param name="User">追加するべきユーザー</param>
		public override Message[] Add(IRemoteUser User) {

			// ログイン状況チェック
			if (User.DbUserInfo == null || User.DbUserInfo.application_id != DBInfo.application_id || User.DbUserInfo.developer_id != User.DbUserInfo.developer_id) {
				return null;
			}

			// 参加させる
			User.JoinedLobby = this;

			// 追加に関するメッセージ一覧を受け取りルーム一覧情報とくっつける
			IEnumerable<Message>[] msg = {
				base.Add(User) , // baseクラスの戻り値
				GetRooms().Select(e=>Message.CreateMessages(e.CreateInfo(),Signal.LOBBY_ADD_ROOM)), // ルーム一覧を通知するメッセージ
			};

			// 配列にして返す
			return msg.SelectMany(e => e).ToArray();
		}

		/// <summary>
		/// ユーザー退出
		/// </summary>
		/// <param name="User">退出するべき</param>
		public override void Leave(IRemoteUser User) {
			base.Leave(User);
			User.JoinedLobby = null;
		}


		/// <summary>
		/// ルーム作成
		/// </summary>
		/// <param name="Info">ルーム作成情報</param>
		/// <returns>作成したインスタンス or 失敗時null</returns>
		public RoomManagera AddRoom(CreateRoomOrder Info) {
			// 作成
			RoomManagera ret = RoomManagera.Create(this, Info);

			// 失敗チェック
			if (ret == null) { return null; }

			lock (Rooms) {
				// 一覧に追加	
				Rooms.Add(ret);
			}


			// ロビーに部屋が増えたことを知らしめるべく全体送信
			AddRoomMessage(ret);

			// 返す
			return ret;
		}

		/// <summary>
		/// 部屋が消える
		/// </summary>
		/// <param name="Room"></param>
		internal void RemoveRoom(RoomManagera Room) {



			lock (Rooms) {
				// 一覧から撤去
				Rooms.Remove(Room);
			}

			// お知らせ
			RemoveRoomMessage(Room);
		}

		/// <summary>
		/// 待ち時間を追加
		/// </summary>
		/// <param name="tick">待った時間</param>
		public void AddAverageTime(long tick) {
			lock (WaitTimeLog) {
				// ログに追記
				WaitTimeLog[(WaitTimeLogCounter++) % WaitLogSize] = tick;

				// 平均待ち時間を算出
				AverageWaitTime = WaitTimeLog.Sum() / WaitLogSize;
			}
		}

		/// <summary>
		/// ルーム一覧参照
		/// </summary>
		public RoomManagera[] GetRooms() {

			lock (Rooms) {
				// 返す
				return Rooms.ToArray();
			}
		}

		/// <summary>
		/// ルーム数を調べる
		/// </summary>
		/// <returns>ルーム数</returns>
		public int RoomCount() {
			lock (Rooms) {
				return Rooms.Count();
			}
		}

		/// <summary>
		/// 初期化
		/// </summary>
		/// <param name="DBInfo">DBでの情報</param>
		public LobbyManagera(m_lobby DBInfo) {
			this.DBInfo = DBInfo;
			Logger.Log($"ロビーが作成されました : [{DBInfo.name}], Application:[{DBInfo.application_id}], Developer:[{DBInfo.developer_id}], EntityID : [{EntityID}]");
		}

		/// <summary>
		/// ユーザー参加
		/// </summary>
		/// <param name="client">増えた奴</param>
		protected override Message UserJoinMessage(UserEntityInfo client) {
			return Message.CreateMessages(client, Signal.LOBBY_ADD_USER);
		}

		/// <summary>
		/// ユーザー退場
		/// </summary>
		/// <param name="client">減った奴</param>
		protected override Message UserLeaveMessage(UserEntityInfo client) {
			return Message.CreateMessages(client, Signal.LOBBY_DEL_USER);
		}

		/// <summary>
		/// ルームが増えたメッセージ用
		/// </summary>
		/// <param name="info">増えたルーム</param>
		private void AddRoomMessage(RoomManagera Room) { BroadcastMessage(Message.CreateMessages(Room.CreateInfo(), Signal.LOBBY_ADD_ROOM)); }

		/// <summary>
		/// ルームが減ったメッセージ用
		/// </summary>
		/// <param name="info">減ったルーム</param>
		private void RemoveRoomMessage(RoomManagera Room) { BroadcastMessage(Message.CreateMessages(Room.CreateInfo(), Signal.LOBBY_DEL_ROOM)); }

		/// <summary>
		/// 情報作成
		/// </summary>
		/// <returns>作成された情報</returns>
		public override UserGroupInfoBase CreateInfo() {
			return new LobbyInfo() {
				EntityID = EntityID,
				MaxUsers = DBInfo.max_room_menber,
				MaxRooms = 65535, // TODO:DBに焼け
				RoomCount = RoomCount(),
				Name = DBInfo.name,
				NowUsers = GetUserCount()
			};
		}
	}
}
