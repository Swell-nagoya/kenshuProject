﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.DB;
using Taurus.Network.Connection;
using Taurus.Util;

namespace Taurus.Network.Server {

	/// <summary>
	/// 同期型メインロジック
	/// </summary>
	public class MainLogicSync : IMainLogic {

		/// <summary>
		/// インスタンス保持用
		/// </summary>
		private static MainLogicSync Instance_;

		/// <summary>
		/// メインロジックインスタンス参照用
		/// </summary>
		public static MainLogicSync Instance { get => Instance_ ?? (Instance_ = new MainLogicSync()); }

		/// <summary>
		/// ロビー一覧
		/// </summary>
		public LobbyManagera[] Lobbys { get; private set; }

		/// <summary>
		/// ユーザー一覧
		/// </summary>
		public IEnumerable<IRemoteUser> Users => EntryUsers.ToArray().Select(e => e.Value);

		/// <summary>
		/// 接続者名簿
		/// </summary>
		private readonly ConcurrentDictionary<Guid, RemoteClientSync> EntryUsers = new ConcurrentDictionary<Guid, RemoteClientSync>();

		/// <summary>
		/// バインド待機
		/// </summary>
		private readonly List<SocketConductor> bindWaitSockets = new List<SocketConductor>();

		/// <summary>
		/// ソケット一覧
		/// </summary>
		private readonly List<SocketConductor> sockets = new List<SocketConductor>();

		/// <summary>
		/// 停止フラグ
		/// </summary>
		private bool abortFlg = false;

		/// <summary>
		/// 停止する
		/// </summary>
		public void Abort() {

			abortFlg = true;
		}

		/// <summary>
		/// コンストラクタは外から触れない
		/// </summary>
		private MainLogicSync() {
			nowRoutine = Routine();


			Logger.Log("DB参照");

			// DBからロビー情報を得る
			using (Task<m_lobby[]> lobbySelect = DBInterface.SelectLobbysAsync()) {
				// 終了待機
				Task.Run(async () => await lobbySelect).Wait();

				// ロビーをすべて登録する
				Lobbys = lobbySelect.Result.Select(e => new LobbyManagera(e)).ToArray();
			}

		}
		
		/// <summary>
		/// 現在実行中のルーチン
		/// </summary>
		private IEnumerator nowRoutine;

		/// <summary>
		/// 毎回処理
		/// </summary>
		/// <returns>正常稼働時ture</returns>
		public bool Update() {
			if (!nowRoutine.MoveNext()) {
				// コルーチンが止まったらいろいろ停止
				abortFlg = true;
				return false;
			}

			return true;
		}

		/// <summary>
		/// メインルーチン
		/// </summary>
		private IEnumerator Routine() {

			// 待機用リスナー起動
			var Soc = new TcpListener(IPAddress.IPv6Any, Common.Config.Port);

			// IPv4でもｲｲﾖ
			Soc.Server.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.IPv6Only, false);

			// 待ち始める
			Soc.Start();

			// 死すべき人々の一覧
			List<Guid> killers = new List<Guid>();


			Logger.Important("メインロジック開始");

			while (!abortFlg) {
				try {
					if (Soc.Pending()) {

						// ソケットを待機処理一覧とソケット一覧に入れるに投げつける
						var soc = new SocketConductor(Soc.AcceptSocket());
						bindWaitSockets.Add(soc);
						sockets.Add(soc);

					}
				} catch (Exception e) {
					// 何か失敗した
					Logger.Warning(e);
				}

				// 全てのソケットを実行
				sockets.RemoveAll(e => {
					try {

						e.Invoke();
						return !e.IsAlive;
					} catch (Exception f) {
						// 例外が出たらこれは死者
						Logger.Caution(f);
						e.IsAlive = false;
						return true;
					}
				});

				// 接続待機一覧からバインドできる人を探してバインド
				bindWaitSockets.RemoveAll(e => {

					try {

						// 死んでるソケットは処理しない
						if (!e.IsAlive) { return true; }

						if (e.EntityID != default(Guid)) {

							// バインド対象を検索
							var target = EntryUsers.GetOrAdd(e.EntityID, (f) => new RemoteClientSync(f));

							Logger.Log($"接続とリモートユーザーを関連付けます({e.Remote} to {e.EntityID})");

							// バインド実行
							target.Bind(e);

							return true;
						}

						return false;
					}catch(Exception f) {
						// なんかしくじった
						Logger.Caution(f);
						return false;
					}
				});

				// 全ユーザーの処理を行う
				foreach (var user in EntryUsers) {
					// 処理を実行
					try {
						user.Value.Update();

						// 死者を検出
						if (!user.Value.IsAlive) {
							killers.Add(user.Value.EntityID);
						}
					} catch (Exception e) {
						// なにか例外が出たら死者として扱う
						Logger.Caution(e);
						killers.Add(user.Value.EntityID);
					}
				}

				// 死者を破棄
				foreach (var killID in killers) {
					if (EntryUsers.TryRemove(killID, out RemoteClientSync user)) {
						try {
							user.Dispose();
						} catch (Exception e) {
							Logger.Warning(e);
						}
					}
				}
				killers.Clear();


				// 状況を報告
				Manipulator.Transponder.RemoteInstance.LobbyCount = Lobbys.Count();
				Manipulator.Transponder.RemoteInstance.UserCount = Users.Count();
				Manipulator.Transponder.RemoteInstance.RoomCount = Lobbys.Select(e=>e.RoomCount()).Sum();


				yield return null;
			}
			

			Logger.Important("メインロジック終了");
			Soc.Stop();

			yield break;
		}
	}
}
