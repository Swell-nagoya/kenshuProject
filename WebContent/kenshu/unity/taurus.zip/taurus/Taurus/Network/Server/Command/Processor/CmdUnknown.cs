﻿using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {

	/// <summary>
	/// 処理できないコマンド
	/// </summary>
	[ByteCommandBinding(OrderPattern.UNKNOWN)]
	public class CmdUnknown : CommandProcessorBase {

		/// <summary>
		/// コマンドの実行にログインを要求しない
		/// </summary>
		public override bool IsLoginRequire => false;

		/// <summary>
		/// 知らんコマンドであることを通達
		/// </summary>
		/// <returns>しらんなぁそんなもん</returns>
		protected override OrderResponceBase InternalExect() {
			// 処理不能であることを通知するインスタンスを作って返す
			return CreateResponce<NonParamResponce>(Common.OrderResponcePattern.UNKNOWN);
		}
	}
}

