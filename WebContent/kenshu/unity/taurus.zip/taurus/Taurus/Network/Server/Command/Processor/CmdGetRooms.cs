﻿using System.Linq;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	/// ロビーのルーム一覧を返す
	/// </summary>
	[ByteCommandBinding(OrderPattern.GET_ROOMS)]
	public class CmdGetRooms : CommandProcessorBase {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect() {

			// ロビーのルーム一覧を返す
			if (User.JoinedLobby != null) {
				return CreateOKResponce<RoomGroupResponce>((e) => e.Rooms = User.JoinedLobby.GetRooms().Select(f => f.CreateInfo()).Cast<RoomInfo>().ToArray());

			} else {
				// ロビーにはいってないから無理
				return CreateResponce(OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}
		}
	}

}
