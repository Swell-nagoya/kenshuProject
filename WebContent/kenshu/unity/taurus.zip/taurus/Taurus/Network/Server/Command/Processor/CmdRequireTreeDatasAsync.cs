﻿using System.Threading;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.DB;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {

	/// <summary>
	/// ツリーデータのノードデータ複数件参照
	/// </summary>
	[ByteCommandBinding(OrderPattern.REQUIRE_TREE_DATAS)]
	public class CmdRequireTreeDatasAsync : CommandProcessorBaseAsync<RequireTreeDatas> {

		/// <summary>
		/// ツリーノードデータ参照
		/// </summary>
		/// <param name="Payload">クライアントから送られてきた内容</param>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>クライアントへの返答内容</returns>
		protected override async Task<OrderResponceBase> InternalExectAsync(RequireTreeDatas Payload, CancellationToken token) {

			// セーブ情報参照
			var treeData = await DBInterface.ReadTreeDataAsync(User.DbUserInfo, Payload.InstanceIDs);

			// 失敗チェック
			if (treeData == null) {
				return CreateResponce(OrderResponcePattern.UNKNOWN);
			}


			// 成功
			return CreateOKResponce<RequireTreeDatasResponce>(e => e.Datas = treeData);
			

		}
	}
}