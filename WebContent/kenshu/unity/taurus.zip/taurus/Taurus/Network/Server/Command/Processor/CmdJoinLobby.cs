﻿using System.Linq;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Server.Command.Processor {
	/// <summary>
	///ロビーに参加したい
	/// </summary>
	[ByteCommandBinding(OrderPattern.JOIN_LOBBY)]
	public class CmdJoinLobby : CommandProcessorBase<JoinLobbyOrder> {

		/// <summary>
		/// 返答を生成
		/// </summary>
		/// <returns>クライアントへの返答内容</returns>
		/// <returns>返すべきメッセージ</returns>
		protected override OrderResponceBase InternalExect(JoinLobbyOrder Payload) {
			// ロビー参加チェック
			if (User.JoinedLobby != null) {
				return CreateResponce(OrderResponcePattern.FAILED_FORBIDDEN);
			}

			// 該当するロビーを検索する
			LobbyManagera target = Logic.
				Lobbys.
				Where(e => e.EntityID == Payload.TargetEntityID).
				FirstOrDefault();

			// 見つかったかチェック
			if (target == null) { 
				return CreateResponce(OrderResponcePattern.FAILED_TARGET_NOT_FOUND);
			}

			// 参加に失敗していないかチェックチェック
			if (!TryEnqueueMessage(target.Add(User))) {
				return CreateResponce(OrderResponcePattern.FAILED_FORBIDDEN);
			}

			// よさげ
			return CreateOKResponce();
		}
	}
}

