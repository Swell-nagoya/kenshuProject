﻿using System.Threading.Tasks;
using Taurus.Network.Common;

namespace Taurus.Network.Server {
	/// <summary>
	/// まともなエンドポイントがバインドできる
	/// </summary>
	public interface IEndpointBinder {

		/// <summary>
		/// TCP接続をバインド
		/// </summary>
		/// <param name="tcp">繋ぐべきTCP</param>
		/// <returns>同期用、完了時true</returns>
		Task<bool> BindTCPEndpointAsync(TCPEndPointBase tcp);
	}
}
