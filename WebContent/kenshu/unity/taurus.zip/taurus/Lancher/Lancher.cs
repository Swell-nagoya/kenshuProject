﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace Lancher {
	class Lancher {

		/// <summary>
		/// メイン処理
		/// </summary>
		/// <param name="args"></param>
		static void Main(string[] args) {


			// 状況取得開始
			Taurus.Manipulator.Transponder.StartReceive();

			bool IsRunning = false;

			// 動作しているか否かチェック
			try {
				IsRunning = Taurus.Manipulator.Transponder.RemoteInstance.IsRunning;
			} catch(RemotingException) {
				// 接続できないので死んでる
				IsRunning = false;
			}




			// オプションチェック
			switch (args.FirstOrDefault()) {

				case "start":
					if (IsRunning) {
						Console.WriteLine("既に起動しています");
					} else {

						// Winじゃなきゃならmonoで実行する
						if (Environment.OSVersion.Platform == PlatformID.Unix) {
							Process.Start("mono", "Taurus.exe --silent");

						} else {
							Process.Start("Taurus.exe", "");
						}


						Console.WriteLine("起動しました");
					}

					break;

				case "state":

					if (IsRunning) {
						Console.WriteLine($"動作中です PID:{Taurus.Manipulator.Transponder.RemoteInstance.ProcessID}");
					} else {

						Console.WriteLine("動作していません");
					}


					break;


				case "stop":

					// 止められそうなら止める
					if (IsRunning) {
						Taurus.Manipulator.Transponder.RemoteInstance.StopRequire = true;
						Console.WriteLine("停止要求を送信しました");
					} else {
						Console.WriteLine("動作していないので停止できません");
					}

					break;

				case "sqllog":
					// SQLログ有効無効設定

					if (IsRunning) {

						switch (args.Skip(1).FirstOrDefault()) {

							case "on":

								Taurus.Manipulator.Transponder.RemoteInstance.IsSqlLogExport = true;
								Console.WriteLine("今からSQLログが出てくるようにしました");

								break;

							case "off":

								Taurus.Manipulator.Transponder.RemoteInstance.IsSqlLogExport = false;
								Console.WriteLine("今からSQLログがとまりました");

								break;

							default:

								Console.WriteLine($"何をすればいいのかわかりませんでした");

								break;
						}

					} else {
						Console.WriteLine("動作していないので設定できません");
					}


					break;

				case "looms":

					// お部屋の数
					if (IsRunning) {
						Console.WriteLine(Taurus.Manipulator.Transponder.RemoteInstance.RoomCount);
					} else {
						Console.WriteLine("動作していないです");
					}

					break;
					
				case "lobbys":

					// ロビーの数
					if (IsRunning) {
						Console.WriteLine(Taurus.Manipulator.Transponder.RemoteInstance.LobbyCount);
					} else {
						Console.WriteLine("動作していないです");
					}

					break;

				case "users":

					// 人の数
					if (IsRunning) {
						Console.WriteLine(Taurus.Manipulator.Transponder.RemoteInstance.UserCount);
					} else {
						Console.WriteLine("動作していないです");
					}

					break;

				default:


					string param = "[start | state | stop | sqllog[on | off] | rooms | lobbys | users ]";


					// OSごとにヒントが変わる
					if (Environment.OSVersion.Platform == PlatformID.Unix) {

						// Monoもいるしexeも省略できない
						Console.WriteLine("Lancher.exe " + param);


					} else {

						// Unixじゃなければmonoなんてなくても動く
						Console.WriteLine("Lancher " + param);

					}

					// オプションの説明
					Console.WriteLine("\tstart\tTaurusが起動する");
					Console.WriteLine("\tstopt\tTaurusが停止する");
					Console.WriteLine("\tstate\tTaurusが生きているか確認できる");
					Console.WriteLine("\tsqllog\tSQLログが出るか出ないかを指定できる");
					Console.WriteLine("\trooms\t部屋の数を調べる");
					Console.WriteLine("\tlobbys\tロビー数を調べる");
					Console.WriteLine("\tusers\tユーザー数が分かる");

					break;


			}







		}
	}
}
