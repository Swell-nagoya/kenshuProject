﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB.Util;
using Taurus.DB.Util.DBOption;

namespace Taurus.DB {

	/// <summary>
	/// ゲームイベント系
	/// </summary>
	public static partial class DBInterface {
		
		/// <summary>
		/// 現在開催中のイベント一覧を取得
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <returns></returns>
		public static async Task<EventInfo[]> GetCurrentEventsAsync(int devId, int appId) {

			using (var db = TaurusDBConfig.Create()) {

				var dbTime = await db.NowAsync();

				var data = await db.d_event.
					WhereApp(appId, devId).
					WhereAlive().
					IsCurrent(dbTime).ToArrayAsync();

				var result = new EventInfo[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new EventInfo() {
						EventId = data[i].event_id,
						EventType = data[i].event_type ?? 0,
						EventTitle = data[i].event_title,
						EventDetail = data[i].event_detail,
						StartDate = data[i].start_date ?? DateTime.MinValue,
						EndDate = data[i].end_date ?? DateTime.MinValue,
						ImagePath = data[i].image_path,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 特定のイベントのサブイベント一覧を取得
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <returns></returns>
		public static async Task<SubEventInfo[]> GetSubEventsAsync(int devId, int appId, int eventId) {

			using (var db = TaurusDBConfig.Create()) {

				var data = await db.d_sub_event.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId).ToArrayAsync();

				var result = new SubEventInfo[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new SubEventInfo() {
						EventId = data[i].event_id,
						SequenceNo = data[i].sequence_no,
						EventType = data[i].event_type ?? 0,
						EventTitle = data[i].event_title,
						EventDetail = data[i].event_detail,
						StartDate = data[i].start_date ?? DateTime.MinValue,
						EndDate = data[i].end_date ?? DateTime.MinValue,
						ImagePath = data[i].image_path,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 特定のイベントにエントリーする
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="sequenceNo"></param>
		/// <param name="userId"></param>
		/// <returns></returns>
		public static async Task<bool> EntryEventAsync(int devId, int appId, int eventId, int sequenceNo, int userId) {

			using (var db = TaurusDBConfig.Create()) {
				try {
					var entry = new d_event_entry_user() { developer_id = devId, application_id = appId, event_id = eventId, sequence_no = sequenceNo, user_id = userId };

					db.d_event_entry_user.Add(entry);

					// レッツコミット
					await db.SaveChangesAsync();
					return true;
				} catch (Exception e) {
					// なんかこけた
					Logger.Warning($"{userId}が{devId}/{appId}/{eventId}/{sequenceNo}へのエントリー失敗\n{e.Message}");
					return false;
				}
			}
		}

		/// <summary>
		/// 特定のイベントにエントリーしているか
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="sequenceNo"></param>
		/// <param name="userId"></param>
		/// <returns></returns>
		public static async Task<bool> IsEntryEventAsync(int devId, int appId, int eventId, int sequenceNo, int userId) {

			using (var db = TaurusDBConfig.Create()) {

				return await db.d_event_entry_user.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.sequence_no == sequenceNo && e.user_id == userId).AnyAsync();
			}
		}

		/// <summary>
		/// 特定のイベントにエントリーしているユーザーの一覧を取得
		/// </summary>
		/// <returns></returns>
		public static async Task<EventEntryUserInfo[]> GetEventEntryUsersAsync(int devId, int appId, int eventId, int sequenceNo) {

			using (var db = TaurusDBConfig.Create()) {

				var data = await db.d_event_entry_user.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.sequence_no == sequenceNo).ToArrayAsync();

				var result = new EventEntryUserInfo[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new EventEntryUserInfo() {
						UserId = data[i].user_id,
						Result1 = data[i].result_1 ?? 0,
						Result2 = data[i].result_2,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 特定のサブイベントでの順位を範囲指定してユーザーを取得
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="sequenceNo"></param>
		/// <param name="minResult"></param>
		/// <param name="maxResult"></param>
		/// <returns></returns>
		public static async Task<EventEntryUserInfoWithUserData[]> GetEventEntryWithInResultAsync(int devId, int appId, int eventId, int sequenceNo, int minResult, int maxResult) {
			using (var db = TaurusDBConfig.Create()) {

				var data = await db.d_event_entry_user.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.sequence_no == sequenceNo && minResult <= e.result_1 && e.result_1 <= maxResult).ToArrayAsync();

				var result = new EventEntryUserInfoWithUserData[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new EventEntryUserInfoWithUserData() {
						UserId = data[i].user_id,
						UserName = (await db.d_user.Where(e => !e.state_code.Equals("BAN")).SingleUserOrDefaultAsync(appId, devId, data[i].user_id))?.reserved_1,
						Result1 = data[i].result_1 ?? 0,
						Result2 = data[i].result_2,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 特定のサブイベントでの順位を特定ユーザーの順位前後範囲指定してユーザーを取得
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="sequenceNo"></param>
		/// <param name="userId"></param>
		/// <param name="minResult"></param>
		/// <param name="maxResult"></param>
		/// <returns></returns>
		public static async Task<EventEntryUserInfoWithUserData[]> GetEventEntryAroundResultWithInResultByUserResultAsync(int devId, int appId, int eventId, int sequenceNo, int userId, int minResult, int maxResult) {
			using (var db = TaurusDBConfig.Create()) {

				var userResult = await db.d_event_entry_user.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.sequence_no == sequenceNo && e.user_id == userId).FirstOrDefaultAsync();

				if (userResult == null) {
					return null;
				}

				var data = await db.d_event_entry_user.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.sequence_no == sequenceNo && 0 < e.result_1 && userResult.result_1 + minResult <= e.result_1 && e.result_1 <= userResult.result_1 + maxResult).ToArrayAsync();

				var result = new EventEntryUserInfoWithUserData[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new EventEntryUserInfoWithUserData() {
						UserId = data[i].user_id,
						UserName = (await db.d_user.Where(e => !e.state_code.Equals("BAN")).SingleUserOrDefaultAsync(appId, devId, data[i].user_id))?.reserved_1,
						Result1 = data[i].result_1 ?? 0,
						Result2 = data[i].result_2,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 特定のサブイベントでの自分の個人戦全てを取得する
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="eventSequenceNo"></param>
		/// <param name="userId"></param>
		/// <returns></returns>
		public static async Task<IndividualMatchInfo[]> GetMyIndividualMatchesAsync(int devId, int appId, int eventId, int eventSequenceNo, int userId) {

			using (var db = TaurusDBConfig.Create()) {

				var data = await db.d_individual_match.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.event_sequence_no == eventSequenceNo && (e.user_id_1 == userId || e.user_id_2 == userId)).ToArrayAsync();

				var result = new IndividualMatchInfo[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new IndividualMatchInfo() {
						EventId = data[i].event_id,
						EventSequenceNo = data[i].event_sequence_no,
						UserId1 = data[i].user_id_1,
						UserId2 = data[i].user_id_2,
						SequenceNo = data[i].sequence_no,
						WinUser = data[i].win_user ?? 0,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 特定のサブイベントでの自分の個人戦全てを取得する
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="eventSequenceNo"></param>
		/// <returns></returns>
		public static async Task<IndividualMatchInfo[]> GetIndividualMatchesInEventAsync(int devId, int appId, int eventId, int eventSequenceNo) {

			using (var db = TaurusDBConfig.Create()) {

				var data = await db.d_individual_match.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.event_sequence_no == eventSequenceNo).ToArrayAsync();

				var result = new IndividualMatchInfo[data.Length];

				for (int i = 0; i < data.Length; i++) {
					result[i] = new IndividualMatchInfo() {
						EventId = data[i].event_id,
						EventSequenceNo = data[i].event_sequence_no,
						UserId1 = data[i].user_id_1,
						UserId2 = data[i].user_id_2,
						SequenceNo = data[i].sequence_no,
						WinUser = data[i].win_user ?? 0,
						Reserved1 = data[i].reserved_1 ?? 0,
						Reserved2 = data[i].reserved_2,
					};
				}
				return result;
			}
		}

		/// <summary>
		/// 自分のエントリー情報を全て取得
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="userId"></param>
		/// <returns></returns>
		public static async Task<EventInfoWithSubEventInfoWithEventEntryUserInfoArray[]> GetEventEntryResultAllByUserIdAsync(int devId, int appId, int userId) {

			using (var db = TaurusDBConfig.Create()) {

				var datas = await db.d_event_entry_user.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.user_id == userId).ToArrayAsync();

				var result = new List<EventInfoWithSubEventInfoWithEventEntryUserInfoArray>();

				var dict = new Dictionary<int, Dictionary<int, EventEntryUserInfo>>();

				foreach (var data in datas) {
					if (!dict.ContainsKey(data.event_id)) {
						dict.Add(data.event_id, new Dictionary<int, EventEntryUserInfo>());
					}
					if (!dict[data.event_id].ContainsKey(data.sequence_no)) {
					}
					dict[data.event_id].Add(data.sequence_no, new EventEntryUserInfo() {
						UserId = data.user_id,
						Result1 = data.result_1 ?? 0,
						Result2 = data.result_2,
						Reserved1 = data.reserved_1 ?? 0,
						Reserved2 = data.reserved_2,
					});
				}

				foreach (var pair in dict) {

					var data = await db.d_event.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == pair.Key).SingleAsync();
					var eventData = new EventInfoWithSubEventInfoWithEventEntryUserInfoArray() {
						EventId = data.event_id,
						EventType = data.event_type ?? 0,
						EventTitle = data.event_title,
						EventDetail = data.event_detail,
						StartDate = data.start_date ?? DateTime.MinValue,
						EndDate = data.end_date ?? DateTime.MinValue,
						ImagePath = data.image_path,
						Reserved1 = data.reserved_1 ?? 0,
						Reserved2 = data.reserved_2,
						SubEventAndEntryArray = new SubEventInfoWithEventEntryUserInfo[pair.Value.Count],
					};

					int i = 0;
					foreach (var pair2 in pair.Value) {
						var subEvent = await db.d_sub_event.
							WhereApp(appId, devId).
							WhereAlive().
							Where(e => e.event_id == pair.Key && e.sequence_no == pair2.Key).SingleAsync();

						var match = await db.d_individual_match.
								WhereApp(appId, devId).
								WhereAlive().
								Where(e => e.event_id == subEvent.event_id && e.event_sequence_no == subEvent.sequence_no && (e.user_id_1 == userId || e.user_id_2 == userId)).ToArrayAsync();

						eventData.SubEventAndEntryArray[i] = new SubEventInfoWithEventEntryUserInfo() {
							EventId = subEvent.event_id,
							SequenceNo = subEvent.sequence_no,
							EventType = subEvent.event_type ?? 0,
							EventTitle = subEvent.event_title,
							EventDetail = subEvent.event_detail,
							StartDate = subEvent.start_date ?? DateTime.MinValue,
							EndDate = subEvent.end_date ?? DateTime.MinValue,
							ImagePath = subEvent.image_path,
							Reserved1 = subEvent.reserved_1 ?? 0,
							Reserved2 = subEvent.reserved_2,
							EntryInfo = pair2.Value,
							MatchInfo = match.Length == 0 || 1 < match.Length ? null : new IndividualMatchInfo() {
								EventId = match[0].event_id,
								EventSequenceNo = match[0].sequence_no,
								UserId1 = match[0].user_id_1,
								UserId2 = match[0].user_id_2,
								SequenceNo = match[0].sequence_no,
								WinUser = match[0].win_user ?? 0,
								Reserved1 = match[0].reserved_1 ?? 0,
								Reserved2 = match[0].reserved_2,
							},
						};
						i++;
					}
					result.Add(eventData);
				}

				return result.ToArray();
			}
		}

		/// <summary>
		/// 特定の個人戦を取得する
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="eventSequenceNo"></param>
		/// <param name="userId1"></param>
		/// <param name="userId2"></param>
		/// <param name="sequenceNo"></param>
		/// <returns></returns>
		public static async Task<IndividualMatchInfo> GetIndividualMatchAsync(int devId, int appId, int eventId, int eventSequenceNo, int userId1, int userId2, int sequenceNo) {

			using (var db = TaurusDBConfig.Create()) {

				var data = await db.d_individual_match.
					WhereApp(appId, devId).
					WhereAlive().
					Where(e => e.event_id == eventId && e.event_sequence_no == eventSequenceNo && e.user_id_1 == userId1 && e.user_id_2 == userId2 && e.sequence_no == sequenceNo).FirstOrDefaultAsync();

				var result = data == null ? (IndividualMatchInfo)null : new IndividualMatchInfo() {
					EventId = data.event_id,
					EventSequenceNo = data.event_sequence_no,
					UserId1 = data.user_id_1,
					UserId2 = data.user_id_2,
					SequenceNo = data.sequence_no,
					WinUser = data.win_user ?? 0,
					Reserved1 = data.reserved_1 ?? 0,
					Reserved2 = data.reserved_2,
				};
				return result;
			}
		}

		/// <summary>
		/// 個人戦を登録する
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="eventSequenceNo"></param>
		/// <param name="userId1"></param>
		/// <param name="userId2"></param>
		/// <param name="sequenceNo"></param>
		/// <param name="winUser"></param>
		/// <param name="reserved1"></param>
		/// <param name="reserved2"></param>
		/// <returns></returns>
		public static async Task<bool> InsertIndividualMatchAsync(int devId, int appId, int eventId, int eventSequenceNo, int userId1, int userId2, int? sequenceNo = null, int? winUser = null, int? reserved1 = null, string reserved2 = null) {

			using (var db = TaurusDBConfig.Create()) {
				using (var tran = db.Database.BeginTransaction()) {

					try {
						if (!sequenceNo.HasValue) {
							sequenceNo = await db.d_individual_match.
								WhereApp(appId, devId).
								WhereAlive().
								Where(e => e.event_id == eventId && e.event_sequence_no == eventSequenceNo && e.user_id_1 == userId1 && e.user_id_2 == userId2).CountAsync();
						}
						var individualMatch = new d_individual_match() {
							developer_id = devId,
							application_id = appId,
							event_id = eventId,
							event_sequence_no = eventSequenceNo,
							user_id_1 = userId1,
							user_id_2 = userId2,
							sequence_no = sequenceNo.Value,
							win_user = winUser,
							reserved_1 = reserved1,
							reserved_2 = reserved2,
						};
						db.d_individual_match.Add(individualMatch);

						// レッツコミット
						await db.SaveChangesAsync();
						tran.Commit();

						return true;

					} catch (Exception e) {

						// なんかこけた
						Logger.Warning($"{devId}/{appId}/{eventId}/{eventSequenceNo}/{userId1}/{userId2}/{sequenceNo}の個人戦結果登録失敗\n{e.Message}");
						tran.Rollback();
						return false;
					}
				}
			}
		}

		/// <summary>
		/// 個人戦を更新する
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="eventId"></param>
		/// <param name="eventSequenceNo"></param>
		/// <param name="userId1"></param>
		/// <param name="userId2"></param>
		/// <param name="sequenceNo"></param>
		/// <param name="winUser"></param>
		/// <param name="reserved1"></param>
		/// <param name="reserved2"></param>
		/// <returns></returns>
		public static async Task<bool> UpdataIndividualMatchAsync(int devId, int appId, int eventId, int eventSequenceNo, int userId1, int userId2, int sequenceNo, int? winUser = null, int? reserved1 = null, string reserved2 = null) {

			if (!winUser.HasValue && !reserved1.HasValue && string.IsNullOrEmpty(reserved2)) {

				// 更新するものがない
				return true;
			}

			using (var db = TaurusDBConfig.Create()) {

				try {
					var data = await db.d_individual_match.
						WhereAlive().
						WhereApp(appId, devId).
						Where(e => e.event_id == eventId && e.event_sequence_no == eventSequenceNo && e.user_id_1 == userId1 && e.user_id_2 == userId2 && e.sequence_no == sequenceNo).FirstOrDefaultAsync();

					// ユーザー未発見なら失敗
					if (data == null) {
						return false;
					}

					// 値を挿げ替える
					if (winUser.HasValue) {
						data.win_user = winUser.Value;
					}
					if (reserved1.HasValue) {
						data.reserved_1 = reserved1.Value;
					}
					if (!string.IsNullOrEmpty(reserved2)) {
						data.reserved_2 = reserved2;
					}

					await db.SaveChangesAsync();

					return true;

				} catch (Exception e) {

					// なんかこけた
					Logger.Warning($"{devId}/{appId}/{eventId}/{eventSequenceNo}/{userId1}/{userId2}/{sequenceNo}の個人戦結果更新失敗\n{e.Message}");
					return false;
				}
			}
		}

		/// <summary>
		/// 公開テーブルに登録する
		/// </summary>
		/// <param name="devId"></param>
		/// <param name="appId"></param>
		/// <param name="values"></param>
		/// <returns>成功時は登録時のIndex 失敗時は-1</returns>
		public static async Task<int> InsertPublishDataAsync(int devId, int appId, string[] values) {

			using (var db = TaurusDBConfig.Create()) {
				using (var tran = db.Database.BeginTransaction()) {

					try {
						var index = await db.d_publish.
							WhereApp(appId, devId).
							WhereAlive().
							CountAsync();
						for (int i = 0; i < values.Length; i++) {
							var publish = new d_publish() {
								developer_id = devId,
								application_id = appId,
								key_index = index,
								sequence_no = i + 1,
								string_data = values[i],
							};
							db.d_publish.Add(publish);
						}

						// レッツコミット
						await db.SaveChangesAsync();
						tran.Commit();

						return index;

					} catch (Exception e) {

						// なんかこけた
						Logger.Warning($"{devId}/{appId}の公開テーブルに登録失敗\n{e.Message}");
						tran.Rollback();
						return -1;
					}
				}
			}
		}
	}
}