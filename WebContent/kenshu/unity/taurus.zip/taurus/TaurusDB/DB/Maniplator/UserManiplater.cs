﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB.Util;
using Taurus.DB.Util.DBOption;

namespace Taurus.DB {

	/// <summary>
	/// ユーザー操作
	/// </summary>
	public static partial class DBInterface {


		/// <summary>
		/// ユーザー生成
		/// </summary>
		/// <param name="IDPair">アプリケーションIDとデベロッパID</param>
		/// <returns>生成されたユーザー</returns>
		public static async Task<LoginInfoAndDBuser> CreateUserAsync(AppIdAndDevIdPair IDPair) {
			// DBに繋ぐ
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// アプリケーション設定
				m_application Application = await db.ApplicationSearch(IDPair.ApplicationID, IDPair.DeveloperID);

				// 格納されているか確認
				if (Application == null) {
					// そんなアプリケーションはなかった
					return null;
				}

				// 返却用の値を作成
				var ret = new LoginInfo() { Password = Guid.NewGuid().ToByteArray() };

				// 追加するユーザー情報を設定
				var user = new d_user() { application_id = Application.application_id, developer_id = Application.developer_id, hash_pass = ret.CreatePassHash(), state_code = "TEMPOLALY" };

				// 作成
				db.d_user.Add(user);

				// レッツコミット
				await db.SaveChangesAsync();

				// 返却用の値を設定する
				ret.UserID = user.user_id;

				// 返却
				return new LoginInfoAndDBuser(ret, user);
			}
		}

		/// <summary>
		/// DBからアプリケーション情報を探す
		/// </summary>
		/// <param name="db">探すDB</param>
		/// <param name="AppId">アプリケーションID</param>
		/// <param name="DevID">デベロッパID</param>
		/// <returns>アプリケーション情報 or 未発見時null</returns>
		private static async Task<m_application> ApplicationSearch(this TaurusDBConfig db, int AppId, int DevID) {
			return await db. // DBから
				m_application. // アプリケーションテーブルをみて
				AsNoTracking(). // いろいろ追従せず
				WhereApp(AppId, DevID). // アプリケーション探す
				WhereAlive(). // 生存していなければならない
				SingleOrDefaultAsync(); // 一件でいいからな
		}

		/// <summary>
		/// アカウントにログイン
		/// </summary>
		/// <param name="info">ログインしてきたユーザー</param>
		/// <returns>ユーザーに関する情報全部 or 未発見時null</returns>
		public static async Task<d_user> UserLoginAsync(LoginOrder info) {

			// DB繋ぐ
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー検索
				d_user user = await db.d_user.Where(e => !e.state_code.Equals("BAN")).SingleUserOrDefaultAsync(info.AppId, info.DevID, info.UserID);

				// ユーザー未発見なら失敗
				if (user == null) { return null; }

				// パスワードハッシュチェック
				if (!user.hash_pass.SequenceEqual(info.Passhash)) { return null; }


				// ユーザー情報を返す
				return user;

			}
		}

		/// <summary>
		/// パラメーター更新
		/// </summary>
		/// <param name="User">更新するユーザー情報</param>
		/// <returns></returns>
		public static async Task<bool> UserUpdateAsync(d_user User) {

			// DB繋ぐ
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー検索
				d_user SearchUser = await db.d_user.SingleUserOrDefaultAsync(User);

				// パスチェック
				if (!SearchUser.hash_pass.SequenceEqual(User.hash_pass)) { return false; }

				// ユーザー未発見なら失敗
				if (SearchUser == null) { return false; }


				// 値を挿げ替える
				// この時置き換えるとaddされる恐怖
				SearchUser.SetParam(User.ConvertToAboutUser());
				
				// コミットして完了
				await db.SaveChangesAsync();

				return true;
			}
		}


	}
}
