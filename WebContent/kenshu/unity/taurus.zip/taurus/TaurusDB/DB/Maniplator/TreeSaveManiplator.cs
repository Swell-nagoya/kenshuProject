﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB.Util;
using Taurus.DB.Util.DBOption;

namespace Taurus.DB {

	/// <summary>
	/// ツリーセーブ制御用
	/// </summary>
	public static partial class DBInterface {
		
		/// <summary>
		/// ユーザーの持っているツリー構造を全部引っこ抜く
		/// </summary>
		/// <param name="user">対象のユーザー情報</param>
		/// <returns>構造の一覧</returns>
		public static async Task<TreeInfo[]> ReadTreeMapAsync(d_user user) {

			using (var db = TaurusDBConfig.Create()) {

				// 一覧をダンプして投げ返す

				return await db.d_treemap.
					WhereUser(user).
					WhereAlive().
					Select(e => new TreeInfo { InstanceID = e.instance_id, ParrentInstanceId = e.parrent_instance_id, Name = e.name }).
					ToArrayAsync();
			}
		}

		/// <summary>
		/// ツリーのデータを引っこ抜く
		/// </summary>
		/// <param name="user">対象のユーザー情報</param>
		/// <param name="InstanceID">インスタンスID</param>
		/// <returns>データ内容物</returns>
		public static async Task<TreeDataInfo> ReadTreeDataAsync(d_user user, int InstanceID) {

			using (var db = TaurusDBConfig.Create()) {
				var tmp = await db.d_treedata.
					WhereUser(user).
					WhereAlive().
					WhereInstance(InstanceID).
					SingleOrDefaultAsync();

				return tmp != null ? new TreeDataInfo() { Data = tmp.data, InstanceID = tmp.instance_id } : null;
			}
		}

		/// <summary>
		/// ツリーのデータを引っこ抜く
		/// </summary>
		/// <param name="user">対象のユーザー情報</param>
		/// <param name="InstanceID">インスタンスID</param>
		/// <returns>データ内容物</returns>
		public static async Task<TreeDataInfo[]> ReadTreeDataAsync(d_user user, params int[] InstanceID) {

			using (var db = TaurusDBConfig.Create()) {
				var tmp = await db.d_treedata.
					WhereUser(user).
					WhereAlive().
					WhereInstance(InstanceID).
					Select(e => new TreeDataInfo { InstanceID = e.instance_id, Data = e.data, }).
					ToArrayAsync();

				return tmp;
			}
		}

		/// <summary>
		/// ツリー構造を更新する
		/// </summary>
		/// <param name="user">対象のユーザー情報</param>
		/// <param name="info">ツリー情報</param>
		/// <returns>待機用task(waitすんなよ)</returns>
		public static async Task UpdateTreeMapAsync(d_user user, TreeInfo[] info) {

			using (var db = TaurusDBConfig.Create()) {

				// あたらしいマップが提示されている場合に処理を行う
				if (info != null) {

					// 今のツリーのマップを作る
					var nowTree = await db.d_treemap.
						WhereUser(user).
						WhereAlive().
						ToDictionaryAsync(e => e.instance_id, e => e);

					// 更新するべきツリーを選択
					foreach (var newNode in info) {

						// 既にある場合は更新
						if (nowTree.TryGetValue(newNode.InstanceID, out var node)) {
							// 値を挿げ替えていく
							node.name = newNode.Name;
							node.parrent_instance_id = newNode.ParrentInstanceId;

						} else {
							// ない場合は追加
							var tmp = new d_treemap() {
								instance_id = newNode.InstanceID,
								parrent_instance_id = newNode.ParrentInstanceId,
								name = newNode.Name,
							};

							// IDもろもろ関連付け
							user.AppendUser(tmp);

							db.d_treemap.Add(tmp);

						}

						// 処理したノードは今のマップの一覧から消す
						nowTree.Remove(newNode.InstanceID);
					}

					// マップ一覧にある残ったすべての要素を削除対象としてマーク
					if (nowTree.Any()) {

						// 全ての不要になるデータを削除対象としてマーク
						foreach (var node in nowTree.Select(e => e.Value)) {

							// 夢の論理削除帝国
							await node.DeleteAsync(db);

							// 関連するデータも削除
							var tmp = await db.d_treedata.
							  WhereUser(user).
							  WhereAlive().
							  WhereInstance(node.instance_id).
							  FirstOrDefaultAsync();

							if (tmp != null) {
								await tmp.DeleteAsync(db);
							}

						}

					}

				} else {

					// 超みたいログだから緑色にする
					db.Database.Log = Logger.Important;

					// 新しいツリー構造がもらえないなら全消し
					await db.Database.ExecuteSqlCommandAsync("UPDATE taurus.d_treedata SET delete_date = @p3 WHERE application_id = @p0 AND developer_id = @p1 AND user_id = @p2", user.application_id, user.developer_id, user.user_id, await db.NowAsync());


				}

				// トランザクション完了
				await db.SaveChangesAsync();

			}
		}

		/// <summary>
		/// ツリー構造のデータを編集する
		/// <param name="user">対象のユーザー情報</param>
		/// <param name="InstanceID">インスタンスID</param>
		/// <param name="datas">更新すべきデータ一覧</param>
		/// <returns></returns>
		public static async Task UpdateTreeDataAsync(d_user user, TreeDataInfo[] datas) {

			using (var db = TaurusDBConfig.Create()) {

				// 今あるデータの一覧を取る
				var nowData = new HashSet<int>(await db.d_treedata.
				WhereUser(user).
				WhereAlive().
				Select(e => e.instance_id).ToArrayAsync());

				// 全ての更新データに対して処理
				foreach (var newData in datas) {

					// 設定用のレコード生成
					var tmpRecord = new d_treedata() {
						instance_id = newData.InstanceID,
						data = null,
						delete_date = null
					};

					// IDもろもろを関連付け
					user.AppendUser(tmpRecord);

					// 存在するデータへの処理であるかを確認
					if (nowData.Contains(newData.InstanceID)) {

						// レコードをSelect済みかのように振舞わせるためテーブルに覚えさせる
						db.d_treedata.Attach(tmpRecord);

						if (newData.Data == null) {
							// データがなければ削除処理
							await tmpRecord.DeleteAsync(db);

						} else {
							// データがあれば更新処理
							tmpRecord.data = newData.Data;
						}
					} else if (newData.Data != null) {
						// 存在しない物で格納したいデータが存在していれば追加する
						db.d_treedata.Add(tmpRecord);
						tmpRecord.data = newData.Data;
					}
				}

				// 何もかもが完了した
				await db.SaveChangesAsync();

			}
		}
	}
}
