﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB.Util;
using Taurus.DB.Util.DBOption;

namespace Taurus.DB {

	/// <summary>
	/// バイナリデータ操作用
	/// </summary>
	public static partial class DBInterface {


		/// <summary>
		/// データを読み出し
		/// </summary>
		/// <param name="AppID">アプリケーションID</param>
		/// <param name="DevID">デベロッパID</param>
		/// <param name="UserID">ユーザーID</param>
		/// <param name="Page">ページ番号</param>
		/// <returns>読み出せないとnull or 最大たぶん1024byteのデータ</returns>
		public static async Task<byte[]> DataRead(int AppID, int DevID, int UserID, int Page) {
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー探索
				d_user user = await db.d_user.SingleUserOrDefaultAsync(AppID, DevID, UserID);

				// なければおしまい
				if (user == null) { return null; }

				// ページを選択して情報を吸い出す
				return (await db.d_savedata.
					Where(e => e.app_id == user.application_id).
					Where(e => e.developer_id == user.developer_id).
					Where(e => e.user_id == user.user_id).
					Where(e => e.sequens_no == Page).
					FirstOrDefaultAsync())?.
					save_data;
			}
		}

		/// <summary>
		/// データ書き出し
		/// </summary>
		/// <param name="AppID">アプリケーションID</param>
		/// <param name="DevID">デベロッパID</param>
		/// <param name="UserID">ユーザーID</param>
		/// <param name="Page">書き出し先ページ番号</param>
		/// <param name="Data">書き出すデータ(1024byteをはみ出す場合は切り捨て)</param>
		/// <returns>成功時true</returns>
		public static async Task<bool> DataWrite(int AppID, int DevID, int UserID, int Page, byte[] Data) {
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー探索
				d_user user = await db.d_user.SingleUserOrDefaultAsync(AppID, DevID, UserID);

				// なければおしまい
				if (user == null) { return false; }

				// ページが存在するかチェック
				d_savedata save = await db.d_savedata.
					Where(e => e.app_id == user.application_id).
					Where(e => e.developer_id == user.developer_id).
					Where(e => e.user_id == user.user_id).
					Where(e => e.sequens_no == Page).
					FirstOrDefaultAsync();

				// あれば消す
				if (save != null) {
					db.d_savedata.Remove(save);
				}
				// 書き出すデータがあるのであれば新しく作る
				if (Data != null) {
					// 新しく作る
					db.d_savedata.Add(new d_savedata() {
						app_id = user.application_id,
						developer_id = user.developer_id,
						user_id = user.user_id,
						sequens_no = Page,
						save_data = Data.Take(1024).ToArray()
					});
				}

				// ほぞん
				await db.SaveChangesAsync();

				return true;

			}
		}

		/// <summary>
		/// データサイズチェック
		/// </summary>
		/// <param name="AppID">アプリケーションID</param>
		/// <param name="DevID">デベロッパID</param>
		/// <param name="UserID">ユーザーID</param>
		/// <returns>そいつの持っているレコード or 失敗時null</returns>
		public static async Task<int[]> DataInfo(int AppID, int DevID, int UserID) {
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー探索
				d_user user = await db.d_user.SingleUserOrDefaultAsync(AppID, DevID, UserID);

				// なければおしまい
				if (user == null) { return null; }

				// 使用領域チェックするクエリ
				// return await db.Database.SqlQuery<int>(@"SELECT sequens_no FROM d_savedata WHERE app_id = @p1 AND developer_id = @p2 AND user_id = @p3", AppID, DevID, UserID).ToArrayAsync();
				return await db.d_savedata.
					Where(e => e.app_id == AppID).
					Where(e => e.developer_id == DevID).
					Where(e => e.user_id == UserID).
					Select(e => e.sequens_no).
					ToArrayAsync();
			}
		}

		/// <summary>
		/// データを削除
		/// </summary>
		/// <param name="AppID">アプリケーションID</param>
		/// <param name="DevID">デベロッパID</param>
		/// <param name="UserID">ユーザーID</param>
		/// <param name="Page">ページ番号</param>
		/// <returns>消えたらtrue</returns>
		public static async Task<bool> DataDelete(int AppID, int DevID, int UserID, int Page) {
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー探索
				d_user user = await db.d_user.SingleUserOrDefaultAsync(AppID, DevID, UserID);

				// なければおしまい
				if (user == null) { return false; }

				// ページが存在するかチェック
				d_savedata save = await db.d_savedata.
					Where(e => e.app_id == user.application_id).
					Where(e => e.developer_id == user.developer_id).
					Where(e => e.user_id == user.user_id).
					Where(e => e.sequens_no == Page).
					FirstOrDefaultAsync();

				// なければ失敗
				if (save != null) {
					return false;
				}

				// 消す
				db.d_savedata.Remove(save);

				// 書き出し
				await db.SaveChangesAsync();

				return true;
			}
		}

		/// <summary>
		/// データを全件削除
		/// </summary>
		/// <param name="AppID">アプリケーションID</param>
		/// <param name="DevID">デベロッパID</param>
		/// <param name="UserID">ユーザーID</param>
		/// <returns>消えたらtrue</returns>
		public static async Task<bool> DataDeleteAll(int AppID, int DevID, int UserID) {
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// ユーザー探索
				d_user user = await db.d_user.SingleUserOrDefaultAsync(AppID, DevID, UserID);

				// なければおしまい
				if (user == null) { return false; }

				// 全消しクエリ
				await db.Database.ExecuteSqlCommandAsync(@"DELETE FROM d_savedata WHERE app_id = @p1 AND developer_id = @p2 AND user_id = @p3", AppID, DevID, UserID);

				// さよーならｺﾐｯﾄ
				await db.SaveChangesAsync();

				return true;
			}
		}

	}
}
