﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB.Util;
using Taurus.DB.Util.DBOption;

namespace Taurus.DB {

	/// <summary>
	/// アプリケーションに関する情報を得る
	/// </summary>
	public static partial class DBInterface {

		/// <summary>
		/// サポートチケットをコミットする
		/// </summary>
		/// <param name="User">更新するユーザー情報</param>
		/// <param name="message">送信するべきメッセージ</param>
		/// <returns>サポート番号</returns>
		public static async Task<int> SupportTicketCommitAsync(d_user User, string message) {

			// DB繋ぐ
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {

				// サポートチケットを生成
				var support = new d_support_ticket() {
					message = message
				};

				// ユーザー情報を関連付け
				User.AppendUser(support);

				// DBに追加
				db.d_support_ticket.Add(support);

				// コミット
				await db.SaveChangesAsync();

				// idを返す
				return support.ticket_id;
			}
		}
		
	}
}
