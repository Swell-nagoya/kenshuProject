﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.DB.Util;
using Taurus.DB.Util.DBOption;

namespace Taurus.DB {

	/// <summary>
	/// アプリケーションに関する情報を得る
	/// </summary>
	public static partial class DBInterface {

		/// <summary>
		/// アプリケーション一覧を返す
		/// </summary>
		/// <returns>アプリケーション一覧</returns>
		public static async Task<m_application[]> SelectApplicationsAsync() {
			// DB繋ぐ
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {
				// 返す
				return await db.m_application.AsNoTracking().ToArrayAsync();
			}
		}

		/// <summary>
		/// ロビー一覧を返す
		/// </summary>
		/// <returns>ロビーの一覧</returns>
		public static async Task<m_lobby[]> SelectLobbysAsync() {
			using (TaurusDBConfig db = TaurusDBConfig.Create()) {
				// さくっとロビー全件検索
				return await db.m_lobby.AsNoTracking().ToArrayAsync();
			}
		}

	}
}
