﻿namespace Taurus.DB.Util.Interface {

	/// <summary>
	/// ユーザーっぽいレコード
	/// </summary>
	public interface IUserRecord : IApplcationRecord {
		int user_id { get; set; }
	}

}
