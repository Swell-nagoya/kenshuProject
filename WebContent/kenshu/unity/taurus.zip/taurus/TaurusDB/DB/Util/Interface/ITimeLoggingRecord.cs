﻿using System;

namespace Taurus.DB.Util.Interface {
	/// <summary>
	/// 時間について扱うレコード
	/// </summary>
	public interface ITimeLoggingRecord {

		System.DateTime insert_date { get; }
		Nullable<System.DateTime> update_date { get; }
		Nullable<System.DateTime> delete_date { get; set; }
	}

}
