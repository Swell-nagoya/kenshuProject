﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network;

namespace Taurus.DB.Util {
	public static class UserDataConverter {

		/// <summary>
		/// DBユーザー情報を一般処理向けなDBユーザーに書き換え
		/// </summary>
		/// <param name="user">DBユーザー情報</param>
		/// <returns>Taurusネットワーク用ユーザー情報</returns>
		public static AboutUser ConvertToAboutUser(this d_user user) {

			var ret = new AboutUser() {

				// IDはプライマリキーなのでnullにはならない
				UserID = user.user_id
			};

			// Nullチェックを行いながら全件処理
			if (user.win_count.HasValue) { ret.WinCount = user.win_count.Value; }
			if (user.lose_count.HasValue) { ret.LoseCount = user.lose_count.Value; }
			if (user.total_match_count.HasValue) { ret.TotalMatchCount = user.total_match_count.Value; }
			if (user.rate.HasValue) { ret.Rate = user.rate.Value; }
			if (user.money.HasValue) { ret.Money = user.money.Value; }
			if (user.exp.HasValue) { ret.Exp = user.exp.Value; }
			if (user.reserved_1 != null) { ret.Reserved1 = user.reserved_1; }
			if (user.reserved_2.HasValue) { ret.Reserved2 = user.reserved_2.Value; }
			if (user.reserved_3 != null) { ret.Reserved3 = user.reserved_3; }

			// ステータス変換
			if (user.state_code != null) {
				switch (user.state_code) {
					default:
					ret.State = AboutUser.UserState.UNKNOWN;
					break;
					case "TEMPOLALY":
					ret.State = AboutUser.UserState.TEMPOLALY;
					break;
					case "NORMAL":
					ret.State = AboutUser.UserState.NORMAL;
					break;
					case "LOCK":
					ret.State = AboutUser.UserState.LOCK;
					break;
					case "BAN":
					ret.State = AboutUser.UserState.BAN;
					break;
					case "DELETE":
					ret.State = AboutUser.UserState.DELETE;
					break;
				}
			}

			// 返す
			return ret;

		}

		/// <summary>
		/// 変更された値を適応する
		/// </summary>
		/// <param name="ApplyTarget">適応先</param>
		/// <param name="UserData">適応する値</param>
		public static void SetParam(this d_user ApplyTarget, AboutUser UserData) {
			// 適応できる値をすべて適応する
			ApplyTarget.win_count = UserData.WinCount;
			ApplyTarget.lose_count = UserData.LoseCount;
			ApplyTarget.total_match_count = UserData.TotalMatchCount;
			ApplyTarget.rate = UserData.Rate;
			ApplyTarget.money = UserData.Money;
			ApplyTarget.exp = UserData.Exp;
			ApplyTarget.reserved_1 = UserData.Reserved1;
			ApplyTarget.reserved_2 = UserData.Reserved2;
			ApplyTarget.reserved_3 = UserData.Reserved3;


			// 状況を処理
			switch (UserData.State) {
				default:
				ApplyTarget.state_code = "UNKNOWN";
				break;
				case AboutUser.UserState.TEMPOLALY:
				ApplyTarget.state_code = "TEMPOLALY";
				break;
				case AboutUser.UserState.NORMAL:
				ApplyTarget.state_code = "NORMAL";
				break;
				case AboutUser.UserState.LOCK:
				ApplyTarget.state_code = "LOCK";
				break;
				case AboutUser.UserState.BAN:
				ApplyTarget.state_code = "BAN";
				break;
				case AboutUser.UserState.DELETE:
				ApplyTarget.state_code = "DELETE";
				break;
			}

		}

	}
}
