﻿namespace Taurus.DB.Util.Interface {
	/// <summary>
	/// アプリケーションっぽいレコード
	/// </summary>
	public interface IApplcationRecord: IDeveloperRecord {

		int application_id { get; set; }

	}

}
