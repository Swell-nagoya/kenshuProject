﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.DB;

namespace Taurus.DB.Util {
	public static class DbToDataFromAppIDAndDevIdPair {

		/// <summary>
		/// ストラクチャつくる
		/// </summary>
		/// <param name="DbApplication">DBからとってきたアプリケーション情報</param>
		/// <returns>ApplicationIdAndDeveloperIdPair構造体</returns>
		public static AppIdAndDevIdPair Create(this m_application DbApplication) {
			return new AppIdAndDevIdPair() {
				ApplicationID = DbApplication.application_id,
				DeveloperID = DbApplication.developer_id
			};
		}
	}
}
