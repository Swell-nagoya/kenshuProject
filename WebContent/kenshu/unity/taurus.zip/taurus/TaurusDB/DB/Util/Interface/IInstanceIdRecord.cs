﻿namespace Taurus.DB.Util.Interface {
	/// <summary>
	/// インスタンスIDを必要とするレコード
	/// </summary>
	public interface IInstanceIdRecord {

		int instance_id { get; }
	}

}
