﻿using System;

namespace Taurus.DB.Util.Interface {
	public interface IPeriodRecord {
		Nullable<DateTime> start_date { get; set; }
		Nullable<DateTime> end_date { get; set; }
	}
}