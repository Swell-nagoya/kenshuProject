﻿namespace Taurus.DB.Util.Interface {
	/// <summary>
	/// デベロッパっぽいレコード
	/// </summary>
	public interface IDeveloperRecord {

		int developer_id { get; set; }

	}

}
