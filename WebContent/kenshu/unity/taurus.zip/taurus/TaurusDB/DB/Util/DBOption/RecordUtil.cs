﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Taurus.DB.Util.Interface;

namespace Taurus.DB.Util.DBOption {
	/// <summary>
	/// レコードごとのお得なクラス
	/// </summary>
	public static class RecordUtil {

		/// <summary>
		/// アプリケーション特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="appId">アプリケーションID</param>
		/// <param name="devId">デベロッパID</param>
		/// <returns>クエリをさらに連結して返す</returns>
		public static IQueryable<T> WhereApp<T>(this IQueryable<T> queryable, int appId, int devId) where T : class, IApplcationRecord =>
			queryable.WhereDev(devId).Where(e => e.application_id == appId);


		/// <summary>
		/// デベロッパ特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="devId">デベロッパID</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static IQueryable<T> WhereDev<T>(this IQueryable<T> queryable, int devId) where T : class, IDeveloperRecord =>
			queryable.Where(e => e.developer_id == devId);

		/// <summary>
		/// ユーザー特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="devId">デベロッパID</param>
		/// <param name="appId">アプリケーションID</param>
		/// <param name="userId">ユーザーID</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static IQueryable<T> WhereUser<T>(this IQueryable<T> queryable, int appId, int devId, int userId) where T : class, IUserRecord =>
			queryable.WhereApp(appId, devId).Where(e => e.user_id == userId);


		/// <summary>
		/// ユーザー特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="user">ユーザーが特定できる何か</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static IQueryable<T> WhereUser<T>(this IQueryable<T> queryable, IUserRecord user) where T : class, IUserRecord =>
			queryable.WhereUser(user.application_id, user.developer_id, user.user_id);

		/// <summary>
		/// 一つだけユーザー特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="user">ユーザーが特定できる何か</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static async Task<T> SingleUserOrDefaultAsync<T>(this IQueryable<T> queryable, int appId, int devId, int userId) where T : class, IUserRecord =>
			await queryable.WhereUser(appId, devId, userId).SingleOrDefaultAsync();


		/// <summary>
		/// 一つだけユーザー特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="user">ユーザーが特定できる何か</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static async Task<T> SingleUserOrDefaultAsync<T>(this IQueryable<T> queryable, IUserRecord user) where T : class, IUserRecord =>
			await queryable.WhereUser(user).SingleOrDefaultAsync();

		/// <summary>
		/// ユーザー特定特定
		/// </summary>
		/// <typeparam name="T">処理したい奴の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="user">ユーザーに関する情報</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static IQueryable<T> WhereUser<T>(this IQueryable<T> queryable, d_user user) where T : class, IUserRecord =>
			queryable.WhereApp(user.application_id, user.developer_id).Where(e => e.user_id == user.user_id);

        /// <summary>
        /// 削除されていない要素のみ列挙
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="queryable">メソッドチェーン元インスタンス</param>
        /// <returns>メソッドチェーン用メソッド</returns>
        public static IQueryable<T> WhereAlive<T>(this IQueryable<T> queryable) where T : class, ITimeLoggingRecord =>
            queryable.Where(e => e.delete_date == null);

        /// 削除されていない要素のみ列挙
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="queryable">メソッドチェーン元インスタンス</param>
        /// <returns>メソッドチェーン用メソッド</returns>
        public static IQueryable<T> WhereInstance<T>(this IQueryable<T> queryable, int insId) where T : class, IInstanceIdRecord =>
            queryable.Where(e => e.instance_id == insId);

        /// <summary>
		/// 削除されていない要素のみ列挙
		/// </summary>
		/// <typeparam name="T">対象の型</typeparam>
		/// <param name="queryable">メソッドチェーン元インスタンス</param>
		/// <param name="insIds">探すInstanceId(複数)</param>
		/// <returns>メソッドチェーン用メソッド</returns>
		public static IQueryable<T> WhereInstance<T>(this IQueryable<T> queryable, params int[] insIds) where T : class, IInstanceIdRecord =>
            queryable.Where(e => insIds.Contains(e.instance_id));

        /// <summary>
        /// 削除済みフラグを立てる
        /// </summary>
        /// <param name="record">削除対象のレコード</param>
        /// <param name="db">親玉のDB</param>
        /// <returns>await用Task</returns>
        public static async Task DeleteAsync(this ITimeLoggingRecord record, TaurusDBConfig db) =>
            record.delete_date = await db.NowAsync();

		/// <summary>
		/// ユーザーを関連付け
		/// </summary>
		/// <param name="from">関連付け元</param>
		/// <param name="to">関連付けられるインスタンス</param>
		public static void AppendUser(this IUserRecord from, IUserRecord to) {
			from.AppendApp(to);
			to.user_id = from.user_id;
		}
		/// <summary>
		/// アプリケーションを関連付け
		/// </summary>
		/// <param name="from">関連付け元</param>
		/// <param name="to">関連付けられるインスタンス</param>
		public static void AppendApp(this IApplcationRecord from, IApplcationRecord to) {
			from.AppendDev(to);
			to.application_id = from.application_id;
		}

		/// <summary>
		/// デベロッパを関連付け
		/// </summary>
		/// <param name="from">関連付け元</param>
		/// <param name="to">関連付けられるインスタンス</param>
		public static void AppendDev(this IDeveloperRecord from, IDeveloperRecord to) =>
			to.developer_id = from.developer_id;

		public static IQueryable<T> IsCurrent<T>(this IQueryable<T> queryable, DateTime date) where T : class, IPeriodRecord =>
			queryable.Where(e => e.start_date <= date && date < e.end_date);

	}
}
