﻿using Taurus.Data.Network.Info;

namespace Taurus.DB.Util {
	/// <summary>
	/// ログインに必要な情報とDB上のユーザー情報のセット
	/// </summary>
	public class LoginInfoAndDBuser {
		/// <summary>
		/// ログインに必要そうな情報
		/// </summary>
		public readonly LoginInfo LoginInfo;

		/// <summary>
		/// ユーザー情報
		/// </summary>
		public readonly d_user DbUser;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="LoginInfo">ログインに必要な情報</param>
		/// <param name="DbUser">ユーザー情報</param>
		public LoginInfoAndDBuser(LoginInfo LoginInfo, d_user DbUser) {
			this.LoginInfo = LoginInfo;
			this.DbUser = DbUser;
		}

	}
}
