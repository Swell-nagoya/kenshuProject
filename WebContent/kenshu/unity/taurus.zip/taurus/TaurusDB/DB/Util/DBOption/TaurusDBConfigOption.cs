﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.DB.Util.Interface;
using Taurus.Manipulator;

namespace Taurus.DB {
	/// <summary>
	/// ログ設定などの追加機能
	/// </summary>
	public partial class TaurusDBConfig {

		/// <summary>
		/// インスタンス生成用
		/// 普段はnew市内でこっち使ってね
		/// </summary>
		/// <returns>生成されたインスタンス</returns>
		public static TaurusDBConfig Create() {
			// インスタンス生成
			var ins = new TaurusDBConfig();

			// SQLログを吐く必要があれば吐かせる
			if (Transponder.RemoteInstance.IsSqlLogExport) {
				ins.Database.Log = Logger.Debug;
			}

			// 返す
			return ins;
		}

		/// <summary>
		/// 今の日時
		/// </summary>
		private DateTime? NowDate;

		/// <summary>
		/// DB時刻を調べる
		/// </summary>
		/// <param name="db">対象のDB</param>
		/// <returns>DBの現在時刻</returns>
		public async Task<DateTime> NowAsync() => (NowDate ?? (NowDate = await Database.SqlQuery<DateTime>("SELECT NOW()").SingleAsync())).Value;
	}

	// インターフェース関連付け

	public partial class d_treedata : IUserRecord, ITimeLoggingRecord, IInstanceIdRecord { }
	public partial class d_treemap : IUserRecord, ITimeLoggingRecord, IInstanceIdRecord { }
	public partial class d_user : IApplcationRecord, IUserRecord { }
	public partial class m_application : IApplcationRecord , ITimeLoggingRecord { }
	public partial class m_developer : IDeveloperRecord , ITimeLoggingRecord { }
	public partial class m_lobby : IApplcationRecord { }
	public partial class d_event : IApplcationRecord, ITimeLoggingRecord, IPeriodRecord { }
	public partial class d_sub_event : IApplcationRecord, ITimeLoggingRecord, IPeriodRecord { }
	public partial class d_event_entry_user : IApplcationRecord, ITimeLoggingRecord { }
	public partial class d_individual_match : IApplcationRecord, ITimeLoggingRecord { }
	public partial class d_friend : IApplcationRecord, ITimeLoggingRecord { }
	public partial class d_block_user : IApplcationRecord, ITimeLoggingRecord { }
	public partial class d_publish : IApplcationRecord, ITimeLoggingRecord { }
	public partial class d_support_ticket : IApplcationRecord, IUserRecord { }
	
}
