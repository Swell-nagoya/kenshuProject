﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// いろんな値チェック
	/// </summary>
	public static class NumericCheck {

		/// <summary>
		/// 配列長をチェックして問題なければ代入する
		/// </summary>
		/// <typeparam name="T">配列の型</typeparam>
		/// <param name="Export">出力先変数</param>
		/// <param name="Value">チェック対象</param>
		/// <param name="MaxSize">最大サイズ</param>
		/// <param name="ValueName">変数名(省略時value)</param>
		public static void ArraySize<T>(ref T[] Export, T[] Value, int MaxSize, string ValueName = "value") {
			if (Value == null) {
				// Nullはだめよ
				throw new ArgumentNullException(ValueName, "nullは指定できません");
			}

			if (Value.Length > MaxSize) {
				// 配列大きすぎよ
				throw new ArgumentOutOfRangeException(ValueName, Value.Length, $"{MaxSize}より大きな配列は指定できません");
			}

			// チェックを潜り抜けた
			Export = Value;
		}

		/// <summary>
		/// 配列サイズとnullチェック
		/// </summary>
		/// <typeparam name="T">配列の型</typeparam>
		/// <param name="Array">配列</param>
		/// <param name="MaxSize">配列最大サイズ</param>
		/// <returns>サイズオーバー or nullであればTrue</returns>
		public static bool IsArraySizeOverOrNull<T>(T[] Array, int MaxSize) => (Array == null || Array.Length > MaxSize);

	}
}
