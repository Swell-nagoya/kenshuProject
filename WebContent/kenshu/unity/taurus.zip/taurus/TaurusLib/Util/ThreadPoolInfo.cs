﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// スレッドプールについての情報を教えてくれる
	/// </summary>
	public static class ThreadPoolInfo {

		/// <summary>
		/// 情報を表示する
		/// </summary>
		/// <param name="export">出力用関数</param>
		public static void DumpInfo(Action<string> export) {

			ThreadPool.GetMaxThreads(out int workMax, out int ioMax);
			ThreadPool.GetAvailableThreads(out int workNow, out int ioNow);
			ThreadPool.GetMinThreads(out int workMin, out int ioMin);



			export.Invoke(
				$"======== THREAD POOL INFO ========" + Environment.NewLine +
				Environment.NewLine +
				$"WORKER" + Environment.NewLine +
				$"  Min:{workMin}" + Environment.NewLine +
				$"  Max:{workMax}" + Environment.NewLine +
				$"  Now:{workMax - workNow}" + Environment.NewLine +
				Environment.NewLine +
				$"IO" + Environment.NewLine +
				$"  Min:{ioMin}" + Environment.NewLine +
				$"  Max:{ioMax}" + Environment.NewLine +
				$"  Now:{workMax - workNow}" + Environment.NewLine +
				Environment.NewLine +
				$"==================================" + Environment.NewLine
				);

		}
	}
}
