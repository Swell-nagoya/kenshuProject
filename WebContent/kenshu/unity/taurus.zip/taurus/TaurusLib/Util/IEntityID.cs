﻿using System;

namespace Taurus.Util {
	/// <summary>
	/// エンティティID
	/// </summary>
	public interface IEntityID {

		/// <summary>
		/// 自己主張用ID
		/// </summary>
		Guid EntityID { get; }
	}
}