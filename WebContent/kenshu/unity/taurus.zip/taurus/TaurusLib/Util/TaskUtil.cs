﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static Taurus.Logger;

namespace Taurus.Util {
	/// <summary>
	/// タスクのチェック用
	/// </summary>
	public static class TaskUtil {

		/// <summary>
		/// 例外ログ出力処理を挟む
		/// </summary>
		/// <typeparam name="T">Taskが戻す型</typeparam>
		/// <param name="task">対象のタスク</param>
		/// <param name="export">例外ログ出力先</param>
		/// <returns>待機するべきタスク</returns>
		public static Task<T> ExLog<T>(this Task<T> task, Action<Exception> export) {

			return task.ContinueWith(e => {
				// 例外が出てたらログ出力に投げつける
				if (e.Exception != null) {
					ExportLog(e.Exception, export);
				}

				// 結果を返す
				// 例外処理もここでやるはず
				return e.Result;

			});
		}

		/// <summary>
		/// 例外ログ出力処理を挟む
		/// </summary>
		/// <param name="task">対象のタスク</param>
		/// <param name="export">例外ログ出力先</param>
		/// <returns>待機するべきタスク</returns>
		public static Task ExLog(this Task task, Action<Exception> export) {


			return task.ContinueWith(e => {
				// 例外が出てたらログ出力に回して例外吐きなおす
				if (e.Exception != null) {
					ExportLog(e.Exception, export);

					throw e.Exception;
				}
			});
		}

		/// <summary>
		/// 例外ログ出力制御
		/// </summary>
		/// <param name="exception">例外</param>
		/// <param name="export">例外ログ出力先</param>
		private static void ExportLog(AggregateException exception, Action<Exception> export) {
			// キャンセル以外の例外を検出したら表示する
			if (exception.InnerExceptions.Any(f => !(f is OperationCanceledException))) {
				export.Invoke(exception);
			}
		}

		/// <summary>
		/// コンテキストスイッチしたい時とかに使え
		/// </summary>
		/// <returns></returns>
		public static Task Yield() {
			return Task.Delay(100);
		}

		/// <summary>
		/// タスクが実行中か否かチェック
		/// 例外が発生した場合その例外を吐き出す
		/// </summary>
		/// <param name="task">チェック対象のタスク</param>
		/// <returns>trueなら動いてる</returns>
		public static bool IsRunning(this Task task) {

			// 何らかの終了条件を満たしていなえればtrue
			return !task.IsCanceled && !task.IsCompleted && !task.IsFaulted;


		}
		
		/// <summary>
		/// AsyncでもWaitしたい
		/// </summary>
		/// <param name="task">待機するタスク</param>
		/// <param name="Interval">終了チェック間隔</param>
		public static void WaitAsync(this Task task, int Interval = 10) {
			while (task.IsRunning()) { Thread.Sleep(Interval); }
		}

	}
}
