﻿using System.Linq;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System;

namespace Taurus.Util {
	/// <summary>
	/// ストリーム便利キット
	/// </summary>
	public static class StreamUtil {

		/// <summary>
		/// ストリーム読み出しに挑戦
		/// </summary>
		/// <param name="Stream">読み出し元ストリーム</param>
		/// <param name="buffer">書き出し先バッファ</param>
		/// <param name="Cancel">キャンセルト－クン</param>
		/// <returns>実際に読み出した量</returns>
		static public async Task<int> TryReadAsync(this Stream Stream, byte[] buffer, CancellationToken Cancel) {

			int read = 0;


			while (read < buffer.Length) {
				// 読み出し
				int nowRead = await Stream.ReadAsync(buffer, read, buffer.Length - read, Cancel).ConfigureAwait(false);

				if (nowRead <= 0) {
					// 読み取り量が0だとソケットが死んでるかも
					return read;
				}

				// 読み出し量加算
				read += nowRead;
			}


			return read;
		}

		/// <summary>
		/// バイト配列を非同期書き出し
		/// </summary>
		/// <param name="Stream">書き出し先ストリーム</param>
		/// <param name="Write">書き出し内容</param>
		/// <param name="Cancel">キャンセルトークン</param>
		/// <returns>別のスレッドに投げるのでそれ相応の処理</returns>
		static public Task WriteAsync(this Stream Stream, byte[] Write, CancellationToken Cancel) {
			return Stream.WriteAsync(Write, 0, Write.Length, Cancel);
		}

		/// <summary>
		/// バイト配列の書き出し
		/// </summary>
		/// <param name="Stream">書き出し先ストリーム</param>
		/// <param name="Write">書き出し内容</param>
		static public void Write(this Stream Stream, byte[] Write) {
			Stream.Write(Write, 0, Write.Length);
		}

		/// <summary>
		/// ストリームからパターンと同じだけの長さの領域を読み出し
		/// パターンと一致するか確認
		/// </summary>
		/// <param name="Stream">読み出し元ストリーム</param>
		/// <param name="Pattern">チェックするパターン</param>
		/// <param name="Cancel">キャンセルトークン</param>
		/// <returns>チェック成功時true</returns>
		static public async Task<bool> PatternCheckAsync(this Stream Stream, byte[] Pattern, CancellationToken Cancel) {

			// 読み出しバッファ作成
			byte[] readbuf = new byte[Pattern.Length];

			// 読み出し
			if (Pattern.Length != await Stream.TryReadAsync(readbuf, Cancel).ConfigureAwait(false)) {
				// 読み出し失敗
				return false;
			}

			// パターンチェック
			return Pattern.SequenceEqual(readbuf);

		}

		/// <summary>
		/// 閉じてみる
		/// </summary>
		/// <param name="Stream">対象ストリーム</param>
		/// <returns>閉じれたらtrue</returns>
		static public bool TryClose(this Stream Stream) {
			try {
				// 閉じて完了
				Stream.Close();
				return true;
			} catch (Exception) {
				// 失敗した
				return false;
			}
		}

	}
}
