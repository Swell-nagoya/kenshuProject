﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// 時間を素敵に扱うやつ
	/// </summary>
	public static class TimeUtil {

		/// <summary>
		/// タイムアウト計測(ミリ秒)
		/// 指定時間よりも時間経過していたらtrueになる
		/// </summary>
		/// <param name="TimeStamp">計測開始時刻</param>
		/// <param name="TimeoutMillSeconds">タイムアウト期限</param>
		/// <returns>タイムアウト検出時true</returns>
		public static bool IsTimeOutMs(this DateTime TimeStamp, double TimeoutMillSeconds) {
			return (DateTime.Now - TimeStamp).TotalMilliseconds >= TimeoutMillSeconds;
		}

		/// <summary>
		/// タイムアウト計測(ミリ秒)
		/// 指定時間よりも時間経過していたらtrueになる
		/// Utc時間用
		/// </summary>
		/// <param name="TimeStamp">計測開始時刻</param>
		/// <param name="TimeoutMillSeconds">タイムアウト期限</param>
		/// <returns>タイムアウト検出時true</returns>
		public static bool IsUtcTimeOutMs(this DateTime TimeStamp, double TimeoutMillSeconds) {
			return (DateTime.UtcNow - TimeStamp).TotalMilliseconds >= TimeoutMillSeconds;
		}


	}
}
