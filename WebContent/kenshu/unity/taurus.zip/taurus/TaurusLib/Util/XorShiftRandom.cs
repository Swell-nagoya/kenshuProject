﻿using System;


namespace Taurus.Util {
	/// <summarY>
	/// わくわく快適乱数
	/// wikipediaから借用
	/// </summarY>
	public class XorShiftRandom {


		UInt32 x;
		UInt32 y;
		UInt32 z;
		UInt32 w;

		/// <summary>
		/// 初期化
		/// </summary>
		/// <param name="SeedGenerator">シード値を取得するための乱数メソッド</param>
		public XorShiftRandom(Random SeedGenerator) {

			// 乱数バッファ作って乱数
			byte[] buf = new byte[sizeof(UInt32) * 4];
			SeedGenerator.NextBytes(buf);


			// 全てが0でなくなるまでループ
			do {
				x = System.BitConverter.ToUInt32(buf, sizeof(UInt32) * 0);
				y = System.BitConverter.ToUInt32(buf, sizeof(UInt32) * 1);
				z = System.BitConverter.ToUInt32(buf, sizeof(UInt32) * 2);
				w = System.BitConverter.ToUInt32(buf, sizeof(UInt32) * 3);

			} while (x + y + z + w != 0);


		}


		UInt32 Xor128() {

			UInt32 t;

			t = x ^ (x << 11);
			x = y;
			y = z;
			z = w;
			return w = (w ^ (w >> 19)) ^ (t ^ (t >> 8));
		}


	}
}
