﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Taurus.Util {
	/// <summary>
	/// AES暗号アルゴリズム便利キット
	/// </summary>
	public class AesStreamProvider :IDisposable{
		
		/// <summary>
		/// ブロックサイズ(bit)
		/// </summary>
		private const int BLOCK_SIZE = 128;   // 128bit 固定

		/// <summary>
		/// キーサイズ
		/// 128/192/256bit から選択できる
		/// </summary>
		private const int KEY_SIZE = 128;

		/// <summary>
		/// AES初期化クン
		/// </summary>
		private AesCryptoServiceProvider Provider;

		/// <summary>
		/// 読み取り用暗号化トランスフォーム
		/// </summary>
		private readonly ICryptoTransform ReadTransform;

		/// <summary>
		/// 書き込み用暗号化トランスフォーム
		/// </summary>
		private readonly ICryptoTransform WriteTransform;

		/// <summary>
		/// 初期化
		/// </summary>
		public AesStreamProvider(int key, int vi) {
			// 暗号化する奴をパラメーター指定で生成
			Provider = new AesCryptoServiceProvider() {
				BlockSize = BLOCK_SIZE,
				KeySize = KEY_SIZE,
				Mode = CipherMode.CBC,
				Padding = PaddingMode.PKCS7

			};

			// キーとベクトルを生成
			new Random(key).NextBytes(Provider.Key = new Byte[KEY_SIZE / 8]);
			new Random(key).NextBytes(Provider.IV = new Byte[KEY_SIZE / 8]);


			// トランスフォーム出力
			ReadTransform = Provider.CreateDecryptor();
			WriteTransform = Provider.CreateEncryptor();
		}

		/// <summary>
		/// 読み取りストリーム生成
		/// </summary>
		/// <param name="BaseStream">元となるストリーム</param>
		/// <returns>暗号化解読用ストリーム</returns>
		public CryptoStream CreateInput(Stream BaseStream) {
			return new CryptoStream(BaseStream, Provider.CreateDecryptor(),CryptoStreamMode.Read);
		}

		/// <summary>
		/// 書き出しストリーム生成
		/// </summary>
		/// <param name="BaseStream">出力先ストリーム</param>
		/// <returns>暗号化用ストリーム</returns>
		public CryptoStream CreateOutput(Stream BaseStream) {
			return new CryptoStream(BaseStream, Provider.CreateEncryptor(), CryptoStreamMode.Write);
		}

		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		/// <summary>
		/// 解放処理
		/// </summary>
		/// <param name="disposing">マネージドオブジェクトの解放をするか否か</param>
		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。
				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。

				ReadTransform.Dispose();
				WriteTransform.Dispose();

				disposedValue = true;
			}
		}

		// TODO: 上の Dispose(bool disposing) にアンマネージ リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
		// ~AesStreamProvider() {
		//   // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
		//   Dispose(false);
		// }

		// このコードは、破棄可能なパターンを正しく実装できるように追加されました。
		/// <summary>
		/// 解放処理
		/// </summary>
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			// GC.SuppressFinalize(this);
		}
		#endregion

	}
}