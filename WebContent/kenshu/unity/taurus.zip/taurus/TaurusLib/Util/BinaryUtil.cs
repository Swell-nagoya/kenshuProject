﻿using BitConverter;
using System;
using System.IO;
/*
* T4テンプレートの習作として自動生成してみているだけなので
* コードに変更が必要であれば適時テンプレート側を変更するか
* partialにしておくんで外部クラスでくっつけてください
*
* .csの方直接弄っても無駄だよ♥
*/ 
namespace Taurus.Util {
	/// <summary>
	/// アーキテクチャを考慮してバイナリ変換するクラス
	/// </summary>
	public static partial class BinaryUtil {

		/// <summary>
		/// 基準点となるエンディアン
		/// </summary>
		public static readonly EndianBitConverter Current = EndianBitConverter.LittleEndian;

		/// <summary>
		/// Int16読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Int16 ReadInt16Arc(this BinaryReader reader) => Current.ToInt16(reader.ReadBytes(sizeof(Int16)),0);

		/// <summary>
		/// UInt16読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static UInt16 ReadUInt16Arc(this BinaryReader reader) => Current.ToUInt16(reader.ReadBytes(sizeof(UInt16)),0);

		/// <summary>
		/// Int32読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Int32 ReadInt32Arc(this BinaryReader reader) => Current.ToInt32(reader.ReadBytes(sizeof(Int32)),0);

		/// <summary>
		/// UInt32読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static UInt32 ReadUInt32Arc(this BinaryReader reader) => Current.ToUInt32(reader.ReadBytes(sizeof(UInt32)),0);

		/// <summary>
		/// Int64読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Int64 ReadInt64Arc(this BinaryReader reader) => Current.ToInt64(reader.ReadBytes(sizeof(Int64)),0);

		/// <summary>
		/// UInt64読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static UInt64 ReadUInt64Arc(this BinaryReader reader) => Current.ToUInt64(reader.ReadBytes(sizeof(UInt64)),0);

		/// <summary>
		/// Single読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Single ReadSingleArc(this BinaryReader reader) => Current.ToSingle(reader.ReadBytes(sizeof(Single)),0);

		/// <summary>
		/// Double読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Double ReadDoubleArc(this BinaryReader reader) => Current.ToDouble(reader.ReadBytes(sizeof(Double)),0);

		/// <summary>
		/// Boolean読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Boolean ReadBooleanArc(this BinaryReader reader) => Current.ToBoolean(reader.ReadBytes(sizeof(Boolean)),0);

		/// <summary>
		/// Char読み込み
		/// </summary>
		/// <param name="reader">読み込み対象</param>
		/// <returns>読み込んだ値</returns>
		public static Char ReadCharArc(this BinaryReader reader) => Current.ToChar(reader.ReadBytes(sizeof(Char)),0);

		/// <summary>
		/// Int16をリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Int16 value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// UInt16をリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, UInt16 value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// Int32をリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Int32 value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// UInt32をリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, UInt32 value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// Int64をリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Int64 value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// UInt64をリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, UInt64 value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// Singleをリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Single value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// Doubleをリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Double value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// Booleanをリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Boolean value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// Charをリトルエンディアンで書き出し
		/// </summary>
		/// <param name="writer">書き出し対象</param>
		/// <param name="value">書き出す値</param>
		public static void WriteArc(this BinaryWriter writer, Char value) => writer.Write(Current.GetBytes(value));

		/// <summary>
		/// バイト配列からInt16に変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Int16 ToInt16(byte[] value, int startIndex) => Current.ToInt16(value, startIndex);

		/// <summary>
		/// バイト配列からUInt16に変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static UInt16 ToUInt16(byte[] value, int startIndex) => Current.ToUInt16(value, startIndex);

		/// <summary>
		/// バイト配列からInt32に変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Int32 ToInt32(byte[] value, int startIndex) => Current.ToInt32(value, startIndex);

		/// <summary>
		/// バイト配列からUInt32に変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static UInt32 ToUInt32(byte[] value, int startIndex) => Current.ToUInt32(value, startIndex);

		/// <summary>
		/// バイト配列からInt64に変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Int64 ToInt64(byte[] value, int startIndex) => Current.ToInt64(value, startIndex);

		/// <summary>
		/// バイト配列からUInt64に変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static UInt64 ToUInt64(byte[] value, int startIndex) => Current.ToUInt64(value, startIndex);

		/// <summary>
		/// バイト配列からSingleに変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Single ToSingle(byte[] value, int startIndex) => Current.ToSingle(value, startIndex);

		/// <summary>
		/// バイト配列からDoubleに変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Double ToDouble(byte[] value, int startIndex) => Current.ToDouble(value, startIndex);

		/// <summary>
		/// バイト配列からBooleanに変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Boolean ToBoolean(byte[] value, int startIndex) => Current.ToBoolean(value, startIndex);

		/// <summary>
		/// バイト配列からCharに変換
		/// </summary>
		/// <param name="value">バイト配列</param>
		/// <param name="startIndex">読み出し開始インデックス</param>
		/// <returns>読み出した値</returns>
		public static Char ToChar(byte[] value, int startIndex) => Current.ToChar(value, startIndex);

		/// <summary>
		/// Int16をバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Int16 value)=>Current.GetBytes(value);

		/// <summary>
		/// UInt16をバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(UInt16 value)=>Current.GetBytes(value);

		/// <summary>
		/// Int32をバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Int32 value)=>Current.GetBytes(value);

		/// <summary>
		/// UInt32をバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(UInt32 value)=>Current.GetBytes(value);

		/// <summary>
		/// Int64をバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Int64 value)=>Current.GetBytes(value);

		/// <summary>
		/// UInt64をバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(UInt64 value)=>Current.GetBytes(value);

		/// <summary>
		/// Singleをバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Single value)=>Current.GetBytes(value);

		/// <summary>
		/// Doubleをバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Double value)=>Current.GetBytes(value);

		/// <summary>
		/// Booleanをバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Boolean value)=>Current.GetBytes(value);

		/// <summary>
		/// Charをバイト配列に変換
		/// </summary>
		/// <param name="value">変換対象の値</param>
		/// <returns>変換したデータ</returns>
		public static byte[] GetBytes(Char value)=>Current.GetBytes(value);

	}
}

