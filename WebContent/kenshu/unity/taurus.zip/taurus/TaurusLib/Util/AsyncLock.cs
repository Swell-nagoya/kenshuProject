﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// asyncでもlockしたい！
	/// http://www.hanselman.com/blog/ComparingTwoTechniquesInNETAsynchronousCoordinationPrimitives.aspx
	/// </summary>

	public sealed class AsyncLock{
		private readonly SemaphoreSlim m_semaphore;
		private readonly Task<IDisposable> m_releaser;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public AsyncLock(int entryCount = 1) {
			m_semaphore = new SemaphoreSlim(entryCount, entryCount);
			m_releaser = Task.FromResult((IDisposable)new Releaser(this));
		}

		/// <summary>
		/// ロックを取る
		/// </summary>
		/// <returns></returns>
		public Task<IDisposable> LockAsync() {
			var wait = m_semaphore.WaitAsync();
			return wait.IsCompleted ?
						m_releaser :
						wait.ContinueWith((_, state) => (IDisposable)state,
							m_releaser.Result, CancellationToken.None,
			TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
		}

		/// <summary>
		/// ロック開放用クラス
		/// </summary>
		private sealed class Releaser : IDisposable {
			private readonly AsyncLock m_toRelease;
			internal Releaser(AsyncLock toRelease) { m_toRelease = toRelease; }
			public void Dispose() { m_toRelease.m_semaphore.Release(); }
		}
		
	}
}
