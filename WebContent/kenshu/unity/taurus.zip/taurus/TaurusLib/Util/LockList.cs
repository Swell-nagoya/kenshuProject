﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// ロックするリスト
	/// </summary>
	/// <typeparam name="T">要素の型</typeparam>
	public sealed class LockList<T> : IList<T>, ICollection<T>, IEnumerable<T>, IReadOnlyCollection<T>, IReadOnlyList<T> {

		/// <summary>
		/// 処理対象のリスト
		/// </summary>
		private readonly List<T> BaseCollection = new List<T>();
		

		/// <summary>
		/// 要素に添え字アクセス
		/// </summary>
		public T this[int index] { get { lock (BaseCollection) { return BaseCollection[index]; } } set { lock (BaseCollection) { BaseCollection[index] = value; } } }

		/// <summary>
		/// 読み取り専用か否か
		/// </summary>
		public bool IsReadOnly => false;

		/// <summary>
		/// 要素数を返す(内部用)
		/// </summary>
		/// <returns>要素数</returns>
		private int InternalCount() {
			lock (BaseCollection) {
				return BaseCollection.Count;
			}
		}

		/// <summary>
		/// 要素数を数える
		/// </summary>
		int ICollection<T>.Count => InternalCount();

		/// <summary>
		/// 要素数を数える
		/// </summary>
		int IReadOnlyCollection<T>.Count => InternalCount();

		/// <summary>
		/// 要素を追加
		/// </summary>
		/// <param name="item">追加する要素</param>
		public void Add(T item) {
			lock (BaseCollection) {
				BaseCollection.Add(item);
			}
		}

		/// <summary>
		/// 空にする
		/// </summary>
		public void Clear() {
			lock (BaseCollection) {
				BaseCollection.Clear();
			}
		}

		/// <summary>
		/// 含まれているか確認
		/// </summary>
		/// <param name="item">探す要素</param>
		/// <returns>含まれていればTrue</returns>
		public bool Contains(T item) {
			lock (BaseCollection) {
				return BaseCollection.Contains(item);
			}
		}

		/// <summary>
		/// 配列にコピー
		/// </summary>
		/// <param name="array">書き出し先配列</param>
		/// <param name="arrayIndex">配列の書き出し開始地点</param>
		public void CopyTo(T[] array, int arrayIndex) {
			lock (BaseCollection) {
				BaseCollection.CopyTo(array, arrayIndex);
			}
		}

		/// <summary>
		/// 要素数を返す
		/// </summary>
		public int Count() {
			lock (BaseCollection) {
				return BaseCollection.Count;
			}
		}

		/// <summary>
		/// 列挙を返す
		/// 要素を一度バッファするから覚悟するべし
		/// バッファするから列挙中でも消せるかもしれんぞ
		/// </summary>
		/// <returns></returns>
		public IEnumerator<T> GetEnumerator() {
			lock (BaseCollection) {
				return BaseCollection.ToList().GetEnumerator();
			}
		}

		/// <summary>
		/// 検索してインデックス番号を返す
		/// </summary>
		/// <param name="item">検索対象の要素</param>
		/// <returns>インデックス番号 or null</returns>
		public int IndexOf(T item) {
			lock (BaseCollection) {
				return BaseCollection.IndexOf(item);
			}
		}

		/// <summary>
		/// 要素と要素の間に新しい要素を挿入する
		/// </summary>
		/// <param name="index">挿入位置</param>
		/// <param name="item">挿入する要素</param>
		public void Insert(int index, T item) {
			lock (BaseCollection) {
				BaseCollection.Insert(index, item);
			}
		}

		/// <summary>
		/// 要素を削除する
		/// </summary>
		/// <param name="item">削除対象の要素</param>
		/// <returns>成功したらtrue</returns>
		public bool Remove(T item) {
			lock (BaseCollection) {
				return BaseCollection.Remove(item);
			}
		}

		/// <summary>
		/// 特定の位置の要素を削除する
		/// </summary>
		/// <param name="index">削除位置</param>
		public void RemoveAt(int index) {
			lock (BaseCollection) {
				BaseCollection.RemoveAt(index);
			}
		}

		/// <summary>
		/// イテレーター返せる状態で返す
		/// </summary>
		/// <returns>複製されたイテレータ</returns>
		IEnumerator IEnumerable.GetEnumerator() {
			lock (BaseCollection) {
				return BaseCollection.ToArray().GetEnumerator();
			}
		}

		/// <summary>
		/// 条件で指定した条件を満たす場合すべて削除
		/// </summary>
		/// <param name="match">削除条件</param>
		/// <returns>削除件数</returns>
		public int RemoveAll(Predicate<T> match) {
			lock (BaseCollection) {
				return BaseCollection.RemoveAll(match);
			}
		}

	}
}
