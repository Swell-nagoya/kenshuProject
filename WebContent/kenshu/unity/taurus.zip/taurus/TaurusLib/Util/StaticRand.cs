﻿using System;

namespace Taurus.Util {
	/// <summary>
	/// 定数型乱数生成機
	/// </summary>
	public static class StaticRand {

		/// <summary>
		/// 乱数生成インスタンス
		/// </summary>
		private static Random Ins = new Random();



	}
}
