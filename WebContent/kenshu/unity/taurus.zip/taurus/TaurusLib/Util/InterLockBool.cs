﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Taurus.Util {

	/// <summary>
	/// インターロックするboolもどき
	/// </summary>
	public class InterLockBool {


		/// <summary>
		/// TRUE
		/// </summary>
		const int TRUE = 1;

		/// <summary>
		/// FALSE
		/// </summary>
		const int FALSE = 0;

		/// <summary>
		/// 値格納用
		/// </summary>
		private int internalValue = FALSE;

		/// <summary>
		/// 指し示している値
		/// </summary>
		public bool Value {
			get => internalValue == TRUE;
			set => Interlocked.Exchange(ref internalValue, value ? TRUE : FALSE);
		}

		/// <summary>
		/// TrueであればFalseにしようとする
		/// </summary>
		/// <returns>もともとTrueであればTrue</returns>
		public bool TryTrueToFalse() {
			return Interlocked.CompareExchange(ref internalValue, FALSE, TRUE) == TRUE;
		}

		/// <summary>
		/// FalseであればTrueにしようとする
		/// </summary>
		/// <returns>もともとFalseであればTrue</returns>
		public bool TryFalseToTrue() {
			return Interlocked.CompareExchange(ref internalValue, TRUE, FALSE) == FALSE;
		}
		
	}
}
