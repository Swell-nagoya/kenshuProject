﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// Linqを素敵に使いこなす用
	/// </summary>
	public static class LinqUtil {
		

		/// <summary>
		/// コレクションのパーティション分割
		/// 
		/// 全件操作するかんな！
		/// </summary>
		/// <typeparam name="T">コレクションの型</typeparam>
		/// <param name="Source">操作対象のコレクション</param>
		/// <param name="Size">パーティションあたりの最大サイズ</param>
		/// <returns>分割されたコレクション</returns>
		public static IEnumerable<IEnumerable<T>> Partition<T>(this IEnumerable<T> Source, int Size) {
			// イテレーターに出す
			using (IEnumerator<T> iterator = Source.GetEnumerator()) {

				// 次がある限り返し続ける
				while (iterator.MoveNext()) {
					
					// 分割要素ごとに配列にして返す
					yield return PartitionInternalIterator(iterator, Size).ToArray();
				}
			}
		}


		/// <summary>
		/// パーティション分割内美処理用イテレーター
		/// 入る前にmovenextすること
		/// </summary>
		/// <typeparam name="T">イテレーターの型</typeparam>
		/// <param name="Source">処理対象のイテレーター</param>
		/// <param name="Size">分割サイズ</param>
		/// <returns></returns>
		private static IEnumerable<T> PartitionInternalIterator<T>(IEnumerator<T> Source, int Size) {

			// とりあえず一件返しておく
			yield return Source.Current;

			// 指定サイズループするかイテレーターが限界に達するまで要素を一つ一つ返し続ける
			// 但し開始位置はさっき一件返したので一つずれる
			for (int i = 1; i < Size && Source.MoveNext(); i++) {
				yield return Source.Current;
			}


		}

	}
}
