﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Taurus.Util {
	/// <summary>
	/// スレッド管理
	/// </summary>
	public abstract class ThreadManagera : IDisposable {
		/// <summary>
		/// 処理するスレッド
		/// </summary>
		private Thread ThreadIns;

		/// <summary>
		/// 初期化
		/// </summary>
		public ThreadManagera() {
			// インスタンスを生成して発火
			ThreadIns = new Thread(ThreadFunc);
			ThreadIns.Start();
		}

		/// <summary>
		/// 別スレッド処理
		/// </summary>
		protected abstract void ThreadFunc();
		
		#region "解放処理(VC自動生成)"
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		/// <summary>
		/// ステキな解放処理
		/// </summary>
		/// <param name="disposing">アンマネージドなやつを処理するか否か</param>
		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。

					// スレッド停止
					ThreadIns.Abort();
				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。

				disposedValue = true;
			}
		}

		
		/// <summary>
		/// ステキな解放処理
		/// </summary>
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
	
		}
		#endregion


	}
}
