﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Util {
	/// <summary>
	/// ネットワーク例外処理に便利なやつ
	/// </summary>
	public static class NetExceptionCheck {

		/// <summary>
		/// タスク処理してるときにIOなチェックする奴
		/// </summary>
		/// <param name="exception">発生した例外</param>
		/// <returns>キャンセルないしIO例外であればtrue</returns>
		public static bool IsTaskIoExcepton(this Exception exception) {
			return exception is IOException || exception is OperationCanceledException || exception is ObjectDisposedException;
		}

	}
}
