﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Util;

namespace Taurus.Coroutine {
	/// <summary>
	/// コルーチンを待つ処理を作る
	/// </summary>
	public static class CoroutineWaitActionFactory {

		/// <summary>
		/// 条件を満たしたらtrueになるようなラムダを返す
		/// </summary>
		/// <param name="WaitObj">対象の待つオブジェクト</param>
		/// <returns>待機完了時trueになるFunc</returns>
		public static Func<bool> Create(object WaitObj) {
			

			// イテレーター待機系
			if (WaitObj is IEnumerator iter) {
				return () => !iter.MoveNext();
			}

			// タスク待機
			if (WaitObj is Task task) {
				return () => !task.IsRunning();
			}

			// それ以外なら即完了
			return () => true;
		}

	}
}
