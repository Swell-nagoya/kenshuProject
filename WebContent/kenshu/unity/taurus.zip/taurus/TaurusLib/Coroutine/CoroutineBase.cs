﻿using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Util;

namespace Taurus.Lib {

	/// <summary>
	/// コルーチン基礎
	/// </summary>
	public abstract class CoroutineBase : IDisposable {

		/// <summary>
		/// コルーチン置き場
		/// </summary>
		private IEnumerator Routine_ = null;

		/// <summary>
		/// コルーチン参照
		/// </summary>
		public IEnumerator Routine { get { return Routine_ ?? (Routine_ = InternalCoroutine()); } }

		/// <summary>
		/// ループフラグ
		/// </summary>
		public bool IsLoop { get; private set; } = true;

		/// <summary>
		/// コルーチン停止
		/// </summary>
		private void Stop() {
			IsLoop = false;
		}

		/// <summary>
		/// 吐き出された例外
		/// </summary>
		public Exception ThrowException { get; private set; }

		/// <summary>
		/// コルーチン内部制御用
		/// </summary>
		/// <returns></returns>
		private IEnumerator InternalCoroutine() {


			// コルーチン生成
			IEnumerator routine = Coroutine();

			// ループフラグがOFFになるまで処理
			while (IsLoop) {
				try {
					// 実行する
					IsLoop = routine.MoveNext();

				} catch (Exception e) {
					// 例外を記録して外に投げる
					ThrowException = e;
					Console.Error.WriteLine(e);
					throw;
				}


				// Taskっぽい値が帰ってきたら終了を待機する
				if (routine.Current is Task task) {
					while (task.IsRunning()) { yield return null; }
				}

				// イテレーターっぽい値が帰ってきたら死ぬまで回す
				if (routine.Current is IEnumerator iter) {
					while (iter.MoveNext()) { yield return null; }
				}

				// コルーチンっぽい値が帰ってきたら死ぬまで回す
				if (routine.Current is CoroutineBase cor) {
					while (cor.Routine.MoveNext()) { yield return null; }
				}


				// 値を返す
				yield return routine.Current;
			}


			// ループから出たら終了処理を行う
			((IDisposable)this).Dispose();
			yield break;

		}

		/// <summary>
		/// コルーチンメソッド
		/// </summary>
		protected abstract IEnumerator Coroutine();


		/// <summary>
		/// タスク作って実行する奴
		/// </summary>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>制御用タスク</returns>
		public async Task TaskRun(CancellationTokenSource token = null) {

			// コルーチン生成
			var routine = Coroutine();
			try {

				// 実行する
				while (routine.MoveNext() && !(token?.IsCancellationRequested ?? false)) {
					await TaskUtil.Yield().ConfigureAwait(false);
				}

			} catch (Exception e) {
				Logger.Warning(e);
			}
			
		}

		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		/// <summary>
		/// 解放する
		/// </summary>
		/// <param name="disposing">マネージドリソースの解放を行うか否か</param>
		private void Dispose(bool disposing) {
			if (!disposedValue) {
				// 子クラスが先に滅ぶ
				ChildDispose(disposing);

				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。
				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。

				disposedValue = true;
			}
		}
		

		/// <summary>
		/// ステキな解放処理
		/// </summary>
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			// GC.SuppressFinalize(this);
		}

		/// <summary>
		/// 子クラスを解放する
		/// </summary>
		/// <param name="disposing">マネージドリソースを解放するか否か</param>
		protected virtual void ChildDispose(bool disposing) { }
		#endregion


	}
}
