﻿using System.Linq;
using System.Collections.Generic;
using System;
using Taurus.Lib;
using System.Collections;
using System.Threading.Tasks;
using Taurus.Util;

namespace Taurus.Lib {
	/// <summary>
	/// コルーチン管理
	/// </summary>
	public class CoroutineManager : CoroutineBase {
		/// <summary>
		/// コルーチン置き場
		/// </summary>
		private List<Task> Routines = new List<Task>();

		/// <summary>
		/// コルーチン追加
		/// </summary>
		/// <param name="Routine">追加されるべきコルーチン</param>
		public void Add(CoroutineBase Routine) {
			lock (Routines) {
				Routines.Add(Routine.TaskRun());
			}
		}

		/// <summary>
		/// コルーチン1ステップ実行
		/// </summary>
		/// <returns>コルーチンが生きていればtrue</returns>
		public bool Exect() {
			lock (Routines) {
				// 死んだルーチンを破棄していく
				// O(n)の演算であるためListの内容物全てを叩く
				// Routines.RemoveAll(e => !SafeExect(e));
				Routines.RemoveAll(e => !e.IsRunning());
				return IsCoroutine;
			}
		}

		/// <summary>
		/// コルーチンがあるかチェック
		/// </summary>
		public bool IsCoroutine {
			get {
				lock (Routines) { return Routines.Any(); }
			}
		}

		/// <summary>
		/// 実行中のコルーチン数
		/// </summary>
		public int Count {
			get {
				lock (Routines) { return Routines.Count; }
			}
		}

		/// <summary>
		/// 安全にコルーチン実行
		/// </summary>
		/// <param name="routine">実行するルーチン</param>
		private static bool SafeExect(CoroutineBase routine) {
			// ルーチンは存在しなければならない
			if (routine == null) { return false; }

			try {
				// 実行してみる
				
				return routine.Routine.MoveNext();
				

			} catch (Exception e) {
				// 例外が出たやつは失敗なのでログ出し
				Logger.Warning(e);

				// 解放しようとする
				try {
					((IDisposable)routine).Dispose();
				} catch (Exception f) {
					// 解放すらも失敗した！
					Logger.Warning(f);
				}

				// 失敗
				return false;
			}
			
		}

		/// <summary>
		/// コルーチン実行用のコルーチン
		/// </summary>
		/// <returns>コルーチン</returns>
		protected override IEnumerator Coroutine() {
			while (true) {
				// ずっと実行し続ける
				Exect();
				yield return null;
			}
		}
	}
}
