﻿using System;
using System.Runtime.Serialization;

namespace Taurus.Exceptions {
	/// <summary>
	/// メッセージデカすぎ
	/// </summary>
	[Serializable]
	public class TaurusMessageTooLargeException : Exception {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TaurusMessageTooLargeException() {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		public TaurusMessageTooLargeException(string message) : base(message) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		/// <param name="innerException"></param>
		public TaurusMessageTooLargeException(string message, Exception innerException) : base(message, innerException) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected TaurusMessageTooLargeException(SerializationInfo info, StreamingContext context) : base(info, context) {
		}
	}
}
