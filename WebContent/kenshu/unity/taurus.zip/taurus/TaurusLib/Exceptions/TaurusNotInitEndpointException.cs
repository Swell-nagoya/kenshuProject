﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Exceptions {
	/// <summary>
	/// エンドポイントの初期化が完了していない
	/// </summary>
	[Serializable]
	public class TaurusNotInitEndpointException : TaurusException {
		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TaurusNotInitEndpointException() {
		}
		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		public TaurusNotInitEndpointException(string message) : base(message) {
		}
		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		/// <param name="innerException"></param>
		public TaurusNotInitEndpointException(string message, Exception innerException) : base(message, innerException) {
		}
		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected TaurusNotInitEndpointException(SerializationInfo info, StreamingContext context) : base(info, context) {
		}
	}
}
