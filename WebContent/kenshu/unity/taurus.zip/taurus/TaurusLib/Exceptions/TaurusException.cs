﻿using System;
using System.Runtime.Serialization;

namespace Taurus.Exceptions {
	/// <summary>
	/// タウルス例外
	/// </summary>
	[Serializable]
	public class TaurusException : Exception {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TaurusException() {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message">ステキなメッセージ</param>
		public TaurusException(string message) : base(message) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message">ステキなメッセージ</param>
		/// <param name="innerException">内蔵する例外？</param>
		public TaurusException(string message, Exception innerException) : base(message, innerException) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected TaurusException(SerializationInfo info, StreamingContext context) : base(info, context) {
		}
	}
}
