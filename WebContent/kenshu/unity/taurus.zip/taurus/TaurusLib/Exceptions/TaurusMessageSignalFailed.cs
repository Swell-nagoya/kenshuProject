﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Exceptions {
	/// <summary>
	/// シグナルがおかしい
	/// </summary>
	[Serializable]
	public class TaurusMessageSignalFailed : TaurusException {
		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TaurusMessageSignalFailed() {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		public TaurusMessageSignalFailed(string message) : base(message) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		/// <param name="innerException"></param>
		public TaurusMessageSignalFailed(string message, Exception innerException) : base(message, innerException) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected TaurusMessageSignalFailed(SerializationInfo info, StreamingContext context) : base(info, context) {
		}
	}
}
