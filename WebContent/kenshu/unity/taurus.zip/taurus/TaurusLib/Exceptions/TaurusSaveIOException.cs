﻿using System;
using System.IO;
using System.Runtime.Serialization;

namespace Taurus.Exceptions {
	/// <summary>
	/// セーブがうまく扱えなかった
	/// </summary>
	[Serializable]
	public class TaurusSaveIOException : IOException {
		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TaurusSaveIOException() {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		public TaurusSaveIOException(string message) : base(message) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		/// <param name="innerException"></param>
		public TaurusSaveIOException(string message, Exception innerException) : base(message, innerException) {
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected TaurusSaveIOException(SerializationInfo info, StreamingContext context) : base(info, context) {
		}
	}
}
