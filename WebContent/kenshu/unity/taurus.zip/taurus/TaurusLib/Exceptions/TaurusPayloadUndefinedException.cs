﻿using System;
using System.Runtime.Serialization;

namespace Taurus.Exceptions {
	/// <summary>
	/// ペイロードすっからかん
	/// </summary>
	[Serializable]
	public class TaurusPayloadUndefinedException : TaurusException {
		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TaurusPayloadUndefinedException() {
		}
		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		public TaurusPayloadUndefinedException(string message) : base(message) {
		}
		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="message"></param>
		/// <param name="innerException"></param>
		public TaurusPayloadUndefinedException(string message, Exception innerException) : base(message, innerException) {
		}
		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected TaurusPayloadUndefinedException(SerializationInfo info, StreamingContext context) : base(info, context) {
		}
	}
}
