﻿using System;
using Newtonsoft.Json.Linq;
using Taurus.Data.Network;
using Taurus.Network.Common;
using System.Linq;

namespace Taurus.Data {
	/// <summary>
	/// 情報格納ベース
	/// </summary>
	[Serializable]
	public abstract class EntityBase : IJsonSelializeData {
		
		/// <summary>
		/// EntityID
		/// </summary>
		public Guid EntityID = Guid.NewGuid();

		/// <summary>
		/// 空のコンストラクタ
		/// </summary>
		public EntityBase() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public EntityBase(EntityBase other) {
			EntityID = other.EntityID;
		}

		/// <summary>
		/// Jsonから読み出して適応
		/// </summary>
		/// <param name="Read">読み取り元オブジェクト</param>
		public virtual void DeselializeToAppend(JObject Read) {
			// 値を適応
			EntityID = new Guid(Read[nameof(EntityID)].Base64Decode());
		}

		/// <summary>
		/// Json書き出し
		/// </summary>
		/// <returns>JsonなObject</returns>
		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public virtual JObject Selialize() {
			var Write = new JObject {
				{ nameof(EntityID), EntityID.ToByteArray() }
			};

			return Write;
		}
	}

}