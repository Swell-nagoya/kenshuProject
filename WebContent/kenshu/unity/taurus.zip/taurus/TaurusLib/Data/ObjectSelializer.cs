﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Taurus.Data {
	/// <summary>
	/// いろいろシリアライズ
	/// </summary>
	/// <typeparam name="T">シリアライズする型</typeparam>
	public class ObjectSelializer<T> {

		/// <summary>
		/// インスタンス内部保持用
		/// </summary>
		private static ObjectSelializer<T> Ins_;

		/// <summary>
		/// インスタンス参照
		/// </summary>
		public static ObjectSelializer<T> Ins { get { return Ins_ ?? (Ins_ = new ObjectSelializer<T>()); } }


		/// <summary>
		/// シングルトン用
		/// </summary>
		private ObjectSelializer() { }

		/// <summary>
		/// 変換用インスタンス
		/// </summary>
		IFormatter Formatter = new BinaryFormatter();

		/// <summary>
		/// シリアライズ
		/// </summary>
		/// <param name="obj">シリアライズしたいもの</param>
		/// <param name="isCompless">圧縮するか否か</param>
		/// <returns>シリアライズされた結果のバイト配列</returns>
		public byte[] Selialize(T obj, bool isCompless = false) {
			using (MemoryStream ret = new MemoryStream()) {
				// シリアライズして配列作って返す
				Selialize(obj, ret, isCompless);
				return ret.ToArray();
			}

		}

		/// <summary>
		/// ストリームへ向けてシリアライズ
		/// </summary>
		/// <param name="obj">シリアライズしたいもの</param>
		/// <param name="isCompless">圧縮するか否か</param>
		/// <param name="ExportStream">出力先ストリーム</param>
		public void Selialize(T obj, Stream ExportStream, bool isCompless = false) {
			// シリアライズする
			Formatter.Serialize(ExportStream, obj);

		}

		/// <summary>
		/// バイト配列から復元
		/// </summary>
		/// <param name="bin">バイナリデータ</param>
		/// <param name="isCompless">圧縮されているか否か</param>
		/// <returns>復元されたオブジェクト</returns>
		public T Deselialize(byte[] bin, bool isCompless = false) {
			try {
				// メモリストリームに必要な情報を渡してデシリアライズする
				using (MemoryStream binstr = new MemoryStream(bin)) {
					return Deselialize(binstr, isCompless);
				}
			} catch {
				return default(T);
			}
		}


		/// <summary>
		/// ストリームから復元
		/// </summary>
		/// <param name="InStr">読み込むストリーム</param>
		/// <param name="isCompless">圧縮されているか否か</param>
		/// <returns>復元されたオブジェクト</returns>
		public T Deselialize(Stream InStr, bool isCompless = false) {

			// 出力
			return (T)Formatter.Deserialize(InStr);

		}

	}
}
