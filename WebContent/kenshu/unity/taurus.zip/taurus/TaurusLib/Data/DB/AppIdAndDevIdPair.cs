﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.DB {

	/// <summary>
	/// アプリケーションIDとデベロッパIDの塊
	/// </summary>
	public struct AppIdAndDevIdPair {

		/// <summary>
		/// アプリケーションID
		/// </summary>
		public int ApplicationID;

		/// <summary>
		/// デベロッパID
		/// </summary>
		public int DeveloperID;

		
	}
}
