﻿using Newtonsoft.Json.Linq;
using System.Linq;
using Taurus.Data.Network.Info;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// ツリー構造更新
	/// </summary>
	public class UpdateTreeMap : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 書き出したいツリー
		/// </summary>
		public TreeInfo[] Tree;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public UpdateTreeMap() : base() {
			Pattern = OrderPattern.UPDATE_TREE;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public UpdateTreeMap(UpdateTreeMap other) : base(other) {
			Pattern = other.Pattern;
			Tree = other.Tree;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Tree), Tree.CreateJsonArray());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Tree = Read.ParseToNewInstanceArray<TreeInfo>(nameof(Tree));
		}

	}

}
