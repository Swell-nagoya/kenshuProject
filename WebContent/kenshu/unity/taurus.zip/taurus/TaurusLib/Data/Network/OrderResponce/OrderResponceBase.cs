﻿using System;
using Newtonsoft.Json.Linq;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// オーダー応答
	/// </summary>
	[Serializable]
	public abstract class OrderResponceBase : EntityBase, IJsonSelializeData {
		
		/// <summary>
		/// 命令に対する返答
		/// </summary>
		public OrderResponcePattern Responce;
		

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public OrderResponceBase() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public OrderResponceBase(OrderResponceBase other) {
			Responce = other.Responce;
		}


		/// <summary>
		/// 成功したか否か
		/// </summary>
		public bool IsOk { get => Responce == OrderResponcePattern.OK; }

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Responce), (byte)Responce);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Responce = (OrderResponcePattern)Read.Value<byte>(nameof(Responce));
		}


	}
}
