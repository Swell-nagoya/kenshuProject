﻿using Newtonsoft.Json.Linq;
using System;

namespace Taurus.Data.Network.OrderPayload {

	/// <summary>
	/// セーブページ指定系
	/// </summary>
	[Serializable]
	public class SavePageOrder : OrderPayloadBase, IJsonSelializeData {
		/// <summary>
		/// 操作対象のページ番号
		/// </summary>
		public int Page;
		
		/// <summary>
		/// コンストラクタ
		/// </summary>
		public SavePageOrder() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public SavePageOrder(SavePageOrder other) : base(other) {
			// 相手の値 or 相手がnullなら適当な配列に詰め込む
			Page = other.Page;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Page), Page);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Page = Read.Value<int>(nameof(Page));
		}

	}
}
