﻿using Newtonsoft.Json.Linq;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// ツリーデータの取得
	/// </summary>
	public class RequireTreeDataResponce : OrderResponceBase, IJsonSelializeData {

		/// <summary>
		/// 内容物
		/// </summary>
		public TreeDataInfo Data;

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Data), Data.Selialize());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Data = Read.ParseToNewInstance<TreeDataInfo>(nameof(Data));
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public RequireTreeDataResponce() {
			Responce = Taurus.Network.Common.OrderResponcePattern.OK;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public RequireTreeDataResponce(RequireTreeDataResponce other) : base(other) {
			Data = other.Data;
		}
	}
}
