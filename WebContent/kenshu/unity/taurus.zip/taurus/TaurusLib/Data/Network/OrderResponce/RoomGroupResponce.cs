﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// 何らかのユーザーの一覧を返す
	/// </summary>
	[Serializable]
	public class RoomGroupResponce : OrderResponceBase, IJsonSelializeData {
		/// <summary>
		/// ユーザー一覧
		/// </summary>
		public RoomInfo[] Rooms;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public RoomGroupResponce() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public RoomGroupResponce(RoomGroupResponce other) : base(other) {
			Rooms = other.Rooms.Select(e => new RoomInfo(e)).ToArray();
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Rooms), Rooms.CreateJsonArray());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Rooms = Read[nameof(Rooms)].ParseToNewInstanceArray<RoomInfo>();
		}
	}
}
