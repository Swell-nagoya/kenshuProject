﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network {

	/// <summary>
	/// ステキなシリアライズできるデータ
	/// </summary>
	public interface ISelializeData {

		/// <summary>
		/// シリアライズ先
		/// </summary>
		/// <param name="Write">書き出し先ストリーム</param>
		void Selialize(Stream Write);

		/// <summary>
		/// デシリアライズして今のオブジェクトに適応
		/// </summary>
		/// <param name="Read">読み取り元ストリーム</param>
		/// <returns>デシリアライズされた何か</returns>
		void DeselializeToAppend(Stream Read);

	}

}
