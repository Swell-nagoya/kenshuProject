﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.Info {
	/// <summary>
	/// ツリー構造の情報
	/// </summary>
	public class TreeInfo : IJsonSelializeData {

		/// <summary>
		/// インスタンスID
		/// </summary>
		public int InstanceID { get; set; }

		/// <summary>
		/// 親のインスタンスID
		/// </summary>
		public int? ParrentInstanceId { get; set; }

		/// <summary>
		/// 要素名
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Jsonにする
		/// </summary>
		/// <returns>ニコニコjson</returns>
		public JObject Selialize() {
			return new JObject {
				{ nameof(InstanceID), InstanceID},
				{ nameof(ParrentInstanceId), ParrentInstanceId},
				{ nameof(Name), Name}
			};

		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {
			
			// 親玉からたどっていく
			InstanceID = Read[nameof(InstanceID)].Value<int>();
			ParrentInstanceId = Read[nameof(ParrentInstanceId)].Value<int?>();
			Name = Read[nameof(Name)].Value<string>();
		}


	}

}
