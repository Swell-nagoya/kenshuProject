﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Taurus.Network.Common;

namespace Taurus.Data.Network.Info {
	/// <summary>
	/// ユーザーまとめ系情報
	/// </summary>
	[Serializable]
	public abstract class UserGroupInfoBase : EntityBase, IJsonSelializeData {

		/// <summary>
		/// 現在のユーザー数
		/// </summary>
		public int NowUsers = 0;

		/// <summary>
		/// 最大ユーザー数
		/// </summary>
		public int MaxUsers = 0;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public UserGroupInfoBase() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public UserGroupInfoBase(UserGroupInfoBase other) : base(other) {
			this.NowUsers = other.NowUsers;
			this.MaxUsers = other.MaxUsers;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {

			// 親に投げる
			base.DeselializeToAppend(Read);

			// もりもりパース
			NowUsers = Read.Value<int>(nameof(NowUsers));
			MaxUsers = Read.Value<int>(nameof(MaxUsers));

		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			// 継承元から引っ張ってくる
			JObject ret = base.Selialize();

			// 値をJsonに突っ込む
			ret.Add(nameof(NowUsers), NowUsers);
			ret.Add(nameof(MaxUsers), MaxUsers);

			// 投げ返す
			return ret;
		}

	}
}
