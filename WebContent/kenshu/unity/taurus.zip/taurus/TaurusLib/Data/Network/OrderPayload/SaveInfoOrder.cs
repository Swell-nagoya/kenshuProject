﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {

	/// <summary>
	/// セーブデータの情報取得
	/// </summary>
	[Serializable]
	public class SaveInfoOrder : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 対象のユーザーID
		/// </summary>
		public int TargetUserID;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public SaveInfoOrder() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public SaveInfoOrder(SaveInfoOrder other) : base(other) {
			// 相手の値 or 相手がnullなら適当な配列に詰め込む
			TargetUserID = other.TargetUserID;
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(TargetUserID), TargetUserID);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			TargetUserID = Read.Value<int>(nameof(TargetUserID));
		}
	}
}
