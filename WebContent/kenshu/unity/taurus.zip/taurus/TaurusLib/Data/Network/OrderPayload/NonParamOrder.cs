﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// パラメーターなしオーダー
	/// </summary>
	[Serializable]
	public class NonParamOrder : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public NonParamOrder() : base() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public NonParamOrder(OrderPayloadBase other) : base(other) {
		}
	}
}
