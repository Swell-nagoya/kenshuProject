﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using Taurus.Data.Network.Info;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// 待ち時間更新
	/// </summary>
	public class UploadLobbyWaitTime : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 待ち時間
		/// </summary>
		public TimeSpan MyWaitTime;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public UploadLobbyWaitTime() : base() {
			Pattern = OrderPattern.WAITTIME_UPLOAD_LOBBY;
			MyWaitTime = TimeSpan.Zero;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public UploadLobbyWaitTime(UploadLobbyWaitTime other) : base(other) {
			Pattern = other.Pattern;
			MyWaitTime = other.MyWaitTime;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(MyWaitTime), MyWaitTime.Ticks);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			MyWaitTime = new TimeSpan(Read.Value<long>(nameof(MyWaitTime)));
		}

	}



}
