﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network {
	/// <summary>
	/// Entityに向かって送信するデータ
	/// </summary>
	[Serializable]
	public class ToEntityMessage : IJsonSelializeData {

		/// <summary>
		/// 送り元
		/// </summary>
		public Guid From;

		/// <summary>
		/// 送り先
		/// </summary>
		public Guid To;

		/// <summary>
		/// メッセージ本文
		/// </summary>
		public byte[] Message;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public ToEntityMessage() { }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="From">送り先</param>
		/// <param name="To">送り元</param>
		/// <param name="Message">送るメッセージ</param>
		public ToEntityMessage(EntityBase From, EntityBase To, byte[] Message) {
			this.From = From.EntityID;
			this.To = To.EntityID;
			this.Message = Message;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public ToEntityMessage(ToEntityMessage other) {
			From = other.From;
			To = other.From;
			Message = other.Message.ToArray();
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public JObject Selialize() {

			// 詰め込んで返す
			return new JObject() {
				{ nameof(From), From.ToByteArray()},
				{ nameof(To), To.ToByteArray()},
				{ nameof(Message), Message}
			};

		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {

			// 値取り出し
			From = new Guid(Read[nameof(From)].Base64Decode());
			To = new Guid(Read[nameof(To)].Base64Decode());
			Message = Read[nameof(Message)].Base64Decode();

		}
	}
}
