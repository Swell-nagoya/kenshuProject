﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce {

	/// <summary>
	/// ユーザー作成成功レスポンス
	/// </summary>
	[Serializable]
	public class CreateUserResponce : OrderResponceBase, IJsonSelializeData {

		/// <summary>
		/// ログインに必要な情報
		/// </summary>
		public LoginInfo login;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public CreateUserResponce() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public CreateUserResponce(CreateUserResponce other) : base(other) {
			login = new LoginInfo(other.login);
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(login), login.Selialize());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			login = Read.ParseToNewInstance<LoginInfo>(nameof(login));
		}
	}
}
