﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// ルーム作成
	/// </summary>
	[Serializable]
	public class CreateRoomResponce : OrderResponceBase, IJsonSelializeData {

		/// <summary>
		/// 部屋の情報
		/// </summary>
		public RoomInfo info;

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(info),info.Selialize());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			info = Read.ParseToNewInstance<RoomInfo>(nameof(info));
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public CreateRoomResponce() {
			Responce = Taurus.Network.Common.OrderResponcePattern.OK;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public CreateRoomResponce(CreateRoomResponce other) : base(other) {
			info = other.info;
		}
	}
}
