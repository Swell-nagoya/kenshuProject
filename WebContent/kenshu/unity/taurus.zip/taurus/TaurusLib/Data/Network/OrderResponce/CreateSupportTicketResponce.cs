﻿using System;
using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// サポートチケット切った結果を返す
	/// </summary>
	[Serializable]
	public class CreateSupportTicketResponce : OrderResponceBase, IJsonSelializeData {
		/// <summary>
		/// サポートチケットID
		/// </summary>
		public int TicketID;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public CreateSupportTicketResponce() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public CreateSupportTicketResponce(CreateSupportTicketResponce other) : base(other) {
			TicketID = other.TicketID;
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			// スッと情報を載せる
			JObject ret = base.Selialize();
			ret.Add(nameof(TicketID), TicketID);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			// Json読み込み
			base.DeselializeToAppend(Read);

			// チケットIDも読み取り
			TicketID = Read.Value<int>(nameof(TicketID));
		}
	}
}
