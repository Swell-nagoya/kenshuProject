﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// ロビーと自分の情報を受け取る
	/// </summary>
	[Serializable]
	public class GetLobbysAndMeResponce : OrderResponceBase, IJsonSelializeData {
		/// <summary>
		/// ロビーとあなたのデータ
		/// </summary>
		public LobbysAndYouInfo Data;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public GetLobbysAndMeResponce() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public GetLobbysAndMeResponce(GetLobbysAndMeResponce other) : base(other) {
			Data = other != null ? new LobbysAndYouInfo(other.Data) : null;
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Data),Data.Selialize());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Data = Read.ParseToNewInstance<LobbysAndYouInfo>(nameof(Data));
		}
	}
}
