﻿using System;
using Newtonsoft.Json.Linq;
using Taurus.Data.Network.OrderPayload;
using Taurus.Network.Common;
using System.Reflection;

namespace Taurus.Data.Network {

	/// <summary>
	/// 命令用
	/// </summary>
	[Serializable]
	public class Order : EntityBase, IJsonSelializeData {

		/// <summary>
		/// オーダー内容
		/// </summary>
		public OrderPayloadBase OrderData;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public Order() : base() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public Order(Order other) : base(other) {
			OrderData = (OrderPayloadBase)Activator.CreateInstance(other.OrderData.GetType(), new object[] { other.OrderData });
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			// 返却用
			JObject ret = base.Selialize();

			// オーダー内容添加
			ret.Add(nameof(OrderData), OrderData.ReflectSelialize());

			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			// 親クラスの値を適応
			base.DeselializeToAppend(Read);

			// オーダー情報も復元
			OrderData = (OrderPayloadBase)Read[nameof(OrderData)].ReflectDeselialize();



		}

	}
}
