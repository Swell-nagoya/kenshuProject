﻿using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network {
	/// <summary>
	/// Jsonっぽいシリアライザ(内部処理用)
	/// </summary>
	public interface IJsonSelializeData {

		/// <summary>
		/// JSONにシリアライズ
		/// </summary>
		/// <returns>Jsonオブジェクト</returns>
		JObject Selialize();

		/// <summary>
		/// デシリアライズして今のオブジェクトに適応
		/// </summary>
		/// <param name="Read">読み取りJsonオブジェクト</param>
		void DeselializeToAppend(JObject Read);

	}
}
