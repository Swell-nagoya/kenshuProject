﻿using Newtonsoft.Json.Linq;
using System;
using System.Linq;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// セーブへ書き出すべきメッセージ
	/// </summary>
	[Serializable]
	public class SaveDataWriteOrder : SavePageOrder, IJsonSelializeData {
		/// <summary>
		/// 転送するべきメッセージ
		/// </summary>
		public byte[] Data = new byte[0];

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public SaveDataWriteOrder() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public SaveDataWriteOrder(SaveDataWriteOrder other) : base(other) {
			// 相手の値 or 相手がnullなら適当な配列に詰め込む
			Data = other.Data?.ToArray() ?? new byte[0];
		}
		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Data), Data);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Data = Read[nameof(Data)].Base64Decode();
		}

	}

}
