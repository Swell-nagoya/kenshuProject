﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// エンティティ狙い撃ちオーダー
	/// </summary>
	[Serializable]
	public abstract class EntityTargetOrderBase : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 目標のEntityID
		/// </summary>
		public Guid TargetEntityID;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public EntityTargetOrderBase() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public EntityTargetOrderBase(EntityTargetOrderBase other) : base(other) {
			TargetEntityID = other.TargetEntityID;
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(TargetEntityID), TargetEntityID.ToByteArray());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			TargetEntityID = new Guid(Read[nameof(TargetEntityID)].Base64Decode());
		}
	}
}
