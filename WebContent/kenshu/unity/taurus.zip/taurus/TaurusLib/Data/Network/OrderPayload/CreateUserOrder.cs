﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// ユーザー作成
	/// </summary>
	[Serializable]
	public class CreateUserOrder : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 対象のアプリケーションID
		/// </summary>
		public int AppId = 0;

		/// <summary>
		/// 対象のデベロッパID
		/// </summary>
		public int DevID = 0;
		
		/// <summary>
		/// ふつうコンストラクタ
		/// </summary>
		public CreateUserOrder(){
			// ユーザー作成
			Pattern = Taurus.Network.Common.OrderPattern.CREATE_USER;
		}
		
		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public CreateUserOrder(CreateUserOrder other) :base(other){
			// コピーコンストラクタはコピーする
			AppId = other.AppId;
			DevID = other.DevID;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(AppId), AppId);
			ret.Add(nameof(DevID), DevID);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			AppId = Read.Value<int>(nameof(AppId));
			DevID = Read.Value<int>(nameof(DevID));
		}
	}
}
