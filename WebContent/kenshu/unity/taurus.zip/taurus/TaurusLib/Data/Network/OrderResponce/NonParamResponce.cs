﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// パラメーターなし
	/// </summary>
	[Serializable]
	public class NonParamResponce : OrderResponceBase, IJsonSelializeData {
		
		/// <summary>
		/// コンストラクタ
		/// </summary>
		public NonParamResponce() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public NonParamResponce(OrderResponceBase other) : base(other) {
		}
		
	}
}
