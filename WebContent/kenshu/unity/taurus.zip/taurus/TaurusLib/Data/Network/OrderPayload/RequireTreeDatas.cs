﻿using Newtonsoft.Json.Linq;
using System.Linq;

namespace Taurus.Data.Network.OrderPayload
{
    /// <summary>
    /// ツリーデータ参照
    /// </summary>
    public class RequireTreeDatas : OrderPayloadBase, IJsonSelializeData
    {
        /// <summary>
        /// 読み出したいインスタンスのID
        /// </summary>
        public int[] InstanceIDs;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RequireTreeDatas() : base()
        {
            Pattern = Taurus.Network.Common.OrderPattern.REQUIRE_TREE_DATAS;
        }

        /// <summary>
        /// コピーコンストラクタ
        /// </summary>
        /// <param name="other">コピー元インスタンス</param>
        public RequireTreeDatas(RequireTreeDatas other) : base(other)
        {
            Pattern = other.Pattern;
            InstanceIDs = other.InstanceIDs;
        }


        /// <summary>
        /// シリアライズする
        /// </summary>
        /// <returns>JsonなObject</returns>
        public override JObject Selialize()
        {
            JObject ret = new JObject {
                { nameof(InstanceIDs), InstanceIDs },
            };
            return ret;
        }

        /// <summary>
        /// デシリアライズしてインスタンスに適応する
        /// </summary>
        /// <param name="Read">読み取り元jsonオブジェクト</param>
        public override void DeselializeToAppend(JObject Read)
        {
            JToken jInstanceIDs = Read[nameof(InstanceIDs)];
            InstanceIDs = new int[jInstanceIDs.Count()];
            int i = 0;
            foreach (int instanceID in jInstanceIDs.Values<int>())
            {
                InstanceIDs[i] = instanceID;
                i++;
            }
        }
    }
}