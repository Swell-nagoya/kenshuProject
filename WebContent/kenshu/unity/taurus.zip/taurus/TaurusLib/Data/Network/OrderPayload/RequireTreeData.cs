﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// ツリーデータ参照
	/// </summary>
	public class RequireTreeData : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 読み出したいインスタンスのID
		/// </summary>
		public int IsntanceID;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public RequireTreeData():base() {
			Pattern = Taurus.Network.Common.OrderPattern.REQUIRE_TREE_DATA;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public RequireTreeData(RequireTreeData other):base(other) {
			Pattern = other.Pattern;
			IsntanceID = other.IsntanceID;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = new JObject {
				{ nameof(IsntanceID), IsntanceID }
			};
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			IsntanceID = Read[nameof(IsntanceID)].Value<int>();
		}

	}

}
