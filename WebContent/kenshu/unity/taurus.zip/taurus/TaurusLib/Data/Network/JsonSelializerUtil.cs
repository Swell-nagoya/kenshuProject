﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;

namespace Taurus.Data.Network {
	/// <summary>
	/// Jsonをシリアライズする上であると嬉しいお得クラス
	/// 
	/// Newtonsoft.Jsonを使用しています
	/// https://raw.githubusercontent.com/JamesNK/Newtonsoft.Json/master/LICENSE.md
	/// </summary>
	public static partial class JsonSelializerUtil {

		#region ふつうのシリアライズ便利キット

		/// <summary>
		/// Json配列をパースして新規インスタンスに包んで配列にして返す
		/// </summary>
		/// <typeparam name="T">作るべきインスタンス</typeparam>
		/// <param name="Key">読み取り対象のキー</param>
		/// <param name="Json">読み取るべきJson配列</param>
		/// <returns>パースされた値を含むインスタンス配列</returns>
		public static T[] ParseToNewInstanceArray<T>(this JToken Json, string Key) where T : IJsonSelializeData, new() {
			return Json.Value<JArray>(Key).Select(e => e.ParseToNewInstance<T>()).ToArray();
		}

		/// <summary>
		/// Json配列をパースして新規インスタンスに包んで配列にして返す
		/// </summary>
		/// <typeparam name="T">作るべきインスタンス</typeparam>
		/// <param name="Json">読み取るべきJson配列</param>
		/// <returns>パースされた値を含むインスタンス配列</returns>
		public static T[] ParseToNewInstanceArray<T>(this JToken Json) where T : IJsonSelializeData, new() {
			return Json.Value<JArray>().Select(e => e.ParseToNewInstance<T>()).ToArray();
		}

		/// <summary>
		/// Jsonをパースして新規インスタンスに包んで返す
		/// </summary>
		/// <typeparam name="T">作るべきインスタンス</typeparam>
		/// <param name="Json">読み取るべきJson</param>
		/// <param name="Key">読み取り対象のキー</param>
		/// <returns>パースされた値を含むインスタンス</returns>
		public static T ParseToNewInstance<T>(this JToken Json, string Key) where T : IJsonSelializeData, new() {
			return Json[Key].ParseToNewInstance<T>();
		}

		/// <summary>
		/// Jsonをパースして新規インスタンスに包んで返す
		/// </summary>
		/// <typeparam name="T">作るべきインスタンス</typeparam>
		/// <param name="Json">読み取るべきJson</param>
		/// <returns>パースされた値を含むインスタンス</returns>
		public static T ParseToNewInstance<T>(this JToken Json) where T : IJsonSelializeData, new() {

			//　インスタンス生成
			var ret = new T();

			// パース実行
			ret.DeselializeToAppend((JObject)Json);

			// 返す
			return ret;

		}

		/// <summary>
		/// 配列要素を生成
		/// </summary>
		/// <param name="From">作成データ</param>
		public static JArray CreateJsonArray(this IEnumerable<IJsonSelializeData> From) {
			return new JArray(From.Select(e => e.Selialize()));
		}



		/// <summary>
		/// Base64の値を解読する
		/// </summary>
		/// <param name="Value">解読対象</param>
		/// <returns>解読結果</returns>
		public static byte[] Base64Decode(this JToken Value) {

			try {
				// レッツパース
				return Convert.FromBase64String(((JValue)Value).Value<string>());
			} catch (Exception e) when (e is ArgumentNullException || e is FormatException) {
				// ﾇﾙｰﾝ
				return null;
			}
		}

		/// <summary>
		/// 要素を追加
		/// </summary>
		/// <param name="Json">追加対象</param>
		/// <param name="Key">追加するキー</param>
		/// <param name="Param">追加する値</param>
		public static void Add(this JObject Json, string Key, object Param) {
			Json.Add(new JProperty(Key, Param));
		}

		#endregion

		#region 型情報を焼かなければならない時のJSON

		/// <summary>
		/// 型情報付きシリアライズ
		/// </summary>
		/// <param name="Object">シリアライズされるオブジェクト</param>
		/// <returns>Jsonな奴</returns>
		public static JObject ReflectSelialize(this IJsonSelializeData Object) {

			// 対象の型情報を取得
			Type type = Object.GetType();

			// シリアライズして返す
			return new JObject() {
				{ "Type", type.FullName },
				{ "Data", Object.Selialize() }
			};

		}

		/// <summary>
		/// リフレクションを使ってデシリアライズ
		/// </summary>
		/// <param name="Json">パース対象のJson</param>
		/// <returns>パースされたインスタンス</returns>
		public static IJsonSelializeData ReflectDeselialize(this JToken Json) {

			// 型名を取り出す
			string type = Json["Type"].Value<string>();

			// 投げ返す用
			IJsonSelializeData Instance = default(IJsonSelializeData);

			// 処理完了までキャッシュをロック
			lock (InstanceGeneratorCach) {

				// キャッシュに情報があるか確認
				if (InstanceGeneratorCach.TryGetValue(type, out Func<IJsonSelializeData> Generator)) {
					// あればそれを利用する
					Instance = Generator.Invoke();
				} else {


					// なければ現在利用できるすべてのクラスから問題のクラスを検索する
					Type TargetType = Assembly.GetExecutingAssembly(). // 現在のアプリケーションドメインの
						GetTypes(). // 全ての型の
						Where(e => typeof(IJsonSelializeData).IsAssignableFrom(e)). // Jsonシリアライズインターフェースを継承している奴の
						Where(e => e.FullName == type). // 名前が一致する奴の
						First(); // 一個適当に取り出す

					// インスタンス生成ラムダを作る
					Generator = () => (IJsonSelializeData)Activator.CreateInstance(TargetType);

					// 試しに実行してみる
					Instance = Generator.Invoke();

					// いけそうなら一覧に記録しておく
					InstanceGeneratorCach.Add(type, Generator);

				}


			}

			// ここまで例外もなく来たならインスタンスできてるだろうからパースして返す
			Instance.DeselializeToAppend((JObject)Json["Data"]);

			return Instance;
		}

		#endregion

		#region 書き出しと読み出し

		private const int SelalizeBufferSize = 1024;

		/// <summary>
		/// エンコード(BOMありUTF8)
		/// </summary>
		private static readonly Encoding Encoding = new UTF8Encoding(true);

		/// <summary>
		/// Jsonを書き出し
		/// </summary>
		/// <param name="Object">Jsonなやつ</param>
		/// <param name="Stream">書き出し先ストリーム</param>
		public static void Export(this IJsonSelializeData Object, Stream Stream) {

			// クラスごとリフレクション情報つきでJsonにする
			var Json = Object.ReflectSelialize();

			// Json書き出し
			// バッファサイズは適当
			using (var Write = new JsonTextWriter(new StreamWriter(Stream, Encoding, SelalizeBufferSize, true))) {
				Json.WriteTo(Write);
			}

		}

		/// <summary>
		/// Jsonを書き出し
		/// </summary>
		/// <param name="Object">書き出すjson</param>
		/// <returns>書き出したバイト配列</returns>
		public static byte[] Export(this IJsonSelializeData Object) {
			using (var write = new MemoryStream()) {
				Object.Export(write);
				return write.ToArray();
			}
		}


		/// <summary>
		/// Json読み込み
		/// </summary>
		/// <param name="Stream">JsonなStream</param>
		/// <returns>Jsonな奴</returns>
		public static IJsonSelializeData Import(Stream Stream) {

			// Json読み出し
			using (var Read = new JsonTextReader(new StreamReader(Stream, Encoding, true))) {

				// とりあえずjson
				JObject Json = (JObject)JToken.Load(Read);

				// 型情報付きパースして返す
				return ReflectDeselialize(Json);
			}
		}

		/// <summary>
		/// Json読み取り
		/// </summary>
		/// <param name="bin">Jsonテキストのバイナリ</param>
		/// <returns>生成されたインスタンス</returns>
		public static IJsonSelializeData Import(byte[] bin) {
			using (var read = new MemoryStream(bin)) {
				return Import(read);
			}
		}


		#endregion

		#region 初期化用

		/// <summary>
		/// Typeからコンストラクタを探せる一覧
		/// </summary>
		private static Dictionary<string, Func<IJsonSelializeData>> InstanceGeneratorCach = new Dictionary<string, Func<IJsonSelializeData>>();

		/// <summary>
		/// クラスを追加する奴
		/// </summary>
		/// <typeparam name="T">追加するクラス</typeparam>
		private static void AddClass<T>() where T : IJsonSelializeData, new() {
			InstanceGeneratorCach.Add(typeof(T).FullName, () => new T());
		}

		#endregion

	}
}
