﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network {
	/// <summary>
	/// ロビー詳細情報
	/// </summary>
	[Serializable]
	public class LobbyDetails : IJsonSelializeData {

		/// <summary>
		/// ロビーについての情報
		/// </summary>
		public LobbyInfo Lobby;

		/// <summary>
		/// 接続ユーザー
		/// </summary>
		public List<UserEntityInfo> JoinUsers = new List<UserEntityInfo>();

		/// <summary>
		/// 部屋の一覧
		/// </summary>
		public List<RoomInfo> Rooms = new List<RoomInfo>();

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public LobbyDetails() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public LobbyDetails(LobbyDetails other) {
			Lobby = new LobbyInfo(other.Lobby);
			JoinUsers = other.JoinUsers.Select(e => new UserEntityInfo(e)).ToList();
			Rooms = other.Rooms.Select(e => new RoomInfo(e)).ToList();
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {
			// インスタンス生成して値を適応
			Lobby = Read.ParseToNewInstance<LobbyInfo>();

			// ユーザーを一度クリアして焼き直し
			JoinUsers.Clear();
			JoinUsers.AddRange(Read[nameof(JoinUsers)].Cast<JObject>().Select(e => e.ParseToNewInstance<UserEntityInfo>()));


			// 部屋一覧もよしなに
			Rooms.Clear();
			Rooms.AddRange(Read[nameof(Rooms)].Cast<JObject>().Select(e => e.ParseToNewInstance<RoomInfo>()));
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public JObject Selialize() {
			// 書き出し先
			return new JObject(

				// ロビーをパース
				new JProperty(nameof(Lobby), Lobby.Selialize()),

				// ユーザー情報もパース
				new JProperty(nameof(JoinUsers), new JArray(JoinUsers.Select(e => e.Selialize()))),

				// 部屋の一覧もパース
				new JProperty(nameof(Rooms), new JArray(Rooms.Select(e => e.Selialize())))

			);
		}
	}
}
