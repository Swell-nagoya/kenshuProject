﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// ロビーに接続
	/// </summary>
	[Serializable]
	public class JoinLobbyOrder : EntityTargetOrderBase, IJsonSelializeData {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public JoinLobbyOrder() : base() {
			Pattern = Taurus.Network.Common.OrderPattern.JOIN_LOBBY;
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public JoinLobbyOrder(JoinLobbyOrder other) : base(other) {
		}
	}
}
