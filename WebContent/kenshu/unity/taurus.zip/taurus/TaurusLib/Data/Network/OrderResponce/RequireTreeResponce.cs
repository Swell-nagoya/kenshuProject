﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce {

	/// <summary>
	/// ツリー構造の取得
	/// </summary>
	public class RequireTreeResponce : OrderResponceBase, IJsonSelializeData {


		/// <summary>
		/// ノード情報
		/// </summary>
		public TreeInfo[] Infos;

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Infos), Infos.CreateJsonArray());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Infos =  Read.ParseToNewInstanceArray<TreeInfo>(nameof(Infos));
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public RequireTreeResponce() {
			Responce = Taurus.Network.Common.OrderResponcePattern.OK;
			Infos = new TreeInfo[0];
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public RequireTreeResponce(RequireTreeResponce other) : base(other) {
			Infos = other.Infos;
		}

	}
}
