﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network.Info {

	/// <summary>
	/// ログイン情報
	/// </summary>
	[Serializable]
	public class LoginInfo : IJsonSelializeData {
		
		/// <summary>
		/// ログインユーザーID
		/// </summary>
		public int UserID = 0;

		/// <summary>
		/// パスワード
		/// </summary>
		public byte[] Password = new byte[0];

		/// <summary>
		/// ハッシュコード生成
		/// </summary>
		public byte[] CreatePassHash() {
			// ハッシュ生成用インスタンス生成
			using (SHA512 HashIns = SHA512.Create()) {
				// パスワードをハッシュコードに変換して返す
				return HashIns.ComputeHash(Password);
			}
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public JObject Selialize() {
			return new JObject() {
				{ nameof(UserID), UserID},
				{ nameof(Password) ,Password}

			};
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {
			UserID = Read.Value<int>(nameof(UserID));
			Password = Read[nameof(Password)].Base64Decode();

		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public LoginInfo() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public LoginInfo(LoginInfo other) {
			this.UserID = other.UserID;
			this.Password = other.Password.ToArray();
		}



	}
}
