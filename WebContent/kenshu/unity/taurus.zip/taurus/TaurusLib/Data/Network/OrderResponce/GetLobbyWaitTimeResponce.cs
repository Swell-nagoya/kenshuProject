﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// ロビー待ち時間参照
	/// </summary>
	[Serializable]
	public class GetLobbyWaitTimeResponce : OrderResponceBase, IJsonSelializeData {

		/// <summary>
		/// 平均待ち時間
		/// </summary>
		public TimeSpan AverageMyWaitTime;

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(AverageMyWaitTime), AverageMyWaitTime.Ticks);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			AverageMyWaitTime = new TimeSpan(Read.Value<long>(nameof(AverageMyWaitTime)));
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public GetLobbyWaitTimeResponce() {
			Responce = Taurus.Network.Common.OrderResponcePattern.OK;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public GetLobbyWaitTimeResponce(GetLobbyWaitTimeResponce other) : base(other) {
			AverageMyWaitTime = other.AverageMyWaitTime;
		}
	}
}
