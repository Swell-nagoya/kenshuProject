﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// 自分の情報を設定したい
	/// </summary>
	[Serializable]
	public class SetMyConfig: OrderPayloadBase , IJsonSelializeData {

		/// <summary>
		/// ユーザー情報
		/// </summary>
		public AboutUser Config;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public SetMyConfig() {
			Pattern = OrderPattern.SET_MYCONFIG;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public SetMyConfig(OrderPayloadBase other) : base(other) {
			Pattern = OrderPattern.SET_MYCONFIG;
			Config = (AboutUser)Config.Clone();
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Config), Config.Selialize());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Config = Read.ParseToNewInstance<AboutUser>(nameof(Config));
		}

	}
}
