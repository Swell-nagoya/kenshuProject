﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Util;

namespace Taurus.Data.Network.OrderPayload {

	/// <summary>
	/// ルーム作成
	/// </summary>
	[Serializable]
	public class CreateRoomOrder : OrderPayloadBase, IJsonSelializeData {
		/// <summary>
		/// 最大配列長
		/// </summary>
		public const int MaxDetails = 1024;


		/// <summary>
		/// ルーム情報(内部保持用)
		/// </summary>
		private byte[] _Details = new byte[0];

		/// <summary>
		/// ルーム情報を指定する
		/// </summary>
		public byte[] Details {
			get => _Details;
			set => NumericCheck.ArraySize(ref _Details, value, MaxDetails);
		}

		/// <summary>
		/// パラメーターがおかしいかチェック
		/// </summary>
		/// <return>おかしければtrue</return>
		public bool IsParamFailed() { return NumericCheck.IsArraySizeOverOrNull(_Details, MaxDetails); }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public CreateRoomOrder() {
			Pattern = Taurus.Network.Common.OrderPattern.CREATE_ROOM;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public CreateRoomOrder(CreateRoomOrder other) : base(other) {
			_Details = (byte[])other._Details.Clone();
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(_Details), _Details);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			_Details = Read[nameof(_Details)].Base64Decode();
		}


	}
}
