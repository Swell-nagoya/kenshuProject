﻿using Newtonsoft.Json.Linq;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// サポート要求を送る
	/// </summary>
	public class CommitSupportOrder : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// メッセージ本文
		/// </summary>
		public string Message;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public CommitSupportOrder() : base() {
			Pattern = OrderPattern.COMMIT_SUPPORT_TICKET;
			this.Message = "";
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public CommitSupportOrder(CommitSupportOrder other) : base(other) {
			Pattern = other.Pattern;
			this.Message = other.Message;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Message), Message);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Message = Read.Value<string>(nameof(Message));
		}

	}



}
