﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using Taurus.Network.Common;

namespace Taurus.Data.Network.Info {
	/// <summary>
	/// 部屋情報
	/// </summary>
	[Serializable]
	public class RoomInfo: UserGroupInfoBase, IJsonSelializeData {

		
		/// <summary>
		/// ルーム情報
		/// </summary>
		public byte[] Details;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public RoomInfo():base() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public RoomInfo(RoomInfo other):base(other) {
			this.Details = other?.Details.Clone() as byte[];
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Details), Details);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Details = Read[nameof(Details)].Base64Decode();
		}
	}
}
