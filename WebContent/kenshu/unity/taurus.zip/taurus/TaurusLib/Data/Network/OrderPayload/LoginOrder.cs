﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.DB;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderPayload {

	/// <summary>
	/// ログインする
	/// </summary>
	[Serializable]
	public class LoginOrder : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 対象のアプリケーションID
		/// </summary>
		public int AppId = 0;

		/// <summary>
		/// 対象のデベロッパID
		/// </summary>
		public int DevID = 0;

		/// <summary>
		/// ログインユーザーID
		/// </summary>
		public int UserID = 0;

		/// <summary>
		/// パスワードハッシュコード
		/// </summary>
		public byte[] Passhash = new byte[0];

		/// <summary>
		/// ふつうコンストラクタ
		/// </summary>
		public LoginOrder() : base() {
			Pattern = Taurus.Network.Common.OrderPattern.LOGIN;
		}

		/// <summary>
		/// infoから作るコンストラクタ
		/// </summary>
		/// <param name="info">ログイン情報</param>
		/// <param name="App">アプリケーションid情報</param>
		public LoginOrder(LoginInfo info, AppIdAndDevIdPair App) : this() {
			AppId = App.ApplicationID;
			DevID = App.DeveloperID;
			UserID = info.UserID;
			Passhash = info.CreatePassHash();
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">他のインスタンス</param>
		public LoginOrder(LoginOrder other) : base(other) {
			Pattern = Taurus.Network.Common.OrderPattern.LOGIN;
			this.AppId = other.AppId;
			this.DevID = other.DevID;
			this.UserID = other.UserID;
			other.Passhash.CopyTo(this.Passhash = new byte[other.Passhash.Length], 0);
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(AppId), AppId);
			ret.Add(nameof(DevID), DevID);
			ret.Add(nameof(UserID), UserID);
			ret.Add(nameof(Passhash), Passhash);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			AppId = Read.Value<int>(nameof(AppId));
			DevID = Read.Value<int>(nameof(DevID));
			UserID = Read.Value<int>(nameof(UserID));
			Passhash = Read[nameof(Passhash)].Base64Decode();
		}


	}
}
