﻿using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// セーブデータチェック
	/// </summary>
	[Serializable]
	public class SaveInfoResponce : OrderResponceBase, IJsonSelializeData {

		/// <summary>
		/// デーブデータに存在するシーケンス番号
		/// </summary>
		public int[] Sequences;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public SaveInfoResponce() {
			Responce = Taurus.Network.Common.OrderResponcePattern.OK;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public SaveInfoResponce(SaveInfoResponce other) : base(other) {
			Sequences = other.Sequences?.ToArray() ?? new int[0];
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Sequences), Sequences);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Sequences = Read[nameof(Sequences)].Select(e => e.Value<int>()).ToArray();
		}

	}
}
