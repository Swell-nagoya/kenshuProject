﻿using System;
using System.Linq;
using Newtonsoft.Json.Linq;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network {
	/// <summary>
	/// ロビー一覧とあなたの情報
	/// </summary>
	[Serializable]
	public class LobbysAndYouInfo : IJsonSelializeData {

		/// <summary>
		/// ロビーの一覧
		/// </summary>
		public LobbyInfo[] LobbyInfo;

		/// <summary>
		/// あなたの情報
		/// </summary>
		public UserEntityInfo You;


		/// <summary>
		/// コンストラクタ
		/// </summary>
		public LobbysAndYouInfo() : base() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public LobbysAndYouInfo(LobbysAndYouInfo other) {
			LobbyInfo = other.LobbyInfo.Select(e => new LobbyInfo(e)).ToArray();
			You = new UserEntityInfo(other.You);
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {
			// Jsonから各Objectを取り出す

			// あなたの情報
			You = Read.ParseToNewInstance<UserEntityInfo>(nameof(You));

			// ロビーの一覧
			LobbyInfo = Read[nameof(LobbyInfo)].ParseToNewInstanceArray<LobbyInfo>();

		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public JObject Selialize() {
			// JObjectに突っ込む
			return new JObject() {
				{ nameof(You), You.Selialize() },
				{nameof(LobbyInfo), LobbyInfo.CreateJsonArray()}
			};


		}
	}
}
