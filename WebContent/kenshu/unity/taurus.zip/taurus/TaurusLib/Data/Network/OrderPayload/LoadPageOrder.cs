﻿using Newtonsoft.Json.Linq;
using System;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// セーブページ指定系
	/// </summary>
	[Serializable]
	public class LoadPageOrder : SavePageOrder, IJsonSelializeData {
		/// <summary>
		/// 見たい奴のユーザー情報
		/// </summary>
		public int UserID;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public LoadPageOrder() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public LoadPageOrder(LoadPageOrder other) : base(other) {
			UserID = other.UserID;
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(UserID), UserID);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			UserID = Read.Value<int>(nameof(UserID));
		}

	}
}
