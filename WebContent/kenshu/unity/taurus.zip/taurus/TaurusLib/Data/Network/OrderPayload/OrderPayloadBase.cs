﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// オーダーペイロードベース
	/// </summary>
	[Serializable]
	public abstract class OrderPayloadBase : IJsonSelializeData {

		/// <summary>
		/// オーダーパターン
		/// </summary>
		public OrderPattern Pattern;

		/// <summary>
		/// こんすとらくた
		/// </summary>
		public OrderPayloadBase() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public OrderPayloadBase(OrderPayloadBase other) {
			Pattern = other.Pattern;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public virtual void DeselializeToAppend(JObject Read) {
			Pattern = (OrderPattern)Read["Pattern"].Value<byte>();
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public virtual JObject Selialize() {
			return new JObject(){ { "Pattern", (byte)Pattern } };
		}
		
	}
}
