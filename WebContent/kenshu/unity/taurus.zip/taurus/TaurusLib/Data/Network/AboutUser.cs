﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network {
	/// <summary>
	/// ユーザーの自己紹介文
	/// </summary>
	[Serializable]
	public class AboutUser : ICloneable, IJsonSelializeData {

		/// <summary>
		/// ユーザーの状況
		/// </summary>
		public enum UserState : byte {
			/// <summary>
			/// 謎
			/// </summary>
			UNKNOWN,

			/// <summary>
			/// 一時的
			/// </summary>
			TEMPOLALY,

			/// <summary>
			/// 通常状態
			/// </summary>
			NORMAL,

			/// <summary>
			/// ロック中
			/// </summary>
			LOCK,

			/// <summary>
			/// BANされてる
			/// </summary>
			BAN,

			/// <summary>
			/// 消されている
			/// </summary>
			DELETE,
		}

		/// <summary>
		/// ユーザーID
		/// </summary>
		public int UserID;

		/// <summary>
		/// ユーザーの状況
		/// </summary>
		public UserState State;

		/// <summary>
		/// 勝利数
		/// </summary>
		public int WinCount;

		/// <summary>
		/// 敗北数
		/// </summary>
		public int LoseCount;

		/// <summary>
		/// 累計戦闘回数
		/// </summary>
		public int TotalMatchCount;

		/// <summary>
		/// マッチングレート
		/// </summary>
		public double Rate;

		/// <summary>
		/// 所持金
		/// </summary>
		public double Money;

		/// <summary>
		/// 経験値
		/// </summary>
		public double Exp;

		/// <summary>
		/// 拡張データ領域1
		/// </summary>
		public string Reserved1;

		/// <summary>
		/// 拡張データ領域2
		/// </summary>
		public double Reserved2;

		/// <summary>
		/// 拡張データ領域3
		/// </summary>
		public string Reserved3;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public AboutUser() { }

		/// <summary>
		/// 複製を作る
		/// </summary>
		/// <returns>作られた複製</returns>
		public object Clone() {
			return this.MemberwiseClone();
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public JObject Selialize() {
			return new JObject() { 
				// とにかく値を突っ込む
				{nameof(UserID), UserID},
				{nameof(State), (byte)State},
				{nameof(WinCount), WinCount},
				{nameof(LoseCount), LoseCount},
				{nameof(TotalMatchCount), TotalMatchCount},
				{nameof(Rate), Rate},
				{nameof(Money), Money},
				{nameof(Exp), Exp},
				{nameof(Reserved1), Reserved1},
				{nameof(Reserved2), Reserved2},
				{nameof(Reserved3), Reserved3}
			};
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {

			// とにかく値を読み出す
			UserID = Read.Value<int>(nameof(UserID));
			State = (UserState)Read.Value<byte>(nameof(State));
			WinCount = Read.Value<int>(nameof(WinCount));
			LoseCount = Read.Value<int>(nameof(LoseCount));
			TotalMatchCount = Read.Value<int>(nameof(TotalMatchCount));
			Rate = Read.Value<double>(nameof(Rate));
			Money = Read.Value<double>(nameof(Money));
			Exp = Read.Value<double>(nameof(Exp));
			Reserved1 = Read.Value<string>(nameof(Reserved1));
			Reserved2 = Read.Value<double>(nameof(Reserved2));
			Reserved3 = Read.Value<string>(nameof(Reserved3));

		}
	}
}
