﻿  
/*
* このコードは自動生成してますので触るべからず
* 要素を追加したい場合は対象にIJsonSelializeDataインターフェースを継承したクラスを作成し
* [ビルド] -> [すべてのT4テンプレートの変換]を実行してください
* By Kento Suzuki
*/

namespace Taurus.Data.Network {


	/// <summary>
	/// リフレクションをマッピング！
	/// </summary>
	public static partial class JsonSelializerUtil {

		/// <summary>
		/// マッパー初期化
		/// 自動化されて超絶イケメンに進化
		/// </summary>
		static JsonSelializerUtil() {			
			AddClass<Taurus.Data.Network.AboutUser>();
			AddClass<Taurus.Data.Network.Info.LobbyInfo>();
			AddClass<Taurus.Data.Network.Info.LoginInfo>();
			AddClass<Taurus.Data.Network.Info.RoomInfo>();
			AddClass<Taurus.Data.Network.Info.TreeDataInfo>();
			AddClass<Taurus.Data.Network.Info.TreeInfo>();
			AddClass<Taurus.Data.Network.Info.UserEntityInfo>();
			AddClass<Taurus.Data.Network.LobbyDetails>();
			AddClass<Taurus.Data.Network.LobbysAndYouInfo>();
			AddClass<Taurus.Data.Network.Order>();
			AddClass<Taurus.Data.Network.OrderPayload.CommitSupportOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.CreateRoomOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.CreateUserOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.JoinLobbyOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.JoinRoomOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.LoadPageOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.LoginOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.NonParamOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.RequireTreeData>();
			AddClass<Taurus.Data.Network.OrderPayload.RequireTreeDatas>();
			AddClass<Taurus.Data.Network.OrderPayload.SaveDataWriteOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.SaveInfoOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.SavePageOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.SetMyConfig>();
			AddClass<Taurus.Data.Network.OrderPayload.TransmitMessageToEntityOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.TransmitMessageOrder>();
			AddClass<Taurus.Data.Network.OrderPayload.UpdateTreeData>();
			AddClass<Taurus.Data.Network.OrderPayload.UpdateTreeMap>();
			AddClass<Taurus.Data.Network.OrderPayload.UploadLobbyWaitTime>();
			AddClass<Taurus.Data.Network.OrderResponce.CreateRoomResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.CreateSupportTicketResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.CreateUserResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.GetLobbysAndMeResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.GetLobbyWaitTimeResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.NonParamResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.RequireTreeDataResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.RequireTreeDatasResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.RequireTreeResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.RoomGroupResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.SaveInfoResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.SaveLoadResponce>();
			AddClass<Taurus.Data.Network.OrderResponce.UserGroupResponce>();
			AddClass<Taurus.Data.Network.ToEntityMessage>();
		}
	}
}

