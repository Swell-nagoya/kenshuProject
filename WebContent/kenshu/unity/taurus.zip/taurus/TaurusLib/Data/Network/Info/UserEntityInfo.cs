﻿using Newtonsoft.Json.Linq;
using System;
using Taurus.Network.Common;

namespace Taurus.Data.Network.Info {
	/// <summary>
	/// ユーザーの存在に関する情報
	/// </summary>
	[Serializable]
	public class UserEntityInfo : UserGroupInfoBase, IJsonSelializeData {
		/// <summary>
		/// ユーザーID
		/// </summary>
		public int UserID;

		/// <summary>
		/// ユーザー情報
		/// </summary>
		public AboutUser About;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public UserEntityInfo() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public UserEntityInfo(UserEntityInfo other) : base(other) {
			UserID = other.UserID;
			About = (AboutUser)other.About.Clone();
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(UserID), UserID);
			ret.Add(nameof(About), About.Selialize());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			UserID = Read.Value<int>(nameof(UserID));
			About = Read.ParseToNewInstance<AboutUser>(nameof(About));
		}

	}
}
