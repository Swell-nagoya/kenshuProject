﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// 転送するべきメッセージ
	/// </summary>
	[Serializable]
	public partial class TransmitMessageOrder : OrderPayloadBase,IJsonSelializeData {
		/// <summary>
		/// 転送するべきメッセージ
		/// </summary>
		public byte[] Message = new byte[0];

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public TransmitMessageOrder() { }

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元</param>
		public TransmitMessageOrder(TransmitMessageOrder other) : base(other) {
			// 相手の値 or 相手がnullなら適当な配列に詰め込む
			Message = other.Message ?? new byte[0];
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Message), Message);
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Message = Read[nameof(Message)].Base64Decode();
		}

	}

}
