﻿using Newtonsoft.Json.Linq;
using System.Linq;
using Taurus.Data.Network.Info;

namespace Taurus.Data.Network.OrderResponce
{
    /// <summary>
    /// ツリーデータの取得
    /// </summary>
    public class RequireTreeDatasResponce : OrderResponceBase, IJsonSelializeData
    {
        /// <summary>
        /// 内容物
        /// </summary>
        public TreeDataInfo[] Datas;

        /// <summary>
        /// シリアライズする
        /// </summary>
        /// <returns>JsonなObject</returns>
        public override JObject Selialize()
        {
            JObject ret = base.Selialize();
            JObject jDatas = new JObject();
            for (int i = 0; i < Datas.Length; i++)
            {
                jDatas.Add(i.ToString(), Datas[i].Selialize());
            }
            ret.Add(nameof(Datas), jDatas);
            return ret;
        }

        /// <summary>
        /// デシリアライズしてインスタンスに適応する
        /// </summary>
        /// <param name="Read">読み取り元jsonオブジェクト</param>
        public override void DeselializeToAppend(JObject Read)
        {
            //System.IO.StreamWriter sw = new System.IO.StreamWriter(
            //           @"D:\milkyway\Desktop\test1.txt", true, System.Text.Encoding.GetEncoding("shift_jis"));

            int i = 0;
            try
            {
                //sw.WriteLine("問題であろうところデシリアライズするよ");
                base.DeselializeToAppend(Read);
                //sw.WriteLine("BaseはOK");
                Datas = new TreeDataInfo[Read[nameof(Datas)].Count()];
                foreach (var jData in Read[nameof(Datas)].Value<JObject>())
                {
                    //sw.WriteLine($"{nameof(jData)}はとれた : {jData}");
                    Datas[i] = jData.Value.ParseToNewInstance<TreeDataInfo>();
                    i++;
                }
            }
            catch (System.Exception e)
            {
                //sw.WriteLine($"こけた i = {i}");
                throw e;
            }
            finally
            {
                //sw.Close();
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RequireTreeDatasResponce()
        {
            Responce = Taurus.Network.Common.OrderResponcePattern.OK;
        }

        /// <summary>
        /// コピーコンストラクタ
        /// </summary>
        /// <param name="other"></param>
        public RequireTreeDatasResponce(RequireTreeDatasResponce other) : base(other)
        {
            Datas = other.Datas;
        }
    }
}
