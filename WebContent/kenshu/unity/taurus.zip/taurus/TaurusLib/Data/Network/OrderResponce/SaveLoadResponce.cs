﻿using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network.OrderResponce {
	/// <summary>
	/// セーブデータ読み出し
	/// </summary>
	[Serializable]
	public class SaveLoadResponce : OrderResponceBase, IJsonSelializeData {

		/// <summary>
		/// デーブデータ
		/// </summary>
		public byte[] Data = new byte[0];

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public SaveLoadResponce() {
			Responce = Taurus.Network.Common.OrderResponcePattern.OK;
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public SaveLoadResponce(SaveLoadResponce other) : base(other) {
			Data = other.Data?.ToArray() ?? new byte[0];
		}

		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			var ret = base.Selialize();
			ret.Add(nameof(Data), Data);
			return ret;
		}


		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Data = Read[nameof(Data)].Base64Decode();
		}
	}
}
