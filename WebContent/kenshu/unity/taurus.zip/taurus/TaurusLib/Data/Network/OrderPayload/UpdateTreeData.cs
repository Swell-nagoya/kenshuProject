﻿using Newtonsoft.Json.Linq;
using System.Linq;
using Taurus.Data.Network.Info;
using Taurus.Network.Common;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// ツリーデータ更新
	/// </summary>
	public class UpdateTreeData : OrderPayloadBase, IJsonSelializeData {

		/// <summary>
		/// 書き出したいデータたち
		/// </summary>
		public TreeDataInfo[] Datas;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public UpdateTreeData() : base() {
			Pattern = OrderPattern.UPDATE_TREE_DATA;
			Datas = new TreeDataInfo[0];
		}

		/// <summary>
		/// コピーコンストラクタ
		/// </summary>
		/// <param name="other">コピー元インスタンス</param>
		public UpdateTreeData(UpdateTreeData other) : base(other) {
			Pattern = other.Pattern;
			Datas = other.Datas;
		}


		/// <summary>
		/// シリアライズする
		/// </summary>
		/// <returns>JsonなObject</returns>
		public override JObject Selialize() {
			JObject ret = base.Selialize();
			ret.Add(nameof(Datas), Datas.CreateJsonArray());
			return ret;
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public override void DeselializeToAppend(JObject Read) {
			base.DeselializeToAppend(Read);
			Datas = Read.ParseToNewInstanceArray<TreeDataInfo>(nameof(Datas));
		}

	}

}
