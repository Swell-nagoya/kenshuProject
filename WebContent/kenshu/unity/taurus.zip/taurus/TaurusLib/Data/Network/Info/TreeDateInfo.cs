﻿using Newtonsoft.Json.Linq;

namespace Taurus.Data.Network.Info {
	/// <summary>
	/// ツリーにぶら下がるデータの情報
	/// </summary>
	public class TreeDataInfo : IJsonSelializeData {

		/// <summary>
		/// 関連付け対象のインスタンスID
		/// </summary>
		public int InstanceID { get; set; }

		/// <summary>
		/// 要素名
		/// </summary>
		public string Data { get; set; }

		/// <summary>
		/// Jsonにする
		/// </summary>
		/// <returns>ニコニコjson</returns>
		public JObject Selialize() {
			return new JObject {
				{ nameof(InstanceID), InstanceID },
				{ nameof(Data), Data }
			};
		}

		/// <summary>
		/// デシリアライズしてインスタンスに適応する
		/// </summary>
		/// <param name="Read">読み取り元jsonオブジェクト</param>
		public void DeselializeToAppend(JObject Read) {
			InstanceID = Read[nameof(InstanceID)].Value<int>();
			Data = Read[nameof(Data)].Value<string>();
		}


	}

}
