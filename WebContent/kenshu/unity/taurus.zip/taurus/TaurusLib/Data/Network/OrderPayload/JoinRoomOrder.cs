﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Data.Network.OrderPayload {
	/// <summary>
	/// ルームに接続
	/// </summary>
	[Serializable]
	public class JoinRoomOrder : EntityTargetOrderBase, IJsonSelializeData {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public JoinRoomOrder() : base() {
			Pattern = Taurus.Network.Common.OrderPattern.JOIN_ROOM;
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="other"></param>
		public JoinRoomOrder(JoinLobbyOrder other) : base(other) {
		}
	}
}
