﻿namespace Taurus.Network.Common {
	/// <summary>
	/// 命令パターン
	/// </summary>
	public enum OrderPattern : byte {

		/// <summary>
		/// 不明
		/// </summary>
		UNKNOWN = 0x00,

		/// <summary>
		/// ロビー一覧と自分の情報参照
		/// </summary>
		GET_LOBBYS_AND_ME = 0x10,

		/// <summary>
		/// 自分の情報を設定したい
		/// </summary>
		SET_MYCONFIG = 0x18,

		/// <summary>
		/// セーブデータ読み出し
		/// </summary>
		SAVE_READ = 0x19,

		/// <summary>
		/// セーブデータ書き出し
		/// </summary>
		SAVE_WRITE = 0x1a,

		/// <summary>
		/// セーブデータ情報を吸い上げる
		/// </summary>
		SAVE_INFO = 0x1b,

		/// <summary>
		/// ロビーに参加中のプレイヤーを教えてほしい
		/// </summary>
		GET_LOBBY_PLAYERS = 0x20,

		/// <summary>
		/// 部屋の一覧を見せてほしい
		/// </summary>
		GET_ROOMS = 0x30,

		/// <summary>
		/// ロビーに入れてほしい
		/// </summary>
		JOIN_LOBBY = 0x40,

		/// <summary>
		/// ロビーから出してほしい
		/// </summary>
		LEAVE_LOBBY = 0x48,

		/// <summary>
		/// 待ち時間報告
		/// </summary>
		WAITTIME_UPLOAD_LOBBY = 0x49,

		/// <summary>
		/// 待ち時間取得
		/// </summary>
		WAITTIME_GET_LOBBY = 0x4a,

		/// <summary>
		/// ルームを作ってほしい
		/// </summary>
		CREATE_ROOM = 0x50,

		/// <summary>
		/// ルームに入れてほしい
		/// </summary>
		JOIN_ROOM = 0x54,

		/// <summary>
		/// ルームから出してほしい
		/// </summary>
		LEAVE_ROOM = 0x58,

		/// <summary>
		/// ルームで叫ぶ
		/// </summary>
		BROADCAST_ROOM = 0x60,

		/// <summary>
		/// ロビーで叫ぶ
		/// </summary>
		BROADCAST_LOBBY = 0x70,

		/// <summary>
		/// 世界で叫ぶ
		/// </summary>
		BROADCAST_GLOBAL = 0x80,

		/// <summary>
		/// 特定個人に向けて叫ぶ
		/// </summary>
		SEND_TARGET = 0x90,
		
		/// <summary>
		/// ツリー要求
		/// </summary>
		REQUIRE_TREE = 0xa0,

		/// <summary>
		/// ツリーデータ要求
		/// </summary>
		REQUIRE_TREE_DATA = 0xa1,

		/// <summary>
		/// ツリー構造を更新
		/// </summary>
		UPDATE_TREE = 0xa2,

		/// <summary>
		/// ツリーデータ設定
		/// </summary>
		UPDATE_TREE_DATA = 0xa3,

		/// <summary>
		/// ツリーデータ複数件要求
		/// </summary>
		REQUIRE_TREE_DATAS = 0xa4,

		/// <summary>
		/// サポートチケット送信
		/// </summary>
		COMMIT_SUPPORT_TICKET = 0xb0,

		/// <summary>
		/// ログイン
		/// </summary>
		LOGIN = 0xf0,

		/// <summary>
		/// 新規ユーザー作成
		/// </summary>
		CREATE_USER = 0xf4,

	}
}
