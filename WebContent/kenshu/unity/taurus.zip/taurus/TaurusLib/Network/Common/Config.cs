﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Network.Common {
	/// <summary>
	/// 設定
	/// </summary>
	public static class Config {

		/// <summary>
		/// ポート番号
		/// </summary>
		public const int Port = 36287;

		/// <summary>
		/// アプリケーションでのタイムアウト(ms)
		/// これを超えると再接続を受け付けられなくなる
		/// </summary>
		public const int AppTimeout = 25000;

		/// <summary>
		/// TCP接続のタイムアウト
		/// これを超えるとコネクション閉じる
		/// コネクションは閉じちゃうけど再接続はできるよ！
		/// </summary>
		public const int TcpTimeout = 5000;
		// public const int TcpTimeout = int.MaxValue;

		/// <summary>
		/// パスワードサイズ
		/// </summary>
		public const int PassLength = 512;

		/// <summary>
		/// 生存シグナル送信間隔
		/// TcpTimeout以下にしないとよくない
		/// </summary>
		public const int AliveSignalInterval = TcpTimeout / 2;

		/// <summary>
		/// ハンドシェークシグナル(クライアントがサーバーに投げるほう)
		/// </summary>
		public static byte[] HandShakeSignalToServer = Encoding.ASCII.GetBytes("Hellow Taurus!");

		/// <summary>
		/// ハンドシェークシグナル(サーバーがクライアントに投げるほう)
		/// </summary>
		public static byte[] HandShakeSignalToClient = Encoding.ASCII.GetBytes("Hellow Client Taurus!");

	}
}
