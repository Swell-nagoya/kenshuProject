﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Exceptions;
using Taurus.Lib;
using Taurus.Network.Common;
using Taurus.Security;
using Taurus.Util;

namespace Taurus.Network.Common {
	/// <summary>
	/// TCP接続終端
	/// </summary>
	public abstract class TCPEndPointBase : IDisposable {

		#region 状態

		/// <summary>
		/// クライアントの状態
		/// </summary>
		public enum ClientEndpointState : byte {
			/// <summary>
			/// 謎
			/// </summary>
			UNKNOWN = 0x00,

			/// <summary>
			/// 接続待機
			/// </summary>
			STANDBY = 0x01,

			/// <summary>
			/// ソケットがつながらない
			/// </summary>
			SOCKET_FAILED = 0x02,

			/// <summary>
			/// ハンドシェイクで死んだ
			/// </summary>
			HANDSHAKE_FAILED = 0x03,

			/// <summary>
			/// 接続した
			/// </summary>
			CONNECTED = 0x04,

			/// <summary>
			/// 切断
			/// </summary>
			CLOSE = 0x05,

			/// <summary>
			/// バージョンが違う
			/// </summary>
			IRREGULAR_SERVER_VERSION = 0x06,
		}

		/// <summary>
		/// 現在の状態
		/// </summary>
		public ClientEndpointState State { get; private set; } = ClientEndpointState.STANDBY;

		#endregion

		#region フィールド変数&プロパティ&定数

		/// <summary>
		/// GUIDのおおきさ
		/// </summary>
		protected const int GUID_BYTES = 16;

		/// <summary>
		/// おおもとのストリーム
		/// </summary>
		private Stream BaseStream;

		/// <summary>
		/// 初期化ルーチン制御用タスク
		/// </summary>
		public Task InitRoutine { get; private set; } = null;

		/// <summary>
		/// 相手の情報
		/// </summary>
		public EndPoint Remote { get; private set; }

		/// <summary>
		/// 生存フラグ
		/// </summary>
		public bool IsAlive { get => !disposedValue; }

		/// <summary>
		/// タスクキャンセル用
		/// </summary>
		protected readonly CancellationTokenSource Cancel = new CancellationTokenSource();

		/// <summary>
		/// サーバーか否か
		/// </summary>
		private bool IsServer = false;

		/// <summary>
		/// 関連付けされる対象のEntityID
		/// </summary>
		public Guid TargetEntityID { get; protected set; }

		/// <summary>
		/// 初期化完了か否か
		/// </summary>
		public bool IsInitCompleat { get => InitRoutine != null && !InitRoutine.IsRunning(); }

		/// <summary>
		/// パラメーター変更用ロックインスタンス
		/// </summary>
		private object PramLock = new object();

		/// <summary>
		/// 結局使えるかどうかについての回答
		/// </summary>
		public bool IsEnabled { get { lock (PramLock) { return _IsEnabled; } } private set { lock (PramLock) { _IsEnabled = value; } } }

		/// <summary>
		/// 結局使えるかどうかについての回答(内部保持用)
		/// </summary>
		private bool _IsEnabled = false;

		/// <summary>
		/// 入力バッファサイズ
		/// </summary>
		protected readonly int InputBufferSize = 4096;

		/// <summary>
		/// 最終的に使用するべき入力ストリーム
		/// </summary>
		private Stream InputStream;

		/// <summary>
		/// 最終的に使用するべき出力ストリーム
		/// </summary>
		private Stream OutputStream;

		#endregion

		/// <summary>
		/// 送信カウント(内部保持用)
		/// </summary>
		private long internalSendCount = 0;

		/// <summary>
		/// 送信カウント
		/// </summary>
		public long SendCount { get { return Interlocked.Read(ref internalSendCount); } }


		/// <summary>
		/// 初期化
		/// </summary>
		protected void Init(Stream BaseStresm, EndPoint Connection, bool IsServer) {
			this.Remote = Connection;
			this.BaseStream = BaseStresm;
			this.IsServer = IsServer;
			InitRoutine = MainRoutine();
		}

		/// <summary>
		/// 初期認証
		/// </summary>
		/// <returns>認証完了時true</returns>
		protected abstract Task<ClientEndpointState> Handsake(Stream stream);

		/// <summary>
		/// メインルーチン
		/// </summary>
		private async Task MainRoutine() {
			try {
				// ストリームチェック
				if (BaseStream == null || !BaseStream.CanRead || !BaseStream.CanWrite) {
					Logger.Warning($"ストリームが利用できません ({Remote})");
					Dispose();
					State = ClientEndpointState.SOCKET_FAILED;
					return;
				}

				Logger.Log($"接続が開始されました ({Remote})");

				// ハンドシェイクチェック
				var state = await Handsake(BaseStream).ConfigureAwait(false);

				switch (state) {
					case ClientEndpointState.IRREGULAR_SERVER_VERSION:
						// バージョンが違う
						Logger.Warning($"ハンドシェイク失敗 ({Remote} > TargetEntityID:{TargetEntityID})");
						Dispose();
						State = ClientEndpointState.IRREGULAR_SERVER_VERSION;
						return;

					case ClientEndpointState.HANDSHAKE_FAILED:
						// 認証失敗
						Logger.Warning($"ハンドシェイク失敗 ({Remote} > TargetEntityID:{TargetEntityID})");
						Dispose();
						State = ClientEndpointState.HANDSHAKE_FAILED;
						return;
				}

				// バッファ作成
				var InputBuffer = new BufferedStream(BaseStream, InputBufferSize);


				// ストリームを適応
				InputStream = InputBuffer;
				OutputStream = BaseStream;



				// 利用可能にする
				IsEnabled = true;

				// 完了ﾝｺﾞ
				State = ClientEndpointState.CONNECTED;

				Logger.Log($"認証完了 ({Remote} > TargetEntityID:{TargetEntityID})");

			} catch (Exception e) {
				Logger.Log($"認証失敗 ({Remote})");

				// IO例外orキャンセル　以外であればログ
				if (!(e.IsTaskIoExcepton())) {
					Logger.Log(e);
				}
				Dispose();
			}
		}


		/// <summary>
		/// 送信を試みる
		/// </summary>
		/// <param name="msg">送信メッセージ</param>
		/// <returns>成功時true</returns>
		public async Task<bool> TrySendMessageAsync(Message msg) {
			try {
				// 利用可能でなければ処理できない
				if (!IsEnabled) {
					return false;
				}

				// 書き出し
				await msg.WriteBinaryAsync(OutputStream, Cancel).ConfigureAwait(false);

				// 完了したので可能であればカウントアップ
				if (SendCount < long.MaxValue) {
					Interlocked.Increment(ref internalSendCount);
				}

				return true;

			} catch (Exception e) {
				// とりあえず解放
				Dispose();

				// IOに問題がある場合はぶった切る
				if (e.IsTaskIoExcepton() || e is NotSupportedException) {
					return false;
				}

				// それ以外の例外は投げる
				throw;
			}
		}

		/// <summary>
		/// 複数件の送信を試みる
		/// </summary>
		/// <param name="msgs">送信メッセージ</param>
		/// <returns>成功時true</returns>
		public async Task<bool> TrySendMessageAsync(IEnumerable<Message> msgs) {
			try {
				// 利用可能でなければ処理できない
				if (!IsEnabled) {
					return false;
				}

				// 送信するべきメッセージを生成
				using (MemoryStream buf = new MemoryStream()) {
					// 全てのメッセージをバッファに書き出し
					Message.WriteBinarys(msgs, buf);
					
					// 頭出し
					buf.Seek(0, SeekOrigin.Begin);

					// 出力(81920はCopyToAsyncのデフォルトバッファサイズ)
					await buf.CopyToAsync(OutputStream, buf.Length < 81920 ? (int)buf.Length : 81920, Cancel.Token);
				}


				// 完了したので可能であればカウントアップ
				if (SendCount < long.MaxValue) {
					Interlocked.Increment(ref internalSendCount);
				}

				return true;

			} catch (Exception e) {
				// とりあえず解放
				Dispose();

				// IOに問題がある場合はぶった切る
				if (e.IsTaskIoExcepton() || e is NotSupportedException) {
					return false;
				}

				// それ以外の例外は投げる
				throw;
			}
		}

		/// <summary>
		/// 受信する
		/// </summary>
		/// <returns>受信したメッセージ</returns>
		public async Task<Message> ReceiveMessageAsync() {

			// まず使えるかチェック
			if (!IsEnabled) { throw new TaurusNotInitEndpointException("使用できる状態ではありません"); }

			try {

				Message receive;

				// 受信しようとする
				receive = await Message.ReadBinaryAsync(InputStream, Cancel).ConfigureAwait(false);

				// 受信失敗してたらしめやかに爆散
				if (receive == null) {
					Dispose();
				}

				// 返す
				return receive;


			} catch (Exception e) {
				// とりあえず解放
				Dispose();

				// IOに問題がある場合はぶった切る
				if (e.IsTaskIoExcepton()) {
					return null;
				}

				// それ以外の例外は投げる
				throw;
			}
		}



		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには
		private object DisposeLockObject = new object(); // マルチスレッド対応


		/// <summary>
		/// マネージドオブジェクトの解放
		/// </summary>
		protected virtual void DisposeManageObject() { }

		/// <summary>
		/// 解放処理
		/// </summary>
		/// <param name="disposing">マネージドリソースの解放を行うか否か</param>
		private void Dispose(bool disposing) {
			lock (DisposeLockObject) {

				// ﾌﾞｯﾁ
				State = ClientEndpointState.CLOSE;

				// 利用不可にする

				IsEnabled = false;
				if (!disposedValue) {

					if (disposing) {

						// 関連するすべてのタスクをキャンセル
						Cancel.Cancel();

						// キャンセルトークン爆破
						Cancel.Dispose();

						// 子クラスがマネージな何かするかも
						try {
							DisposeManageObject();
						} catch (Exception e) {
							// もう死にゆく存在なので例外はガン無視
							Logger.Warning(e);
						}

						disposedValue = true;

					}
				}
			}
		}



		/// <summary>
		/// ステキな解放処理
		/// </summary>
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。

			Dispose(true);

			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			GC.SuppressFinalize(this);
		}
		#endregion

	}
}
