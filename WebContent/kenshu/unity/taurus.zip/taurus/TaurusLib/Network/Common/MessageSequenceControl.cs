﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Network.Common {
	/// <summary>
	/// メッセージのシーケンス番号をよしなにする
	/// スレッドセーフじゃないから大事に扱え
	/// </summary>
	public class MessageSequenceControl {

		/// <summary>
		/// 制御対象外のシーケンス番号
		/// </summary>
		public const ushort DontControlSequence = ushort.MinValue;

		/// <summary>
		/// メッセージ一覧
		/// </summary>
		private readonly LinkedList<Message> msgs = new LinkedList<Message>();

		/// <summary>
		/// メッセージ検索用インデックス
		/// </summary>
		private readonly Dictionary<ushort, LinkedListNode<Message>> msgIndex = new Dictionary<ushort, LinkedListNode<Message>>();

		/// <summary>
		/// 現在のシーケンス番号
		/// </summary>
		private ushort currentSeq = 0;

		/// <summary>
		/// メッセージを登録する
		/// 失敗すると例外が出る
		/// </summary>
		/// <param name="msg">送信するべきメッセージ</param>
		public void Regest(ref Message msg) {
			// シーケンス番号が承認対象外になっていないかチェック
			if (unchecked(++currentSeq == DontControlSequence)) {
				// 更にインクリメントしてずらす
				++currentSeq;
			}

			// メッセージにシーケンス番号を付与する
			msg.SequenceNumber = currentSeq;

			// 一覧に追記
			msgIndex.Add(msg.SequenceNumber, msgs.AddLast(msg));
		}

		/// <summary>
		/// 要素を削除
		/// </summary>
		/// <param name="seq">対象のシーケンス番号</param>
		/// <returns>成功時true</returns>
		public bool Remove(ushort seq) {
			if (msgIndex.TryGetValue(seq, out LinkedListNode<Message> msg)) {
				// 記録にあるメッセージであれば破棄
				msgIndex.Remove(seq);
				msgs.Remove(msg);
				return true;
			}

			// そのような要素がない場合失敗
			return false;
		}

		/// <summary>
		/// 登録済みのメッセージを全て取得
		/// </summary>
		/// <returns>登録済みでたまってるメッセージ</returns>
		public Message[] GetRegestedMessage() {
			return msgs.ToArray();
		}

	}
}
