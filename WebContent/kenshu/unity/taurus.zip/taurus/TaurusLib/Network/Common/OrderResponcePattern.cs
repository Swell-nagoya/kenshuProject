﻿namespace Taurus.Network.Common {
	/// <summary>
	/// オーダー応答
	/// </summary>
	public enum OrderResponcePattern : byte {

		/// <summary>
		/// 未知
		/// </summary>
		UNKNOWN = 0x00,
		
		/// <summary>
		/// 願いは叶えられた
		/// </summary>
		OK = 0x10,

		/// <summary>
		/// そんつらもんねぇよ
		/// </summary>
		FAILED_NOT_FOUND = 0x11,

		/// <summary>
		/// ロビーに入っていないがために失敗した
		/// </summary>
		FAILED_NOT_JOINED_LOBBY = 0x20,

		/// <summary>
		/// ルームに入っていないがために失敗した
		/// </summary>
		FAILED_NOT_JOINED_ROOM = 0x30,

		/// <summary>
		/// 未知の対象に対しての処理なので失敗した
		/// </summary>
		FAILED_UNKNOWN_TARGET = 0x40,

		/// <summary>
		/// サーバーに拒否されたので失敗した
		/// </summary>
		FAILED_FORBIDDEN = 0x50,

		/// <summary>
		/// ルームの何らかの許容量を超えたがために失敗した
		/// </summary>
		FAILED_ROOM_CAPACITY_OVER = 0x60,

		/// <summary>
		/// ログインしていなかったため失敗した
		/// </summary>
		FAILED_NOT_LOGIN = 70,

		/// <summary>
		/// 対象が不明である
		/// </summary>
		FAILED_TARGET_NOT_FOUND = 0x80,



		/// <summary>
		/// 原因は不明だが失敗した
		/// </summary>
		FAILED_CAUSE_UNKNOWN = 0xff,
	}
}
