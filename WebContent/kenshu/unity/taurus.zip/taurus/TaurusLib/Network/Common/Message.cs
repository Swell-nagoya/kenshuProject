﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Data;
using Taurus.Data.Network;
using Taurus.Exceptions;
using Taurus.Util;

namespace Taurus.Network.Common {
	/// <summary>
	/// 送信メッセージ
	/// 
	/// 以下のようなフォーマットで送られます
	/// |----[Signal構造体 1Byte]----|----[メッセージ長ushort 2byte]----|----[シーケンス番号ushort 2Byte]----|----[ペイロード 最大65535byte]----|
	/// 
	/// シリアルデータはセキュリティ上の都合により滅びました
	/// ナムサン
	/// 
	/// </summary>
	public class Message {

		#region 定数

		/// <summary>
		/// シグナルサイズ
		/// </summary>
		public const int SIGNAL_HEADER_SIZE = sizeof(Signal);

		/// <summary>
		/// メッセージ長を記録するヘッダのサイズ
		/// </summary>
		public const int SIZE_HEADER_SIZE = sizeof(ushort);

		/// <summary>
		/// メッセージのシーケンス番号の大きさ
		/// </summary>
		public const ushort MESSAGE_SEQUENCE_NUMBER_SIZE = sizeof(ushort);

		/// <summary>
		/// ヘッダサイズ合計
		/// </summary>
		public const int HEADER_SIZE = MESSAGE_SEQUENCE_NUMBER_SIZE + SIGNAL_HEADER_SIZE + SIZE_HEADER_SIZE;

		#endregion
		
		/// <summary>
		/// ロック用オブジェクト
		/// </summary>
		private readonly object LockObject = new object();

		/// <summary>
		/// ペイロード
		/// </summary>
		public byte[] Payload = new byte[0];

		/// <summary>
		/// シーケンス番号
		/// </summary>
		public ushort SequenceNumber = MessageSequenceControl.DontControlSequence;

		/// <summary>
		/// 空コンストラクタ
		/// </summary>
		public Message() { }

		/// <summary>
		/// シーケンス承認の応答を行うべきか否か
		/// </summary>
		/// <returns>応答するべきであればTrue</returns>
		public bool IsACKSendRequire() => SequenceNumber != MessageSequenceControl.DontControlSequence;

		/// <summary>
		/// メッセージ種類
		/// </summary>
		public Signal SignalType = Signal.UNKNOWN;

		/// <summary>
		/// メッセージ作成
		/// </summary>
		/// <typeparam name="T">生成する型</typeparam>
		/// <param name="Payload">載せるデータ</param>
		/// <param name="SignalType">シグナル種類</param>
		/// <returns>メッセージ一覧</returns>
		public static Message CreateMessages<T>(T Payload, Signal SignalType) where T : IJsonSelializeData {

			// とりあえずシリアライズ
			byte[] bin = Payload.Export();

			// サイズチェック
			if (bin.Length > ushort.MaxValue) {
				throw new TaurusMessageTooLargeException($"シリアライズの結果が大きすぎます。{bin.Length}/{ushort.MaxValue} Byte");
			}


			// 作って返す
			return new Message() { SignalType = SignalType, Payload = bin };
		}

		/// <summary>
		/// メッセージ作成
		/// </summary>
		/// <typeparam name="T">生成する型</typeparam>
		/// <param name="Payload">載せるデータ</param>
		/// <param name="SignalType">シグナル種類</param>
		/// <param name="message">生成されたメッセージ</param>
		/// <returns>メッセージ一覧</returns>
		public static bool TryCreateMessages<T>(T Payload, Signal SignalType, out Message message) where T : IJsonSelializeData {

			// try-catchして成功したらtrueな

			try {
				message = CreateMessages(Payload, SignalType);
				return true;
			} catch (Exception e) when (e is TaurusException || e is ArgumentNullException || e is SerializationException || e is SecurityException) {
				message = null;
				return false;
			}

		}

		/// <summary>
		/// 書き換え待機
		/// </summary>
		public void Wait() {
			lock (LockObject) {
				return;
			}
		}

		/// <summary>
		/// 送信ペイロードが正しいかチェック
		/// </summary>
		private void PayloadCheck() {
			// ペイロードチェック
			if (Payload == null) {
				throw new TaurusPayloadUndefinedException("Payloadがnullです new byte[0] とか入れましょう");
			}

			// サイズチェック
			if (Payload.Length > ushort.MaxValue) {
				throw new TaurusMessageTooLargeException($"送信するデータが大きすぎます。{Payload.Length}/{ushort.MaxValue} Byte");
			}

		}

		/// <summary>
		/// バイナリ書き出し
		/// </summary>
		/// <param name="write">書き出し先</param>
		/// <param name="Cancel">キャンセルトークン</param>
		public async Task WriteBinaryAsync(Stream write, CancellationTokenSource Cancel = null) {
			// ペイロードチェック
			PayloadCheck();

			// 引数チェック
			if (write == null) {
				throw new ArgumentException("ストリームがnullです", "write");
			}

			// 引数チェック
			if (Cancel == null) {
				throw new ArgumentException("キャンセルトークンが未指定です", "Cancel");
			}

			// 書き出し量計算
			int bufSize = HEADER_SIZE + Payload.Length;

			// 書き出し用バッファ作成
			byte[] writeBuf = new byte[bufSize];

			// バイナリっぽく書く
			using (var buffer = new MemoryStream(writeBuf)) {
				BufWrite(buffer);
			}

			// バッファを書き出し
			await write.WriteAsync(writeBuf, 0, bufSize, Cancel?.Token ?? CancellationToken.None).ConfigureAwait(false);
		}

		/// <summary>
		/// 複数同時にストリームに書き出し
		/// 非同期じゃないからバッファとかに焼くといいよ
		/// </summary>
		/// <param name="msgs">書き出すべきメッセージの一覧</param>
		/// <param name="write">書き出し先ストリーム</param>
		public static void WriteBinarys(IEnumerable<Message> msgs, Stream write) {
			foreach (var msg in msgs) {
				msg.BufWrite(write);
			}
		}

		/// <summary>
		/// ストリームに書き出し
		/// </summary>
		/// <param name="buffer">書き出し先</param>
		private void BufWrite(Stream buffer) {
			// シグナル指定
			buffer.WriteByte((byte)SignalType);
			
			// ペイロードサイズ書き出し
			buffer.Write(BinaryUtil.Current.GetBytes((ushort)Payload.Length));

			// シーケンス番号書き出し
			buffer.Write(BinaryUtil.Current.GetBytes((ushort)SequenceNumber));

			// ペイロード本文書き出し
			buffer.Write(Payload);
		}

		/// <summary>
		/// バイト配列にする
		/// </summary>
		/// <returns>バイト配列</returns>
		public byte[] ToByteArray() {
			// ペイロードチェック
			PayloadCheck();

			// 書き出し量計算
			int bufSize = HEADER_SIZE + Payload.Length;

			// 書き出し用バッファ作成
			byte[] writeBuf = new byte[bufSize];

			// バイナリっぽく書く
			using (var buffer = new MemoryStream(writeBuf)) {
				BufWrite(buffer);
			}
			return writeBuf;
		}

		/// <summary>
		/// ストリームから非同期読み出し
		/// </summary>
		/// <param name="read">読み出し元</param>
		/// <param name="Cancel">キャンセルトークン</param>
		/// <returns>読み出し結果</returns>
		public static async Task<Message> ReadBinaryAsync(Stream read, CancellationTokenSource Cancel = null) {

			try {

				// ヘッダ読み出し準備
				byte[] headBuf = new byte[HEADER_SIZE];

				// 読み出し
				if (HEADER_SIZE != await read.TryReadAsync(headBuf, Cancel?.Token ?? CancellationToken.None).ConfigureAwait(false)) {
					// 読み出し量が足りないため失敗
					return null;

				}

				// シグナルタイプ受信
				Signal Signaltype = (Signal)headBuf[0];

				// サイズ計算
				ushort size = BinaryUtil.Current.ToUInt16(headBuf, SIGNAL_HEADER_SIZE);

				// シーケンス番号取得
				ushort seq = BinaryUtil.Current.ToUInt16(headBuf, SIGNAL_HEADER_SIZE + SIZE_HEADER_SIZE);


				// ペイロードのバッファ作成
				byte[] payloadBuf = new byte[size];

				// 読み出し
				if (size != await read.TryReadAsync(payloadBuf, Cancel?.Token ?? CancellationToken.None).ConfigureAwait(false)) {
					// 読み出し量が足りないため失敗
					return null;
				}

				// 返す
				return new Message() { Payload = payloadBuf, SignalType = Signaltype, SequenceNumber = seq };

			} catch (IOException) {

				// ストリームに異常がある場合はnullを返す
				return null;
			}
		}

		/// <summary>
		/// ヘッダ解析
		/// </summary>
		/// <param name="header">ヘッダ</param>
		/// <param name="offset">オフセット</param>
		/// <param name="size">転送データ全長</param>
		/// <param name="seq">シーケンス番号</param>
		/// <param name="signal">送信シグナル</param>
		public static void HeaderParse(byte[] header, int offset, out int size, out ushort seq, out Signal signal) {
			signal = (Signal)header[offset];
			size = BinaryUtil.Current.ToUInt16(header, offset + SIGNAL_HEADER_SIZE);
			seq = BinaryUtil.Current.ToUInt16(header, offset + SIGNAL_HEADER_SIZE + SIZE_HEADER_SIZE);
		}
	}
}
