﻿namespace Taurus.Network.Common {
	/// <summary>
	/// ネットワーク通信シグナル
	/// </summary>
	public enum Signal : byte {

		#region 通信制御系

		/// <summary>
		/// 未知の情報
		/// </summary>
		UNKNOWN = 0x00,

		/// <summary>
		/// 生存シグナル
		/// </summary>
		LIVING_SIG = 0x10,

		/// <summary>
		/// シーケンス承認
		/// </summary>
		SEQUENCE_ACK = 0x18,

		#endregion

		#region マッチング・ユーザー情報制御系

		/// <summary>
		/// 命令
		/// </summary>
		ORDER = 0x30,

		/// <summary>
		/// オーダーに対しての応答
		/// </summary>
		ORDER_RESPONCE = 0x31,

		/// <summary>
		/// ユーザー情報編集
		/// </summary>
		USER_CONFIGURE = 0x38,

		/// <summary>
		/// 切断
		/// </summary>
		CLOSE = 0x40,

		/// <summary>
		/// プッシュ通知
		/// </summary>
		PUSH = 0x50,

		#endregion

		#region 領域別通信系

		#region 全域通信

		/// <summary>
		/// 全域通信
		/// </summary>
		GLOBAL_BROADCAST = 0x60,

		#endregion

		#region ロビー内通信用

		/// <summary>
		/// ロビー内全体メッセージ
		/// </summary>
		LOBBY_BROADCAST = 0x70,

		/// <summary>
		/// ユーザー追加
		/// </summary>
		LOBBY_ADD_USER = 0x71,

		/// <summary>
		/// ユーザー削除
		/// </summary>
		LOBBY_DEL_USER = 0x72,

		/// <summary>
		/// ルーム追加
		/// </summary>
		LOBBY_ADD_ROOM = 0x74,

		/// <summary>
		/// ルーム削除
		/// </summary>
		LOBBY_DEL_ROOM = 0x75,
		
		#endregion

		#region ルーム内通信

		/// <summary>
		/// ルーム内全体通信
		/// </summary>
		ROOM_BROADCAST = 0x80,

		/// <summary>
		/// ユーザー追加
		/// </summary>
		ROOM_ADD_USER = 0x81,

		/// <summary>
		/// ユーザー削除
		/// </summary>
		ROOM_DEL_USER = 0x82,

		#endregion

		#region 個別

		/// <summary>
		/// Entityに対してのメッセージを受信
		/// </summary>
		RCEIVE_TO_ENTITY = 0x90,

		#endregion

		#endregion


	}
}
