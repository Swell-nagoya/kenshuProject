﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Security {
	/// <summary>
	/// 暗号ストリーム生成
	/// </summary>
	public static class CryptoStreamFactory {

		/// <summary>
		/// 暗号化ストリームを生成
		/// </summary>
		/// <param name="InputBaseStream">入力の元となるストリーム</param>
		/// <param name="OutputBaseStream">出力の元となるストリーム</param>
		/// <param name="VI">初期ベクトル生成乱数用乱数シード</param>
		/// <param name="Input">入力ストリーム</param>
		/// <param name="Output">出力ストリーム</param>
		public static void Create(Stream InputBaseStream, Stream OutputBaseStream,int VI, out Stream Input, out Stream Output) {
			
			// 暗号化プロバイダ
			AesCryptoServiceProvider Aes = new AesCryptoServiceProvider();

			// パラメーター設定
			// AESはブロック・キーサイズ共に128bit固定
			Aes.BlockSize = 128;
			Aes.KeySize = 128;

			// 暗号化モードはCBCがおすすめらしい
			Aes.Mode = CipherMode.CBC; 

			// パディングはランダムな何かを詰め込んでもらう
			Aes.Padding = PaddingMode.PKCS7;

			// 初期ベクトル設定
			var vi = new byte[Aes.BlockSize / 8];
			new Random(VI).NextBytes(vi);
			Aes.IV = vi;

			// パスワード設定
			var pass = new byte[Aes.BlockSize / 8];
			new Random(0337125534).NextBytes(vi);
			Aes.Key = pass;

			// 暗号化ストリーム生成
			Input = new CryptoStream(InputBaseStream, Aes.CreateEncryptor(), CryptoStreamMode.Read);
			Output = new CryptoStream(OutputBaseStream, Aes.CreateEncryptor(), CryptoStreamMode.Write);

		}

		


	}
}
