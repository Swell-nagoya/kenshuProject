﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using static Taurus.Logger;

namespace Taurus.Logging.Export {
	/// <summary>
	/// コンソールにログを吐き出す
	/// </summary>
	public class ConsoleExport : LogExportBase {


#pragma warning disable CS1998 // 非同期メソッドは、'await' 演算子がないため、同期的に実行されます
		/// <summary>
		/// 書き出し
		/// </summary>
		/// <param name="Messages">書くメッセージ(複数可)</param>
		public async override Task Write(IEnumerable<MessageAndLevel> Messages) {
#pragma warning restore CS1998 // 非同期メソッドは、'await' 演算子がないため、同期的に実行されます

			foreach (var Message in Messages) {

				// コンソールの色を調整
				switch (Message.Level) {
					case LogLevel.DEBUG:
						Console.ForegroundColor = ConsoleColor.DarkYellow;
						break;

					case LogLevel.CAUTION:
						Console.ForegroundColor = ConsoleColor.Yellow;
						break;

					case LogLevel.WARNING:
						Console.ForegroundColor = ConsoleColor.Red;
						break;

					case LogLevel.ALERT:
						Console.ForegroundColor = ConsoleColor.Red;
						Console.BackgroundColor = ConsoleColor.White;
						break;

					case LogLevel.IMPORTANT:
						Console.ForegroundColor = ConsoleColor.Green;
						break;

					default:
						Console.ResetColor();
						break;
				}


				// コンソールに書き出し
				Console.WriteLine(Message.Message);

				// 事がすんだら色を元に戻しておく
				Console.ResetColor();
			}
		}

		/// <summary>
		/// コンソール出力は特に何かを解放する必要はない
		/// </summary>
		public override void Dispose() { }
	}
}
