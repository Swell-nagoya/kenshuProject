﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taurus.Logging.Export {
	/// <summary>
	/// ログ出力基底クラス
	/// </summary>
	public abstract class LogExportBase : IDisposable{

		/// <summary>
		/// 解放処理を行う
		/// </summary>
		public abstract void Dispose();

		/// <summary>
		/// メッセージ出力
		/// </summary>
		/// <param name="Message">出力されるべきメッセージ</param>
		/// <returns>Await用Task</returns>
		public abstract Task Write(IEnumerable<MessageAndLevel> Message);

		

	}
}



