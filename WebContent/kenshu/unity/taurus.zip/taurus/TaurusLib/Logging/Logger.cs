﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Lib;
using Taurus.Logging;
using Taurus.Logging.Export;
using Taurus.Util;

namespace Taurus {
	/// <summary>
	/// Taurus しょぼいログシステム
	/// </summary>
	public static class Logger {

		#region "定数"
		/// <summary>
		/// ログの重要性を指定する
		/// 重要なほど下に置くべし
		/// </summary>
		public enum LogLevel : byte {
			/// <summary>
			/// デバッグ
			/// </summary>
			DEBUG,

			/// <summary>
			/// 普通のログ
			/// </summary>
			LOG,

			/// <summary>
			/// 注意
			/// </summary>
			CAUTION,

			/// <summary>
			/// 警告
			/// </summary>
			WARNING,

			/// <summary>
			/// 警報
			/// </summary>
			ALERT,

			/// <summary>
			/// 重要
			/// </summary>
			IMPORTANT,

		}


		#endregion


		#region "一般ログ出力"

		/// <summary>
		/// デバッグ出力
		/// 開発中に使うべし
		/// 変数の中身をbreakせずに見たい時などにオススメ
		/// </summary>
		/// <param name="msg">表示するメッセージ</param>
		public static void Debug(object msg) {
			Write(msg, LogLevel.DEBUG);
		}

		/// <summary>
		/// 普通ログ出力
		/// とりとめのない事を書き出すべし
		/// 他に該当する出力がない時などにオススメ
		/// </summary>
		/// <param name="msg">表示するメッセージ</param>
		public static void Log(object msg) {
			Write(msg, LogLevel.LOG);
		}

		/// <summary>
		/// 注意出力
		/// 大したことないけどやばい時に使うべし
		/// ファイルアクセスに失敗したりソケット閉じずにクライアントが音信不通になった時などにオススメ
		/// </summary>
		/// <param name="msg">表示するメッセージ</param>
		public static void Caution(object msg) {
			Write(msg, LogLevel.CAUTION);
		}

		/// <summary>
		/// 警告出力
		/// 死ぬほどではないけどすごくやばい時に使うべし
		/// 普通の例外処理などにお勧め
		/// </summary>
		/// <param name="msg">表示するメッセージ</param>
		public static void Warning(object msg) {
			Write(msg, LogLevel.WARNING);
		}

		/// <summary>
		/// 警報出力
		/// 超やばい時に使うべし
		/// アプリが落ちるとかメンテナンスが絶対必要な時にオススメ
		/// </summary>
		/// <param name="msg">表示するメッセージ</param>
		public static void Alert(object msg) {
			Write(msg, LogLevel.ALERT);
		}

		/// <summary>
		/// 重要出力
		/// 別にやばくはないけど重要なお知らせに使うべし
		/// 重要なシステムが起動する時や固定データを編集する時などにオススメ
		/// </summary>
		/// <param name="msg">表示するメッセージ</param>
		public static void Important(object msg) {
			Write(msg, LogLevel.IMPORTANT);
		}

		#endregion

		#region"内部処理用"

		/// <summary>
		/// 書き出し
		/// </summary>
		/// <param name="msg">書き出すべきメッセージ</param>
		/// <param name="level">ログの重要性</param>
		private static void Write(object msg, LogLevel level) {

			// 出力用ヘッダ
			StringBuilder header = new StringBuilder();

			// 日付を書いておく
			header.Append($"[{DateTime.Now.ToString()}] ");

			// レベルに応じて状況をお知らせ
			switch (level) {
				case LogLevel.DEBUG:
					header.Append("[DEBU]");
					break;

				case LogLevel.CAUTION:
					header.Append("[注意]");
					break;

				case LogLevel.WARNING:
					header.Append("[警告]");
					break;

				case LogLevel.ALERT:
					header.Append("[警報]");
					break;

				case LogLevel.IMPORTANT:
					header.Append("[重要]");
					break;

				default:
					header.Append("[通常]");
					break;
			}

			// メッセージとの区切り文字
			header.Append(" : ");

			// 改行コードで分割
			string[] msgs = new Regex(@"\r\n|\n|\r").Split(ObjectToString(msg)).Where(e => e != "").ToArray();

			EnqueueMessage(msgs.Select(e => new MessageAndLevel(level, header + e)));


		}

		/// <summary>
		/// 例外をいい感じに出力する
		/// </summary>
		/// <param name="e">例外</param>
		/// <returns>スタックトレース付きの文字列</returns>
		private static string ExceptionParser(Exception e) {
			StringBuilder str = new StringBuilder();

			// 例外の内容を出力
			str.AppendLine(e.ToString());

			// スタックトレースも書き出し
			str.Append(e.StackTrace);

			// 返す
			return str.ToString();

		}

		/// <summary>
		/// オブジェクトを文字列にうまいこと変換する
		/// </summary>
		private static string ObjectToString(object obj) {

			if (obj is Exception) {
				// 例外はステキな出力する
				return ExceptionParser((Exception)obj);

			} else if (obj is string) {
				// 文字列はそのまま
				return (string)obj;
			} else {
				// それ以外はToStringする
				return obj?.ToString() ?? "NULL";

			}
		}


		#endregion

		#region ログ出力タスク処理

		/// <summary>
		/// キャンセル用トークン
		/// </summary>
		private static CancellationTokenSource Cancel;

		/// <summary>
		/// ログ置き場出力バッファ
		/// </summary>
		private static readonly ConcurrentQueue<MessageAndLevel[]> MessagesBuffer = new ConcurrentQueue<MessageAndLevel[]>();

		/// <summary>
		/// 作業用
		/// </summary>
		private static Task worker;

		/// <summary>
		/// メッセージ追加
		/// </summary>
		/// <param name="msg">書き出すメッセージ</param>
		private static void EnqueueMessage(IEnumerable<MessageAndLevel> msg) {

			// キューに値を入れる
			MessagesBuffer.Enqueue(msg.ToArray());


		}

		/// <summary>
		/// ログ出力先
		/// </summary>
		static public readonly ConcurrentBag<LogExportBase> LogOut = new ConcurrentBag<LogExportBase>();

		/// <summary>
		/// ログ出力メイン処理
		/// </summary>
		/// <param name="token">キャンセル用トークン</param>
		/// <returns>同期用コンテキスト</returns>
		private static async Task WorkerTask(CancellationToken token) {

			// キャンセルされるまでぶん回す
			while (!token.IsCancellationRequested) {

				// 取り出すキュー
				var msgs = new LinkedList<MessageAndLevel[]>();

				// 取り出せるだけ取り出す
				while (MessagesBuffer.TryDequeue(out MessageAndLevel[] write)) {
					msgs.AddLast(write);
				}


				// キューから取り出しができたら処理
				if (msgs.Any()) {

					// 書き出し前に配列に投影しておく
					var write = msgs.SelectMany(e => e).ToArray();

					// 全ての書き出し処理を発動
					var logWrite = LogOut.Select(e => e.Write(write)).ToArray();

					// 完了を待機する
					foreach (Task log in logWrite) {
						try {
							// 書き出し
							await log.ConfigureAwait(false);
						} catch (Exception e) {
							// ログ吐きが失敗したらエラーに吐く
							Console.Error.WriteLine(e);
						}
					}
				}

				// コンテキストスイッチ
				await TaskUtil.Yield().ConfigureAwait(false);
			}
		}


		/// <summary>
		/// 開始
		/// </summary>
		/// <param name="Export">ログ出力インスタンス</param>
		public static void Start(params LogExportBase[] Export) {
			// トークン初期化
			Cancel = new CancellationTokenSource();

			if (Export?.Any() ?? false) {
				// ログ出力を記録する
				foreach (var ins in Export) {
					LogOut.Add(ins);
				}

			} else {
				// 指定がなければコンソール出力しておく
				LogOut.Add(new ConsoleExport());
			}

			// メイン処理実行開始
			worker = WorkerTask(Cancel.Token).

				// メイン処理終了後に全ての出力先を破棄する
				ContinueWith(e => {
					foreach (var export in LogOut) {
						Task.Run(() => export?.Dispose());
					}

				});

		}

		/// <summary>
		/// 終了
		/// </summary>
		public static void End() {
			// トークンをキャンセル
			Cancel.Cancel();
		}

		#endregion

	}
}
