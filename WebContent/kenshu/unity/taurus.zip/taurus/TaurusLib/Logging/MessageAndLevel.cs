﻿using System.Text;

namespace Taurus.Logging {
	/// <summary>
	/// メッセージ出力用
	/// </summary>
	public struct MessageAndLevel {
		/// <summary>
		/// ログレベル
		/// </summary>
		public readonly Logger.LogLevel Level;

		/// <summary>
		/// 出力するべきメッセージ
		/// </summary>
		public readonly string Message;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="Level">ログレベル</param>
		/// <param name="Message">出力メッセージ</param>
		public MessageAndLevel(Logger.LogLevel Level, string Message) {
			this.Level = Level;
			this.Message = Message;
		}
	}
}
