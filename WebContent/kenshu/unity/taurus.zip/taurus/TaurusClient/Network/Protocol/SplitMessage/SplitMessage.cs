﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network;
using Taurus.Network.Client;
using Taurus.Network.Common;
using Taurus.Util;
using static Taurus.Network.Client.LocalClient;

namespace Taurus.Network.Protocol.SplitMessage {
	/// <summary>
	/// 分割メッセージマネージャ
	/// 
	/// 以下のようなメッセージ構造のメッセージをやり取りします
	/// |----MESSAGE_SIZE[UInt16]---|---MESSAGE_KEY[UInt64]---|---MAX_PAGE[UInt32]---|---CURRENT_PAGE[UInt32]---|---PAYLOAD[Byte[MESSAGE_SIZ]]---|
	/// 
	/// MESSAGE_SIZEはMESSAGE_MAX_SIZE以下の値になります
	/// 
	/// </summary>
	public class SplitMessage : IDisposable {

		#region event

		/// <summary>
		/// メッセージ受信イベント
		/// メッセージ、送信範囲、送信元の順
		/// </summary>
		public event SplitMessageReceiveHandler OnMessage;

		/// <summary>
		/// 分割メッセージイベント受信用デリゲート
		/// </summary>
		/// <param name="sender">送信元オブジェクト</param>
		/// <param name="e">メッセージ内容物</param>
		public delegate void SplitMessageReceiveHandler(object sender, SplitMessageReceiveArgs e);

		/// <summary>
		/// 分割メッセージイベント情報
		/// </summary>
		public class SplitMessageReceiveArgs : EventArgs {

			/// <summary>
			/// 送信メッセージ
			/// </summary>
			public byte[] Message;

			/// <summary>
			/// 送信対象
			/// </summary>
			public Target To;

			/// <summary>
			/// 送信元
			/// </summary>
			public Guid From;
		}


		#endregion

		/// <summary>
		/// 送信範囲
		/// </summary>
		public enum Target {
			/// <summary>
			/// 謎
			/// </summary>
			UNKNOWN,

			/// <summary>
			/// 全域
			/// </summary>
			GLOBAL,

			/// <summary>
			/// ロビー
			/// </summary>
			LOBBY,

			/// <summary>
			/// ルーム
			/// </summary>
			ROOM,

			/// <summary>
			/// 個別送信
			/// </summary>
			PRIVATE

		}

		/// <summary>
		/// メッセージ最大長
		/// </summary>
		const int MESSAGE_MAX_SIZE = 4096;

		/// <summary>
		/// 全体のメッセージ最大サイズ
		/// </summary>
		const int TOTAL_MESSAGE_SIZE = 1024 * 1024 * 1024;

		/// <summary>
		/// メッセージ受信領域
		/// </summary>
		private readonly Dictionary<UInt64, byte[][]> MessageBuffer = new Dictionary<ulong, byte[][]>();

		/// <summary>
		/// 対象のクライアント
		/// </summary>
		private readonly LocalClient TargetClient;

		/// <summary>
		/// ID生成装置
		/// </summary>
		private static Random IdGen = new Random();

		/// <summary>
		/// キー生成
		/// </summary>
		/// <returns>生成されたキー</returns>
		private static UInt64 GetKey() {
			lock (IdGen) {
				// 配列に乱数生成して64bit変数にする
				byte[] buf = new byte[sizeof(UInt64)];
				IdGen.NextBytes(buf);
				return BitConverter.EndianBitConverter.LittleEndian.ToUInt64(buf, 0);
			}
		}

		/// <summary>
		/// メッセージ生成
		/// </summary>
		/// <param name="buf">出力内容のバッファ</param>
		/// <returns>分割されたメッセージ</returns>
		public static byte[][] Split(byte[] buf) {
			// 値チェック
			if (buf == null) { throw new ArgumentNullException("buf", "引数をNullにできません"); }

			// 転送限界を超えていないか確認
			// デフォならなんと1GBまでしか送れないのだ
			// てか送るな
			if (buf.Length > TOTAL_MESSAGE_SIZE) { throw new ArgumentOutOfRangeException("buf", buf.Length, $"転送限界を超えています ({TOTAL_MESSAGE_SIZE} byteまでです)"); }

			// メッセージキー生成
			UInt64 Key = GetKey();


			// 分割してindexつけておく
			var parts = buf.Partition(MESSAGE_MAX_SIZE).ToArray();

			// 総ページ数算出
			UInt32 MaxPage = (uint)parts.Length;

			// 返す
			return parts.Select((v, i) => {

				// 出力用バッファ
				byte[] buffer = new byte[sizeof(UInt16) + sizeof(UInt64) + sizeof(UInt32) + sizeof(UInt32) + v.Count()];

				// バイナリ書き出し用
				using (BinaryWriter bin = new BinaryWriter(new MemoryStream(buffer))) {

					// メッセージサイズ出力
					bin.WriteArc((UInt16)v.Count());

					// キー
					bin.WriteArc(Key);

					// ページ最大
					bin.WriteArc(MaxPage);

					// 現在ページ数
					bin.WriteArc((UInt32)i);

					// 情報
					bin.Write(v.ToArray());
				}


				// 返却
				return buffer;
			}).ToArray();


		}

		/// <summary>
		/// どこかにメッセージを投げるメソッド(内部用)
		/// </summary>
		/// <param name="payload">送るデータ</param>
		/// <param name="SendFunc">送る関数</param>
		/// <returns>送った結果</returns>
		private async Task<OrderResponceSignalAndData<bool>> InternalSendMessageAsync(byte[] payload, Func<byte[], Task<OrderResponceSignalAndData<bool>>> SendFunc) {
			// 全件送信
			var sendtask = Split(payload).Select(SendFunc).ToArray();

			// 返却用
			OrderResponceSignalAndData<bool> ret = default(OrderResponceSignalAndData<bool>);

			// エラー検出用
			OrderResponceSignalAndData<bool>? err = null;

			// 待つ
			foreach (var task in sendtask) {
				// 値受け取り
				ret = await task.ConfigureAwait(false);

				// エラーチェック
				if (!ret.Value) { err = ret; }

				// タスク解放
				task.Dispose();
			}

			// エラーがあればエラーを返す
			if (err.HasValue) { return err.Value; }

			// 問題なければ最後の値を返す
			return ret;

		}

		/// <summary>
		/// グローバルブロードキャスト送信
		/// </summary>
		/// <param name="payload">送るデータ</param>
		/// <returns>送った結果</returns>
		public async Task<OrderResponceSignalAndData<bool>> SendGlobalBroadCastAsync(byte[] payload) {
			return await InternalSendMessageAsync(payload, TargetClient.BroadcastGlobalAsync).ConfigureAwait(false);
		}

		/// <summary>
		/// ロビーブロードキャスト送信
		/// </summary>
		/// <param name="payload">送るデータ</param>
		/// <returns>送った結果</returns>
		public async Task<OrderResponceSignalAndData<bool>> SendLobbyBroadCastAsync(byte[] payload) {
			return await InternalSendMessageAsync(payload, TargetClient.BroadcastLobbyAsync).ConfigureAwait(false);
		}

		/// <summary>
		/// ルームブロードキャスト送信
		/// </summary>
		/// <param name="payload">送るデータ</param>
		/// <returns>送った結果</returns>
		public async Task<OrderResponceSignalAndData<bool>> SendRoomBroadCastAsync(byte[] payload) {
			return await InternalSendMessageAsync(payload, TargetClient.BroadcastRoomAsync).ConfigureAwait(false);
		}

		/// <summary>
		/// プライベートメッセージ送信
		/// </summary>
		/// <param name="payload">送るデータ</param>
		/// <param name="Target">送り先</param>
		/// <returns>送った結果</returns>
		public async Task<OrderResponceSignalAndData<bool>> SendPrivateMessageAsync(byte[] payload, Guid Target) {
			return await InternalSendMessageAsync(payload, async e => await TargetClient.ToEntityAsync(e, Target)).ConfigureAwait(false);
		}

		/// <summary>
		/// メッセージ解析
		/// </summary>
		/// <param name="msg">メッセージひとつ</param>
		/// <param name="tgt">メッセージ送信範囲</param>
		private void MessageParser(ToEntityMessage msg, Target tgt) {

			// バイナリ読み込み
			using (BinaryReader bin = new BinaryReader(new MemoryStream(msg.Message))) {

				// メッセージサイズ
				UInt16 MsgSize = bin.ReadUInt16Arc();

				// サイズチェック
				if (MsgSize > MESSAGE_MAX_SIZE) { return; }

				// キー
				UInt64 MsgKey = bin.ReadUInt64Arc();

				// 総ページ数
				UInt32 MaxPage = bin.ReadUInt32Arc();

				// 現ページ数
				UInt32 CurrentPage = bin.ReadUInt32Arc();

				// ペイロード
				byte[] Payload = bin.ReadBytes(MsgSize);

				// メッセージがとても短い場合ここで終了する
				if (MaxPage <= 1) {
					OnMessage?.Invoke(this, new SplitMessageReceiveArgs() { Message = Payload, To = tgt, From = msg.From });
					return;
				}

				lock (MessageBuffer) {
					// 未登録の内容であれば新しく作る
					if (!MessageBuffer.TryGetValue(MsgKey, out byte[][] MsgSet)) {
						MessageBuffer.Add(MsgKey, MsgSet = new byte[MaxPage][]);
					}

					// 所定の位置にメッセージを入れる
					MsgSet[CurrentPage] = Payload;

					// メッセージがそろっているかチェック
					if (MsgSet.Where(e => e != null).Count() >= MsgSet.Length) {

						// イベント発行してバッファから消す
						OnMessage?.Invoke(this, new SplitMessageReceiveArgs() { Message = MsgSet.SelectMany(e => e).ToArray(), To = tgt, From = msg.From });
						MessageBuffer.Remove(MsgKey);

					}
				}
			}
		}

		/// <summary>
		/// グローバルメッセージ受信用
		/// </summary>
		private void GlobalMessage(object sender, ToEntityMessageArgs e) => MessageParser(e.Message, Target.GLOBAL);

		/// <summary>
		/// ロビーメッセージ受信用
		/// </summary>
		private void LobbyMessage(object sender, ToEntityMessageArgs e) => MessageParser(e.Message, Target.LOBBY);

		/// <summary>
		/// ルームメッセージ受信用
		/// </summary>
		private void RoomMessage(object sender, ToEntityMessageArgs e) => MessageParser(e.Message, Target.ROOM);

		/// <summary>
		/// プライベートメッセージ受信用
		/// </summary>
		private void PrivateMessage(object sender, ToEntityMessageArgs e) => MessageParser(e.Message, Target.PRIVATE);

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="TargetClient">制御対象のクライアント</param>
		public SplitMessage(LocalClient TargetClient) {
			this.TargetClient = TargetClient;

			// クライアントにイベントをつける
			TargetClient.BroadCastGlobalEvent += GlobalMessage;
			TargetClient.BroadCastLobbyEvent += LobbyMessage;
			TargetClient.BroadCastRoomEvent += RoomMessage;
			TargetClient.ToEntityMessageEvent += PrivateMessage;
		}

		#region IDisposable Support
		private bool disposedValue = false; // 重複する呼び出しを検出するには

		/// <summary>
		/// 解放処理
		/// </summary>
		/// <param name="disposing">マネージオブジェクト開放するか否か</param>
		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: マネージ状態を破棄します (マネージ オブジェクト)。
				}

				// TODO: アンマネージ リソース (アンマネージ オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
				// TODO: 大きなフィールドを null に設定します。

				// イベント止める
				TargetClient.BroadCastGlobalEvent -= GlobalMessage;
				TargetClient.BroadCastLobbyEvent -= LobbyMessage;
				TargetClient.BroadCastRoomEvent -= RoomMessage;
				TargetClient.ToEntityMessageEvent -= PrivateMessage;

				disposedValue = true;
			}
		}

		// TODO: 上の Dispose(bool disposing) にアンマネージ リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
		// ~SplitMessage() {
		//   // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
		//   Dispose(false);
		// }

		/// <summary>
		/// ステキな解放処理
		/// </summary>
		public void Dispose() {
			// このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
			Dispose(true);
			// TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
			// GC.SuppressFinalize(this);
		}
		#endregion

	}
}