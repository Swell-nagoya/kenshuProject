﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.Info;
using Taurus.Network.Client;

namespace Taurus.Network.Protocol.Tree {

	/// <summary>
	/// ツリーなドキュメント
	/// </summary>
	public class TreeDocument {

		/// <summary>
		/// 親玉のクライアント
		/// </summary>
		internal LocalClient client;

		/// <summary>
		/// ツリーマップ
		/// </summary>
		public readonly Dictionary<int, TreeNode> treeMap = new Dictionary<int, TreeNode>();

		/// <summary>
		/// ノードのインスタンスIDで検索
		/// </summary>
		/// <param name="instanceID">インスタンスID</param>
		/// <returns>あればよかったね</returns>
		public TreeNode this[int instanceID] => treeMap[instanceID];

		/// <summary>
		/// 値検索試行
		/// </summary>
		/// <param name="instanceID">インスタンスID</param>
		/// <param name="node">ノード渡し先</param>
		/// <returns>あればtrue</returns>
		public bool TryGetNode(int instanceID, out TreeNode node) {
			return treeMap.TryGetValue(instanceID, out node);
		}

		/// <summary>
		/// ルートノード
		/// </summary>
		public TreeNode Root { get; private set; } = null;

		/// <summary>
		/// 乱数生成用
		/// </summary>
		private Random rand = new Random();

		/// <summary>
		/// 整合性チェックフラグ
		/// </summary>
		internal bool IsCheckedStructuralIntegrity = false;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="client">関連付け対象のクライアント</param>
		internal TreeDocument(LocalClient client) {
			this.client = client;
		}

		/// <summary>
		/// ノード生成する
		/// </summary>
		/// <param name="nodeName">ノード名</param>
		public TreeNode CreateNode(string nodeName) {


			// インスタンスIDを決定する

			// 存在しないIDを発見するまでループ
			int id = rand.Next();
			for (; treeMap.ContainsKey(id); id = rand.Next()) { }

			// 生成
			var ret = new TreeNode(this, id) { Name = nodeName ?? "" };

			// 一覧に追記
			treeMap.Add(ret.InstanceID, ret);

			// 返す
			return ret;
		}


		/// <summary>
		/// ツリー構造クリア
		/// </summary>
		public void Clear() {
			treeMap.Clear();
			Root = CreateNode("root");
		}

		/// <summary>
		/// ツリー構造を更新
		/// </summary>
		/// <returns>成功時true</returns>
		public async Task<bool> LoadMapAsync() {

			// クリアする
			treeMap.Clear();

			// 最新ツリー構造を取得する
			var loadtree = await client.ReadTreeAsync().ConfigureAwait(false);

			// ツリーが読めたかチェックする
			if (loadtree.Value == null) { return false; }

			// 要素がなければrootになんか詰めて初期化
			if (!loadtree.Value.Any()) {
				Root = CreateNode("root");
				return true;
			}

			// インスタンスをとりあえず生成
			var rawMap = loadtree.Value.ToDictionary(e => e.InstanceID, e => new { node = new TreeNode(this, e.InstanceID) { Name = e.Name, state = TreeNode.DataState.Unknown }, parrent = e.ParrentInstanceId });

			// 全ての要素に対して処理
			foreach (var record in rawMap) {

				if (record.Value.parrent == null) {
					// 親がいないときルート
					Root = record.Value.node;
				} else {

					// 親がいるなら検索して親子関係を構築する
					if (!rawMap.TryGetValue(record.Value.parrent.Value, out var parrent)) {
						// 見つからなかった
						continue;
					}

					// 親の子になる
					parrent.node.AppendChild(record.Value.node);
				}

				// 一覧に追記
				treeMap.Add(record.Value.node.InstanceID, record.Value.node);
			}

			// rootが見つからない場合はまた初期化
			if (Root == null) { Clear(); }

			// 完了
			return true;
		}


		/// <summary>
		/// 全ての情報をアップロードする
		/// </summary>
		/// <returns>成功時true</returns>
		public async Task<bool> UploadAsync() {

			// 整合性チェックの実行
			DocumentStructuralIntegrityUpdate();

			// ツリー構造をサーバーに展開
			if (!(await client.UpdateTreeAsync(
				treeMap.
				Select(
					// 変換
					e => new TreeInfo() {
						InstanceID = e.Value.InstanceID,
						Name = e.Value.Name,
						ParrentInstanceId = e.Value?.Parrent?.InstanceID
					}).
				ToArray()).ConfigureAwait(false)).
				Value) { return false; }

			// 更新するべき一覧を出す
			TreeDataInfo[] updates = GetRequiredUploadData().ToArray();

			// 送信用バッファもどき
			var sendBuffer = new List<TreeDataInfo>(updates.Length);

			// バッファにため込んだ量
			int bufferSize = 0;

			// 全ての要素を送信
			foreach (var node in updates) {
				if(bufferSize + node.Data.Length > 8092){
					
					// 8kbを超えるようなら一旦そこで送信してしまう
					await SendDates(sendBuffer.ToArray()).ConfigureAwait(false);

					// 転送量を空にする
					bufferSize = 0;

					// バッファもクリア
					sendBuffer.Clear();
				}

				// バッファにため込む
				sendBuffer.Add(node);

				// 長さも覚える
				bufferSize += node.Data.Length;
				
			}

			// バッファに残りがあれば送信する
			if (sendBuffer.Any()) {
				await (SendDates(sendBuffer.ToArray()).ConfigureAwait(false));
			}



			// 成功
			return true;

		}

		/// <summary>
		/// ある程度まとめでデータ送信
		/// </summary>
		/// <param name="updates">送信するべき要素一覧</param>
		/// <returns>awaitするやつ</returns>
		private async Task SendDates(TreeDataInfo[] updates) {
			// 全てのデータをサーバーに展開
			if (!(await client.UpdateTreeDataAsync(updates).ConfigureAwait(false)).Value) {

				// 失敗したらフラグ元に戻しておく
				foreach (var node in updates) {
					treeMap[node.InstanceID].state = TreeNode.DataState.Update;
				}

			}

		}

		/// <summary>
		/// 更新要求一覧を取得して更新済みフラグを付ける
		/// </summary>
		/// <returns>更新に必要なデータ</returns>
		private IEnumerable<TreeDataInfo> GetRequiredUploadData() {

			// そもそもノードがあるか確認
			if (Root == null) { yield break; }

			foreach (var node in treeMap) {
				// 状況をチェック
				if (node.Value.state == TreeNode.DataState.Update) {
					// 更新要求フラグを検出したのでフラグ破棄の後値を返す
					node.Value.state = TreeNode.DataState.Loaded;

					yield return new TreeDataInfo() {
						InstanceID = node.Key,
						Data = node.Value.internalValue
					};


				}
			}

		}

		/// <summary>
		/// 構造的整合性の更新
		/// </summary>
		public void DocumentStructuralIntegrityUpdate() {

			// 整合性チェック済みか確認
			if (IsCheckedStructuralIntegrity) { return; }

			// ルートがなければ要素一覧をクリアして終了
			if (Root == null) {
				treeMap.Clear();
				return;
			}

			// 存在が確認されたノードの一覧
			var aliveNode = new HashSet<int>();


			// ルートから順にやる
			NodeStructuralIntegrityUpdate(Root, null, aliveNode);


			// チェック完了
			IsCheckedStructuralIntegrity = true;
		}

		/// <summary>
		/// ノードに対しての整合性チェック
		/// </summary>
		/// <param name="node">処理対象のノード</param>
		/// <param name="parrentNode">親のノード</param>
		/// <param name="alivenode">今まで生存確認できたノード一覧</param>
		private void NodeStructuralIntegrityUpdate(TreeNode node, TreeNode parrentNode, HashSet<int> alivenode) {

			// ノードが一覧にあるかチェック
			if (treeMap.ContainsKey(node.InstanceID)) {

				// 参加しているドキュメントが別物なら相手から撤去
				if (node.document != null && node.document != this && node.document.treeMap.ContainsKey(node.InstanceID)) {
					node.document.treeMap.Remove(node.InstanceID);
				}

				// とにかく自分に参照をつなげる
				node.document = this;

			} else {
				// 追加する
				treeMap.Add(node.InstanceID, node);
			}

			// 既に同じIDで発見された何らかのノードがあるか確認する
			if (alivenode.Contains(node.InstanceID)) {

				// 親のレコードから自分を含むものを検索
				var parrentToMe = parrentNode?.childNodes.SingleOrDefault(e => e.Value == node);

				// いったん今の親から切断
				if (parrentToMe.HasValue) { parrentNode.childNodes.Remove(parrentToMe.Value.Key); }


				try {
					// いったんドキュメントから切断
					parrentNode.childNodes.Remove(treeMap.Single(e => e.Value == node).Key);
				} catch (InvalidOperationException) {
					// なけりゃそれでいい
				}

				// IDを更新する
				for (; treeMap.ContainsKey(node.InstanceID); node.InstanceID = rand.Next())
					;


				// ドキュメントと親に再接続
				treeMap.Add(node.InstanceID, node);
				parrentNode.childNodes.Add(node.InstanceID, node);

			}

			// 親と相互接続しているか確認
			if (parrentNode != node.Parrent) {

				// 親に接続
				node.Parrent = parrentNode;

				// 親の子の一覧に名けえれば追記する
				if (!parrentNode.childNodes.ContainsKey(node.InstanceID)) {
					parrentNode.childNodes.Add(node.InstanceID, node);
				}
			}

			// 発見済みとして記録
			alivenode.Add(node.InstanceID);

			// 全ての子を処理する
			foreach (var child in node.ChildNodes.ToArray()) {

				if (alivenode.Contains(child.InstanceID) && child.Parrent != node) {

					// 発見済みのノードが含まれていて親が自分ない場合は子から外す
					node.childNodes.Remove(child.InstanceID);

				} else {

					// 子に対しても整合性チェックを行う
					NodeStructuralIntegrityUpdate(child, node, alivenode);

				}
			}
		}
	}
}
