﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Taurus.Exceptions;
using System.Linq;
using Taurus.Data.Network.Info;
using Taurus.Network.Client;

namespace Taurus.Network.Protocol.Tree {
	/// <summary>
	/// ツリーなノード
	/// </summary>
	public class TreeNode {


		/// <summary>
		/// ドキュメント管理用クラス
		/// </summary>
		internal TreeDocument document;

		/// <summary>
		/// インスタンスID
		/// </summary>
		public int InstanceID { get; internal set; }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="document">対応するドキュメントルート</param>
		/// <param name="instanceID">インスタンスID</param>
		internal TreeNode(TreeDocument document, int instanceID) {
			this.document = document;
			this.InstanceID = instanceID;
		}

		#region ツリー構造の維持に必要 


		/// <summary>
		/// 親の参照
		/// </summary>
		public TreeNode Parrent { get; internal set; }

		/// <summary>
		/// ノード名
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// 子の要素
		/// </summary>
		internal Dictionary<int, TreeNode> childNodes = new Dictionary<int, TreeNode>();

		/// <summary>
		/// すべての子
		/// </summary>
		public IEnumerable<TreeNode> ChildNodes => childNodes.Select(e => e.Value);

		/// <summary>
		/// 子に追加
		/// </summary>
		/// <param name="treeNode">追加したいノード</param>
		public void AppendChild(TreeNode treeNode) {

			// 相手と自分のドキュメントが違う場合は処理できない
			if (document != treeNode.document) {
				throw new TaurusTreeException($"{nameof(TreeDocument)}を超えて親子関係の変更はできません");
			}

			// 相手の親が自分なら何もしない
			if (treeNode.Parrent == this) {
				return;
			}

			// 整合性チェック済みフラグOFF
			document.IsCheckedStructuralIntegrity = false;

			// 相手の親がいれば相手の親の子要素一覧から外す
			treeNode.Parrent?.childNodes.Remove(treeNode.InstanceID);

			// 相手の親を自分にする
			treeNode.Parrent = this;

			// 自分の子の一覧に入れる
			childNodes.Add(treeNode.InstanceID, treeNode);


		}

		/// <summary>
		/// 名前基準で子を検索
		/// </summary>
		/// <param name="nodeName">ノード名</param>
		/// <returns>ノード</returns>
		public TreeNode FindName(string nodeName) {
			return childNodes.FirstOrDefault(e => e.Value.Name == nodeName).Value;
		}

		/// <summary>
		/// 名前基準で子を検索して見つからなければ新規作成
		/// </summary>
		/// <param name="nodeName">ノード名</param>
		/// <returns>ノード</returns>
		public TreeNode FindNameOrCreate(string nodeName) {
			return childNodes.FirstOrDefault(e => e.Value.Name == nodeName).Value ?? CreateChild(nodeName);
		}

		/// <summary>
		/// 名前基準で子を複数検索
		/// </summary>
		/// <param name="nodeName">ノード名</param>
		/// <returns>ノード</returns>
		public TreeNode[] Findnames(string nodeName) {
			return childNodes.Where(e => e.Value.Name == nodeName).Select(e => e.Value).ToArray();
		}

		/// <summary>
		/// 子に追加
		/// </summary>
		/// <param name="treeNodes">追加したい子どもたち</param>
		public void AppendChild(params TreeNode[] treeNodes) {
			foreach (var node in treeNodes) { AppendChild(treeNodes); }
		}

		/// <summary>
		/// 子に追加
		/// </summary>
		/// <param name="treeNodes">追加したい子どもたち</param>
		public void AppendChild(IEnumerable<TreeNode> treeNodes) {
			foreach (var node in treeNodes) { AppendChild(treeNodes); }
		}

		/// <summary>
		/// 誰かの下に付く
		/// </summary>
		/// <param name="parrentNode">親のノード</param>
		public void AttachParrent(TreeNode parrentNode) {
			parrentNode.AppendChild(this);
		}

		/// <summary>
		/// この要素と子要素全てを消す
		/// </summary>
		public void Remove() {
			// 構造チェック必須
			document.IsCheckedStructuralIntegrity = false;

			// 子の要素全部殺す
			foreach (var node in AllChildren().ToArray()) {
				node.InternalRemove();
			}

			// もちろん自分も死ぬ
			InternalRemove();
		}

		/// <summary>
		/// この要素を消す
		/// 内部処理用
		/// </summary>
		private void InternalRemove() {
			// 親に忘れてもらう
			Parrent.childNodes.Remove(InstanceID);

			// ドキュメントルートにも忘れてもらう
			document.treeMap.Remove(InstanceID);
		}


		/// <summary>
		/// 子の要素を作る
		/// </summary>
		/// <param name="nodeName">ノード名</param>
		/// <returns>新しい要素</returns>
		public TreeNode CreateChild(string nodeName) {
			// ノード作る
			var node = document.CreateNode(nodeName);

			// 子にする
			AppendChild(node);

			// 返す
			return node;
		}

		/// <summary>
		/// 全ての子要素を取り出す
		/// 再回帰呼び出しを防ぐ機能はない
		/// </summary>
		/// <returns>子孫全てのノード</returns>
		internal IEnumerable<TreeNode> AllChildren() {

			// 全ての自分の子に対して処理
			foreach (var node in ChildNodes) {
				// 直下の子を出す
				yield return node;

				// 子の持っているすべての一覧を吐かせる
				foreach (var childHaveNode in node.AllChildren()) {
					yield return childHaveNode;
				}

			}

		}



		#endregion

		#region セーブデータの維持に必要

		/// <summary>
		/// データの状況
		/// </summary>
		public enum DataState : byte {

			/// <summary>
			/// どういう状況かわからない
			/// </summary>
			Unknown = 0,

			/// <summary>
			/// ロード済み
			/// </summary>
			Loaded = 1,

			/// <summary>
			/// 値の更新を検出
			/// </summary>
			Update = 2,

		}


		/// <summary>
		/// 値の状況
		/// </summary>
		internal DataState state = DataState.Loaded;

		/// <summary>
		/// 内部の値保持
		/// </summary>
		internal string internalValue;

		/// <summary>
		/// 子要素全ての値を取り出す
		/// </summary>
		/// <returns>待機用タスク</returns>
		public async Task ChildGetValueAsync() {
			await GetValueAsync().ConfigureAwait(false);

			foreach (var node in AllChildren()) {
				await node.GetValueAsync().ConfigureAwait(false);
			}
		}

		/// <summary>
		/// 値をサーバーに問い合わせる
		/// </summary>
		/// <returns>問い合わせた値</returns>
		public async Task<string> GetValueAsync() {

			// 状況が不明でなければ値を今の値を返す
			if (state != DataState.Unknown) { return internalValue; }

			// サーバーへ問い合わせを行う
			var data = await document.client.ReadTreeDataAsync(InstanceID).ConfigureAwait(false);

			// 完了し次第適応する
			state = DataState.Loaded;
			return internalValue = data.Value?.Data;
		}


		/// <summary>
		/// 値を参照
		/// 事前にGetValueAsyncをしないと非常にひどい目に会います
		/// あとスレッドセーフじゃないですので丁寧に使ってください
		/// </summary>
		public string Value {

			get {
				// 非読み込み済みなら読み込んだスレッドをブロックして読み込みを行う
				if (state == DataState.Unknown) { Task.Run(async()=>await GetValueAsync().ConfigureAwait(false)).Wait();	}
				
				return internalValue;
			}

			set {

				// 値が代入されたときすでに読み込み済みであれば値の変化を比較して更新が必要か判断する
				state = state != DataState.Unknown ? internalValue == value ? state : DataState.Update : DataState.Update;

				// 値を代入
				internalValue = value;

			}
		}

		/// <summary>
		/// キャッシュをクリアする
		/// </summary>
		public void RemoveCache() {

			// ロード済み以外は消せない
			if (state != DataState.Loaded) {
				return;
			}

			// フラグを未知に
			state = DataState.Unknown;

			// 保持してる値を解放
			internalValue = null;
		}

		/// <summary>
		/// 子のキャッシュ全クリア
		/// </summary>
		/// <param name="isSelfClear">自分のキャッシュもクリアするか否か</param>
		public void RemoveCacheChildren(bool isSelfClear = true) {
			// 自分のキャッシュをクリアする必要があれば消す
			if (isSelfClear) { RemoveCache(); }

			// 子の要素も全部消す
			foreach (var node in ChildNodes) {
				node.RemoveCacheChildren(true);
			}
		}

		#endregion

		/// <summary>
		/// 子要素全ての値を一気に取り出す
		/// </summary>
		/// <returns>待機用タスク</returns>
		public async Task ChildGetValueAsyncAll() {
			List<int> instanceIds = new List<int>();

			// 取得が必要なInstanceIdを探す
			if (state == DataState.Unknown) {
				instanceIds.Add(InstanceID);
			}

			if (childNodes != null) {
				foreach (var node in AllChildren()) {
					if (node.state == DataState.Unknown) {
						instanceIds.Add(node.InstanceID);
					}
				}
			}

			OrderResponceSignalAndData<TreeDataInfo[]> datas = new OrderResponceSignalAndData<TreeDataInfo[]>();

			if (0 < instanceIds.Count) {
				// サーバーへ問い合わせを行う
				datas = await document.client.ReadTreeDatasAsync(instanceIds.ToArray());
			}

			if (datas.Value != null) {
				// 取ってきたInstanceIdをはめる
				// 引っ張ってこようとしたのにデータがないやつはNULLをはめる
				foreach (TreeNode node in AllChildren()) {
					if (node.state == DataState.Loaded) {
						continue;
					}
					foreach (TreeDataInfo data in datas.Value) {
						if (data.InstanceID == node.InstanceID) {
							node.internalValue = data.Data;
							node.state = DataState.Loaded;
							break;
						}
					}
					if (node.state != DataState.Loaded) {
						node.internalValue = null;
						node.state = DataState.Loaded;
					}
				}
			}
		}
	}
}
