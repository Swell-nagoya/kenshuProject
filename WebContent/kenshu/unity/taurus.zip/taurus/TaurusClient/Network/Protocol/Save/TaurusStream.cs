﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Exceptions;
using Taurus.Lib;
using Taurus.Network.Client;
using Taurus.Util;

namespace Taurus.Network.Protocol.Save {

	/// <summary>
	/// ストリームっぽくセーブシステムを弄り回せる
	/// ※非スレッドセーフです！！！！
	/// </summary>
	public class TaurusStream : Stream {

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="Client">使用するクライアント</param>
		public TaurusStream(LocalClient Client) : this(Client, Client.LobbyAndYou.You.About.UserID) {
			IsWrite = true;
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="Client">使用するクライアント</param>
		/// <param name="TargetUser">対象のユーザー</param>
		public TaurusStream(LocalClient Client, int TargetUser) {
			this.Client = Client;
			this.TargetUser = TargetUser;
		}

		/// <summary>
		/// クライアント
		/// </summary>
		private LocalClient Client;

		/// <summary>
		/// アクセス対象のユーザー
		/// </summary>
		private readonly int TargetUser;

		/// <summary>
		/// 書き込み可能対象であるか否か
		/// </summary>
		private bool IsWrite = false;

		/// <summary>
		/// 最大サイズ
		/// </summary>
		private long MaxSize;

		/// <summary>
		/// 現在位置
		/// </summary>
		private long CurrentPosition = 0;

		/// <summary>
		/// ページサイズ
		/// </summary>
		const long PageSize = 1024;

		/// <summary>
		/// 今見ているページの内容
		/// </summary>
		byte[] CurrentPageBuf = new byte[0];


		/// <summary>
		/// 保有しているページ番号一覧
		/// </summary>
		public List<int> PageInfos = null;

		/// <summary>
		/// 最大量再計算
		/// </summary>
		private void MaxSizeUpdate() {
			MaxSize = PageInfos.Any() ? (PageInfos.Max() + 1) * PageSize : 0;
		}

		/// <summary>
		/// ページ情報
		/// </summary>
		private async Task PageInfoUpdateAsync() {

			// 情報取得
			var info = await Client.SaveInfoAsync(TargetUser).ConfigureAwait(false);

			// 成功チェック
			if (info.Pattern != Common.OrderResponcePattern.OK) {
				throw new TaurusSaveIOException($"ページ読み出しに失敗しました Message : {info.Pattern}");
			}

			// 読み出した内容を書き出し
			PageInfos = new List<int>(info.Value);
			MaxSizeUpdate();

		}

		/// <summary>
		/// シーク先
		/// </summary>
		private long SeekTo = -1;

		/// <summary>
		/// ページ非同期移動
		/// </summary>
		/// <param name="page">シーク先</param>
		private async Task PageMoveAsync(int page) {

			// まだなら先にページ情報を更新
			if (PageInfos == null) {
				await PageInfoUpdateAsync().ConfigureAwait(false);

				// 更新フラグはへし折っておく
				IsFlushRequired = false;
			}

			// 現在地点を書き出す
			await FlushAsync().ConfigureAwait(false);


			//ページの位置にシークする
			SeekTo = CurrentPosition = page * PageSize;


			// 読み出し予定位置が存在しなければ確保だけする
			if (!PageInfos.Contains(page)) {
				CurrentPageBuf = new byte[1024];
				PageInfos.Add(page);
				MaxSizeUpdate();

				// 更新は必要
				IsFlushRequired = true;

				return;
			}


			// 吸出し
			var load = await Client.SaveReadAsync(TargetUser, page).ConfigureAwait(false);

			// 成功チェック
			if (load.Pattern != Common.OrderResponcePattern.OK) {
				throw new TaurusSaveIOException($"ページ読み出しに失敗しました Message : {load.Pattern}");
			}

			// 一覧になければ記録しておく
			if (!PageInfos.Contains(page)) {
				PageInfos.Add(page);
				MaxSizeUpdate();
			}

			if (load.Value.Length == PageSize) {
				// 問題なさそうであれば現在のページへ適応
				CurrentPageBuf = load.Value;

			} else if (load.Value.Length < PageSize) {

				// ページサイズが足りなければ既定サイズにする
				CurrentPageBuf = new byte[PageSize];
				Buffer.BlockCopy(load.Value, 0, CurrentPageBuf, 0, (int)PageSize);
			} else {

				// ページサイズが長すぎるので切り詰める
				CurrentPageBuf = load.Value.Take((int)PageSize).ToArray();
			}
		}

		/// <summary>
		/// シークチェック
		/// </summary>
		private async Task SeekCheck() {

			// シークの必要があるか確認
			if (SeekTo != CurrentPosition) {

				if (CurrentPosition < 0) {
					// 初期化が必要
					await PageMoveAsync(0).ConfigureAwait(false);
				} else {
					// シークするべきページを算出してページ移動
					var targetPage = (SeekTo / PageSize);
					await PageMoveAsync((int)targetPage).ConfigureAwait(false);
				}
			}
		}

		/// <summary>
		/// 読み取り可能であるか否か
		/// </summary>
		public override bool CanRead => !Client.IsDispose;

		/// <summary>
		/// シーク可能であるか否か
		/// </summary>
		public override bool CanSeek => CanRead;

		/// <summary>
		/// 書き込み可能であるか否か
		/// </summary>
		public override bool CanWrite => IsWrite;

		/// <summary>
		/// 初期化を行う
		/// </summary>
		/// <returns>非同期初期化</returns>
		public async Task InitAsync() {
			// 必要であれば初期化を行う
			if (CurrentPosition < 0) {
				await PageMoveAsync(0).ConfigureAwait(false);
			}
		}

		/// <summary>
		/// メインスレッドをロックして初期化を行う
		/// </summary>
		public void Init() {
			// 必要であれば初期化
			if (CurrentPosition < 0) {

				using (var Task = InitAsync()) {
					while (Task.IsRunning()) { Thread.Sleep(10); }
				}
			}
		}


		/// <summary>
		/// 長さ
		/// 全長未収得の場合はメインスレッドをロックして読み込みを行う
		/// </summary>
		public override long Length {
			get {
				// 初期化する
				Init();

				return MaxSize * PageSize;
			}
		}

		/// <summary>
		/// 現在位置
		/// </summary>
		public override long Position { get => SeekTo; set => Seek(value, SeekOrigin.Begin); }

		/// <summary>
		/// 更新しなければいけないか
		/// </summary>
		private bool IsFlushRequired = false;

		/// <summary>
		/// 非同期読み出し
		/// </summary>
		/// <param name="buffer">書き出し先</param>
		/// <param name="offset">書き出し位置</param>
		/// <param name="count">書き出し先</param>
		/// <param name="cancellationToken">キャンセルトークン(キャンセルできないかも)</param>
		/// <returns>読み取ったバイト数</returns>
		public override async Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken) {

			// 引数チェックの森
			if (buffer == null) { throw new ArgumentNullException(nameof(buffer), "引数がnullです"); }
			if (offset < 0) { throw new ArgumentOutOfRangeException(nameof(offset), "バッファの範囲外を指定しようとしました"); }
			if (count < 0) { throw new ArgumentOutOfRangeException(nameof(count), "マイナス量の読み出しはできません"); }
			if (buffer.Length - offset < count) { throw new ArgumentException("バッファに十分な領域がありません"); }

			// チェック終了
			Contract.EndContractBlock();

			// 現在位置がマイナスであれば初期位置に移動
			if (CurrentPosition < 0) {
				await PageMoveAsync(0).ConfigureAwait(false);
			}

			// シークチェック
			await SeekCheck().ConfigureAwait(false);

			// 読み出し可能量を算出して溢れる場合は丸め込み
			if ((CurrentPosition + count) > MaxSize) {
				count = (int)(MaxSize - CurrentPosition);
			}

			// 読み出せなさそうであれば読まずに0を返す
			if (count <= 0) {
				return 0;
			}

			// 現在のページに収まるか
			if ((int)(Math.Ceiling((double)(CurrentPosition / PageSize))) == (int)(Math.Ceiling((double)((CurrentPosition + count) / PageSize)))) {
				// 読み出しを行う
				Buffer.BlockCopy(CurrentPageBuf, (int)(CurrentPosition % PageSize), buffer, offset, count);
				return count;
			}



			// 現在ページを計算
			int currentpage = (int)(CurrentPosition / PageSize);

			// 収まらないのであれば必要なページ数を調べる
			int UsePageCount = (int)Math.Ceiling((double)((count + CurrentPosition) / PageSize));

			// バッファ書き出し位置
			int BufferPosition = offset;

			// 読み込みサイズ
			int ReadSize = 0;

			// 開始位置を覚えておく
			long FirestPoint = CurrentPosition;

			// まずは現在のページを記録
			Buffer.BlockCopy(CurrentPageBuf, (int)(CurrentPosition % PageSize), buffer, BufferPosition, ReadSize += (int)(PageSize - (CurrentPosition % PageSize)));



			// 読み出し量がゼロになるまで読み出し
			int TmpReadCount = 0;
			while ((count - ReadSize) > 0) {
				// 1ページ読み出し
				await PageMoveAsync(++currentpage).ConfigureAwait(false);

				// 今回読み出す量を計算
				TmpReadCount = (int)((count - ReadSize) <= PageSize ? (count - ReadSize) : PageSize);

				// 読み出し
				Buffer.BlockCopy(CurrentPageBuf, 0, buffer, offset + ReadSize, TmpReadCount);

				// 読み出し量を記録
				ReadSize += TmpReadCount;

			}

			// 現在位置を移動
			CurrentPosition = FirestPoint + ReadSize;
			SeekTo = CurrentPosition;

			// 読み出した量を返す
			return ReadSize;
		}

		/// <summary>
		/// 書き出し
		/// </summary>
		/// <param name="buffer">書き出しバッファー</param>
		/// <param name="offset">書き出しバッファーの読み出し位置</param>
		/// <param name="count">書き出す量</param>
		/// <param name="cancellationToken">キャンセルトークン(動かんなこれ♥)</param>
		/// <returns>void</returns>
		public override async Task WriteAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken) {

			// 引数チェックの森
			if (buffer == null) { throw new ArgumentNullException(nameof(buffer), "引数がnullです"); }
			if (offset < 0) { throw new ArgumentOutOfRangeException(nameof(offset), "バッファの範囲外を指定しようとしました"); }
			if (count < 0) { throw new ArgumentOutOfRangeException(nameof(count), "マイナス量の読み出しはできません"); }
			if (buffer.Length - offset < count) { throw new ArgumentException("バッファに十分な領域がありません"); }

			// チェック終了
			Contract.EndContractBlock();

			// 現在位置がマイナスであれば初期位置に移動

			if (CurrentPosition < 0) {
				await PageMoveAsync(0).ConfigureAwait(false);
			}

			// 更新が必要
			IsFlushRequired = true;

			// シークチェック
			await SeekCheck().ConfigureAwait(false);

			// 現在のページに収まるか
			if ((int)(Math.Ceiling((double)(CurrentPosition / PageSize))) == (int)(Math.Ceiling((double)((CurrentPosition + count) / PageSize)))) {
				// 書き出しを行う
				Buffer.BlockCopy(buffer, offset, CurrentPageBuf, (int)(CurrentPosition % PageSize), count);

				// 更新必要フラグon
				IsFlushRequired = true;

				return;
			}

			// 開始位置を覚える
			long StartPos = CurrentPosition;

			// 現在ページを計算
			int currentpage = (int)(CurrentPosition / PageSize);

			// 収まらないのであれば必要なページ数を調べる
			int UsePageCount = (int)Math.Ceiling((double)((count + CurrentPosition) / PageSize));

			// バッファ書き出し位置
			int BufferPosition = offset;

			// 書き込みサイズ
			int WriteSize = 0;

			// まずは現在のページを記録
			Buffer.BlockCopy(buffer, BufferPosition, CurrentPageBuf, (int)(CurrentPosition % PageSize), WriteSize += (int)(PageSize - (CurrentPosition % PageSize)));


			int TmpWriteCount = 0;

			// 書き出し出し量がゼロになるまで読み出し
			while ((count - WriteSize) > 0) {
				// ページ移動
				await PageMoveAsync(++currentpage).ConfigureAwait(false);

				// 今回書き出す量を計算
				TmpWriteCount = (int)((count - WriteSize) <= PageSize ? (count - WriteSize) : PageSize);

				// 書き出し
				Buffer.BlockCopy(buffer, offset + WriteSize, CurrentPageBuf, 0, TmpWriteCount);

				// 更新は必要
				IsFlushRequired = true;

				// 書き出し量を記録
				WriteSize += TmpWriteCount;
			}

			// 現在位置を最終地点に

			SeekTo = CurrentPosition = (StartPos + WriteSize);

		}


		/// <summary>
		/// 値をサーバーに書き出し
		/// </summary>
		/// <param name="cancellationToken">キャンセルトークン(使えないよ)</param>
		/// <returns>void</returns>
		public override async Task FlushAsync(CancellationToken cancellationToken) {
			// 更新が不要そうであればやらない
			if (!IsFlushRequired) { return; }
			IsFlushRequired = false;

			// 書き出し
			var write = await Client.SaveWriteAsync((int)(CurrentPosition / PageSize), CurrentPageBuf).ConfigureAwait(false);

			// 成功チェック
			if (write.Pattern != Common.OrderResponcePattern.OK) {
				throw new TaurusSaveIOException($"セーブデータの保存に失敗しました Message : {write.Pattern}");
			}

		}

		/// <summary>
		/// セーブデータ書き出し
		/// </summary>
		public override void Flush() {
			// 非同期処理のを転用
			using (var task = FlushAsync()) {

				// 終了するまで呼び出し元のスレッドをブロック
				while (task.IsRunning()) { Thread.Sleep(1); }
			}

		}

		/// <summary>
		/// 読み出し
		/// </summary>
		/// <param name="buffer">読み出しバッファ</param>
		/// <param name="offset">読み出し</param>
		/// <param name="count">読み出し量</param>
		/// <returns></returns>
		public override int Read(byte[] buffer, int offset, int count) {
			// 非同期処理のを転用

			using (var task = ReadAsync(buffer, offset, count)) {

				// 終了するまで呼び出し元のスレッドをブロック
				while (task.IsRunning()) { Thread.Sleep(1); }

				// 返す
				return task.Result;
			}
		}

		/// <summary>
		/// シークする
		/// </summary>
		/// <param name="offset">移動量</param>
		/// <param name="origin">移動開始地点</param>
		/// <returns></returns>
		public override long Seek(long offset, SeekOrigin origin) {
			// 仮位置
			long tmpPos = CurrentPosition;

			// 数える位置を考慮する
			switch (origin) {
				case SeekOrigin.Begin:
				tmpPos = offset;
				break;

				case SeekOrigin.Current:
				tmpPos += offset;
				break;

				case SeekOrigin.End:
				tmpPos = offset;
				break;
			}

			// 値が妙な値であれば無理
			if (tmpPos < 0) {
				throw new TaurusSaveIOException($"マイナス地点へのシークはできません MoveTo : {tmpPos}");
			}

			// 現在位置よりも遠くに置かれた場合はサイズが伸びる
			if (tmpPos > MaxSize) {
				MaxSize = tmpPos;
			}

			// 移動位置記録して返す
			return SeekTo = tmpPos;
		}

		/// <summary>
		/// 長さを調節
		/// </summary>
		/// <param name="value"></param>
		public override void SetLength(long value) {
			// 減らせはしない
			if (value < MaxSize) {
				throw new TaurusSaveIOException($"サイズを小さくすることはできません Size : {value}");
			}

			MaxSize = value;
		}

		/// <summary>
		/// 書き出し
		/// </summary>
		/// <param name="buffer">書き出しバッファ</param>
		/// <param name="offset">書き出しバッファの開始位置</param>
		/// <param name="count">書き出し量</param>
		public override void Write(byte[] buffer, int offset, int count) {
			// 非同期処理のを転用

			using (var task = WriteAsync(buffer, offset, count)) {

				// 終了するまで呼び出し元のスレッドをブロック
				while (task.IsRunning()) { Thread.Sleep(1); }
			}
		}




		#region "解放系"

		/// <summary>
		/// 解放済みか否か
		/// </summary>
		private bool IsDispose = false;

		/// <summary>
		/// わくわく解放処理
		/// </summary>
		/// <param name="disposing">アンマネージドリソースを解放するか否か</param>
		protected override void Dispose(bool disposing) {
			base.Dispose(disposing);

			//　未開放なら解放
			if (!IsDispose) {
				IsDispose = true;
				Flush();
			}

		}

		#endregion
	}
}
