﻿using System;
using Taurus.Network.Common;

namespace Taurus.Network.Client {

	/// <summary>
	/// 送信メッセージと実行するべきコールバックのペア
	/// </summary>
	public class MessageAndCallback {

		/// <summary>
		/// 送信したオーダーのID
		/// </summary>
		public Guid EntityID;

		/// <summary>
		/// 送信対象のメッセージ
		/// </summary>
		public Message Msg;

		/// <summary>
		/// コールバック
		/// </summary>
		public Action<Message> Callback;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public MessageAndCallback() { }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="Msg"></param>
		/// <param name="Callback"></param>
		public MessageAndCallback(Message Msg, Action<Message> Callback) {
			this.Msg = Msg;
			this.Callback = Callback;
		}

	}
}
