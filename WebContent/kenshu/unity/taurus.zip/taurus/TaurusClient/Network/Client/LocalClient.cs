﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;
using Taurus.Data;
using Taurus.Data.DB;
using Taurus.Data.Network;
using Taurus.Data.Network.Info;
using Taurus.Data.Network.OrderPayload;
using Taurus.Data.Network.OrderResponce;
using Taurus.Lib;
using Taurus.Network.Common;
using Taurus.Network.Protocol.Tree;
using Taurus.Util;

namespace Taurus.Network.Client {
	/// <summary>
	/// 末端側のクライアント処理
	/// </summary>
	public class LocalClient : CoroutineBase {

		#region 状態が分かるEnum

		/// <summary>
		/// クライアントの状況
		/// </summary>
		public enum ClientState : byte {

			/// <summary>
			/// 謎
			/// </summary>
			UNKNOWN = 0x00,

			/// <summary>
			/// 起動待機中
			/// </summary>
			STANDBY = 0x01,

			/// <summary>
			/// 接続待機中
			/// </summary>
			CONNECTION_WAIT = 0x02,

			/// <summary>
			/// 接続完了
			/// </summary>
			CONNECTED = 0x03,

			/// <summary>
			/// ログイン完了
			/// </summary>
			LOGIN = 0x04,

			/// <summary>
			/// ログイン失敗
			/// </summary>
			LOGIN_FAILED = 0x05,

			/// <summary>
			/// 接続失敗
			/// </summary>
			CONNECTION_FAILED = 0x06,

			/// <summary>
			/// ログアウト
			/// </summary>
			LOGOUT = 0x07,

			/// <summary>
			/// タイムアウト
			/// </summary>
			TIMEOUT = 0x08,

			/// <summary>
			/// サーバーバージョンがなんかまずい
			/// </summary>
			IRREGULAR_SERVER_VERSION = 0x09,

			/// <summary>
			/// コネクション切断
			/// </summary>
			CONNECTION_CLOSE = 0x0a,

			/// <summary>
			/// ログイン衝突
			/// </summary>
			LOGIN_COLLISION = 0x0b,

			/// <summary>
			/// アカウント無効化済み
			/// </summary>
			INVALID_ACCOUNT = 0x0c,

		}

		/// <summary>
		/// クライアントの現在の情報が分かる
		/// </summary>
		public ClientState State { get; private set; } = ClientState.STANDBY;

		#endregion


		#region 初期化・解放などの一般処理

		/// <summary>
		/// 接続先
		/// </summary>
		private readonly string Target = "";

		/// <summary>
		/// 通信制御ロック用
		/// </summary>
		private object ComLock = new object();

		/// <summary>
		/// 接続が確立しているか否か
		/// </summary>
		public bool IsConnect { get => !(Com == null); }

		/// <summary>
		/// 初期化完了しているか否か
		/// </summary>
		public bool IsInitCompleat { get; private set; } = false;

		/// <summary>
		/// 接続の初期化に失敗した数
		/// </summary>
		private int comInitFailedCount = 0;

		/// <summary>
		/// 通信用
		/// </summary>
		private TCPEndPointBase Com = null;

		/// <summary>
		/// 最終送信時刻
		/// </summary>
		private DateTime LastSend = DateTime.Now;

		/// <summary>
		/// タイムアウト制御用の時計
		/// </summary>
		private DateTime AppTimeoutWatch = DateTime.Now;

		/// <summary>
		/// エンティティID
		/// </summary>
		public readonly Guid EntityID = Guid.NewGuid();

		/// <summary>
		/// バッファサイズ
		/// </summary>
		int BufferSize = 4096;

		/// <summary>
		/// アプリケーション特定に必要な情報
		/// </summary>
		public readonly AppIdAndDevIdPair Application;

		/// <summary>
		/// ログインに必要な情報
		/// </summary>
		public LoginInfo LoginData { get; private set; }

		/// <summary>
		/// ツリー型セーブ領域
		/// </summary>
		public TreeDocument TreeSave { get; private set; }

		/// <summary>
		/// デフォルトパラメーターで初期化
		/// </summary>
		/// <param name="Application">アプリケーション情報</param>
		/// <param name="HostName">ホスト名</param>
		/// <param name="LoginData">ログインに必要な情報(省略時新規ユーザー作成)</param>
		public LocalClient(AppIdAndDevIdPair Application, string HostName, LoginInfo LoginData = null) {
			Target = HostName;
			this.Application = Application;
			this.LoginData = LoginData;
		}

		/// <summary>
		/// バッファサイズも指定して初期化
		/// </summary>
		/// <param name="Application">アプリケーション情報</param>
		/// <param name="HostName">ホスト名</param>
		/// <param name="LoginData">ログインに必要な情報(省略時新規ユーザー作成)</param>
		/// <param name="BufferSize">TCPバッファサイズ</param>
		public LocalClient(AppIdAndDevIdPair Application, string HostName, LoginInfo LoginData, int BufferSize) : this(Application, HostName, LoginData) {
			this.BufferSize = BufferSize;
		}

		/// <summary>
		/// バッファサイズも指定して初期化
		/// ユーザーは新規作成される
		/// </summary>
		/// <param name="Application">アプリケーション情報</param>
		/// <param name="HostName">ホスト名</param>
		/// <param name="BufferSize">TCPバッファサイズ</param>
		public LocalClient(AppIdAndDevIdPair Application, string HostName, int BufferSize) : this(Application, HostName, null) {
			this.BufferSize = BufferSize;
		}

		/// <summary>
		/// 解放済みか否か
		/// </summary>
		public bool IsDispose { get; private set; } = false;

		/// <summary>
		/// 解放ロック用
		/// </summary>
		private object DisposeLock = new object();

		/// <summary>
		/// 解放する
		/// </summary>
		/// <param name="disposing">マネージドリソースの解放を行うか否か</param>
		protected override void ChildDispose(bool disposing) {

			// 解放する
			if (!IsDispose) {
				IsDispose = true;

				if (disposing) {
					// 制御系はまだ使えるか確認
					if (Com != null) {

						// 解放処理
						Task.Run(async () => {

							// 初期化完了を待機
							while (!Com.IsInitCompleat) { await TaskUtil.Yield().ConfigureAwait(false); }

							// 利用可能か確認
							if (Com.IsEnabled) {
								// 利用可能であれば切断指示
								await Com.TrySendMessageAsync(new Message() { SignalType = Signal.CLOSE }).ConfigureAwait(false);
							}

							// 解放
							Com.Dispose();

						});

						// 切断指令　あればここに
					}
				}

			}
		}

		#endregion

		#region 保持する情報

		/// <summary>
		/// 現在のロビー
		/// </summary>
		public LobbyInfo NowLobby { get; private set; }

		/// <summary>
		/// 現在の部屋
		/// </summary>
		public RoomInfo NowRoom { get; private set; } = null;

		/// <summary>
		/// ルーム一覧
		/// </summary>
		public readonly LockList<RoomInfo> Rooms = new LockList<RoomInfo>();

		/// <summary>
		/// ロビーユーザー一覧
		/// </summary>
		public readonly LockList<UserEntityInfo> LobbyUsers = new LockList<UserEntityInfo>();

		/// <summary>
		/// ルームユーザー一覧
		/// </summary>
		public readonly LockList<UserEntityInfo> RoomUsers = new LockList<UserEntityInfo>();


		/// <summary>
		/// ロビーとあなたの情報
		/// </summary>
		public LobbysAndYouInfo LobbyAndYou { get; private set; }

		#endregion

		#region イベント

		#region イベントハンドラ・引数クラス

		/// <summary>
		/// ユーザーイベント系引数
		/// </summary>
		public class UserTargetArgs : EventArgs {

			/// <summary>
			/// ユーザー情報
			/// </summary>
			public UserEntityInfo User;
		}

		/// <summary>
		/// ユーザー系イベント発生時のデリゲート
		/// </summary>
		/// <param name="sender">イベント発生させたオブジェクト</param>
		/// <param name="e">引数</param>
		public delegate void UserTargetHandler(object sender, UserTargetArgs e);

		/// <summary>
		/// ルームイベント系引数
		/// </summary>
		public class RoomTargetArgs : EventArgs {

			/// <summary>
			///ルーム情報
			/// </summary>
			public RoomInfo Room;
		}

		/// <summary>
		///ルーム系イベント発生時のデリゲート
		/// </summary>
		/// <param name="sender">イベント発生させたオブジェクト</param>
		/// <param name="e">引数</param>
		public delegate void RoomTargetHandler(object sender, RoomTargetArgs e);


		/// <summary>
		/// 誰かにメッセージを投げつけたイベント系引数
		/// </summary>
		public class ToEntityMessageArgs : EventArgs {

			/// <summary>
			///投げられたメッセージ
			/// </summary>
			public ToEntityMessage Message;
		}

		/// <summary>
		///誰かにメッセージを投げつけた系イベント発生時のデリゲート
		/// </summary>
		/// <param name="sender">イベント発生させたオブジェクト</param>
		/// <param name="e">引数</param>
		public delegate void ToEntityMessageHandler(object sender, ToEntityMessageArgs e);


		/// <summary>
		/// システムメッセージイベント系引数
		/// </summary>
		public class SystemMessageArgs : EventArgs {

			/// <summary>
			///投げられたメッセージ
			/// </summary>
			public Message Message;
		}

		/// <summary>
		/// システムメッセージ系イベント発生時のデリゲート
		/// </summary>
		/// <param name="sender">イベント発生させたオブジェクト</param>
		/// <param name="e">引数</param>
		public delegate void SystemMessageHandler(object sender, SystemMessageArgs e);


		#endregion

		#region 定義
		/// <summary>
		/// ロビーに人が増えたイベント
		/// </summary>
		public event UserTargetHandler LobbyAddUserEvent;

		/// <summary>
		/// ロビーから人が減るイベント
		/// </summary>
		public event UserTargetHandler LobbyRemoveUserEvent;

		/// <summary>
		/// ルームに人が増えるイベント
		/// </summary>
		public event UserTargetHandler RoomAddUserEvent;

		/// <summary>
		/// ルームから人が減るイベント
		/// </summary>
		public event UserTargetHandler RoomRemoveUserEvent;

		/// <summary>
		/// ルーム追加
		/// </summary>
		public event RoomTargetHandler CreateRoomEvent;

		/// <summary>
		/// ルーム削除
		/// </summary>
		public event RoomTargetHandler RemoveRoomEvent;

		/// <summary>
		/// 全域通信
		/// </summary>
		public event ToEntityMessageHandler BroadCastGlobalEvent;

		/// <summary>
		/// ロビー通信
		/// </summary>
		public event ToEntityMessageHandler BroadCastLobbyEvent;

		/// <summary>
		/// ルーム通信
		/// </summary>
		public event ToEntityMessageHandler BroadCastRoomEvent;

		/// <summary>
		/// エラー受信用
		/// </summary>
		public event SystemMessageHandler ErrorMessageEvent;

		/// <summary>
		/// エンティティに対しての送信
		/// </summary>
		public event ToEntityMessageHandler ToEntityMessageEvent;

		#endregion
		#endregion


		/// <summary>
		/// メッセージ送信キュー
		/// </summary>
		private readonly ConcurrentQueue<MessageAndCallback> SendQueue = new ConcurrentQueue<MessageAndCallback>();

		/// <summary>
		/// 結果待ち中のオーダー
		/// </summary>
		private readonly List<MessageAndCallback> WaitOrder = new List<MessageAndCallback>();

		/// <summary>
		/// 非同期処理
		/// </summary>
		protected override IEnumerator Coroutine() {

			// 接続待機中
			State = ClientState.CONNECTION_WAIT;

			// 送信ルーチン
			IEnumerator Send = SendFunc();

			// 受信ルーチン
			IEnumerator Receive = ReceiveFunc();

			// 通信ルーチンが正常に動いていることを観測する
			bool IsRoutineCompleat = true;

			// タイマーリセット
			AppTimeoutWatch = DateTime.Now;

			// 初期化処理を投げる
			Task<OrderResponceSignalAndData<bool>> InitTask = TryInitAsync();

			// ツリーセーブを起動
			TreeSave = new TreeDocument(this);

			comInitFailedCount = 0;
			bool isFirstConnect = true;

			// 送受信無限ループ
			do {

				// ちょい待ち
				yield return null;

				// 初期化完了チェック
				if (!IsInitCompleat && !InitTask.IsRunning()) {
					IsInitCompleat = true;
					InitTask.Dispose();
				}

				// ロック中にyield returnすると別スレッドになる危険性があるので先に読み出しておく
				bool tmpDispose;
				lock (DisposeLock) { tmpDispose = IsDispose; };

				// 接続先が何らかの理由によりダウンしていないか確認
				switch (Com?.State ?? TCPEndPointBase.ClientEndpointState.UNKNOWN) {

					// ソケットが開けなかったらタイムアウトだよきっと
					case TCPEndPointBase.ClientEndpointState.SOCKET_FAILED:

						Com = null;
						break;

				}

				lock (ComLock) {
					// 送信可能か確認する
					if (Com?.IsEnabled ?? false) {

						// 初期化完了していたら実行
						if (Com.IsInitCompleat) {
							comInitFailedCount = 0;
							isFirstConnect = false;
							IsRoutineCompleat = Send.MoveNext() && Receive.MoveNext();

							if (!IsRoutineCompleat) {
								State = ClientState.CONNECTION_CLOSE;
							}
						}

						// 最終送信時刻がインターバルより長くなった時に送信キューが空であればキューにメッセージ追加
						if (LastSend.IsTimeOutMs(Config.AliveSignalInterval) && !SendQueue.Any()) {
							SendQueue.Enqueue(new MessageAndCallback() { Msg = new Message() { SignalType = Signal.LIVING_SIG } });
							LastSend = DateTime.Now;
						}
					} else if (Com != null) {
						// インスタンスがあるのに接続が切れている場合の処理
						switch (Com.State) {

							case TCPEndPointBase.ClientEndpointState.IRREGULAR_SERVER_VERSION:
								// バージョンが違う
								State = ClientState.IRREGULAR_SERVER_VERSION;
								goto ENDLOOP;

							case TCPEndPointBase.ClientEndpointState.HANDSHAKE_FAILED:
								// エラー吐いたりguidがおかしかったり
								State = ClientState.IRREGULAR_SERVER_VERSION;
								goto ENDLOOP;

							case TCPEndPointBase.ClientEndpointState.SOCKET_FAILED:

								// ソケットつながらない
								State = ClientState.CONNECTION_FAILED;
								goto ENDLOOP;
						}
					}
				}

				// 後に接続チェック
				if ((Com == null || !Com.IsAlive) && !tmpDispose) {

					const int tryMaxCount = 3;

					// 一度も送信していないのに初期化が必要な場合は失敗カウントインクリメント
					if ((Com?.SendCount ?? 1) <= 0) {
						comInitFailedCount++;
					}

					// 初期化失敗しすぎなら通信終了
					if (comInitFailedCount >= tryMaxCount && isFirstConnect) {
						State = ClientState.CONNECTION_FAILED;
						goto ENDLOOP;
					}

					// 古い接続を落とす
					Com?.Dispose();

					// 非同期で投げる
					bool isInit = true;
					var initTask = Task.Run(() => {
						try {

							Com = new TCPClientEndpoint(Target, EntityID);
						}
						catch (Exception e) {
							isInit = false;
							Logger.Warning($"{nameof(LocalClient)}.initTask{comInitFailedCount + 1}回目 : {e.Message}");
						}
					});

					// 終わるまで待つ
					while (initTask.IsRunning()) { yield return null; }

					// 終わったら開放しとく
					initTask.Dispose();

					// エラー吐いたら再試行
					if (!isInit) {
						comInitFailedCount++;
						Com?.Dispose();
						// 初期化失敗しすぎなら通信終了
						if (comInitFailedCount >= tryMaxCount && isFirstConnect) {
							State = ClientState.CONNECTION_FAILED;
							goto ENDLOOP;
						}
						while (!AppTimeoutWatch.IsTimeOutMs(Config.TcpTimeout)) {
							yield return null;
						}
						if (isFirstConnect) {
							AppTimeoutWatch = DateTime.Now;
							continue;
						}
					}

					// タイマーもリセット
					AppTimeoutWatch = DateTime.Now;

				}
				
				// アプリケーションのタイムアウトチェック
				if (!isFirstConnect && Config.AppTimeout / Config.TcpTimeout <= comInitFailedCount) {
					// もう待てない
					State = ClientState.TIMEOUT;
					break;
				}

				// TCP接続のタイムアウトチェック
				if (isFirstConnect && AppTimeoutWatch.IsTimeOutMs(Config.TcpTimeout)) {

					// TCP切断を検出したのでTCP殺しておく
					Com?.Dispose();

					// タイマーもリセット
					AppTimeoutWatch = DateTime.Now;

					comInitFailedCount++;
				}
			} while (IsRoutineCompleat && !IsDispose);

			ENDLOOP:

			// メインループを抜けたので自爆して終了
			((IDisposable)this).Dispose();
		}

		/// <summary>
		/// 送信メソッド
		/// </summary>
		private IEnumerator SendFunc() {
			while (true) {
				// 送信キューチェック
				if (SendQueue.TryDequeue(out MessageAndCallback tmp)) {
					// 一個切り出す

					// 返答を期待していれば覚えておく
					if (tmp.Callback != null) {
						WaitOrder.Add(tmp);
					}

					// メッセージ一件送るまで抜けないループ
					while (true) {

						// 接続インスタンス参照
						TCPEndPointBase Com = null;
						bool isActive = false;

						lock (ComLock) {
							Com = this.Com;

							// 使えるかもlock中にチェックする
							isActive = Com == null || !Com.IsEnabled;
						}

						// 接続先チェック
						if (isActive) {
							yield return null;
							continue;
						}

						// 通信開始
						Task<bool> task = Com.TrySendMessageAsync(tmp.Msg);

						// 処理完了まで待つ
						while (task.IsRunning() && ReferenceEquals(Com, this.Com)) { yield return null; }

						// 問題なく完了したら次に行く
						if (task.IsCompleted && !task.IsCanceled && task.Exception == null && task.Result) {
							// タイマー更新しておく
							LastSend = DateTime.Now;
							break;

						}
					}

				} else {
					// 何事もなければ少し待つ
					yield return null;
				}
			}
		}

		/// <summary>
		/// 受信メソッド
		/// </summary>
		private IEnumerator ReceiveFunc() {
			while (true) {

				Message msg = null;

				// 一件読み出し
				while (true) {

					// 接続インスタンス参照
					TCPEndPointBase Com = null;
					bool isActive = false;

					lock (ComLock) {
						Com = this.Com;

						// 使えるかもlock中にチェックする
						isActive = Com == null || !Com.IsEnabled;
					}

					// 接続先チェック
					if (isActive) {
						yield return null;
						continue;
					}

					// 通信開始
					Task<Message> task = Com.ReceiveMessageAsync();

					// 完了待機
					while (task.IsRunning() && ReferenceEquals(Com, this.Com)) { yield return null; }


					// 受信成功してたらループ抜ける
					if (!task.IsCanceled && task.IsCompleted && task.Exception == null && (msg = task.Result) != null) {
						break;
					}
				}

				// 応答不要シーケンス以外は応答する
				if (msg.IsACKSendRequire()) {
					SendQueue.Enqueue(new MessageAndCallback(new Message() { SignalType = Signal.SEQUENCE_ACK, Payload = BinaryUtil.GetBytes(msg.SequenceNumber) }, (e) => { }));
				}

				// メッセージに応じての処理
				switch (msg.SignalType) {
					case Signal.ORDER_RESPONCE: {
							// オーダーの応答が発生した
							OrderResponceBase resp = (OrderResponceBase)JsonSelializerUtil.Import(msg.Payload);

							// 同じEntityIDを持つ命令を探す
							MessageAndCallback wait = WaitOrder.Find(e => e.EntityID == resp.EntityID);

							// あればコールバック発火して削除
							if (wait != null) {
								wait.Callback?.Invoke(msg);
								WaitOrder.Remove(wait);
							}

							// 返答が未ログインによる失敗であれば回線切断
							if (resp.Responce == OrderResponcePattern.FAILED_NOT_LOGIN) {
								State = ClientState.LOGOUT;
								Dispose();
							}
						}
						break;

					case Signal.LOBBY_ADD_USER: {
							// ロビーに人が増えた
							var tmp = (UserEntityInfo)JsonSelializerUtil.Import(msg.Payload);

							// 参加中のロビーがあれば追加する
							if (NowLobby != null) {
								LobbyUsers.Add(tmp);

								// イベントも焚く
								LobbyAddUserEvent?.Invoke(this, new UserTargetArgs() { User = tmp });
							}

						}
						break;

					case Signal.LOBBY_DEL_USER: {
							// ロビーから人が減った
							var tmp = (UserEntityInfo)JsonSelializerUtil.Import(msg.Payload);

							// 参加中のロビーがあれば削除する
							if (NowLobby != null) {
								LobbyUsers.RemoveAll(e => e.EntityID == tmp.EntityID);

								// イベントも焚く
								LobbyRemoveUserEvent?.Invoke(this, new UserTargetArgs() { User = tmp });
							}
						}
						break;

					case Signal.LOBBY_ADD_ROOM: {
							// ロビーに部屋が増える
							var tmp = (RoomInfo)JsonSelializerUtil.Import(msg.Payload);

							// 参加中のロビーがあればルーム一覧に追加
							if (NowLobby != null) {
								Rooms.Add(tmp);

								// イベントも焚く
								CreateRoomEvent?.Invoke(this, new RoomTargetArgs() { Room = tmp });
							}
						}
						break;

					case Signal.LOBBY_DEL_ROOM: {
							// ロビーから人が減った
							var tmp = (RoomInfo)JsonSelializerUtil.Import(msg.Payload);

							// 参加中のロビーがあれば削除する
							if (NowLobby != null) {
								LobbyUsers.RemoveAll(e => e.EntityID == tmp.EntityID);

								// イベントも焚く
								RemoveRoomEvent?.Invoke(this, new RoomTargetArgs() { Room = tmp });
							}
						}
						break;

					case Signal.ROOM_ADD_USER: {
							// ルームに人が増えた
							var tmp = (UserEntityInfo)JsonSelializerUtil.Import(msg.Payload);

							// 参加中のルームがあれば追加する
							if (NowRoom != null) {
								RoomUsers.Add(tmp);

								// イベントも焚く
								RoomAddUserEvent?.Invoke(this, new UserTargetArgs() { User = tmp });
							}


						}
						break;

					case Signal.ROOM_DEL_USER: {
							// ルームから人が減った
							var tmp = (UserEntityInfo)JsonSelializerUtil.Import(msg.Payload);

							// 参加中のルームがあれば削除する
							if (NowRoom != null) {
								RoomUsers.RemoveAll(e => e.EntityID == tmp.EntityID);
								// イベントも焚く
								RoomRemoveUserEvent?.Invoke(this, new UserTargetArgs() { User = tmp });
							}
						}
						break;

					case Signal.GLOBAL_BROADCAST: {
							// 全域通信
							BroadCastGlobalEvent?.Invoke(this, new ToEntityMessageArgs() { Message = (ToEntityMessage)JsonSelializerUtil.Import(msg.Payload) });

						}
						break;

					case Signal.LOBBY_BROADCAST: {
							// ロビー通信
							BroadCastLobbyEvent?.Invoke(this, new ToEntityMessageArgs() { Message = (ToEntityMessage)JsonSelializerUtil.Import(msg.Payload) });

						}
						break;

					case Signal.ROOM_BROADCAST: {
							// ルーム通信

							BroadCastRoomEvent?.Invoke(this, new ToEntityMessageArgs() { Message = (ToEntityMessage)JsonSelializerUtil.Import(msg.Payload) });
						}
						break;

					case Signal.RCEIVE_TO_ENTITY: {
							// 自分宛の通信
							ToEntityMessageEvent?.Invoke(this, new ToEntityMessageArgs() { Message = (ToEntityMessage)JsonSelializerUtil.Import(msg.Payload) });
						}
						break;

					case Signal.LIVING_SIG:
						// 生存報告に対して何か特別するべきことはない
						break;

					default:
					case Signal.UNKNOWN:
					case Signal.CLOSE: {
							Logger.Log($"切断しようとします ({EntityID} > Signal:{msg.SignalType.ToString()})");

							// 切断
							yield break;
						}
				}

				// 問題なさそうならタイマーリセット
				AppTimeoutWatch = DateTime.Now;

				yield return null;
			}



		}

		/// <summary>
		/// ユーザー情報更新
		/// </summary>
		private void UpdateUserInfo() {

			// オーダー作成
			Order order = new Order() {
				OrderData = new SetMyConfig() {
					Config = LobbyAndYou.You.About
				}
			};

			// 送信キューに追加
			SendOrder(order);
		}

		/// <summary>
		/// オーダーを送信する
		/// </summary>
		/// <param name="order">オーダー内容</param>
		/// <param name="callback">完了時コールバック(失敗時はnullがもらえる)</param>
		public void SendOrder(Order order, Action<OrderResponceBase> callback = null) {
			// 送信文を作成
			Message msg = Message.CreateMessages(order, Signal.ORDER);

			// 送信コールバックつきで固める
			MessageAndCallback sendandcallback = new MessageAndCallback() {
				Msg = msg,
				EntityID = order.EntityID,
				Callback = (Message) => {
					// 返答であるかチェック
					if (Message.SignalType == Signal.ORDER_RESPONCE) {
						// コールバック関数に投げる
						callback?.Invoke((OrderResponceBase)JsonSelializerUtil.Import(Message.Payload));
					} else {
						// よくわからんからエラーに投げる
						ErrorMessageEvent?.Invoke(this, new SystemMessageArgs() { Message = Message });

						// 本来のコールバックにはNull投げる
						callback?.Invoke(null);
					}
				}
			};

			// 一覧に追加
			SendQueue.Enqueue(sendandcallback);
		}

		/// <summary>
		/// 非同期オーダー送信
		/// 
		/// コールバックはIOスレッドと同期して実行される
		/// つまるところ、レスポンスを受け取った直後に実行される事が保証される
		/// つまりつまり、await SendOrderAsync(...);の次の行は受け取った直後でなく実行までの間にほかのメッセージを受信する可能性がある
		/// </summary>
		/// <param name="order">オーダー内容</param>
		/// <param name="OkCallback">成功時コールバック関数(省略可能)</param>
		/// <param name="FailedCallback">失敗時コールバック</param>
		/// <returns>結果 (失敗時null)</returns>
		public async Task<OrderResponceBase> SendOrderAsync(Order order, Action<OrderResponceBase> OkCallback = null, Action<OrderResponceBase> FailedCallback = null) {
			// 待機フラグ
			bool IsWait = true;

			// 受け取ったレスポンス
			OrderResponceBase Responce = null;

			// ロック用
			object locker = new object();

			// オーダー発射
			SendOrder(order, (e) => {
				lock (locker) {
					// 待機解除
					IsWait = false;

					// レスポンス代入
					Responce = e;

					// 成功・失敗コールバック
					if (e.IsOk) {
						OkCallback?.Invoke(e);
					} else {
						FailedCallback?.Invoke(e);
					}
				}
			});

			// オーダー完了を待機
			while (true) {

				lock (locker) {
					if (!IsWait) {
						// ループ完了
						break;
					}
				}

				// ちょい待ち
				await TaskUtil.Yield().ConfigureAwait(false);
			}

			// 値を返せる
			return Responce;

		}

		/// <summary>
		/// ロビー接続
		/// </summary>
		/// <param name="Target"></param>
		/// <returns></returns>
		public async Task<OrderResponceSignalAndData<bool>> JoinLobbyAsync(LobbyInfo Target) {

			// オーダー投げる
			OrderResponceBase resp = await SendOrderAsync(new Order() { OrderData = new JoinLobbyOrder() { TargetEntityID = Target.EntityID } }, (e) => LobbyUsers.Clear()).ConfigureAwait(false);

			// オーダー応答チェック
			if (resp.IsOk) {

				// 接続成功
				NowLobby = Target;

				// 成功
				return new OrderResponceSignalAndData<bool>(true, resp);
			}

			// 応答が未知の形式 or 接続失敗であれば失敗
			return new OrderResponceSignalAndData<bool>(false, resp);


		}

		/// <summary>
		/// ルーム内通信
		/// </summary>
		/// <param name="payload">送信内容</param>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> BroadcastRoomAsync(byte[] payload) {

			// 引数チェック
			if (payload == null) { throw new ArgumentNullException("payload", "引数がNullです"); }

			// 送信
			OrderResponceBase tmp = await SendOrderAsync(new Order() { OrderData = new TransmitMessageOrder() { Pattern = OrderPattern.BROADCAST_ROOM, Message = payload } }).ConfigureAwait(false);

			// 成功チェック
			return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
		}

		/// <summary>
		/// ロビー内通信
		/// </summary>
		/// <param name="payload">送信内容</param>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> BroadcastLobbyAsync(byte[] payload) {

			// 引数チェック
			if (payload == null) { throw new ArgumentNullException("payload", "引数がNullです"); }

			// ロビー参加チェック
			if (NowLobby == null) {
				return new OrderResponceSignalAndData<bool>(false, OrderResponcePattern.FAILED_NOT_JOINED_LOBBY);
			}

			// 送信
			OrderResponceBase tmp = await SendOrderAsync(new Order() { OrderData = new TransmitMessageOrder() { Pattern = OrderPattern.BROADCAST_LOBBY, Message = payload } }).ConfigureAwait(false);

			// 成功チェック
			return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
		}

		/// <summary>
		/// 全域通信したい
		/// </summary>
		/// <param name="payload">送信内容</param>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> BroadcastGlobalAsync(byte[] payload) {

			// 引数チェック
			if (payload == null) { throw new ArgumentNullException("payload", "引数がNullです"); }

			// 送信
			OrderResponceBase tmp = await SendOrderAsync(new Order() { OrderData = new TransmitMessageOrder() { Pattern = OrderPattern.BROADCAST_GLOBAL, Message = payload } }).ConfigureAwait(false);

			// 成功チェック
			return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
		}

		/// <summary>
		/// 特定Entityに向けてメッセージを送りたい
		/// </summary>
		/// <param name="payload">送信内容</param>
		/// <param name="TargetEntityID">対象のエンティティID</param>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> ToEntityAsync(byte[] payload, Guid TargetEntityID) {


			// 引数チェック
			if (payload == null) { throw new ArgumentNullException("payload", "引数がNullです"); }


			// 送信
			OrderResponceBase tmp = await SendOrderAsync(new Order() { OrderData = new TransmitMessageToEntityOrder() { Message = payload, TargetEntityID = TargetEntityID } }).ConfigureAwait(false);

			// 成功チェック
			return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
		}


		/// <summary>
		/// じぶんの情報を設定
		/// </summary>
		/// <param name="user">じぶんの自己紹介</param>
		/// <returns>成功時trueを返すtask</returns>
		public async Task<OrderResponceSignalAndData<bool>> SetMyConfigAsync(AboutUser user) {
			// オーダー生成
			var order = new Order() {
				// ユーザーのデータ載せる
				OrderData = new SetMyConfig() {
					Config = user
				}
			};

			// 送信
			OrderResponceBase tmp = await SendOrderAsync(order).ConfigureAwait(false);

			// 値を返す
			return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);

		}

		/// <summary>
		/// ロビーと自分の情報を参照する
		/// </summary>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> GetLobbyAndMeAsync() {

			// 更新オーダー作成
			var order = new Order() {
				OrderData = new NonParamOrder() {
					Pattern = OrderPattern.GET_LOBBYS_AND_ME
				}
			};

			// なげる
			OrderResponceBase tmp = await SendOrderAsync(order).ConfigureAwait(false);

			// 成功していれば更新
			if (tmp.IsOk && tmp is GetLobbysAndMeResponce responce) {
				LobbyAndYou = responce.Data;
				return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
			} else {
				// だめだこりゃ
				return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
			}

		}

		/// <summary>
		/// 初期化
		/// 失敗するとDisposeして自爆する
		/// これが動作中の間もコルーチンは動作させ続けてくれ
		/// </summary>
		/// <returns>正常完了時true</returns>
		private async Task<OrderResponceSignalAndData<bool>> TryInitAsync() {
			// オーダー作成
			Order order = new Order();

			// ログインを行うか否か
			bool IsLogin = LoginData != null;


			if (IsLogin) {
				// レッツログイン
				order.OrderData = new LoginOrder(LoginData, Application);


			} else {
				// 新規ユーザー作成
				order.OrderData = new CreateUserOrder() {
					AppId = Application.ApplicationID,
					DevID = Application.DeveloperID
				};
			}

			// オーダー実行
			OrderResponceBase tmp = await SendOrderAsync(order).ConfigureAwait(false);

			// 成功チェック
			if (!tmp.IsOk) {
				((IDisposable)this).Dispose();

				// 状況を特定
				switch (tmp.Responce) {

					// アカウント衝突
					case OrderResponcePattern.FAILED_TARGET_NOT_FOUND:
						State = ClientState.INVALID_ACCOUNT;
						break;

					// アカウント無効化済み
					case OrderResponcePattern.FAILED_FORBIDDEN:
						State = ClientState.LOGIN_COLLISION;
						break;

					// 謎なら鯖とバージョンがずれている可能性がある
					default:
						State = ClientState.IRREGULAR_SERVER_VERSION;
						break;
				}

				return new OrderResponceSignalAndData<bool>(tmp.IsOk, tmp);
			}

			// アカウント生成であれば生成された情報を記録する
			if (!IsLogin) {
				// レッツキャスト
				if (tmp is CreateUserResponce create) {
					// 値を受け取る
					LoginData = create.login;
				} else {
					// なんかおかしいから切る
					((IDisposable)this).Dispose();
					State = ClientState.LOGIN_FAILED;
					return new OrderResponceSignalAndData<bool>(false, tmp);
				}
			}


			// ツリーセーブ読み出し
			await TreeSave.LoadMapAsync().ConfigureAwait(false);

			// ログイン完了
			State = ClientState.LOGIN;

			// root要素がなければ作る
			if (TreeSave.Root == null) {
				TreeSave.Clear();
			}

			// アカウントとロビーの情報を参照する
			return await GetLobbyAndMeAsync().ConfigureAwait(false);

		}



		/// <summary>
		/// ルーム接続
		/// 
		/// ロビーに入っていないと失敗する
		/// ルーム側に何らかの理由で拒否される可能性もある
		/// </summary>
		/// <param name="Target">接続先ルーム</param>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> JoinRoomAsync(RoomInfo Target) {

			// オーダー投げる
			OrderResponceBase resp = await SendOrderAsync(new Order() { OrderData = new JoinRoomOrder() { TargetEntityID = Target.EntityID } }, (e) => {
				// ルームユーザークリア
				RoomUsers.Clear();

				// ルーム設定
				NowRoom = Target;

			}).ConfigureAwait(false);

			// 応答が未知の形式 or 接続失敗であれば失敗
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);


		}

		/// <summary>
		/// ルーム作成
		/// </summary>
		public async Task<OrderResponceSignalAndData<bool>> CreateRoomAsync(CreateRoomOrder RoomData) {
			// オーダー作成
			var order = new Order() {
				OrderData = new CreateRoomOrder(RoomData)
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order, (e) => {
				// ルームを無人に
				RoomUsers.Clear();

				// ルーム情報を設定
				NowRoom = ((CreateRoomResponce)e).info;
			}).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);


		}

		/// <summary>
		/// ルーム脱出
		/// </summary>
		public async Task<OrderResponceSignalAndData<bool>> LeaveRoomAsync() {
			// オーダー作成
			var order = new Order() {
				OrderData = new NonParamOrder() { Pattern = OrderPattern.LEAVE_ROOM }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order, (e) => {
				// ルームを無人に
				RoomUsers.Clear();

				// ルーム情報を設定
				NowRoom = null;
			}).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);


		}

		/// <summary>
		/// ロビー脱出
		/// </summary>
		public async Task<OrderResponceSignalAndData<bool>> LeaveLobbyAsync() {
			// オーダー作成
			var order = new Order() {
				OrderData = new NonParamOrder() { Pattern = OrderPattern.LEAVE_LOBBY }
			};
			
			// 発火
			OrderResponceBase resp = await SendOrderAsync(order, (e) => {
				// ルームを無人に
				RoomUsers.Clear();

				// ルーム情報を設定
				NowRoom = null;
			}).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);
		}

		/// <summary>
		/// セーブ情報参照
		/// </summary>
		/// <param name="TargetUserID">対象のユーザーID</param>
		/// <returns>成否と存在するシーケンス番号の一覧</returns>
		public async Task<OrderResponceSignalAndData<int[]>> SaveInfoAsync(int TargetUserID) {
			// オーダー作成
			var order = new Order() {
				OrderData = new SaveInfoOrder() { Pattern = OrderPattern.SAVE_INFO, TargetUserID = TargetUserID }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<int[]>((resp as SaveInfoResponce)?.Sequences, resp);
		}

		/// <summary>
		/// セーブ情報書き出し
		/// </summary>
		/// <param name="Page">ページ番号</param>
		/// <param name="Data">データ配列(1024kb以上は切り捨て)</param>
		/// <returns>成否</returns>
		public async Task<OrderResponceSignalAndData<bool>> SaveWriteAsync(int Page, byte[] Data) {
			// オーダー作成
			var order = new Order() {
				OrderData = new SaveDataWriteOrder() { Pattern = OrderPattern.SAVE_WRITE, Data = Data?.Take(1024).ToArray(), Page = Page }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);
		}

		/// <summary>
		/// セーブデータ読み出し
		/// </summary>
		/// <param name="UserID">ユーザーID</param>
		/// <param name="Page">ページ番号</param>
		/// <returns></returns>
		public async Task<OrderResponceSignalAndData<byte[]>> SaveReadAsync(int UserID, int Page) {
			// オーダー作成
			var order = new Order() {
				OrderData = new LoadPageOrder() { Pattern = OrderPattern.SAVE_READ, Page = Page, UserID = UserID }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<byte[]>((resp as SaveLoadResponce)?.Data, resp);
		}

		/// <summary>
		/// ツリー記録領域を参照
		/// </summary>
		/// <returns>ツリー情報</returns>
		public async Task<OrderResponceSignalAndData<TreeInfo[]>> ReadTreeAsync() {

			// オーダー作成
			var order = new Order() {
				OrderData = new NonParamOrder() { Pattern = OrderPattern.REQUIRE_TREE }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<TreeInfo[]>((resp as RequireTreeResponce)?.Infos, resp);
		}

		/// <summary>
		/// ツリー記録領域のデータを読み出し
		/// </summary>
		/// <param name="instanceId">対象のインスタンスID</param>
		/// <returns>ツリーのデータ</returns>
		public async Task<OrderResponceSignalAndData<TreeDataInfo>> ReadTreeDataAsync(int instanceId) {

			// オーダー作成
			var order = new Order() {
				OrderData = new RequireTreeData() { Pattern = OrderPattern.REQUIRE_TREE_DATA, IsntanceID = instanceId }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<TreeDataInfo>((resp as RequireTreeDataResponce)?.Data, resp);
		}

		/// <summary>
		/// ツリー記録領域のデータを読み出し
		/// </summary>
		/// <param name="instanceIds">対象のインスタンスID</param>
		/// <returns>ツリーのデータ</returns>
		public async Task<OrderResponceSignalAndData<TreeDataInfo[]>> ReadTreeDatasAsync(params int[] instanceIds) {

			// オーダー作成
			var order = new Order() {
				OrderData = new RequireTreeDatas() { Pattern = OrderPattern.REQUIRE_TREE_DATAS, InstanceIDs = instanceIds }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order);

			// 結果を返す
			return new OrderResponceSignalAndData<TreeDataInfo[]>((resp as RequireTreeDatasResponce)?.Datas, resp);
		}

		/// <summary>
		/// ツリー記録領域を書き出し
		/// </summary>
		/// <returns>ツリー情報</returns>
		public async Task<OrderResponceSignalAndData<bool>> UpdateTreeAsync(TreeInfo[] newTree) {

			// オーダー作成
			var order = new Order() {
				OrderData = new UpdateTreeMap() { Pattern = OrderPattern.UPDATE_TREE, Tree = newTree }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);
		}

		/// <summary>
		/// ツリー記録領域のデータを書き出し
		/// </summary>
		/// <param name="newData">あたらしいデータたち</param>
		/// <returns>成功時True</returns>
		public async Task<OrderResponceSignalAndData<bool>> UpdateTreeDataAsync(TreeDataInfo[] newData) {

			// オーダー作成
			var order = new Order() {
				OrderData = new UpdateTreeData() { Pattern = OrderPattern.UPDATE_TREE_DATA, Datas = newData }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);
		}

		/// <summary>
		/// ロビーの待ち時間を報告
		/// </summary>
		/// <param name="waitTime">待った時間</param>
		/// <returns>成功時true</returns>
		public async Task<OrderResponceSignalAndData<bool>> UploadLobbyWaitTime(TimeSpan waitTime) {

			// オーダー作成
			var order = new Order() {
				OrderData = new UploadLobbyWaitTime() { Pattern = OrderPattern.WAITTIME_UPLOAD_LOBBY, MyWaitTime = waitTime }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<bool>(resp.IsOk, resp);
		}

		/// <summary>
		/// ロビーの平均待ち時間を取得
		/// </summary>
		/// <returns>取得できれば平均待ち時間を返す</returns>
		public async Task<OrderResponceSignalAndData<TimeSpan>> GetLobbyWaitTime() {

			// オーダー作成
			var order = new Order() {
				OrderData = new NonParamOrder() { Pattern = OrderPattern.WAITTIME_GET_LOBBY }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<TimeSpan>((resp as GetLobbyWaitTimeResponce)?.AverageMyWaitTime ?? TimeSpan.Zero, resp);
		}



		/// <summary>
		/// サポートチケット送信
		/// </summary>
		/// <param name="message">送信するメッセージ</param>
		/// <returns>成功時チケットID 失敗時-1</returns>
		public async Task<OrderResponceSignalAndData<int>> CommtiSupportTicketAsync(string message) {

			// オーダー作成
			var order = new Order() {
				OrderData = new CommitSupportOrder() { Pattern = OrderPattern.COMMIT_SUPPORT_TICKET, Message = message }
			};

			// 発火
			OrderResponceBase resp = await SendOrderAsync(order).ConfigureAwait(false);

			// 結果を返す
			return new OrderResponceSignalAndData<int>((resp as CreateSupportTicketResponce)?.TicketID  ?? -1, resp);
		}

	}
}