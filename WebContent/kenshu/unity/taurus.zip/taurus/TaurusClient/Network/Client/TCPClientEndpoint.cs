﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Taurus.Network.Common;
using Taurus.Util;

namespace Taurus.Network.Client {
	/// <summary>
	/// TCP制御用クライアントエンドポイント
	/// </summary>
	public class TCPClientEndpoint : TCPEndPointBase {

		/// <summary>
		/// TCP接続
		/// </summary>
		private TcpClient BaseTCP;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="remote">接続先</param>
		/// <param name="buffer">バッファサイズ</param>
		public TCPClientEndpoint(string remote, int buffer = 4096) : this(remote, Guid.NewGuid(), buffer) { }

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="remote">接続先</param>
		/// <param name="TargetEntityID">対象のエンティティID</param>
		/// <param name="buffer">バッファサイズ</param>
		public TCPClientEndpoint(string remote, Guid TargetEntityID, int buffer = 4096) {
			// 接続先を決定
			var RemoteEP = new DnsEndPoint(remote, Config.Port);

			// TCP接続
			BaseTCP = new TcpClient(remote, Config.Port) {
				ReceiveBufferSize = buffer,
				SendBufferSize = buffer
			};

			// EntityID初期化
			this.TargetEntityID = TargetEntityID;

			// 初期化
			Init(BaseTCP.GetStream(), RemoteEP, false);
		}

		/// <summary>
		/// ハンドシェイク認証
		/// 非同期で実行される
		/// </summary>
		protected override async Task<ClientEndpointState> Handsake(Stream stream) {
			try {

				// ハンドシェイクシグナル出力
				await stream.WriteAsync(Config.HandShakeSignalToServer, Cancel.Token).ConfigureAwait(false);

				// EntiryIDを出力
				await stream.WriteAsync(TargetEntityID.ToByteArray(), Cancel.Token).ConfigureAwait(false);

				// 焼く
				await stream.FlushAsync().ConfigureAwait(false);

				// 応答受信
				return await stream.PatternCheckAsync(Config.HandShakeSignalToClient, Cancel.Token).ConfigureAwait(false) ? ClientEndpointState.CONNECTED : ClientEndpointState.IRREGULAR_SERVER_VERSION;
				
			} catch (Exception e) {
				// ストリームがおかしいかキャンセル食らったら失敗
				if (e.IsTaskIoExcepton()) {
					return ClientEndpointState.HANDSHAKE_FAILED;
				}

				// それ以外は例外伝達
				throw;
			}
		}

		/// <summary>
		/// 解放
		/// </summary>
		protected override void DisposeManageObject() {
			base.DisposeManageObject();
			BaseTCP?.Close();

		}
	}
}
