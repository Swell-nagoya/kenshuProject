﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taurus.Data.Network.OrderResponce;
using Taurus.Network.Common;

namespace Taurus.Network.Client {
	/// <summary>
	/// オーダー結果シグナルと値を投げてくれる
	/// </summary>
	/// <typeparam name="T">戻り値の型</typeparam>
	public struct OrderResponceSignalAndData<T> {

		/// <summary>
		/// 値
		/// </summary>
		public readonly T Value;

		/// <summary>
		/// 返答パターン
		/// </summary>
		public readonly OrderResponcePattern Pattern;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="Value">値</param>
		/// <param name="Pattern">パターン</param>
		public OrderResponceSignalAndData(T Value, OrderResponcePattern Pattern) {
			this.Value = Value;
			this.Pattern = Pattern;
		}

		/// <summary>
		/// コンストラクタ
		/// </summary>
		/// <param name="Value">値</param>
		/// <param name="Responce">オーダー返答情報</param>
		public OrderResponceSignalAndData(T Value, OrderResponceBase Responce) {
			this.Value = Value;
			this.Pattern = Responce?.Responce ?? OrderResponcePattern.UNKNOWN;
		}
		

	}
}
