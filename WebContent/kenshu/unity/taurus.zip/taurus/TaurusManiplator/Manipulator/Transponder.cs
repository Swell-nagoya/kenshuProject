﻿using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;

namespace Taurus.Manipulator {
	/// <summary>
	/// 通信制御
	/// </summary>
	public static class Transponder {


		/// <summary>
		/// 通信チャンネル名
		/// </summary>
		const string IpcChannelName = "Taurus2Transponder";
		
		/// <summary>
		/// 制御用URL
		/// </summary>
		const string IcpUri = "ipc://" + IpcChannelName + "/" + nameof(ControlObject);

		/// <summary>
		/// 通信用クラスのインスタンス
		/// </summary>
		public static ControlObject RemoteInstance { get; private set; }


		/// <summary>
		/// 送信開始
		/// ホストになる
		/// </summary>
		public static void StartTransmit() {

			// チャンネル生成
			var IpcChannel = new IpcServerChannel(IpcChannelName);

			// チャンネル登録
			ChannelServices.RegisterChannel(IpcChannel, false);

			// 通信用のリモートオブジェクト作る
			RemoteInstance = new ControlObject();

			// 作った奴を公開
			RemotingServices.Marshal(RemoteInstance, nameof(ControlObject));
		}

		/// <summary>
		/// 受信を開始する
		/// </summary>
		public static void StartReceive() {

			// チャンネル生成
			var IpcChannel = new IpcClientChannel();

			// チャンネル登録
			ChannelServices.RegisterChannel(IpcChannel, false);

			// 通信用のリモートオブジェクトを受け取る
			RemoteInstance = (ControlObject)Activator.GetObject(typeof(ControlObject), $"ipc://{IpcChannelName}/{ nameof(ControlObject)}");
		}


	}

}
