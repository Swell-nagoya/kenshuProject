﻿using System;

namespace Taurus.Manipulator {
	/// <summary>
	/// 公開するオブジェクト
	/// </summary>
	public class ControlObject : MarshalByRefObject {

		/// <summary>
		/// 停止要求
		/// </summary>
		public bool StopRequire { get; set; } = false;

		/// <summary>
		/// プロセスID
		/// </summary>
		public int ProcessID { get; set; }

		/// <summary>
		/// 動作しているか否か
		/// </summary>
		public bool IsRunning { get; set; } = false;

		/// <summary>
		/// ロビー数
		/// </summary>
		public int LobbyCount { get; set; }

		/// <summary>
		/// ルーム数
		/// </summary>
		public int RoomCount { get; set; }

		/// <summary>
		/// ユーザー数
		/// </summary>
		public int UserCount { get; set; }

		/// <summary>
		/// ロビーを再読み込み要求
		/// </summary>
		public bool RequireReloadLobby { get; set; } = false;

		/// <summary>
		/// SQLログを吐き散らすか否か
		/// </summary>
		public bool IsSqlLogExport { get; set; } =

#if DEBUG
		true;
#else
		false;
#endif



		/// <summary>
		/// 自動的に切断されるのを回避する
		/// </summary>
		public override object InitializeLifetimeService() {
			return null;
		}
	}

}
