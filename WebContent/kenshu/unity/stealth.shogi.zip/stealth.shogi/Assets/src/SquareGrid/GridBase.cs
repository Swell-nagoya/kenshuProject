﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace SquareGrid {

	/// <summary>
	/// 四角いグリッドの制御クラス
	/// </summary>

	public class GridBase<T> : IEnumerable<GridCell<T>> {

		/// <summary>
		/// X座標の次元数
		/// </summary>
		private const int dimX = 0;

		/// <summary>
		/// Y座標の次元数
		/// </summary>
		private const int dimY = 1;

		/// <summary>
		/// グリッド置き場
		/// </summary>
		private GridCell<T>[,] grid;

		/// <summary>
		/// トーラスフラグ
		/// </summary>
		private bool torus;


		/// <summary>
		/// 要素にアクセスするインデクサー
		/// </summary>
		/// <param name="x">x座標</param>
		/// <param name="y">y座標</param>
		/// <returns>その座標のセル or null</returns>
		public GridCell<T> this[int x, int y] { get { return GetPos(new Pos(x, y)); } }

		public GridCell<T> GetPos(Pos pos) {
			// 縦幅と横幅を算出
			int width = grid.GetLength(dimX);
			int height = grid.GetLength(dimY);

			if (torus) {
				// トーラス形状であれば座標の折り返しを考慮して返す
				return grid[
					(pos.x + width) % width,
						(pos.y + height) % height
					];
			} else {
				// 範囲外はnull
				if (pos.x < 0 || pos.y < 0 || pos.x >= width || pos.y >= height) {
					return null;
				}

				// 範囲内だった
				return grid[pos.x, pos.y];

			}
		}

		/// <summary>
		/// フィールドサイズを指定して初期化
		/// 通常は左上が座標0で平面型の形状
		/// </summary>
		/// <param name="width">横幅</param>
		/// <param name="heigh">縦幅</param>
		/// <param name="reverseX">X座標反転</param>
		/// <param name="reverseY">Y座標反転</param>
		/// <param name="isTorus">トーラスか否か</param>
		public GridBase(int width, int heigh, bool reverseX, bool reverseY, bool isTorus) {
			// 初期化
			Init(width, heigh, reverseX, reverseY, isTorus);
		}

		/// <summary>
		/// フィールドサイズを指定して初期化
		/// 通常は左上が座標0で平面型の形状
		/// </summary>
		/// <param name="width">横幅</param>
		/// <param name="heigh">縦幅</param>
		public GridBase(int width, int height) {
			Init(width, height, false, false, false);
		}

		/// <summary>
		/// フィールドサイズを指定して初期化
		/// 通常は左上が座標0で平面型の形状
		/// </summary>
		/// <param name="width">横幅</param>
		/// <param name="heigh">縦幅</param>
		/// <param name="reverseX">X座標反転</param>
		/// <param name="reverseY">Y座標反転</param>
		public GridBase(int width, int height, bool reverseX, bool reverseY) {
			Init(width, height, reverseX, reverseY, false);
		}

		/// <summary>
		/// グリッド初期化
		/// 通常は左上が0地点になり右下が+になる
		/// </summary>
		/// <param name="width">横幅</param>
		/// <param name="height">縦幅</param>
		/// <param name="reverseX">X軸を反転(右側を0)</param>
		/// <param name="reverseY">Y軸を反転(下が0)</param>
		/// <param name="torus">トーラス化するか否か</param>
		private void Init(int width, int height, bool reverseX, bool reverseY, bool torus) {
			int x, y;

			// 領域を確保
			grid = new GridCell<T>[width, height];

			// トーラスフラグセット
			this.torus = torus;

			// 生成ループ
			for (x = 0; x < width; x++) {
				for (y = 0; y < height; y++) {
					grid[x, y] = new GridCell<T>(new Pos(x, y));
				}
			}

			// セル相互リンクループ
			for (x = 0; x < width; x++) {
				for (y = 0; y < height; y++) {
					// 現在地点
					Pos nowPos = new Pos(x, y);
					GridCell<T> nowCell = GetPos(nowPos);

					// 一応nullチェック
					if (nowCell == null) { continue; }

					// 全ての方角に対して処理
					foreach (EDirection dir in System.Enum.GetValues(typeof(EDirection))) {
						// 座標演算して読み出した座標をそのまま記録
						nowCell.SetDirection(dir, GetPos(nowPos + DirectionPos(dir, reverseX, reverseX)));
					}
				}
			}
		}


		/// <summary>
		/// 方角に対応する単位量の座標を返す
		/// </summary>
		/// <param name="dir">方角</param>
		/// <param name="reverseX">X座標反転</param>
		/// <param name="reverseY">Y座標反転</param>
		/// <returns>指定方角に単位量ずれた座標</returns>
		private Pos DirectionPos(EDirection dir, bool reverseX, bool reverseY) {
			// 反転用の座標を生成
			Pos reverse = new Pos(reverseX ? -1 : 1, reverseY ? -1 : 1);

			// 返却用座標置き場
			Pos ret;

			// 方角に応じた値を出す
			switch (dir) {
				default: ret = new Pos(0, 0); break; // 原点

				case EDirection.N: ret = new Pos(0, 1); break; // 北
				case EDirection.E: ret = new Pos(1, 0); break; // 東
				case EDirection.S: ret = new Pos(0, -1); break; // 南
				case EDirection.W: ret = new Pos(-1, 0); break; // 西
				case EDirection.NE: ret = new Pos(1, 1); break; // 北東
				case EDirection.NW: ret = new Pos(-1, 1); break; // 北西
				case EDirection.SE: ret = new Pos(1, -1); break; // 南東
				case EDirection.SW: ret = new Pos(-1, -1); break; // 南西
			}

			// 反転考慮して返す
			return ret * reverse;
		}

		/// <summary>
		/// セル全てを処理するイテレータ
		/// </summary>
		/// <returns>イテレータ</returns>
		public IEnumerator<GridCell<T>> GetEnumerator() {
			foreach (GridCell<T> cell in grid) {
				yield return cell;
			}

			yield break;
		}

		/// <summary>
		/// セル全てを処理するイテレータ
		/// </summary>
		/// <returns>イテレータ</returns>
		IEnumerator IEnumerable.GetEnumerator() {
			return grid.GetEnumerator();
		}
	}


}