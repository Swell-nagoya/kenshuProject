﻿namespace SquareGrid {
    /// <summary>
    /// 方角列挙用
    /// </summary>
    public enum EDirection {
        N,
        NE,
        E,
        SE,
        S,
        SW,
        W,
        NW
    }
}