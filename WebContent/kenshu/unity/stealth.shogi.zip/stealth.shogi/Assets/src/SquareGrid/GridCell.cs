﻿using System.Collections.Generic;

namespace SquareGrid {

	/// <summary>
	/// 四角いグリッドのセル
	/// </summary>
	public class GridCell<T> {

		/// <summary>
		/// 値
		/// </summary>
		public T value { get; set; }

		/// <summary>
		/// 座標
		/// </summary>
		public Pos position { get; private set; }

		/// <summary>
		/// 座標を指定して初期化
		/// </summary>
		public GridCell(Pos pos){
			position = pos;
		}

		/// <summary>
		/// 周囲の方位と親の記録
		/// </summary>
		/// <param name="field">存在しているフィールド</param>
		/// <param name="N">北のセル</param>
		/// <param name="NE">北東のセル</param>
		/// <param name="E">東のセル</param>
		/// <param name="SE">東南のセル</param>
		/// <param name="S">南のセル</param>
		/// <param name="SW">南西のセル</param>
		/// <param name="W">西のセル</param>
		/// <param name="NW">北西のセル</param>
		public void setLinkCellAndFeld(
			GridBase<T> field,
			GridCell<T> N,
			GridCell<T> NE,
			GridCell<T> E,
			GridCell<T> SE,
			GridCell<T> S,
			GridCell<T> SW,
			GridCell<T> W,
			GridCell<T> NW
			) {

			// 値をセット
			this.field = field;
			this.N = N;
			this.NE = NE;
			this.E = E;
			this.SE = SE;
			this.S = S;
			this.SW = SW;
			this.W = W;
			this.NW = NW;
		}


		/// <summary>
		/// 将棋のフィールド
		/// </summary>
		public GridBase<T> field { private set; get; }

		/// <summary>
		/// 北
		/// </summary>
		public GridCell<T> N { private set; get; }

		/// <summary>
		/// 北東
		/// </summary>
		public GridCell<T> NE { private set; get; }

		/// <summary>
		/// 東
		/// </summary>
		public GridCell<T> E { private set; get; }

		/// <summary>
		/// 南東
		/// </summary>
		public GridCell<T> SE { private set; get; }

		/// <summary>
		/// 南
		/// </summary>
		public GridCell<T> S { private set; get; }

		/// <summary>
		/// 南西
		/// </summary>
		public GridCell<T> SW { private set; get; }

		/// <summary>
		/// 西
		/// </summary>
		public GridCell<T> W { private set; get; }

		/// <summary>
		/// 北西
		/// </summary>
		public GridCell<T> NW { private set; get; }

		/// <summary>
		/// 北方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterN { get { return new IGridDirectionEmurable<T>(this, EDirection.N); } }

		/// <summary>
		/// 東方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterE { get { return new IGridDirectionEmurable<T>(this, EDirection.E); } }

		/// <summary>
		/// 南方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterS { get { return new IGridDirectionEmurable<T>(this, EDirection.S); } }

		/// <summary>
		/// 西方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterW { get { return new IGridDirectionEmurable<T>(this, EDirection.W); } }

		/// <summary>
		/// 北東方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterNE { get { return new IGridDirectionEmurable<T>(this, EDirection.NE); } }

		/// <summary>
		/// 北西方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterNW { get { return new IGridDirectionEmurable<T>(this, EDirection.NW); } }

		/// <summary>
		/// 南東方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterSE { get { return new IGridDirectionEmurable<T>(this, EDirection.SE); } }

		/// <summary>
		/// 南西方向へ連続処理するイテレータ
		/// </summary>
		public IEnumerable<GridCell<T>> IterWW { get { return new IGridDirectionEmurable<T>(this, EDirection.SW); } }


		/// <summary>
		/// 方角を指定して参照
		/// </summary>
		/// <param name="direction">取りたい方向 or null</param>
		/// <returns>将棋セル or null</returns>
		public GridCell<T> GetDirection(EDirection direction) {
			switch (direction) {
				default: return null;
				case EDirection.N: return N;
				case EDirection.NE: return NE;
				case EDirection.E: return E;
				case EDirection.SE: return SE;
				case EDirection.S: return S;
				case EDirection.SW: return SW;
				case EDirection.W: return W;
				case EDirection.NW: return NW;
			}
		}



		/// <summary>
		/// 方角を指定して記録
		/// </summary>
		/// <param name="direction">取りたい方向 or null</param>
		/// <returns>将棋セル or null</returns>
		public void SetDirection(EDirection direction, GridCell<T> cell) {
			switch (direction) {
				case EDirection.N: N = cell; break;
				case EDirection.NE: NE = cell; break;
				case EDirection.E: E = cell; break;
				case EDirection.SE: SE = cell; break;
				case EDirection.S: S = cell; break;
				case EDirection.SW: SW = cell; break;
				case EDirection.W: W = cell; break;
				case EDirection.NW: NW = cell; break;
			}
		}


	}

}