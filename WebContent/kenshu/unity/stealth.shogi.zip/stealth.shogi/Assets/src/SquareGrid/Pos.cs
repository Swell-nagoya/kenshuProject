﻿namespace SquareGrid {
	public struct Pos {
		/// <summary>
		/// X座標
		/// </summary>
		public int x { set; get; }

		/// <summary>
		/// Y座標
		/// </summary>
		public int y { set; get; }

		/// <summary>
		/// 座標を指定して初期化
		/// </summary>
		public Pos(int x, int y) {
			this.x = x;
			this.y = y;
		}

		/// <summary>
		/// 座標を複製して初期化
		/// </summary>
		/// <param name="other"></param>
		public Pos(Pos other) {
			x = other.x;
			y = other.y;
		}

		/// <summary>
		/// 座標を減算
		/// </summary>
		/// <param name="p1">減算される座標</param>
		/// <param name="p2">減算する座標</param>
		/// <returns>減算した座標(p1 - p2)</returns>
		public static Pos operator -(Pos p1, Pos p2) {
			return new Pos(p1.x - p2.x, p1.y - p2.y);
		}

		/// <summary>
		/// 座標を加算
		/// </summary>
		/// <param name="p1">加算される座標</param>
		/// <param name="p2">加算する座標</param>
		/// <returns>加算した座標(p1 + p2)</returns>
		public static Pos operator +(Pos p1, Pos p2) {
			return new Pos(p1.x + p2.x, p1.y + p2.y);
		}

		/// <summary>
		/// 座標を乗算
		/// </summary>
		/// <param name="p1">乗算される座標</param>
		/// <param name="p2">乗算する座標</param>
		/// <returns>乗算した座標(p1 * p2)</returns>
		public static Pos operator *(Pos p1, Pos p2) {
			return new Pos(p1.x * p2.x, p1.y * p2.y);
		}
	}
}