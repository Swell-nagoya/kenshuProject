﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace SquareGrid {

    public class IGridDirectionEmurable<T> : IEnumerable<GridCell<T>> {

		/// <summary>
		/// ループ対象の方角
		/// </summary>
		private EDirection dir;

		/// <summary>
		/// セル開始地点
		/// </summary>
		private GridCell<T> start;

		/// <summary>
		/// 処理を行う方角を指定して初期化
		/// </summary>
		/// <param name="dir">処理する方向</param>
		/// <param name="start">開始地点</param>
		public IGridDirectionEmurable(GridCell<T> start, EDirection dir) {
			this.dir = dir;
			this.start = start;
		}

		/// <summary>
		/// 初期化時に選択した方向で処理する反復子
		/// </summary>
		/// <returns>イテレータ</returns>
		public IEnumerator<GridCell<T>> GetEnumerator() {
			GridCell<T> tmp = start;
			while (true) {
				// 値読み出し
				tmp = start.GetDirection(dir);

				
				if(tmp != null) {
					// null でなければ返す
					yield return tmp;
				} else {
					// nullなら終了
					yield break;
				}
			}
        }

		/// <summary>
		/// 初期化時に選択した方向で処理する反復子
		/// </summary>
		/// <returns>イテレータ</returns>
		IEnumerator IEnumerable.GetEnumerator() {
            return GetEnumerator();
        }
    }

}