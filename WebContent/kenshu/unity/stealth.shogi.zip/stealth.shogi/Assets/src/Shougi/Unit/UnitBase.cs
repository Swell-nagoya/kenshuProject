﻿using System.Collections.Generic;
using SquareGrid;
using System.Linq;

namespace Shougi.Unit {

	/// <summary>
	/// 将棋の駒のスーパークラス
	/// </summary>
	public abstract class UnitBase {

		/// <summary>
		/// 変形可能か否か
		/// </summary>
		/// <returns>可能であればtrue</returns>
		public abstract bool IsReverse { get; }

		/// <summary>
		/// 所属参照
		/// </summary>
		public Core.EBelong Aff { get; set; }

		/// <summary>
		/// 移動可能なセル参照
		/// </summary>
		/// <returns>移動可能なセル全て</returns>
		public abstract IEnumerable<GridCell<UnitBase>> CanMovePos();

		/// <summary>
		/// 自分のセル
		/// </summary>
		public GridCell<UnitBase> cell { get; set; }

		/// <summary>
		/// 自分のセルを指定して初期化
		/// </summary>
		public UnitBase(GridCell<UnitBase> cell) {
			
		}

		/// <summary>
		/// グリッド上に設置
		/// </summary>
		/// <param name="cell">設置するセル</param>
		public void Put(GridCell<UnitBase> cell) {
			this.cell = cell;
			cell.value = this;
		}

		/// <summary>
		/// グリッド上から撤去
		/// </summary>
		public void Remove() {
			cell = null;
			cell.value = null;
		}

		public bool MoveCell(GridCell<UnitBase> moveto) {
			// 移動可能なセルに移動先が含まれているか確認
			if(CanMovePos().Where(e=>e == moveto).Count() > 0) {
				// 取って置く
				Remove();
				Put(moveto);
				return true;
			}

			// 移動先に選べない
			return false;


		}

	}

}