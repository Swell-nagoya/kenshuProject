﻿namespace Shougi.Core {
	/// <summary>
	/// 所属識別用
	/// </summary>
	public enum EBelong {
		NONE,			// 未定・不定・不明など
		PLAYER_1,		// 一人目のプレイヤー
		PLAYER_2		// 二人目のプレイヤー
	}
}