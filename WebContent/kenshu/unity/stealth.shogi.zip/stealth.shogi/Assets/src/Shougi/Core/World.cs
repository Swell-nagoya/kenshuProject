﻿using Shougi.Unit;

namespace Shougi.Core {
	/// <summary>
	/// 将棋板クラス
	/// </summary>
	public class Board {
		/// <summary>
		/// 将棋版横幅
		/// </summary>
		const int BOARD_WIDTH = 9;

		/// <summary>
		/// 将棋版縦幅
		/// </summary>
		const int BOARD_HEIGHT = 9;


		/// <summary>
		/// 将棋グリッド
		/// </summary>
		private SquareGrid.GridBase<IUnitBase> grid;

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public Board() {
			// 右上が0地点の将棋の駒を置くためのグリッド生成
			grid = new SquareGrid.GridBase<IUnitBase>(BOARD_WIDTH, BOARD_HEIGHT, true, false);
		}

	}
}