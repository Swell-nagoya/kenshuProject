package Validate;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import util.Message;
import util.StringUtil;
import bean.CLS907_SearchResutlBean;
import bean.CLS908_InsertBean;

/**
 * 点数及び偏差値の入力チェックを行うクラス。
 *
 * @author kume
 *
 */
public class CLS908Validate {

	/**
	 * 点数及び偏差値の入力チェックを行う。
	 * @param request リクエスト
	 * @param insertBean 登録情報Bean
	 * @param sessionBean 作業対象の成績セッションBean
	 * @return
	 */
	public static List<String> validate(HttpServletRequest request,
			CLS908_InsertBean insertBean,
			CLS907_SearchResutlBean sessionBean) {

		List<String> list = new ArrayList<>();

		// 国語点数の半角数値チェック
		if (!StringUtil.isSingleByteNumeric(insertBean.getMarks_jap())) {
			list.add(Message.getMessage("marks_jap.invalid"));
			insertBean.setMarks_jap("");
			insertBean.setMessage(list);

			if (sessionBean.getMarks_jap() != null) {
				sessionBean.setMarks_jap(null);
			}

		} else {
			// 点数の範囲チェック
			if (!StringUtil.isInRange(insertBean.getMarks_jap())) {
				list.add(Message.getMessage("marks_jap.range.invalid"));
				insertBean.setMarks_jap("");
				insertBean.setMessage(list);

				if (sessionBean.getMarks_jap() != null) {
					sessionBean.setMarks_jap(null);
				}

			}

			if (request.getParameter("repear") != null) {
				sessionBean.setMarks_jap(null);
			}
		}

		// 数学点数の半角数値チェック
		if (!StringUtil.isSingleByteNumeric(insertBean.getMarks_math())) {
			list.add(Message.getMessage("marks_math.invalid"));
			insertBean.setMarks_math("");
			insertBean.setMessage(list);

			if (sessionBean.getMarks_math() != null) {
				sessionBean.setMarks_math(null);
			}

		} else {
			// 点数の範囲チェック
			if (!StringUtil.isInRange(insertBean.getMarks_math())) {
				list.add(Message.getMessage("marks_math.range.invalid"));
				insertBean.setMarks_math("");
				insertBean.setMessage(list);

				if (sessionBean.getMarks_math() != null) {
					sessionBean.setMarks_math(null);
				}

			}
			if (request.getParameter("repear") != null) {
				sessionBean.setMarks_math(null);
			}
		}

		// 理科点数の半角数値チェック
		if (!StringUtil.isSingleByteNumeric(insertBean.getMarks_siec())) {
			list.add(Message.getMessage("marks_siec.invalid"));
			insertBean.setMarks_siec("");
			insertBean.setMessage(list);

			if (sessionBean.getMarks_siec() != null) {
				sessionBean.setMarks_siec(null);
			}

		} else {
			// 点数の範囲チェック
			if (!StringUtil.isInRange(insertBean.getMarks_siec())) {
				list.add(Message.getMessage("marks_siec.range.invalid"));
				insertBean.setMarks_siec("");
				insertBean.setMessage(list);

				if (sessionBean.getMarks_siec() != null) {
					sessionBean.setMarks_siec(null);
				}

			}
			if (request.getParameter("repear") != null) {
				sessionBean.setMarks_siec(null);
			}
		}

		// 社会点数の半角数値チェック
		if (!StringUtil.isSingleByteNumeric(insertBean.getMarks_scty())) {
			list.add(Message.getMessage("marks_scty.invalid"));
			insertBean.setMarks_scty("");
			insertBean.setMessage(list);

			if (sessionBean.getMarks_scty() != null) {
				sessionBean.setMarks_scty(null);
			}

		} else {
			// 点数の範囲チェック
			if (!StringUtil.isInRange(insertBean.getMarks_scty())) {
				list.add(Message.getMessage("marks_scty.range.invalid"));
				insertBean.setMarks_scty("");
				insertBean.setMessage(list);

				if (sessionBean.getMarks_scty() != null) {
					sessionBean.setMarks_scty(null);
				}

			}
			if (request.getParameter("repear") != null) {
				sessionBean.setMarks_scty(null);
			}
		}

		// 英語点数の半角数値チェック
		if (!StringUtil.isSingleByteNumeric(insertBean.getMarks_eng())) {
			list.add(Message.getMessage("marks_eng.invalid"));
			insertBean.setMarks_eng("");
			insertBean.setMessage(list);

			if (sessionBean.getMarks_eng() != null) {
				sessionBean.setMarks_eng(null);
			}

		} else {
			// 点数の範囲チェック
			if (!StringUtil.isInRange(insertBean.getMarks_eng())) {
				list.add(Message.getMessage("marks_eng.range.invalid"));
				insertBean.setMarks_eng("");
				insertBean.setMessage(list);

				if (sessionBean.getMarks_eng() != null) {
					sessionBean.setMarks_eng(null);
				}

			}
			if (request.getParameter("repear") != null) {
				sessionBean.setMarks_eng(null);
			}
		}

		// 国語偏差値の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getDeviation_jap())) {
			list.add(Message.getMessage("deviation_jap.invalid"));
			insertBean.setDeviation_jap("");
			insertBean.setMessage(list);

			if (sessionBean.getDeviation_jap() != null) {
				sessionBean.setDeviation_jap(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setDeviation_jap(null);
			}
		}

		// 数学偏差値の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getDeviation_math())) {
			list.add(Message.getMessage("deviation_math.invalid"));
			insertBean.setDeviation_math("");
			insertBean.setMessage(list);

			if (sessionBean.getDeviation_math() != null) {
				sessionBean.setDeviation_math(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setDeviation_math(null);
			}
		}

		// 理科偏差値の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getDeviation_siec())) {
			list.add(Message.getMessage("deviation_siec.invalid"));
			insertBean.setDeviation_siec("");
			insertBean.setMessage(list);

			if (sessionBean.getDeviation_siec() != null) {
				sessionBean.setDeviation_siec(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setDeviation_siec(null);
			}
		}

		// 社会偏差値の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getDeviation_scty())) {
			list.add(Message.getMessage("deviation_scty.invalid"));
			insertBean.setDeviation_scty("");
			insertBean.setMessage(list);

			if (sessionBean.getDeviation_scty() != null) {
				sessionBean.setDeviation_scty(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setDeviation_scty(null);
			}
		}

		// 英語偏差値の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getDeviation_eng())) {
			list.add(Message.getMessage("deviation_eng.invalid"));
			insertBean.setDeviation_eng("");
			insertBean.setMessage(list);

			if (sessionBean.getDeviation_eng() != null) {
				sessionBean.setDeviation_eng(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setDeviation_eng(null);
			}
		}

		// 5教科偏差値の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getDeviation_five())) {
			list.add(Message.getMessage("deviation_five.invalid"));
			insertBean.setDeviation_five("");
			insertBean.setMessage(list);

			if (sessionBean.getDeviation_five() != null) {
				sessionBean.setDeviation_eng(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setDeviation_five(null);
			}
		}
		return list;
	}
}
