package bean;

public class CLS003Bean {

		Mst001_UserMstBean mst001_UserMstBean = null;
		Mst002_StudentMstBean mst002_StudentMstBean = null;
		Mst003_GuardianMstBean mst003_GuardianMstBean = null;
		Trn011_CrammertestTrnBean trn011_CrammertestTrnBean = null;
		Trn012_OtherstestTrnBean trn012_OthertestTrnBean = null;
		Trn013_HokushinTrnBean trn013_HokushinTrnBean = null;
		Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = null;
		Trn015_TestTrnBean Trn015_TestTrnBean = null;
		int Count = 0;

		/**
		 * mst001_UserMstBeanを取得します。
		 * @return mst001_UserMstBean
		 */
		public Mst001_UserMstBean getMst001_UserMstBean() {
		    return mst001_UserMstBean;
		}
		/**
		 * mst001_UserMstBeanを設定します。
		 * @param mst001_UserMstBean mst001_UserMstBean
		 */
		public void setMst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
		    this.mst001_UserMstBean = mst001_UserMstBean;
		}
		/**
		 * mst002_StudentMstBeanを取得します。
		 * @return mst002_StudentMstBean
		 */
		public Mst002_StudentMstBean getMst002_StudentMstBean() {
		    return mst002_StudentMstBean;
		}
		/**
		 * mst002_StudentMstBeanを設定します。
		 * @param mst002_StudentMstBean mst002_StudentMstBean
		 */
		public void setMst002_StudentMstBean(Mst002_StudentMstBean mst002_StudentMstBean) {
		    this.mst002_StudentMstBean = mst002_StudentMstBean;
		}
		/**
		 * mst003_GuardianMstBeanを取得します。
		 * @return mst003_GuardianMstBean
		 */
		public Mst003_GuardianMstBean getMst003_GuardianMstBean() {
		    return mst003_GuardianMstBean;
		}
		/**
		 * mst003_GuardianMstBeanを設定します。
		 * @param mst003_GuardianMstBean mst003_GuardianMstBean
		 */
		public void setMst003_GuardianMstBean(Mst003_GuardianMstBean mst003_GuardianMstBean) {
		    this.mst003_GuardianMstBean = mst003_GuardianMstBean;
		}
		/**
		 * trn011_CrammertestTrnBeanを取得します。
		 * @return trn011_CrammertestTrnBean
		 */
		public Trn011_CrammertestTrnBean getTrn011_CrammertestTrnBean() {
		    return trn011_CrammertestTrnBean;
		}
		/**
		 * trn011_CrammertestTrnBeanを設定します。
		 * @param trn011_CrammertestTrnBean trn011_CrammertestTrnBean
		 */
		public void setTrn011_CrammertestTrnBean(Trn011_CrammertestTrnBean trn011_CrammertestTrnBean) {
		    this.trn011_CrammertestTrnBean = trn011_CrammertestTrnBean;
		}
		/**
		 * trn012_OthertestTrnBeanを取得します。
		 * @return trn012_OthertestTrnBean
		 */
		public Trn012_OtherstestTrnBean getTrn012_OthertestTrnBean() {
		    return trn012_OthertestTrnBean;
		}
		/**
		 * trn012_OthertestTrnBeanを設定します。
		 * @param trn012_OthertestTrnBean trn012_OthertestTrnBean
		 */
		public void setTrn012_OtherstestTrnBean(Trn012_OtherstestTrnBean trn012_OthertestTrnBean) {
		    this.trn012_OthertestTrnBean = trn012_OthertestTrnBean;
		}
		/**
		 * trn013_HokushinTrnBeanを取得します。
		 * @return trn013_HokushinTrnBean
		 */
		public Trn013_HokushinTrnBean getTrn013_HokushinTrnBean() {
		    return trn013_HokushinTrnBean;
		}
		/**
		 * trn013_HokushinTrnBeanを設定します。
		 * @param trn013_HokushinTrnBean trn013_HokushinTrnBean
		 */
		public void setTrn013_HokushinTrnBean(Trn013_HokushinTrnBean trn013_HokushinTrnBean) {
		    this.trn013_HokushinTrnBean = trn013_HokushinTrnBean;
		}
		/**
		 * trn014_ConfidentialTrnBeanを取得します。
		 * @return trn014_ConfidentialTrnBean
		 */
		public Trn014_ConfidentialTrnBean getTrn014_ConfidentialTrnBean() {
		    return trn014_ConfidentialTrnBean;
		}
		/**
		 * trn014_ConfidentialTrnBeanを設定します。
		 * @param trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean
		 */
		public void setTrn014_ConfidentialTrnBean(Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean) {
		    this.trn014_ConfidentialTrnBean = trn014_ConfidentialTrnBean;
		}
		/**
		 * Trn015_TestTrnBeanを取得します。
		 * @return Trn015_TestTrnBean
		 */
		public Trn015_TestTrnBean getTrn015_TestTrnBean() {
		    return Trn015_TestTrnBean;
		}
		/**
		 * Trn015_TestTrnBeanを設定します。
		 * @param Trn015_TestTrnBean Trn015_TestTrnBean
		 */
		public void setTrn015_TestTrnBean(Trn015_TestTrnBean Trn015_TestTrnBean) {
		    this.Trn015_TestTrnBean = Trn015_TestTrnBean;
		}
		/**
		 * Countを取得します。
		 * @return Count
		 */
		public int getCount() {
		    return Count;
		}
		/**
		 * Countを設定します。
		 * @param Count Count
		 */
		public void setCount(int Count) {
		    this.Count = Count;
		}


}
