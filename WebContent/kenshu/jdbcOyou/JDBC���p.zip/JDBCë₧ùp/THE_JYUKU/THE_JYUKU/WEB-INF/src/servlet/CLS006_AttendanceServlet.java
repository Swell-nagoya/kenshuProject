package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.CLS006DAO;
import Dao.ConnectionManager;
import bean.CLS006Bean;
import bean.Mst001_UserMstBean;


/**
 * 更新はこのサーブレットで行う
 * @author hasumi
 *
 */
public class CLS006_AttendanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		//過去に取得したパラメータを削除
		request.removeAttribute("cls006");

		session.removeAttribute("alart");

		//beanの取得
		CLS006Bean cls006 = new CLS006Bean();

		//Daoの取得
		CLS006DAO cls006dao = new CLS006DAO();

		//取得予定のリスト
		List<CLS006Bean> list = new ArrayList<CLS006Bean>();

		//フォームの取得
		Mst001_UserMstBean mst001_login = (Mst001_UserMstBean)session.getAttribute("loginSession");
		int permission = mst001_login.getPermission();

		String userID = mst001_login.getId_user();
		String selectDate = null;
		String selectYear = request.getParameter("YEAR");
		String selectMonth = request.getParameter("MONTH");

		System.out.println(userID);

		ConnectionManager.beginTransaction();

		if(request.getParameter("menu") == null){
			selectYear = request.getParameter("YEAR");
			selectMonth = request.getParameter("MONTH");
			selectDate = selectYear + "/" + selectMonth;
		}else{

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
			SimpleDateFormat sdf2 = new SimpleDateFormat("MM");
			Date today = new Date();
			selectYear = sdf.format(today);
			selectMonth = sdf2.format(today);
			selectDate = selectYear + "/" + sdf2.format(today);
		}
		list = cls006dao.search(cls006,userID,selectDate,permission);

		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("キチンとここまで処理できましたよ！！やったね！！");

		session.setAttribute("cls006", list);
		request.setAttribute("YEAR",selectYear);
		request.setAttribute("MONTH",selectMonth);
		request.getRequestDispatcher("JSP/topmenu/menu/CLS006_Attendance.jsp").forward(request, response);




	}
}

