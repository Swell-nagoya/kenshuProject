package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.ConnectionManager;
import Dao.Mst001_UserMstDAO;
import bean.Mst001_UserMstBean;


/**
 * 更新はこのサーブレットで行う
 *
 * @author hasumi
 *
 */
public class CLS007_UpdateInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		session.removeAttribute("alart");

		session.getAttribute("loginSession");
		//フォームの取得
		Mst001_UserMstBean mst001_UserMst = new Mst001_UserMstBean();

		//アラート表示用のストリング
		//String alart;

		Mst001_UserMstDAO userCustomdao = new Mst001_UserMstDAO();

		ConnectionManager.beginTransaction();

		try {
			ConnectionManager.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		Mst001_UserMstBean Mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");
		String userID = Mst001_UserMstBean.getId_user();
		System.out.println(userID);
		mst001_UserMst.setId_user(userID);
		mst001_UserMst.setName(Mst001_UserMstBean.getName());
		mst001_UserMst.setBirthday(Mst001_UserMstBean.getBirthday());
		mst001_UserMst.setKana_name(Mst001_UserMstBean.getKana_name());
		mst001_UserMst.setSex(Mst001_UserMstBean.getSex());
		mst001_UserMst.setNickname(Mst001_UserMstBean.getNickname());
		mst001_UserMst.setPhone(Mst001_UserMstBean.getPhone());
		mst001_UserMst.setPermission(Mst001_UserMstBean.getPermission());
		mst001_UserMst.setId_lastupdate(Mst001_UserMstBean.getId_lastupdate());
		mst001_UserMst.setDate_lastupdate(Mst001_UserMstBean.getDate_lastupdate());

		mst001_UserMst.setPass(request.getParameter("NEWPASSWORD"));
		mst001_UserMst.setNickname(request.getParameter("NICKNAME"));
		mst001_UserMst.setMail(request.getParameter("MAIL_ADDRESS"));

		//ミリ秒での現在時刻の取得
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		mst001_UserMst.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));
		System.out.println(timestamp.toString());
		Mst001_UserMstDAO userdao = new Mst001_UserMstDAO();
		//hiddenで取得
		mst001_UserMst.setId_lastupdate(request.getParameter("id_lastupdate"));

		// 入力チェック
		String alart;
		ValidateServlet Validate = new ValidateServlet();
		// 現パスワードが一致していれば入力チェックを行う。
		if (Mst001_UserMstBean.getPass().equals(request.getParameter("PASSWORD"))) {
			alart = Validate.ChangeInfoCheck(request);
			request.setAttribute("alart", alart);
		} else {
			alart = "現パスワードが間違っています。もう一度入力して下さい。";
			request.setAttribute("alart", alart);
		}
		if (alart != null) {
			request.getRequestDispatcher(
					"JSP/topmenu/menu/CLS007_ChangeInfo.jsp").forward(request,
					response);
			return;
		}
		ConnectionManager.beginTransaction();
		Mst001_UserMstBean mst001_lastupdate = userCustomdao.findById(userID);
		if(Mst001_UserMstBean.getDate_lastupdate().equals(mst001_lastupdate.getDate_lastupdate())){
			userdao.update(mst001_UserMst);
			ConnectionManager.commit();
		}else{
			ConnectionManager.rollback();
		}
		ConnectionManager.beginTransaction();
		mst001_UserMst = userdao.findById(mst001_UserMst.getId_user());
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		System.out.println("キチンとここまで処理できましたよ！！やったね！！");

		session.setAttribute("loginSession", mst001_UserMst);

		request.getRequestDispatcher("JSP/topmenu/menu/CLS007_Complete.jsp")
				.forward(request, response);
	}
}

