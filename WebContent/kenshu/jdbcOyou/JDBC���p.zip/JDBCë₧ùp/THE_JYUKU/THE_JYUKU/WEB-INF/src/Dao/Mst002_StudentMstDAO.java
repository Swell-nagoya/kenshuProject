package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Mst002_StudentMstBean;

public class Mst002_StudentMstDAO extends DataAccessObject {

	/**
	 * ユーザーIDで検索するSQL
	 */

	String SQL_FIND_BY_ID_USER =
			"select " +
			join(getColumns(),",") +
			" from " +
			getTableName() +
			" where " +
			"ID_USER=?";

		/**
		 * 登録処理を行います。
		 * @param Mst002_StudentMst student
		 */
		public void create(Mst002_StudentMstBean student) {
			update(createSQLForCreate(),
				new Object[] {
				student.getId_user()
				,student.getId_family()
				,student.getGrade()
				,student.getId_elementary()
				,student.getId_junior_high_school()
				,student.getId_high_school()
				,student.getId_university()
				,student.getIn_crammer()
				,student.getOut_crammer()
				,student.getFlg_sendentermail()
				,student.getFlg_sendexitmail()
				,student.getLastupdate_id()
				,student.getLastupdate_date()
				});
		}

		/**
		 * 更新処理を行います。
		 * @param Mst002_StudentMst student
		 */
		public void update(Mst002_StudentMstBean student) {
			update(createSQLForUpdate(),
				new Object[] {
				student.getId_user()
				,student.getId_family()
				,student.getGrade()
				,student.getId_elementary()
				,student.getId_junior_high_school()
				,student.getId_high_school()
				,student.getId_university()
				,student.getIn_crammer()
				,student.getOut_crammer()
				,student.getFlg_sendentermail()
				,student.getFlg_sendexitmail()
				,student.getLastupdate_id()
				,student.getLastupdate_date()
				,student.getId_user()
				});
		}

		/**
		 * 主キー検索を行います。
		 * @param student 生徒
		 * @return id_user
		 */
		public Mst002_StudentMstBean findByPrimaryKey(java.lang.Integer userno) {
			return (Mst002_StudentMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst002_StudentMstBean.class);
		}

		@Override
		public String[] getPKColumns() {
			return new String[] {"ID_USER"};
		}

		@Override
		public String[] getColumns() {
			return new String[] {
					"ID_USER"
					,"ID_FAMILY"
					,"GRADE"
					,"ID_ELEMENTARY_SCHOOL"
					,"ID_JUNIOR_HIGH_SCHOOL"
					,"ID_HIGH_SCHOOL"
					,"ID_UNIVERSITY"
					,"IN_CRAMMER"
					,"OUT_CRAMMER"
					,"FLG_SENDENTERMAIL"
					,"FLG_SENDEXITMAIL"
					,"ID_LASTUPDATE"
					,"DATE_LASTUPDATE"
			};
		}

		@Override
		public String getTableName() {
			return "MST002_STUDENTMST";
		}

		/**
		 * ユーザIDで一致する行を取得します。
		 * @param user_id
		 * @return Mst002_StudentMstDAO
		 */

		public Mst002_StudentMstBean findById_user(String id_user) {

			Mst002_StudentMstBean mst002_StudentMstBean = new Mst002_StudentMstBean();
			PreparedStatement stmt = null;
			ResultSet rs = null;
			try {
				stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_USER);
				System.out.println(SQL_FIND_BY_ID_USER);
				System.out.println("id:" + id_user);
				fillPreparedStatement(stmt, 1, id_user);
				rs = stmt.executeQuery();

				if (rs.next()) {
					mst002_StudentMstBean.setId_user(rs.getString("ID_USER"));
					mst002_StudentMstBean.setId_family(rs.getString("ID_FAMILY"));
					mst002_StudentMstBean.setGrade(rs.getInt("GRADE"));
					mst002_StudentMstBean.setId_elementary(rs.getString("ID_ELEMENTARY_SCHOOL"));
					mst002_StudentMstBean.setId_junior_high_school(rs.getString("ID_JUNIOR_HIGH_SCHOOL"));
					mst002_StudentMstBean.setId_high_school(rs.getString("ID_HIGH_SCHOOL"));
					mst002_StudentMstBean.setId_university(rs.getString("ID_UNIVERSITY"));
					mst002_StudentMstBean.setIn_crammer(rs.getTimestamp("IN_CRAMMER"));
					mst002_StudentMstBean.setOut_crammer(rs.getTimestamp("OUT_CRAMMER"));
					mst002_StudentMstBean.setFlg_sendentermail(rs.getInt("FLG_SENDENTERMAIL"));
					mst002_StudentMstBean.setFlg_sendexitmail(rs.getInt("FLG_SENDEXITMAIL"));
					mst002_StudentMstBean.setId_lastupdate(rs.getString("ID_LASTUPDATE"));
					mst002_StudentMstBean.setDate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));

				}
			} catch (SQLException e) {
				e.getMessage();
				e.printStackTrace();
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

			return mst002_StudentMstBean;
		}
}
