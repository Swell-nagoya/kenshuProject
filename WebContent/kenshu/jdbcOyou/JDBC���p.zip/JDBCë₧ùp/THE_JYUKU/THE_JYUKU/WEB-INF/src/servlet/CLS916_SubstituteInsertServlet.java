package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.time.DateUtils;

import common.ServretCommon;
import Dao.ConnectionManager;
import Dao.Trn005_SubstituteTrnDAO;
import bean.Trn005_SubstituteTrnBean;

/**
 * 振替の登録用のサーブレットクラス
 *
 * @author m-hayashi
 */

public class CLS916_SubstituteInsertServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = new Trn005_SubstituteTrnBean();
		Trn005_SubstituteTrnDAO trn005_SubstituteTrnDAO = new Trn005_SubstituteTrnDAO();

		// 今の最終日更新日
		Timestamp date_compareupdate = new Timestamp(System.currentTimeMillis());

		// 前画面の最終更新日
		Timestamp date_beforeupdate = new Timestamp(System.currentTimeMillis());
		trn005_SubstituteTrnBean.setdate_lastupdate(Timestamp.valueOf(date_beforeupdate.toString()));

		// ユーザーテーブルの各更新日を取得する(更新/削除)
		if (request.getParameter("substitute_update_id_user") != null
				|| request.getParameter("substitute_delete_id_user") != null) {
			ConnectionManager.beginTransaction();
			date_compareupdate = trn005_SubstituteTrnDAO.findByKey(
					request.getParameter("substitute_update_id_user"),
					request.getParameter("substitute_update_id_course"),
					request.getParameter("substitute_update_start_lecture")).getdate_lastupdate();
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
		}

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		session.removeAttribute("alart");

		/*
		 * トランテーブルをインサート
		 */
		// 登録
		// ミリ秒での現在時刻の取得
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		// アラートメッセージ
		String alart;
		// 入力チェック
		ValidateServlet Validate = new ValidateServlet();
		alart = Validate.SubstituteInsCheck(request);
		if (alart != null) {
			session.setAttribute("alart", alart);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS916_SubstituteInsert.jsp").forward(request, response);
			return;
		}
		if (request.getParameter("substitute_update_id_user") == null
				&& request.getParameter("substitute_delete_id_user") == null) {
			trn005_SubstituteTrnBean.setid_user(request.getParameter("ID_USER"));
			if (request.getParameter("ID_COURSE") != null) {
				trn005_SubstituteTrnBean.setid_course(request.getParameter("ID_COURSE"));
			}
			trn005_SubstituteTrnBean.setflg_absence(Integer.parseInt(request.getParameter("FLG_ABSENCE")));
			trn005_SubstituteTrnBean.setflg_late(Integer.parseInt(request.getParameter("FLG_LATE")));
			trn005_SubstituteTrnBean.setflg_early(Integer.parseInt(request.getParameter("FLG_EARLY")));
			trn005_SubstituteTrnBean.setflg_substitute(Integer.parseInt(request.getParameter("FLG_SUBSTITUTE")));
			//trn005_SubstituteTrnBean.settimetable_lecture(request.getParameter("TIMETABLE_LECTURE"));
			trn005_SubstituteTrnBean.setstart_lecture(changeTimestampForCourse(request, "START", "LECTURE"));
			trn005_SubstituteTrnBean.setend_lecture(changeTimestampForCourse(request, "END", "LECTURE"));
			trn005_SubstituteTrnBean.setstart_substitute(changeTimestampForCourse(request, "START", "SUBSTITUTE"));
			trn005_SubstituteTrnBean.setend_substitute(changeTimestampForCourse(request, "END", "SUBSTITUTE"));
			//trn005_SubstituteTrnBean.settimetable_lecture((request.getParameter("TIMETABLE_SUBSTITUTE")));
			//trn005_SubstituteTrnBean.setdate_substitute(Timestamp.valueOf(timestamp.toString()));
			trn005_SubstituteTrnBean.setflg_delete(0);
			trn005_SubstituteTrnBean.setid_lastupdate(request.getParameter("id_lastupdate"));

			ConnectionManager.beginTransaction();
			try {
				trn005_SubstituteTrnDAO.create(trn005_SubstituteTrnBean);
				ConnectionManager.commit();
			} finally {
				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					// TODO 自動生成された catch ブロック
					e.printStackTrace();
				}
			}

		// 削除
		} else if (request.getParameter("substitute_delete_id_user") != null) {
			ConnectionManager.beginTransaction();
			try {
				trn005_SubstituteTrnBean = trn005_SubstituteTrnDAO.findByKey(
						request.getParameter("substitute_delete_id_user"),
						request.getParameter("substitute_delete_id_course"),
						request.getParameter("substitute_delete_start_lecture"));
				ConnectionManager.commit();
			} finally {
				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					// TODO 自動生成された catch ブロック
					e.printStackTrace();
				}
			}
			trn005_SubstituteTrnBean.setflg_delete(1);
			trn005_SubstituteTrnBean.setid_lastupdate(request.getParameter("id_lastupdate"));
			// ミリ秒での現在時刻の取得
			// Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			trn005_SubstituteTrnBean.setdate_lastupdate(Timestamp.valueOf(timestamp.toString()));

			ConnectionManager.beginTransaction();
			try {
				trn005_SubstituteTrnDAO.update(trn005_SubstituteTrnBean);
			} finally {
				ConnectionManager.commit();
			}
		// 更新
		} else if (request.getParameter("substitute_update_id_user") != null) {
			//開催日時(開始)を取得・変換
			String start_lecture_year = (request.getParameter("START_LECTURE"));
			String start_lecture_month = (request.getParameter("START_LECTURE_MONTH"));
			String start_lecture_day = (request.getParameter("START_LECTURE_DAY"));
			String start_lecture_hour = (request.getParameter("START_LECTURE_HOUR"));
			String start_lecture_minute = (request.getParameter("START_LECTURE_MINUTE"));
			String strstart_lecture = start_lecture_year + "-" + start_lecture_month + "-" + start_lecture_day +
									 " " + start_lecture_hour + ":" + start_lecture_minute + ":00";
			Timestamp start_lecture = Timestamp.valueOf(strstart_lecture);
			
			//開催日時(終了)を取得・変換
			String end_lecture_year = (request.getParameter("START_LECTURE"));
			String end_lecture_month = (request.getParameter("START_LECTURE_MONTH"));
			String end_lecture_day = (request.getParameter("START_LECTURE_DAY"));
			String end_lecture_hour = (request.getParameter("END_LECTURE_HOUR"));
			String end_lecture_minute = (request.getParameter("END_LECTURE_MINUTE"));
			String strend_lecture = end_lecture_year + "-" + end_lecture_month + "-" + end_lecture_day +
									 " " + end_lecture_hour + ":" + end_lecture_minute + ":00";
			Timestamp end_lecture = Timestamp.valueOf(strend_lecture);

			//振替日時(開始)を取得・変換
			String start_substitute_year = (request.getParameter("START_SUBSTITUTE"));
			String start_substitute_month = (request.getParameter("START_SUBSTITUTE_MONTH"));
			String start_substitute_day = (request.getParameter("START_SUBSTITUTE_DAY"));
			String start_substitute_hour = (request.getParameter("START_SUBSTITUTE_HOUR"));
			String start_substitute_minute = (request.getParameter("START_SUBSTITUTE_MINUTE"));
			String strstart_substitute = start_substitute_year + "-" + start_substitute_month + "-" + start_substitute_day +
									" " + start_substitute_hour + ":" + start_substitute_minute + ":00";
			Timestamp start_substitute = Timestamp.valueOf(strstart_substitute);
			
			//振替日時(終了)を取得・変換
			String end_substitute_year = (request.getParameter("START_SUBSTITUTE"));
			String end_substitute_month = (request.getParameter("START_SUBSTITUTE_MONTH"));
			String end_substitute_day = (request.getParameter("START_SUBSTITUTE_DAY"));
			String end_substitute_hour = (request.getParameter("END_SUBSTITUTE_HOUR"));
			String end_substitute_minute = (request.getParameter("END_SUBSTITUTE_MINUTE"));
			String strend_substitute = end_substitute_year + "-" + end_substitute_month + "-" + end_substitute_day +
									" " + end_substitute_hour + ":" + end_substitute_minute + ":00";
			Timestamp end_substitute = Timestamp.valueOf(strend_substitute);

			trn005_SubstituteTrnBean.setid_user(request.getParameter("substitute_update_id_user"));
			trn005_SubstituteTrnBean.setid_course(request.getParameter("substitute_update_id_course"));
			trn005_SubstituteTrnBean.setflg_absence(Integer.parseInt(request.getParameter("FLG_ABSENCE")));
			trn005_SubstituteTrnBean.setflg_late(Integer.parseInt(request.getParameter("FLG_LATE")));
			trn005_SubstituteTrnBean.setflg_early(Integer.parseInt(request.getParameter("FLG_EARLY")));
			trn005_SubstituteTrnBean.setflg_substitute(Integer.parseInt(request.getParameter("FLG_SUBSTITUTE")));
			trn005_SubstituteTrnBean.setstart_lecture(start_lecture);
			trn005_SubstituteTrnBean.setend_lecture(end_lecture);
			trn005_SubstituteTrnBean.setstart_substitute(start_substitute);
			trn005_SubstituteTrnBean.setend_substitute(end_substitute);
			trn005_SubstituteTrnBean.setflg_delete(0);
			trn005_SubstituteTrnBean.setid_lastupdate(request.getParameter("id_lastupdate"));
			// ミリ秒での現在時刻の取得
			// Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			trn005_SubstituteTrnBean.setdate_lastupdate(Timestamp.valueOf(timestamp.toString()));

//			if (date_compareupdate.compareTo(date_beforeupdate) == 0) {
				ConnectionManager.beginTransaction();
				try {
					trn005_SubstituteTrnDAO.update(trn005_SubstituteTrnBean);
					ConnectionManager.commit();
				} finally {
					try {
						ConnectionManager.close();
					} catch (SQLException e) {
						// TODO 自動生成された catch ブロック
						e.printStackTrace();
					}
				}
//			}
		} else {
			String e = "error";
			System.err.println(e);
		}
		System.out.println("キチンとここまで処理できましたよ！！やったね！！");
		// 過去に取得していたら破棄
		session.removeAttribute("permission");
		session.setAttribute("alart", "更新が完了しました。");
		request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS915_SubstituteSearch.jsp").forward(request, response);
	}
	
	// コース日時用タイムスタップ変更メソッド
	public Timestamp changeTimestampForCourse(HttpServletRequest request, String first, String second) {
		Timestamp ts = null;
		
		String year = (request.getParameter("START_" + second));
		String month = (request.getParameter("START_" + second + "_MONTH"));
		String day = (request.getParameter("START_" + second + "_DAY"));
		String hour = (request.getParameter(first + "_" + second + "_HOUR"));
		String minute = (request.getParameter(first + "_" + second + "_MINUTE"));
		
		try{
			String targetDatetime = year + "-" + month + "-" + day + " " +
									hour +":"+ minute + ":00";
			ts = new Timestamp(DateUtils.parseDate(targetDatetime, new String[] {"yyyy-MM-dd HH:mm:ss"}).getTime());
		}catch(Exception ex){}
		return ts;
	}
}
