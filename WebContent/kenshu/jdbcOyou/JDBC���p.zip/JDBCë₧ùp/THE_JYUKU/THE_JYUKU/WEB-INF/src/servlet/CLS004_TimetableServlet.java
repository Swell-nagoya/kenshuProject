package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.CLS002DAO;
import Dao.CLS004DAO;
import Dao.ConnectionManager;
import Dao.Mst020_ConstantMstDAO;
import bean.CLS002Bean;
import bean.CLS002_ForCalender;
import bean.Mst001_UserMstBean;

import common.ServretCommon;

public class CLS004_TimetableServlet extends HttpServlet {

    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
                    throws ServletException, IOException {
        //DAOの生成
        CLS002DAO cls002dao = new CLS002DAO();

        //セッションの取得
        HttpSession session = request.getSession();

        //セッション情報を値にぶち込む
        Mst001_UserMstBean mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");
        String id_user = mst001_UserMstBean.getId_user();

        Calendar calendar = Calendar.getInstance();
        int month;
        month = calendar.get(Calendar.MONTH);
        calendar.set(calendar.get(Calendar.YEAR), month, 1);
        //トランザクションを開く、各種DAOの実行
        ConnectionManager.beginTransaction();
        CLS004DAO cls004dao = new CLS004DAO();
        //定数マスタから休校日を取得
        Date date = new Date();
        Timestamp today = new Timestamp(date.getTime());
        List<CLS002Bean> groupBeans = cls004dao.PersonalSubjectTimeTableFindByUser(id_user, today);
        Mst020_ConstantMstDAO mst020_ConstantMstDAO = new Mst020_ConstantMstDAO();
        List<String> restDays = mst020_ConstantMstDAO.getConstants(today, "REST_SCHOOL");
        //DateTimeにパースできない日付は省き、当月の休校日を取得する。
        restDays = CLS002_TOPServret.getEnableRestDays(restDays, month);

        List<CLS002_ForCalender> calendarList = getLectureDays(calendar, groupBeans);
//		List<CLS002Bean> substituteBeans = cls002dao.SubstituteFindByUser(id_user);
        List<CLS002Bean> homeworkBeans = cls002dao.getHomeWorkTimeTableList(id_user, month + 1);

        //トランザクションを開く
        try {
            ConnectionManager.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //セッション情報の削除、付与
        session.removeAttribute("calendarList");
        session.removeAttribute("restDays");
        session.removeAttribute("homeworkBeans");

        session.setAttribute("calendarList", calendarList);
        session.setAttribute("restDays", restDays);
        session.setAttribute("homeworkBeans", homeworkBeans);


        //次画面に飛ぶ
        request.getRequestDispatcher("JSP/topmenu/menu/CLS004_timetable.jsp").forward(request, response);


    }

    public static List<CLS002_ForCalender> getLectureDays(Calendar calendar, List<CLS002Bean> list) {

        //日付の設定

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        //画面表示用のリストビーン
        List<CLS002_ForCalender> calendarBeans = new ArrayList<>();

        for (CLS002Bean bean : list) {
            CLS002_ForCalender calendarBean = new CLS002_ForCalender();
            calendarBean.setName_Cource(bean.getName_subject());
            calendarBean.setStartLecture(bean.getStart_lecture());
            calendarBean.setEndLecture(bean.getEnd_lecture());
            List<Timestamp> lectureStartDays = new ArrayList<>();
            List<Timestamp> lectureEndDays = new ArrayList<>();
            for (int getTargetMonth = month -1; getTargetMonth <= month + 1; getTargetMonth++) {
                for (int day = 1; day <= calendar.getActualMaximum(Calendar.DATE); day++) {
                    calendar.set(year, getTargetMonth, day);
                    if (ServretCommon.checkEnableLecture(bean, year, month, day)) {
                        switch (calendar.get(Calendar.DAY_OF_WEEK)) {
                        case Calendar.SUNDAY:
                            if (bean.getDay_lecture() == 6) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        case Calendar.MONDAY:
                            if (bean.getDay_lecture() == 0) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        case Calendar.TUESDAY:
                            if (bean.getDay_lecture() == 1) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        case Calendar.WEDNESDAY:
                            if (bean.getDay_lecture() == 2) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        case Calendar.THURSDAY:
                            if (bean.getDay_lecture() == 3) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        case Calendar.FRIDAY:
                            if (bean.getDay_lecture() == 4) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        case Calendar.SATURDAY:
                            if (bean.getDay_lecture() == 5) {
                                lectureStartDays.add(createTimestamp(calendar, bean.getStart_time_lecture()));
                                lectureEndDays.add(createTimestamp(calendar, bean.getEnd_time_lecture()));
                            }
                            break;
                        }
                    }
                }
            }
            calendarBean.setExistStartLessonDatetime(lectureStartDays);
            calendarBean.setExistEndLessonDatetime(lectureEndDays);
            calendarBeans.add(calendarBean);
        }

        return calendarBeans;
    }
    public static Timestamp createTimestamp(Calendar calendar, Timestamp bean) {
    Timestamp timestamp = Timestamp.valueOf(calendar.get(Calendar.YEAR) + "-" +
            (calendar.get(Calendar.MONTH) + 1) + "-" +
            calendar.get(Calendar.DATE) + " " +
            bean.toString().split(" ")[1]);
    return timestamp;
    }

}
