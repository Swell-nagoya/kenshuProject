package bean;

public class CLS006Bean {

		Mst001_UserMstBean mst001_UserMstBean = null;
		Mst002_StudentMstBean mst002_StudentMstBean = null;
		Mst003_GuardianMstBean mst003_GuardianMstBean = null;
		Mst010_CourseMstBean mst010_CourseMstBean = null;
		Mst011_CourseMeisaiMstBean mst011_CourseMeisaiMstBean = null;
		Mst012_PersonalMstBean mst012_PersonalMstBean = null;
		Mst013_SubjectMstBean mst013_SubjectMstBean = null;
		Mst016_GetCourseMstBean mst016_GetCourseMstBean = null;
		Mst017_TimeTableMstBean mst017_TimeTableMstBean = null;
		Mst020_ConstantMstBean mst020_ConstantMstBean = null;
		Trn010_AttendanceTrnBean trn010_AttendanceTrnBean = null;
		/**
		 * mst001_UserMstBeanを取得します。
		 * @return mst001_UserMstBean
		 */
		public Mst001_UserMstBean getMst001_UserMstBean() {
		    return mst001_UserMstBean;
		}
		/**
		 * mst001_UserMstBeanを設定します。
		 * @param mst001_UserMstBean mst001_UserMstBean
		 */
		public void setMst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
		    this.mst001_UserMstBean = mst001_UserMstBean;
		}
		/**
		 * mst002_StudentMstBeanを取得します。
		 * @return mst002_StudentMstBean
		 */
		public Mst002_StudentMstBean getMst002_StudentMstBean() {
		    return mst002_StudentMstBean;
		}
		/**
		 * mst002_StudentMstBeanを設定します。
		 * @param mst002_StudentMstBean mst002_StudentMstBean
		 */
		public void setMst002_StudentMstBean(Mst002_StudentMstBean mst002_StudentMstBean) {
		    this.mst002_StudentMstBean = mst002_StudentMstBean;
		}
		/**
		 * mst003_GuardianMstBeanを取得します。
		 * @return mst003_GuardianMstBean
		 */
		public Mst003_GuardianMstBean getMst003_GuardianMstBean() {
		    return mst003_GuardianMstBean;
		}
		/**
		 * mst003_GuardianMstBeanを設定します。
		 * @param mst003_GuardianMstBean mst003_GuardianMstBean
		 */
		public void setMst003_GuardianMstBean(Mst003_GuardianMstBean mst003_GuardianMstBean) {
		    this.mst003_GuardianMstBean = mst003_GuardianMstBean;
		}
		/**
		 * mst010_CourseMstBeanを取得します。
		 * @return mst010_CourseMstBean
		 */
		public Mst010_CourseMstBean getMst010_CourseMstBean() {
		    return mst010_CourseMstBean;
		}
		/**
		 * mst010_CourseMstBeanを設定します。
		 * @param mst010_CourseMstBean mst010_CourseMstBean
		 */
		public void setMst010_CourseMstBean(Mst010_CourseMstBean mst010_CourseMstBean) {
		    this.mst010_CourseMstBean = mst010_CourseMstBean;
		}
		/**
		 * mst011_CourseMeisaiMstBeanを取得します。
		 * @return mst011_CourseMeisaiMstBean
		 */
		public Mst011_CourseMeisaiMstBean getMst011_CourseMeisaiMstBean() {
		    return mst011_CourseMeisaiMstBean;
		}
		/**
		 * mst011_CourseMeisaiMstBeanを設定します。
		 * @param mst011_CourseMeisaiMstBean mst011_CourseMeisaiMstBean
		 */
		public void setMst011_CourseMeisaiMstBean(Mst011_CourseMeisaiMstBean mst011_CourseMeisaiMstBean) {
		    this.mst011_CourseMeisaiMstBean = mst011_CourseMeisaiMstBean;
		}
		/**
		 * mst012_PersonalMstBeanを取得します。
		 * @return mst012_PersonalMstBean
		 */
		public Mst012_PersonalMstBean getMst012_PersonalMstBean() {
		    return mst012_PersonalMstBean;
		}
		/**
		 * mst012_PersonalMstBeanを設定します。
		 * @param mst012_PersonalMstBean mst012_PersonalMstBean
		 */
		public void setMst012_PersonalMstBean(Mst012_PersonalMstBean mst012_PersonalMstBean) {
		    this.mst012_PersonalMstBean = mst012_PersonalMstBean;
		}
		/**
		 * mst013_SubjectMstBeanを取得します。
		 * @return mst013_SubjectMstBean
		 */
		public Mst013_SubjectMstBean getMst013_SubjectMstBean() {
		    return mst013_SubjectMstBean;
		}
		/**
		 * mst013_SubjectMstBeanを設定します。
		 * @param mst013_SubjectMstBean mst013_SubjectMstBean
		 */
		public void setMst013_SubjectMstBean(Mst013_SubjectMstBean mst013_SubjectMstBean) {
		    this.mst013_SubjectMstBean = mst013_SubjectMstBean;
		}
		/**
		 * mst016_GetCourseMstBeanを取得します。
		 * @return mst016_GetCourseMstBean
		 */
		public Mst016_GetCourseMstBean getMst016_GetCourseMstBean() {
		    return mst016_GetCourseMstBean;
		}
		/**
		 * mst016_GetCourseMstBeanを設定します。
		 * @param mst016_GetCourseMstBean mst016_GetCourseMstBean
		 */
		public void setMst016_GetCourseMstBean(Mst016_GetCourseMstBean mst016_GetCourseMstBean) {
		    this.mst016_GetCourseMstBean = mst016_GetCourseMstBean;
		}
		/**
		 * mst017_TimeTableMstBeanを取得します。
		 * @return mst017_TimeTableMstBean
		 */
		public Mst017_TimeTableMstBean getMst017_TimeTableMstBean() {
		    return mst017_TimeTableMstBean;
		}
		/**
		 * mst017_TimeTableMstBeanを設定します。
		 * @param mst017_TimeTableMstBean mst017_TimeTableMstBean
		 */
		public void setMst017_TimeTableMstBean(Mst017_TimeTableMstBean mst017_TimeTableMstBean) {
		    this.mst017_TimeTableMstBean = mst017_TimeTableMstBean;
		}
		/**
		 * mst020_ConstantMstBeanを取得します。
		 * @return mst020_ConstantMstBean
		 */
		public Mst020_ConstantMstBean getMst020_ConstantMstBean() {
		    return mst020_ConstantMstBean;
		}
		/**
		 * mst020_ConstantMstBeanを設定します。
		 * @param mst020_ConstantMstBean mst020_ConstantMstBean
		 */
		public void setMst020_ConstantMstBean(Mst020_ConstantMstBean mst020_ConstantMstBean) {
		    this.mst020_ConstantMstBean = mst020_ConstantMstBean;
		}
		/**
		 * trn010_AttendanceTrnBeanを取得します。
		 * @return trn010_AttendanceTrnBean
		 */
		public Trn010_AttendanceTrnBean getTrn010_AttendanceTrnBean() {
		    return trn010_AttendanceTrnBean;
		}
		/**
		 * trn010_AttendanceTrnBeanを設定します。
		 * @param trn010_AttendanceTrnBean trn010_AttendanceTrnBean
		 */
		public void setTrn010_AttendanceTrnBean(Trn010_AttendanceTrnBean trn010_AttendanceTrnBean) {
		    this.trn010_AttendanceTrnBean = trn010_AttendanceTrnBean;
		}



}
