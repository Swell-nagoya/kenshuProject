package util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringUtil {

	/**
	 *  文字列が空文字またはnullかどうかを判定
	 * @param parameter
	 * @return
	 */
	public static boolean isEmpty(String parameter) {

		if (parameter == null || parameter.length() == 0) {
			return true;
		}

		return false;
	}

	/**
	 *  日付がyyyy-MM-DD形式かチェックを行う。
	 * @return
	 */
	public static boolean isValidDateFormat(String date) {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			format.parse(date);
		} catch (ParseException e) {
			// 日付フォーマットエラー
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * 日付がyyyy-MM-dd形式かチェックを行う。
	 * @param start 開始日
	 * @param end 終了日
	 * @return false:指定のフォーマットでない true:指定のフォーマット
	 */
	public static boolean isValidDateFormat(String start, String end) {

		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try {
			format.parse(start);
			format.parse(end);
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * 日付の比較を行う
	 * @param startDate 検索開始日
	 * @param endDate 検索終了日
	 * @return boolean 開始日 < 終了日:true 開始日 > 終了日:false
	 * @throws ParseException 日付フォーマットエラー
	 */
	public static boolean compareDate(String startDate, String endDate) {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate_ = null;
		Date endDate_ = null;
		try {
			startDate_ = format.parse(startDate);
			endDate_ = format.parse(endDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		if (endDate_.compareTo(startDate_) < 0) {
			return false;
		}

		return true;
	}

	/**
	 * 点数が半角数値か判定
	 * @param num
	 * @return
	 */
	public static boolean isSingleByteNumeric(String num) {

		// 入力があればチェック
		if (!StringUtil.isEmpty(num)) {

			if (!num.matches("^[0-9]+$")) {
				return false;
			}
		}

		return true;
	}

	/**
	 * 点数が0点以上100以下であるか判定
	 */
	public static boolean isInRange(String input) {

		if (!StringUtil.isEmpty(input)) {
			int num = Integer.parseInt(input);

			if (num < 0 || 100 < num) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 偏差値が半角数値かつ小数か判定
	 */
	public static boolean isValidDeviation(String num) {

		if (!StringUtil.isEmpty(num.trim())) {
			try {
				Double.parseDouble(num);
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
				return false;
			}
		}

		return true;
	}

	/**
	 * 引数が数値か判定
	 * @param num
	 * @return
	 */
	public static boolean isNumeric(String num) {

		try {
			Integer.parseInt(num);
		} catch (NumberFormatException e) {
			return false;
		}

		return true;
	}

	/**
	 * 年度の桁が4桁か判定
	 * @param num
	 * @return
	 */
	public static boolean isYearInRange(String num) {

		if (num.length() != 4) {
			return false;
		}

        return true;
	}
}
