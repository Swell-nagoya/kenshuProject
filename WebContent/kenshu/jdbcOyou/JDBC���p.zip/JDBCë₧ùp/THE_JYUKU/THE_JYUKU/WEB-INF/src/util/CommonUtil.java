package util;

import java.sql.ResultSet;
import java.sql.SQLException;

//汎用的に使えそうなメソッド格納クラス
public class CommonUtil {

	/**
	 * 引数でもらったResultSetから結果の件数を返す
	 * @return 件数
	 */
	public static int getCountResult(ResultSet rs) {
		int rc = 0;		//件数
		int row;		//行
		try {
			//初期の行取得
			row = rs.getRow();
			//件数をカウント
			while(rs.next()){
				rc++;
			}
			//行を初期行に戻す
			rs.absolute(row);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//件数を返す
		return rc;
	}

}
