package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * プロパティファイルからメッセージを取得する。
 * @author kume
 *
 */
public class Message {

	private static final String PROPERTYFILE = "message.properties";

	/**
	 * プロパティファイルからメッセージ定義を取得する。
	 * @param message メッセージキー
	 * @return メッセージ
	 */
	public static String getMessage(String message) {

		final InputStream inputStream =
				Thread.currentThread().getContextClassLoader().getResourceAsStream(PROPERTYFILE);

	        Properties props = new Properties();
	        // ファイルをロードする
	        try {
				props.load(inputStream);
			} catch (IOException e) {
				e.printStackTrace();
			}

		return props.getProperty(message);
	}
}
