package bean;

import java.sql.Timestamp;

public class Mst014_SchoolMstBean {

	//学校ID
	String id_school = null;
	//学校名
	String name_school = null;
	//住所
	String address_school = null;
	//学区
	String district_school = null;
	//学期
	Integer term = null;
	//評価段階数
	Integer type_evaluation = null;
	//削除フラグ
	Integer flg_delete = null;
	//最終更新ID
	String id_lastupdate = null;
	//最終更新日
	Timestamp date_lastupdate = null;
	//学校種別
	Integer categorize_school = null;
	/**
	 * @return categorize_school
	 */
	public Integer getCategorize_school() {
		return categorize_school;
	}

	/**
	 * @param categorize_school セットする categorize_school
	 */
	public void setcategorize_school(Integer categorize_school) {
		this.categorize_school = categorize_school;
	}

	/**
	 * 学校IDを設定します。
	 * @param id_school
	 */
	public void setid_school(String id_school) {
		this.id_school = id_school;
	}

	/**
	 * 学校名を設定します。
	 * @param name_school
	 */
	public void setname_school(String name_school) {
		this.name_school = name_school;
	}

	/**
	 * 住所を設定します。
	 * @param address_school
	 */
	public void setaddress_school(String address_school) {
		this.address_school = address_school;
	}

	/**
	 * 学区を設定します。
	 * @param district_school
	 */
	public void setdistrict_school(String district_school) {
		this.district_school = district_school;
	}

	/**
	 * 学期を設定します。
	 * @param term
	 */
	public void setterm(Integer term) {
		this.term = term;
	}

	/**
	 * 評価段階数を設定します。
	 * @param type_evaluation
	 */
	public void settype_evaluation(Integer type_evaluation) {
		this.type_evaluation = type_evaluation;
	}

	/**
	 * 削除フラグを設定します。
	 * @param flg_delete
	 */
	public void setflg_delete(Integer flg_delete) {
		this.flg_delete = flg_delete;
	}

	/**
	 * 最終更新IDを設定します。
	 * @param id_lastupdate
	 */
	public void setid_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}

	/**
	 * 最終更新日を設定します。
	 * @param date_lastupdate
	 */
	public void setdate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}


	/**
	 * 学校IDを取得します。
	 * @param id_school
	 */
	public String getid_school() {
		return id_school;
	}

	/**
	 * 学校名を取得します。
	 * @param name_school
	 */
	public String getname_school() {
		return name_school;
	}

	/**
	 * 住所を取得します。
	 * @param address_school
	 */
	public String getaddress_school() {
		return address_school;
	}

	/**
	 * 学区を取得します。
	 * @param district_school
	 */
	public String getdistrict_school() {
		return district_school;
	}

	/**
	 * 学期を取得します。
	 * @param term
	 */
	public Integer getterm() {
		return term;
	}

	/**
	 * 評価段階数を取得します。
	 * @param type_evaluation
	 */
	public Integer gettype_evaluation() {
		return type_evaluation;
	}

	/**
	 * 削除フラグを取得します。
	 * @param flg_delete
	 */
	public Integer getflg_delete() {
		return flg_delete;
	}

	/**
	 * 最終更新IDを取得します。
	 * @param id_lastupdate
	 */
	public String getid_lastupdate() {
		return id_lastupdate;
	}

	/**
	 * 最終更新日を取得します。
	 * @param date_lastupdate
	 */
	public Timestamp getdate_lastupdate() {
		return date_lastupdate;
	}
}
