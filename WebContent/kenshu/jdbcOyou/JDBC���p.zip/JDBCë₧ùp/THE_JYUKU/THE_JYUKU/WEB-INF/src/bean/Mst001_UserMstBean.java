package bean;

import java.sql.Timestamp;

public class Mst001_UserMstBean {
	/**
	 * USERMST表のDTOクラス。
	 * <pre>
	 * ユーザーのデータを格納します。
	 * </pre>
	 */
	//ユーザーID
	String id_user;

	//パスワード
	String pass;

	//氏名
	String name;

	//氏名（カナ）
	String kana_name;

	//性別
	int sex = 0;

	//ニックネーム
	String nickname;

	//誕生日
	Timestamp birthday;

	//携帯番号
	String phone;

	//メールアドレス
	String mail;

	//権限
	int permission = 0;

	//最終更新ID
	String id_lastupdate;

	//最終更新日
	Timestamp date_lastupdate;

	//コメント欄表示
	String comment;

	//削除フラグ
	int flg_delete;

	//カードID
	String iD_Card;

	public int getFlg_delete() {
		return flg_delete;
	}

	public void setFlg_delete(int flg_delete) {
		this.flg_delete = flg_delete;
	}

	/**
	 * ユーザーIDを取得します。
	 * @param id ユーザID
	 */
	public String getId_user() {
		return this.id_user;
	}

	/**
	 * パスワードを取得します。
	 * @param pass パスワード
	 */
	public String getPass() {
		return this.pass;
	}

	/**
	 * 氏名を取得します。
	 * @param name 氏名
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * 氏名(ｶﾅ)を取得します。
	 * @param kana_name 氏名(ｶﾅ)
	 */
	public String getKana_name() {
		return this.kana_name;
	}

	/**
	 * 性別を取得します。
	 * @param sex 性別
	 */
	public int getSex() {
		return this.sex;
	}

	/**
	 * ニックネームを取得します。
	 * @param name 氏名(ｶﾅ)
	 */
	public String getNickname() {
		return this.nickname;
	}

	/**
	 * 生年月日を取得します。
	 * @param birthday 生年月日
	 */
	public Timestamp getBirthday() {
		return this.birthday;
	}
	/**
	 * 電話番号を取得します。
	 * @param phone 電話番号
	 */
	public String getPhone() {
		return this.phone;
	}

	/**
	 * メールアドレスを取得します。
	 * @param mail メールアドレス
	 */
	public String getMail() {
		return this.mail;
	}

	/**
	 * 権限を取得します。
	 * @param permission 権限
	 */
	public int getPermission() {
		return this.permission;
	}

	/**
	 * 最終更新IDを取得します。
	 * @param mail 最終更新ID
	 */
	public String getId_lastupdate() {
		return this.id_lastupdate;
	}
	/**
	 * 最終更新日を取得します。
	 * @param mail 最終更新日
	 */
	public Timestamp getDate_lastupdate() {
		return this.date_lastupdate;
	}

	/**
	 * コメントを取得します。
	 * @param comment コメント
	 */
	public String getComment() {
		return this.comment;
	}

	/**
	 * ユーザーIDを設定します。
	 * @param id ユーザID
	 */
	public void setId_user(String id_user) {
		this.id_user = id_user;
	}

	/**
	 * パスワードを設定します。
	 * @param pass パスワード
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}
	/**
	 * 氏名を設定します。
	 * @param name 氏名
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * 氏名(ｶﾅ)を設定します。
	 * @param kana_name 氏名(ｶﾅ)
	 */
	public void setKana_name(String kana_name) {
		this.kana_name = kana_name;
	}
	/**
	 * 性別を設定します。
	 * @param sex 性別
	 */
	public void setSex(int sex) {
		this.sex = sex;
	}
	/**
	 * ニックネームを設定します。
	 * @param nickname ニックネーム
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	/**
	 * 生年月日を設定します。
	 * @param birdayth
	 */
	public void setBirthday(Timestamp birthday) {
		this.birthday = birthday;
	}

	/**
	 * 電話番号を設定します。
	 * @param phone 電話番号
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * メールアドレスを設定します。
	 * @param mail メールアドレス
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * 権限を設定します。
	 * @param permission 権限
	 */
	public void setPermission(int permission) {
		this.permission = permission;
	}

	/**
	 * 最終更新IDを設定します。
	 * @param id_lastupdate 最終更新ID
	 */
	public void setId_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}

	/**
	 * 最終更新日を設定します。
	 * @param date_lastupdate 最終更新日
	 */
	public void setDate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}

	/**
	 * コメントを設定します。
	 * @param comment コメント
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return iD_Card
	 */
	public String getiD_Card() {
		return iD_Card;
	}

	/**
	 * @param iD_Card セットする iD_Card
	 */
	public void setiD_Card(String iD_Card) {
		this.iD_Card = iD_Card;
	}




}
