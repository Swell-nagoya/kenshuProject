package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.CLS905_SearchResultBean;
import bean.CLS906_InsertBean;

public class CLS906DAO extends DataAccessObject {

	public static final CLS906DAO instance = new CLS906DAO();

	public static CLS906DAO getInstance() {
		return instance;
	}

	@Override
	public String[] getPKColumns() {
		return new String[]{
				"ID_TEST",
				"FISCAL_YEAR",
				"TIMES",
		};
	}

	@Override
	public String[] getColumns() {
		return new String[]{
				"ID_TEST",
				"FISCAL_YEAR",
				"TIMES",
				"TEST_TYPE",
				"DATE_HOLD",
				"AVERAGE_JAP",
				"AVERAGE_MATH",
				"AVERAGE_SIEC",
				"AVERAGE_SCTY",
				"AVERAGE_ENG",
				"FLG_DELETE",
				"ID_LASTUPDATE",
				"DATE_LASTUPDATE",

		};
	}

	@Override
	public String getTableName() {
		return "TRN015_TESTTRN";
	}

	/*
	 * 新規登録時に必要なテストIDをテストトランの最終情報から取得し採番する。
	 *
	 */
	public static int getTestID() {

		StringBuffer buf =
				new StringBuffer("SELECT max(id_test) cnt FROM TRN015_TESTTRN;");

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		Statement stmt = null;

		ResultSet set = null;

		int count = 0;

		try {

			stmt = conn.createStatement();
			set = stmt.executeQuery(buf.toString());
			set.next();
			count = set.getInt("cnt");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;
	}

	/**
	 * 回次重複チェックを行う。
	 * @return
	 */
	public static boolean duplicationCheck(String times) {

		// 回次重複チェックSQL作成
		StringBuffer checkQuery =
				new StringBuffer("SELECT COUNT(*) FROM ")
									.append(instance.getTableName())
									.append(" WHERE TIMES = ?");

		ConnectionManager.beginTransaction();

		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		PreparedStatement stmt;
		ResultSet set;

		try {
			stmt = conn.prepareStatement(checkQuery.toString());
			//int型に対してStringで検索しようとしていたので変更
			stmt.setInt(1, Integer.parseInt(times));

			set = stmt.executeQuery();

			int result = 0;

			while(set.next()) {
				result = set.getInt("COUNT(*)");
			}

			if (result != 0) {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	public int testInsert(CLS906_InsertBean bean) {

		// テスト登録用SQL作成
		StringBuffer insertQuery =
				new StringBuffer("INSERT INTO ")
									.append(instance.getTableName())
									.append(" ( ")
									.append(CLS906DAO.getInstance().join(instance.getColumns(),","))
									.append(" ) VALUES ")
									.append(" (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now()) ;");

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		int result = 0;

		try {
			PreparedStatement stmt = conn.prepareStatement(insertQuery.toString());

			stmt.setString(1, bean.getTestID());
			stmt.setString(2, bean.getFiscal_year());
			stmt.setString(3, bean.getTimes());
			stmt.setString(4, bean.getTest_type());
			stmt.setString(5, bean.getDate_hold());
			stmt.setString(6, blankToDefault(bean.getAverage_jap()));
			stmt.setString(7, blankToDefault(bean.getAverage_math()));
			stmt.setString(8, blankToDefault(bean.getAverage_siec()));
			stmt.setString(9, blankToDefault(bean.getAverage_scty()));
			stmt.setString(10, blankToDefault(bean.getAverage_eng()));
			stmt.setInt(11, 0);
			stmt.setString(12, bean.getLast_up_user());

			result = stmt.executeUpdate();

			ConnectionManager.commit();

			ConnectionManager.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public int testUpdate(CLS906_InsertBean bean, CLS905_SearchResultBean sessionbean) {

		// テスト登録用SQL作成
		StringBuffer updateQuery =
				new StringBuffer("UPDATE ")
							.append(instance.getTableName())
							.append(" SET ")
							.append(" ID_TEST = ?,")
							.append(" FISCAL_YEAR = ?, ")
							.append(" TIMES = ?, ")
							.append(" TEST_TYPE = ?, ")
							.append(" DATE_HOLD = ?, ")
							.append(" AVERAGE_JAP = ?, ")
							.append(" AVERAGE_MATH = ?, ")
							.append(" AVERAGE_SIEC = ?, ")
							.append(" AVERAGE_SCTY = ?, ")
							.append(" AVERAGE_ENG = ?, ")
							.append(" ID_LASTUPDATE = ?, ")
							.append(" DATE_LASTUPDATE = now() ")
							.append(" WHERE ID_TEST = ? ")
							.append(" AND ")
							.append(" FISCAL_YEAR = ? ")
							.append(" AND ")
							.append(" TIMES = ?;");

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		int result = 0;

		try {
			PreparedStatement stmt = conn.prepareStatement(updateQuery.toString());

			stmt.setString(1, bean.getTestID());
			stmt.setString(2, bean.getFiscal_year());
			stmt.setString(3, bean.getTimes());
			stmt.setString(4, bean.getTest_type());
			stmt.setString(5, bean.getDate_hold());
			stmt.setString(6, blankToDefault(bean.getAverage_jap()));
			stmt.setString(7, blankToDefault(bean.getAverage_math()));
			stmt.setString(8, blankToDefault(bean.getAverage_siec()));
			stmt.setString(9, blankToDefault(bean.getAverage_scty()));
			stmt.setString(10, blankToDefault(bean.getAverage_eng()));
			stmt.setString(11, bean.getLast_up_user());
			stmt.setString(12, sessionbean.getTestID());
			stmt.setString(13, sessionbean.getFiscal_year());
			stmt.setString(14, sessionbean.getTimes());

			result = stmt.executeUpdate();

			ConnectionManager.commit();

			ConnectionManager.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public int testDelete(CLS905_SearchResultBean sessionbean) {

		// テスト登録用SQL作成
		StringBuffer deleteQuery =
				new StringBuffer("UPDATE ")
									.append(instance.getTableName())
									.append(" SET ")
									.append(" ID_LASTUPDATE = ?, ")
									.append(" FLG_DELETE = 1, ")
									.append(" DATE_LASTUPDATE = now() ")
									.append(" WHERE ID_TEST = ? ")
									.append(" AND ")
									.append(" FISCAL_YEAR = ? ")
									.append(" AND ")
									.append(" TIMES = ?;");

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		int result = 0;

		try {
			PreparedStatement stmt = conn.prepareStatement(deleteQuery.toString());

			stmt.setString(1, sessionbean.getLast_up_user());
			stmt.setString(2, sessionbean.getTestID());
			stmt.setString(3, sessionbean.getFiscal_year());
			stmt.setString(4, sessionbean.getTimes());

			result = stmt.executeUpdate();

			ConnectionManager.commit();

			ConnectionManager.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}
	/**
	 * フォームから取得した偏差値が空文字の場合、
	 * DB格納用にデフォルト値(-10.00)に変換する。
	 * ■補足：点数と同様に偏差値の変換もプロシージャで行おうとしたが、
	 *         処理出来なかった為、javaロジックに組み込みました。
	 * @param param フォームから取得したデータ
	 * @return デフォルト値に変換済または変換不要データ
	 */
	public static String blankToDefault(String param) {

		// 空文字ならデフォルト値に変換
		if ("".equals(param)) {
			return "-10.00";
		// 空文字でないならばそのまま引数の値を返却。
		} else {
			return param;
		}
	}
}
