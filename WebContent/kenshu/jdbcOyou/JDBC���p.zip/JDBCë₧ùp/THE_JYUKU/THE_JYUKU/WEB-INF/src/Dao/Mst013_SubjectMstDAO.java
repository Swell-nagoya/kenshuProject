package Dao;

import bean.Mst013_SubjectMstBean;

public class Mst013_SubjectMstDAO extends DataAccessObject {

		/**
		 * 登録処理を行います。
		 * @param Mst013_SubjectMst mst013_subjectmst
		 */
		public void create(Mst013_SubjectMstBean mst013_subjectmst) {
			update(createSQLForCreate(),
				new Object[] {
				mst013_subjectmst.getid_subject()
				,mst013_subjectmst.getname_subject()
				,mst013_subjectmst.getflg_delete()
				,mst013_subjectmst.getid_lastupdate()
				,mst013_subjectmst.getdate_lastupdate()
				});
		}

		/**
		 * 更新処理を行います。
		 * @param Mst013_SubjectMst mst013_subjectmst
		 */
		public void update(Mst013_SubjectMstBean mst013_subjectmst) {
			update(createSQLForUpdate(),
				new Object[] {
				mst013_subjectmst.getid_subject()
				,mst013_subjectmst.getname_subject()
				,mst013_subjectmst.getflg_delete()
				,mst013_subjectmst.getid_lastupdate()
				,mst013_subjectmst.getdate_lastupdate()
				});
		}

		/**
		 * 主キー検索を行います。
		 * @param ID_SUBJECT 科目ID
		 * @return ID_SUBJECT
		 */
		public Mst013_SubjectMstBean findByPrimaryKey(java.lang.Integer userno) {
			return (Mst013_SubjectMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst013_SubjectMstBean.class);
		}

		@Override
		public String[] getPKColumns() {
			return new String[] {"ID_SUBJECT"};
		}

		@Override
		public String[] getColumns() {
			return new String[] {"ID_SUBJECT"
				,"NAME_SUBJECT"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};
		}

		@Override
		public String getTableName() {
			return "MST013_SUBJECTMST";
		}

}
