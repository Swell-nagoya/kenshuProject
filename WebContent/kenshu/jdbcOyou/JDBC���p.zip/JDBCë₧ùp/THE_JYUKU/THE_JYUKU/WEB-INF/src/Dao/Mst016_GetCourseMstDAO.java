package Dao;

import bean.Mst016_GetCourseMstBean;

public class Mst016_GetCourseMstDAO extends DataAccessObject {

		/**
		 * �o�^�������s���܂��B
		 * @param Mst016_GetCourseMst mst016_getcoursemst
		 */
		public void create(Mst016_GetCourseMstBean mst016_getcoursemst) {
			update(createSQLForCreate(),
				new Object[] {
				mst016_getcoursemst.getid_user()
				,mst016_getcoursemst.getid_course()
				,mst016_getcoursemst.getDate_start()
				,mst016_getcoursemst.getDate_end()
				,mst016_getcoursemst.getflg_delete()
				,mst016_getcoursemst.getid_lastupdate()
				,mst016_getcoursemst.getdate_lastupdate()
				});
		}

		/**
		 * �X�V�������s���܂��B
		 * @param Mst016_GetCourseMst mst016_getcoursemst
		 */
		public void update(Mst016_GetCourseMstBean mst016_getcoursemst) {
			update(createSQLForUpdate(),
				new Object[] {
				mst016_getcoursemst.getid_user()
				,mst016_getcoursemst.getid_course()
				,mst016_getcoursemst.getDate_start()
				,mst016_getcoursemst.getDate_end()
				,mst016_getcoursemst.getflg_delete()
				,mst016_getcoursemst.getid_lastupdate()
				,mst016_getcoursemst.getdate_lastupdate()
				,mst016_getcoursemst.getid_user()
				,mst016_getcoursemst.getid_course()
				});
		}

		/**
		 * ��L�[�������s���܂��B
		 * @param ID_USER ���[�U�[ID
		 * @return ID_USER
		 * @param ID_COURSE �R�[�XID
		 * @return ID_COURSE
		 */
		public Mst016_GetCourseMstBean findByPrimaryKey(java.lang.Integer userno) {
			return (Mst016_GetCourseMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst016_GetCourseMstBean.class);
		}

		@Override
		public String[] getPKColumns() {
			return new String[] {"ID_USER","ID_COURSE"};
		}

		@Override
		public String[] getColumns() {
			return new String[] {
				 "ID_USER"
				,"ID_COURSE"
				,"DATE_START"
				,"DATE_END"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};
		}

		@Override
		public String getTableName() {
			return "MST016_GETCOURSEMST";
		}

}
