
package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import bean.CLS002Bean;
import bean.Mst012_PersonalMstBean;
import bean.Mst013_SubjectMstBean;
import bean.Mst017_TimeTableMstBean;

public class CLS002DAO extends ConnectionManager {


    Mst012_PersonalMstDAO mst012_PersonalMstDAO = new Mst012_PersonalMstDAO();

    Mst012_PersonalMstDAO mst012_PersonalMstDAO2 = new Mst012_PersonalMstDAO();
    Mst013_SubjectMstDAO mst013_SubjectMstDAO = new Mst013_SubjectMstDAO();
    Mst017_TimeTableMstDAO mst017_TimeTableMstDAO = new Mst017_TimeTableMstDAO();

    Mst012_PersonalMstBean mst012_PersonalMstBean = new Mst012_PersonalMstBean();
    Mst013_SubjectMstBean mst013_SubjectMstBean = new Mst013_SubjectMstBean();
    Mst017_TimeTableMstBean mst017_TimeTableMstBean = new Mst017_TimeTableMstBean();


    /**
     * 振替用のトランを一覧表示するSQLを作成する
     * @return
     */
    private String createSQLTRN005_SubstituteFindByUser() {
        Trn005_SubstituteTrnDAO substituteTrnDAO = new Trn005_SubstituteTrnDAO();
        Mst016_GetCourseMstDAO mst016_GetCourseMstDAO = new Mst016_GetCourseMstDAO();
        Mst011_CourseMeisaiMstDAO mst011_CourseMeisaiMstDAO = new Mst011_CourseMeisaiMstDAO();
        Mst013_SubjectMstDAO mst013_SubjectMstDAO = new Mst013_SubjectMstDAO();

        StringBuffer buffer = new StringBuffer();

        buffer.append("SELECT ")
            .append("T05.ID_COURSE")
            .append(",	T05.START_SUBSTITUTE")
            .append(",	T05.END_SUBSTITUTE")
            .append(",	T05.START_LECTURE")
            .append(",	T05.FLG_DELETE")
            .append(",	M013.NAME_SUBJECT")
            .append(" FROM ")
            .append("	TRN005_SUBSTITUTETRN T05")
            .append(",	" + mst013_SubjectMstDAO.getTableName() +" M013")
            .append(",	" + mst011_CourseMeisaiMstDAO.getTableName() +" M011")
            .append(" WHERE ")
            .append("	T05.ID_COURSE = M011.ID_COURSE")
            .append("	AND")
            .append("	M011.ID_SUBJECT = M013.ID_SUBJECT")
            .append("	AND")
            .append("	T05.ID_USER = ?")
            .append("	AND")
            .append("	T05.FLG_DELETE <> 1");

        return buffer.toString();
    }



    /**
     * 個別授業のカレンダー表示用のSQL文を作成します。
     * 使用するマスタ
     * MST012_PERSONALMST
     * MST013_SUBJECTMST
     * MST017_TIMETABLEMST
     *
     * @param ID_USER
     * @return SQL文
     *
     */

    public String createSQLPersonalSubjectTimeTableFindByuser() {

        String sql =
                "SELECT" +
                    "	1_TBL.NAME_SUBJECT" +
                    ",	1_TBL.DAY_LECTURE1" +
                    ",	1_TBL.START_LECTURE" +
                    ",	1_TBL.END_LECTURE" +
                    ",	2_TBL.NAME_SUBJECT AS NAME_SUBJECT_2" +
                    ",	2_TBL.DAY_LECTURE2" +
                    ",	2_TBL.START_LECTURE AS START_LECTURE_2" +
                    ",	2_TBL.END_LECTURE AS END_LECTURE_2" +
                    ",	3_TBL.NAME_SUBJECT AS NAME_SUBJECT_3" +
                    ",	3_TBL.DAY_LECTURE3" +
                    ",	3_TBL.START_LECTURE AS START_LECTURE_3" +
                    ",	3_TBL.END_LECTURE AS END_LECTURE_3" +
                    ",	4_TBL.NAME_SUBJECT AS NAME_SUBJECT_4" +
                    ",	4_TBL.DAY_LECTURE4" +
                    ",	4_TBL.START_LECTURE AS START_LECTURE_4" +
                    ",	4_TBL.END_LECTURE AS END_LECTURE_4" +
                    ",	5_TBL.NAME_SUBJECT AS NAME_SUBJECT_5" +
                    ",	5_TBL.DAY_LECTURE5" +
                    ",	5_TBL.START_LECTURE AS START_LECTURE_5" +
                    ",	5_TBL.END_LECTURE AS END_LECTURE_5" +
                "	FROM" +
                    "	(SELECT" +
                        "	MST012.DAY_LECTURE1" +
                        ",	MST013.NAME_SUBJECT" +
                        ",	MST017.START_LECTURE" +
                        ",	MST017.END_LECTURE" +
                    "	FROM" +
                        "	MST012_PERSONALMST MST012" +
                        ",	MST013_SUBJECTMST MST013" +
                        ",	MST017_TIMETABLEMST MST017" +
                    "	WHERE" +
                        "	MST012.DAY_LECTURE1 = MST017.DAY_LECTURE" +
                    "	AND" +
                        "	MST012.TIMETABLE_LECTURE1 = MST017.TIMETABLE_LECTURE" +
                    "	AND" +
                        "	MST012.ID_SUBJECT1 = MST013.ID_SUBJECT" +
                    "	AND" +
                        "	MST012.ID_USER = ?)" +
                        " 1_TBL" +

                    ",	(SELECT" +
                        "	MST012.DAY_LECTURE2" +
                        ",	MST013.NAME_SUBJECT" +
                        ",	MST017.START_LECTURE" +
                        ",	MST017.END_LECTURE" +
                    "	FROM" +
                        "	MST012_PERSONALMST MST012" +
                        ",	MST013_SUBJECTMST MST013" +
                        ",	MST017_TIMETABLEMST MST017" +
                    "	WHERE" +
                        "	MST012.DAY_LECTURE2 = MST017.DAY_LECTURE" +
                    "	AND" +
                        "	MST012.TIMETABLE_LECTURE2 = MST017.TIMETABLE_LECTURE" +
                    "	AND" +
                        "	MST012.ID_SUBJECT2 = MST013.ID_SUBJECT" +
                    "	AND" +
                        "	MST012.ID_USER = ?)" +
                        " 2_TBL" +

                    ",	(SELECT" +
                        "	MST012.DAY_LECTURE3" +
                        ",	MST013.NAME_SUBJECT" +
                        ",	MST017.START_LECTURE" +
                        ",	MST017.END_LECTURE" +
                    "	FROM" +
                        "	MST012_PERSONALMST MST012" +
                        ",	MST013_SUBJECTMST MST013" +
                        ",	MST017_TIMETABLEMST MST017" +
                    "	WHERE" +
                        "	MST012.DAY_LECTURE3 = MST017.DAY_LECTURE" +
                    "	AND" +
                        "	MST012.TIMETABLE_LECTURE3 = MST017.TIMETABLE_LECTURE" +
                    "	AND" +
                        "	MST012.ID_SUBJECT3 = MST013.ID_SUBJECT" +
                    "	AND" +
                        "	MST012.ID_USER = ?)" +
                        " 3_TBL" +

                    ",	(SELECT" +
                        "	MST012.DAY_LECTURE4" +
                        ",	MST013.NAME_SUBJECT" +
                        ",	MST017.START_LECTURE" +
                        ",	MST017.END_LECTURE	" +
                    "	FROM" +
                        "	MST012_PERSONALMST MST012" +
                        ",	MST013_SUBJECTMST MST013" +
                        ",	MST017_TIMETABLEMST MST017" +
                    "	WHERE" +
                        "	MST012.DAY_LECTURE4 = MST017.DAY_LECTURE" +
                    "	AND" +
                        "	MST012.TIMETABLE_LECTURE4 = MST017.TIMETABLE_LECTURE" +
                    "	AND" +
                        "	MST012.ID_SUBJECT4 = MST013.ID_SUBJECT" +
                    "	AND MST012.ID_USER = ?)" +
                    "	4_TBL" +

                    ",	(SELECT" +
                        "	MST012.DAY_LECTURE5" +
                        ",	MST013.NAME_SUBJECT" +
                        ",	MST017.START_LECTURE" +
                        ",	MST017.END_LECTURE" +
                    "	FROM" +
                        "	MST012_PERSONALMST MST012" +
                        ",	MST013_SUBJECTMST MST013" +
                        ",	MST017_TIMETABLEMST MST017" +
                    "	WHERE" +
                        "	MST012.DAY_LECTURE5 = MST017.DAY_LECTURE" +
                    "	AND" +
                        "	MST012.TIMETABLE_LECTURE5 = MST017.TIMETABLE_LECTURE" +
                    "	AND" +
                        "	MST012.ID_SUBJECT5 = MST013.ID_SUBJECT" +
                    "	AND" +
                        "	MST012.ID_USER = ?)" +
                    "	5_TBL";

        return sql;
    }


    /**
     * 時間割に必要な情報を取得する
     * @param id_user
     * @return 時間割用リスト
     */
    public List<CLS002Bean> substituteFindByUser(String id_user) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLTRN005_SubstituteFindByUser();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, id_user);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setId_cource(rs.getString("ID_COURSE"));
                bean.setName_subject(rs.getString("NAME_SUBJECT"));
                bean.setStart_lecture(rs.getTimestamp("START_SUBSTITUTE"));
                bean.setEnd_lecture(rs.getTimestamp("END_SUBSTITUTE"));
                bean.setDate_substitute(rs.getTimestamp("START_LECTURE"));
                bean.setFlg_delete(rs.getInt("FLG_DELETE"));
                cls002Beans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return cls002Beans;
    }

    /**
     * コースの授業をカレンダー表示用のSQL文を作成します。
     */
    public String createSQLCourseSubjectTimeTableFindByUser () {

        Mst016_GetCourseMstDAO mst016_GetCourseMstDAO = new Mst016_GetCourseMstDAO();
        Mst011_CourseMeisaiMstDAO mst011_CourseMeisaiMstDAO = new Mst011_CourseMeisaiMstDAO();
        Mst013_SubjectMstDAO mst013_SubjectMstDAO = new Mst013_SubjectMstDAO();

        StringBuffer stringBuffer = new StringBuffer();

        stringBuffer.append("SELECT");
            stringBuffer.append("	M016.ID_COURSE");
            stringBuffer.append(",	M013.NAME_SUBJECT");
            stringBuffer.append(",	M011.DAY_LECTURE");
            stringBuffer.append(",	M011.START_TIME_LECTURE");
            stringBuffer.append(",	M011.END_TIME_LECTURE");
            stringBuffer.append(",	M011.START_LECTURE");
            stringBuffer.append(",	M011.END_LECTURE");
        stringBuffer.append("	FROM");
            stringBuffer.append("	" + mst016_GetCourseMstDAO.getTableName() +" M016");
            stringBuffer.append(",	" + mst013_SubjectMstDAO.getTableName() +" M013");
            stringBuffer.append(",	" + mst011_CourseMeisaiMstDAO.getTableName() +" M011");
        stringBuffer.append("	WHERE");
            stringBuffer.append("	M016.ID_COURSE = M011.ID_COURSE");
        stringBuffer.append("	AND");
            stringBuffer.append("	M011.ID_SUBJECT = M013.ID_SUBJECT");
        stringBuffer.append("	AND");
            stringBuffer.append("	M016.ID_USER = ?");
        stringBuffer.append("	ORDER BY M011.DAY_LECTURE, M011.START_TIME_LECTURE");

        System.out.println(stringBuffer.toString());
        return stringBuffer.toString();
    }

    public String createSQLPersonalHomeWorkTABLEFindByUserandDate() {

        String sql =
            "SELECT" +
                " TRN003.ID_USER" +
                ", TRN003.DATE_LECTURE" +
                ", TRN003.HOMEWORK" +
                ", TRN003.FLG_DELETE" +
            " FROM" +
                " TRN003_PERSONALHOMEWORKTRN AS TRN003" +
            " WHERE" +
            " TRN003.DATE_LECTURE BETWEEN" +
            "? AND ?" +
            " AND" +
                " TRN003.ID_USER = ?" +
            " AND" +
                " TRN003.FLG_DELETE <> 1 ";
        System.out.println(sql);
        return sql;
    }

    public String createSQLHomeWorkTableFindByUserandDate() {
        String sql =
                "SELECT" +
                "  MST016.ID_USER" +
                ", TRN002.DATE_LECTURE" +
                ", TRN002.HOMEWORK" +
                ", TRN002.FLG_DELETE" +
            " FROM" +
                " TRN002_HOMEWORKTRN AS TRN002" +
                " LEFT JOIN" +
                " MST016_GETCOURSEMST AS MST016" +
                " ON" +
                " TRN002.ID_COURSE = MST016.ID_COURSE" +
            " WHERE" +
                    " TRN002.DATE_LECTURE BETWEEN ? AND ?" +
                " AND" +
                    " MST016.ID_USER = ?" +
                " AND" +
                    " TRN002.FLG_DELETE <> 1 " +
                " AND" +
                    " MST016.FLG_DELETE <> 1 ";
        return sql;
    }

    /**
     * 指定したユーザの指定した月の通常授業の宿題が設定されている日付とその宿題をリスト取得します。
     * @param String id_user、int 月
     * @return 宿題リスト（CLS002Bean）
     */
    public List<CLS002Bean> getHomeWorkTimeTableList (String id_user,int month) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        String strmonth = null;
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        if (month < 10) {
            strmonth = "0" + String.valueOf(month);
        } else {
            strmonth = String.valueOf(month);
        }
        String beginmonth = String.valueOf(year) + "-" + strmonth + "-" + "01";
        String lastmonth = String.valueOf(year) + "-" + strmonth + "-" + String.valueOf(calendar.getActualMaximum(Calendar.DATE));

        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLHomeWorkTableFindByUserandDate();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, beginmonth);
            stmt.setString(2, lastmonth);
            stmt.setString(3, id_user);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setId_user(rs.getString("ID_USER"));
                bean.setDate_lecture(rs.getTimestamp("DATE_LECTURE"));
                bean.setHomework(rs.getString("HOMEWORK"));
                bean.setFlg_delete(rs.getInt("FLG_DELETE"));
                cls002Beans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return cls002Beans;
    }
    /**
     * 指定したユーザの指定した月の通常授業の宿題が設定されている日付とその宿題をリスト取得します。
     * @param String id_user、int 月
     * @return 宿題リスト（CLS002Bean）
     */
    public List<CLS002Bean> PersonalHomeWorkTABLEFindByUserandDate (String id_user,int month) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        String strmonth = null;
        System.out.println(month);
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        if (month < 10) {
            strmonth = "0" + String.valueOf(month);
        } else {
            strmonth = String.valueOf(month);
        }
        String beginmonth = String.valueOf(year) + "-" + strmonth + "-" + "01";
        String lastmonth = String.valueOf(year) + "-" + strmonth + "-" + String.valueOf(calendar.getActualMaximum(Calendar.DATE));

        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLPersonalHomeWorkTABLEFindByUserandDate();
        System.out.println(sql);
        System.out.println(beginmonth);
        System.out.println(lastmonth);
        System.out.println(id_user);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, beginmonth);
            stmt.setString(2, lastmonth);
            stmt.setString(3, id_user);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setId_user(rs.getString("ID_USER"));
                bean.setDate_lecture(rs.getTimestamp("DATE_LECTURE"));
                bean.setHomework(rs.getString("HOMEWORK"));
                bean.setFlg_delete(rs.getInt("FLG_DELETE"));
                cls002Beans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return cls002Beans;
    }

    public List<CLS002Bean> CourseSubjectTimeTableFindByUser (String id_user) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;

        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLCourseSubjectTimeTableFindByUser();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            timestamp.toString().split(" ");
            stmt.setString(1, id_user);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setId_cource(rs.getString("ID_COURSE"));
                bean.setName_subject(rs.getString("NAME_SUBJECT"));
                bean.setDay_lecture(rs.getInt("DAY_LECTURE"));
                bean.setStart_time_lecture(rs.getTimestamp("START_TIME_LECTURE"));
                bean.setEnd_time_lecture(rs.getTimestamp("END_TIME_LECTURE"));
                bean.setStart_lecture(rs.getTimestamp("START_LECTURE"));
                bean.setEnd_lecture(rs.getTimestamp("END_LECTURE"));
                cls002Beans.add(bean);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }


        return cls002Beans;
    }


    public List<CLS002Bean> PersonalSubjectTimeTableFindByuser (String id_user) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;

        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLPersonalSubjectTimeTableFindByuser();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, id_user);
            stmt.setString(2, id_user);
            stmt.setString(3, id_user);
            stmt.setString(4, id_user);
            stmt.setString(5, id_user);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setName_subject(rs.getString("NAME_SUBJECT"));
                bean.setDay_lecture(rs.getInt("DAY_LECTURE1"));
                bean.setStart_lecture(rs.getTimestamp("START_LECTURE"));
                bean.setEnd_lecture(rs.getTimestamp("END_LECTURE"));
                cls002Beans.add(bean);

                CLS002Bean bean2 = new CLS002Bean();
                bean2.setName_subject(rs.getString("NAME_SUBJECT_2"));
                bean2.setDay_lecture(rs.getInt("DAY_LECTURE2"));
                bean2.setStart_lecture(rs.getTimestamp("START_LECTURE_2"));
                bean2.setEnd_lecture(rs.getTimestamp("END_LECTURE_2"));
                cls002Beans.add(bean2);

                CLS002Bean bean3 = new CLS002Bean();
                bean3.setName_subject(rs.getString("NAME_SUBJECT_3"));
                bean3.setDay_lecture(rs.getInt("DAY_LECTURE3"));
                bean3.setStart_lecture(rs.getTimestamp("START_LECTURE_3"));
                bean3.setEnd_lecture(rs.getTimestamp("END_LECTURE_3"));
                cls002Beans.add(bean3);

                CLS002Bean bean4 = new CLS002Bean();
                bean4.setName_subject(rs.getString("NAME_SUBJECT_4"));
                bean4.setDay_lecture(rs.getInt("DAY_LECTURE4"));
                bean4.setStart_lecture(rs.getTimestamp("START_LECTURE_4"));
                bean4.setEnd_lecture(rs.getTimestamp("END_LECTURE_4"));
                cls002Beans.add(bean4);

                CLS002Bean bean5 = new CLS002Bean();
                bean5.setName_subject(rs.getString("NAME_SUBJECT_5"));
                bean5.setDay_lecture(rs.getInt("DAY_LECTURE5"));
                bean5.setStart_lecture(rs.getTimestamp("START_LECTURE_5"));
                bean5.setEnd_lecture(rs.getTimestamp("END_LECTURE_5"));
                cls002Beans.add(bean5);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }


        return cls002Beans;
    }

}
