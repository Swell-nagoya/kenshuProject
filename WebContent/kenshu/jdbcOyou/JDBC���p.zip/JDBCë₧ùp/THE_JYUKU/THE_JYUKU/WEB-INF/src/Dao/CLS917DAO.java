package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.CLS917Exception;

import bean.CLS917Bean;
import bean.Mst001_UserMstBean;
import bean.Mst014_SchoolMstBean;
import bean.Trn900_NfcTrnBean;

public class CLS917DAO extends ConnectionManager {
	public static CLS917DAO cls917dao;
	public static CLS917DAO getInstance() {
		if (cls917dao == null) {
			cls917dao = new CLS917DAO();
		}
		return cls917dao;
	}

	public String getSQLMst001findlist() {
		String str = "select MST001_USERMST.ID_USER" +
			", NAME_USER" +
			", KANA_NAME_USER" +
			", DATE_ACCESS " +
			", TIME_INCRAMMER " +
			", TIME_OUTCRAMMER " +
			", FLAG_DELETE	" +
			" from " +
			" MST001_USERMST " +
			" inner join " +
			" TRN900_NFCTRN " +
			" on " +
			"MST001_USERMST.ID_USER=TRN900_NFCTRN.ID_USER";
		StringBuffer sb = new StringBuffer(str);
			sb.append(" where ");
			sb.append("MST001_USERMST.ID_USER = ?");
			sb.append(" and ");
			sb.append("DATE_ACCESS >= ?");
			sb.append("and DATE_ACCESS < ?");
		return sb.toString();
	}
	public String getSQLMst001find() {
		String str = "select MST001_USERMST.ID_USER" +
			", NAME_USER" +
			", KANA_NAME_USER" +
			", DATE_ACCESS " +
			", TIME_INCRAMMER " +
			", TIME_OUTCRAMMER " +
			", FLAG_DELETE	" +
			" from " +
			" MST001_USERMST " +
			" inner join " +
			" TRN900_NFCTRN " +
			" on " +
			"MST001_USERMST.ID_USER=TRN900_NFCTRN.ID_USER";
		StringBuffer sb = new StringBuffer(str);
			sb.append(" where ");
			sb.append("MST001_USERMST.ID_USER = ?");
			sb.append(" and ");
			sb.append("DATE_ACCESS = ?");
		return sb.toString();
	}

	public List<CLS917Bean> getUserListByColumns(String id_user, String strdate, String strenddate) throws CLS917Exception {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		//取得対象のパラメータ
		List<CLS917Bean> list = new ArrayList<>();
		//検索対象のパラむ
		List<String> palam = new ArrayList<>();
		//検索対象の値
		List <String> value = new ArrayList<>();

		//パラメーターの設定（ユーザーマスタ）
		//他の検索条件は取り敢えず当面使わないので、使用する場合には
		//ここの部分の処理をエンハンスする必要がある。

		//パラメータのチェック
		if (id_user == null || id_user.equals(""))
			throw new CLS917Exception();
		if (strdate == null || strdate.equals(""))
			throw new CLS917Exception();

		String sql = getSQLMst001findlist();

		try {
			stmt = getConnection().prepareStatement(sql);
			value.add(id_user);
			//登校、帰宅のカラムのどちらも検索対象に入れる
			value.add(strdate);
			value.add(strenddate);
			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}
			rs = stmt.executeQuery();
			while (rs.next()) {
				CLS917Bean cls917Bean = new CLS917Bean();
				Mst001_UserMstBean bean = new Mst001_UserMstBean();
				bean.setId_user(rs.getString("ID_USER"));
				bean.setName(rs.getString("NAME_USER"));
				bean.setKana_name(rs.getString("KANA_NAME_USER"));
				cls917Bean.setmst001_UserMstBean(bean);
				Trn900_NfcTrnBean trn900Bean = new Trn900_NfcTrnBean();
				trn900Bean.setDate_access(rs.getTimestamp("DATE_ACCESS"));
				trn900Bean.setTime_incrammer(rs.getInt("TIME_INCRAMMER"));
				trn900Bean.setTime_outcrammer(rs.getInt("TIME_OUTCRAMMER"));
				trn900Bean.setFlag_delete(rs.getInt("FLAG_DELETE"));
				cls917Bean.setBean(trn900Bean);
				list.add(cls917Bean);
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return list;
	}

	public Trn900_NfcTrnBean getNfcTrnData(String id_user, String strdate) throws CLS917Exception {
		Trn900_NfcTrnBean trn900Bean = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		//取得対象のパラメータ
		//検索対象の値
		List <String> value = new ArrayList<>();

		//パラメーターの設定（ユーザーマスタ）
		//他の検索条件は取り敢えず当面使わないので、使用する場合には
		//ここの部分の処理をエンハンスする必要がある。

		//パラメータのチェック
		if (id_user == null || id_user.equals(""))
			throw new CLS917Exception();
		if (strdate == null || strdate.equals(""))
			throw new CLS917Exception();

		String sql = getSQLMst001find();
		try {
			stmt = getConnection().prepareStatement(sql);
			value.add(id_user);
			//登校、帰宅のカラムのどちらも検索対象に入れる
			value.add(strdate);
			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}

			rs = stmt.executeQuery();
			if (rs.next()) {
				trn900Bean = new Trn900_NfcTrnBean();
				trn900Bean.setId_user(rs.getString("ID_USER"));
				trn900Bean.setDate_access(rs.getTimestamp("DATE_ACCESS"));
				trn900Bean.setTime_incrammer(rs.getInt("TIME_INCRAMMER"));
				trn900Bean.setTime_outcrammer(rs.getInt("TIME_OUTCRAMMER"));
				trn900Bean.setFlag_delete(rs.getInt("FLAG_DELETE"));
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return trn900Bean;
	}
}
