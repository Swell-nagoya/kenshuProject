package Dao;					
					
import bean.Mst015_NewsMstBean;					
					
public class Mst015_NewsMstDAO extends DataAccessObject {					
					
		/**			
		 * �o�^�������s���܂��B			
		 * @param Mst015_NewsMst mst015_newsmst			
		 */			
		public void create(Mst015_NewsMstBean mst015_newsmst) {			
			update(createSQLForCreate(),		
				new Object[] {	
				mst015_newsmst.getid_news()	
				,mst015_newsmst.gettarget()	
				,mst015_newsmst.gettitle_news()	
				,mst015_newsmst.getmeisai_news()	
				,mst015_newsmst.getstart_news()	
				,mst015_newsmst.getend_news()	
				,mst015_newsmst.getflg_delete()	
				,mst015_newsmst.getid_lastupdate()	
				,mst015_newsmst.getdate_lastupdate()	
				});	
		}			
					
		/**			
		 * �X�V�������s���܂��B			
		 * @param Mst015_NewsMst mst015_newsmst			
		 */			
		public void update(Mst015_NewsMstBean mst015_newsmst) {			
			update(createSQLForUpdate(),		
				new Object[] {	
				mst015_newsmst.getid_news()	
				,mst015_newsmst.gettarget()	
				,mst015_newsmst.gettitle_news()	
				,mst015_newsmst.getmeisai_news()	
				,mst015_newsmst.getstart_news()	
				,mst015_newsmst.getend_news()	
				,mst015_newsmst.getflg_delete()	
				,mst015_newsmst.getid_lastupdate()	
				,mst015_newsmst.getdate_lastupdate()	
				});	
		}			
					
		/**			
		 * ��L�[�������s���܂��B			
		 * @param ID_NEWS �j���[�XID			
		 * @return ID_NEWS			
		 * @param TARGET �Ώۊw�N			
		 * @return TARGET			
		 */			
		public Mst015_NewsMstBean findByPrimaryKey(java.lang.Integer userno) {			
			return (Mst015_NewsMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst015_NewsMstBean.class);		
		}			
					
		@Override			
		public String[] getPKColumns() {			
			return new String[] {"ID_NEWS","TARGET"};		
		}			
					
		@Override			
		public String[] getColumns() {			
			return new String[] {"ID_NEWS"		
				,"TARGET"	
				,"TITLE_NEWS"	
				,"MEISAI_NEWS"	
				,"START_NEWS"	
				,"END_NEWS"	
				,"FLG_DELETE"	
				,"ID_LASTUPDATE"	
				,"DATE_LASTUPDATE"	
			};		
		}			
					
		@Override			
		public String getTableName() {			
			return "Mst015_NEWSMST";		
		}			
					
}					
