package bean;

public class CLS913Bean {

	Mst014_SchoolMstBean mst014_SchoolMstBean = null;

	/**
	 * Mst014_SchoolMstを設定します。
	 * 
	 * @param Mst014_SchoolMstBean
	 */
	public void setMst014_SchoolMstBean(Mst014_SchoolMstBean mst014_SchoolMstBean) {
		this.mst014_SchoolMstBean = mst014_SchoolMstBean;
	}

	/**
	 * Mst014_SchoolMstを取得します。
	 * 
	 * @return Mst014_SchoolMstBean
	 */
	public Mst014_SchoolMstBean getMst014_SchoolMstBean() {
		return mst014_SchoolMstBean;
	}
}