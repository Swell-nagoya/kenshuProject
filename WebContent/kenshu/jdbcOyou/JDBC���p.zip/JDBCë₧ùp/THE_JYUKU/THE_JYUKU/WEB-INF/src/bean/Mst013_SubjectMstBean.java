package bean;

import java.sql.Timestamp;

public class Mst013_SubjectMstBean {




//科目ID
String id_subject = null;
//科目名
String name_subject = null;
//削除フラグ
int flg_delete = 0;
//最終更新ID
String id_lastupdate = null;
//最終更新日
Timestamp date_lastupdate = null;



/**
 * 科目IDを設定します。
 * @param id_subject
 */
public void setid_subject(String id_subject) {
	this.id_subject = id_subject;
}

/**
 * 科目名を設定します。
 * @param name_subject
 */
public void setname_subject(String name_subject) {
	this.name_subject = name_subject;
}

/**
 * 削除フラグを設定します。
 * @param flg_delete
 */
public void setflg_delete(int flg_delete) {
	this.flg_delete = flg_delete;
}

/**
 * 最終更新IDを設定します。
 * @param id_lastupdate
 */
public void setid_lastupdate(String id_lastupdate) {
	this.id_lastupdate = id_lastupdate;
}

/**
 * 最終更新日を設定します。
 * @param date_lastupdate
 */
public void setdate_lastupdate(Timestamp date_lastupdate) {
	this.date_lastupdate = date_lastupdate;
}


/**
 * 科目IDを取得します。
 * @param id_subject
 */
public String getid_subject() {
	return id_subject;
}

/**
 * 科目名を取得します。
 * @param name_subject
 */
public String getname_subject() {
	return name_subject;
}

/**
 * 削除フラグを取得します。
 * @param flg_delete
 */
public int getflg_delete() {
	return flg_delete;
}

/**
 * 最終更新IDを取得します。
 * @param id_lastupdate
 */
public String getid_lastupdate() {
	return id_lastupdate;
}

/**
 * 最終更新日を取得します。
 * @param date_lastupdate
 */
public Timestamp getdate_lastupdate() {
	return date_lastupdate;
}
}
