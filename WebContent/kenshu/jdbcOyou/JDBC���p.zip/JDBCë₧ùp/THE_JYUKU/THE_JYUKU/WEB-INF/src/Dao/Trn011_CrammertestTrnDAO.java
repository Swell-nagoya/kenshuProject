				
package Dao;				
				
import bean.Trn011_CrammertestTrnBean;				
				
public class Trn011_CrammertestTrnDAO extends DataAccessObject {				
				
		/**		
		 * �o�^�������s���܂��B		
		 * @param Trn011_CrammertestTrn trn011_crammertesttrn		
		 */		
		public void create(Trn011_CrammertestTrnBean trn011_crammertesttrn) {		
			update(createSQLForCreate(),	
				new Object[] {
				trn011_crammertesttrn.getid_user()
				,trn011_crammertesttrn.getid_test()
				,trn011_crammertesttrn.getmarks_jap()
				,trn011_crammertesttrn.getdeviation_jap()
				,trn011_crammertesttrn.getmarks_math()
				,trn011_crammertesttrn.getdeviation_math()
				,trn011_crammertesttrn.getmarks_siec()
				,trn011_crammertesttrn.getdeviation_siec()
				,trn011_crammertesttrn.getmarks_scty()
				,trn011_crammertesttrn.getdeviation_scty()
				,trn011_crammertesttrn.getmarks_eng()
				,trn011_crammertesttrn.getdeviation_eng()
				,trn011_crammertesttrn.getdeviation_five()
				,trn011_crammertesttrn.getflg_delete()
				,trn011_crammertesttrn.getid_lastupdate()
				,trn011_crammertesttrn.getdate_lastupdate()
				});
		}		

		/**		
		 * �X�V�������s���܂��B		
		 * @param Trn011_CrammertestTrn trn011_crammertesttrn		
		 */		
		public void update(Trn011_CrammertestTrnBean trn011_crammertesttrn) {		
			update(createSQLForUpdate(),	
				new Object[] {
				trn011_crammertesttrn.getid_user()
				,trn011_crammertesttrn.getid_test()
				,trn011_crammertesttrn.getmarks_jap()
				,trn011_crammertesttrn.getdeviation_jap()
				,trn011_crammertesttrn.getmarks_math()
				,trn011_crammertesttrn.getdeviation_math()
				,trn011_crammertesttrn.getmarks_siec()
				,trn011_crammertesttrn.getdeviation_siec()
				,trn011_crammertesttrn.getmarks_scty()
				,trn011_crammertesttrn.getdeviation_scty()
				,trn011_crammertesttrn.getmarks_eng()
				,trn011_crammertesttrn.getdeviation_eng()
				,trn011_crammertesttrn.getdeviation_five()
				,trn011_crammertesttrn.getflg_delete()
				,trn011_crammertesttrn.getid_lastupdate()
				,trn011_crammertesttrn.getdate_lastupdate()
				});
		}		

		/**		
		 * ��L�[�������s���܂��B		
		 * @param id_user ���[�U�[ID		
		 * @return id_user		
		 * @param id_test �e�X�gID		
		 * @return id_test		
		 */		
		public Trn011_CrammertestTrnBean findByPrimaryKey(java.lang.Integer userno) {		
			return (Trn011_CrammertestTrnBean) query(createSQLForFindByPK(), new Object[]{userno}, Trn011_CrammertestTrnBean.class);	
		}		

		@Override		
		public String[] getPKColumns() {		
			return new String[] {"id_user","id_test"};	
		}		

		@Override		
		public String[] getColumns() {		
			return new String[] {"ID_USER"	
				,"ID_TEST"
				,"MARKS_JAP"
				,"DEVIATION_JAP"
				,"MARKS_MATH"
				,"DEVIATION_MATH"
				,"MARKS_SIEC"
				,"DEVIATION_SIEC"
				,"MARKS_SCTY"
				,"DEVIATION_SCTY"
				,"MARKS_ENG"
				,"DEVIATION_ENG"
				,"DEVIATION_FIVE"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};	
		}		

		@Override		
		public String getTableName() {	
			return "TRN011_CRAMMERTESTTRN";
		}	

}			
