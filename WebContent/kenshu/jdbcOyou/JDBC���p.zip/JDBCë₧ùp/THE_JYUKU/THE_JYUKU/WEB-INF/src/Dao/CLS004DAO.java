package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import bean.CLS002Bean;
import bean.Mst017_TimeTableMstBean;

public class CLS004DAO extends ConnectionManager {
    Mst012_PersonalMstDAO mst012_PersonalMstDAO = new Mst012_PersonalMstDAO();

    Mst012_PersonalMstDAO mst012_PersonalMstDAO2 = new Mst012_PersonalMstDAO();
    Mst013_SubjectMstDAO mst013_SubjectMstDAO = new Mst013_SubjectMstDAO();
    Mst017_TimeTableMstDAO mst017_TimeTableMstDAO = new Mst017_TimeTableMstDAO();


    private String createSQLTRN005_SubstituteFindByUser() {
        Trn005_SubstituteTrnDAO substituteTrnDAO = new Trn005_SubstituteTrnDAO();

        StringBuffer buffer = new StringBuffer();

        buffer.append("select ")
            .append(substituteTrnDAO.join(substituteTrnDAO.getColumns(), ", "))
            .append(" from ")
            .append("	TRN005_SUBSTITUTETRN")
            .append(" where ")
            .append("	ID_USER = ?");

        return buffer.toString();
    }


    /**
     * 通常授業の取得用のSQL文を取得する
     * @return 通常授業用のSQL
     */
    private String createSQLPersonalSubjectTimeTableFindByuser() {
        Mst016_GetCourseMstDAO mst016_GetCourseMstDAO = new Mst016_GetCourseMstDAO();
        Mst011_CourseMeisaiMstDAO mst011_CourseMeisaiMstDAO = new Mst011_CourseMeisaiMstDAO();
        Mst013_SubjectMstDAO mst013_SubjectMstDAO = new Mst013_SubjectMstDAO();
        Mst001_UserMstDAO mst001_UserMstDAO = new Mst001_UserMstDAO();
        StringBuffer stringBuffer = new StringBuffer();


        stringBuffer.append("select")
                    .append("	M016.ID_USER")
                    .append(",	M016.ID_COURSE")
                    .append(",	M013.NAME_SUBJECT")
                    .append(",	M011.DAY_LECTURE")
                    .append(",	M011.START_TIME_LECTURE")
                    .append(",	M011.END_TIME_LECTURE")
                    .append(",	M011.START_LECTURE")
                    .append(",	M011.END_LECTURE")
                    .append(",	M01.NAME_USER")
                .append("	from")
                .append("	" + mst016_GetCourseMstDAO.getTableName() +" M016")
                .append(",	" + mst013_SubjectMstDAO.getTableName() +" M013")
                .append(",	" + mst011_CourseMeisaiMstDAO.getTableName() +" M011")
                .append(" left join ")
                .append("	" + mst001_UserMstDAO.getTableName() + " M01")
                .append(" on " + "M011.ID_TEACHER")
                .append(" = ")
                .append(" M01.ID_USER")
                .append("	where")
                    .append("	M016.ID_COURSE = M011.ID_COURSE")
                .append("	and")
                    .append("	M011.ID_SUBJECT = M013.ID_SUBJECT")
                .append("	and")
                    .append("	M016.FLG_DELETE <> 1")
                .append("	and")
                    .append("	M016.ID_USER = ?")
                .append("	and")
                    .append("	M011.START_LECTURE < ?")
                .append("	and")
                    .append("	M011.END_LECTURE > ?");

        System.out.println(stringBuffer.toString());
        return stringBuffer.toString();
    }

    /**
     * 時間割の時間を取得するSQL文を作成します。
     * @return 時間割のリスト
     */
    private String createSQLPersonalSubjectTimeTableFind() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("select ")
            .append(mst017_TimeTableMstDAO.join(mst017_TimeTableMstDAO.getColumns(), ", "))
            .append(" from ")
            .append(mst017_TimeTableMstDAO.getTableName());
        return buffer.toString();
    }


    /**
     * 時間割に必要な情報を取得する
     * @param id_user
     * @return 時間割用リスト
     */
    public List<CLS002Bean> SubstituteFindByUser(String id_user) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLTRN005_SubstituteFindByUser();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, id_user);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setId_cource(rs.getString("ID_COURSE"));
                bean.setFlg_delete(rs.getInt("FLG_SUBSTITUTE"));
                bean.setTimetable_lecture(rs.getInt("TIMETABLE_LECTURE"));
                bean.setDate_lecture(rs.getTimestamp("DATE_LECTURE"));
                bean.setTimetable_substitute(rs.getInt("TIMETABLE_SUBSTITUTE"));
                bean.setDate_substitute(rs.getTimestamp("DATE_SUBSTITUTE"));
                bean.setFlg_delete(rs.getInt("FLG_DELETE"));
                cls002Beans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return cls002Beans;
    }

    /**
     * 時間割に必要な情報を取得する
     * @param id_user
     * @return 時間割用リスト
     */
    public List<CLS002Bean> PersonalSubjectTimeTableFindByUser(String id_user, Timestamp timestamp) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        List<CLS002Bean> cls002Beans = new ArrayList<CLS002Bean>();

        sql = createSQLPersonalSubjectTimeTableFindByuser();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, id_user);
            stmt.setTimestamp(2, timestamp);
            stmt.setTimestamp(3, timestamp);
            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS002Bean bean = new CLS002Bean();
                bean.setId_user(rs.getString("ID_USER"));
                bean.setId_cource(rs.getString("ID_COURSE"));
                bean.setName_teacher(rs.getString("NAME_USER"));
                bean.setName_subject(rs.getString("NAME_SUBJECT"));
                bean.setDay_lecture(rs.getInt("DAY_LECTURE"));
                bean.setStart_time_lecture(rs.getTimestamp("START_TIME_LECTURE"));
                bean.setEnd_time_lecture(rs.getTimestamp("END_TIME_LECTURE"));
                bean.setStart_lecture(rs.getTimestamp("START_LECTURE"));
                bean.setEnd_lecture(rs.getTimestamp("END_LECTURE"));
                cls002Beans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return cls002Beans;
    }

    /**
     * 時間割に表示するための時間を取得する
     * @return 時間割用リスト
     */
    public List<Mst017_TimeTableMstBean> PersonalSubjectTimeTableFind() {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        List<Mst017_TimeTableMstBean> mst017Beans = new ArrayList<Mst017_TimeTableMstBean>();

        sql = createSQLPersonalSubjectTimeTableFind();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Mst017_TimeTableMstBean bean = new Mst017_TimeTableMstBean();
                bean.setday_lecture(rs.getInt("DAY_LECTURE"));
                bean.settimetable_lecture(rs.getInt("TIMETABLE_LECTURE"));
                bean.setstart_lecture(rs.getTimestamp("START_LECTURE"));
                bean.setend_lecture(rs.getTimestamp("END_LECTURE"));
                bean.setflg_delete(rs.getInt("FLG_DELETE"));
                bean.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
                bean.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
                mst017Beans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return mst017Beans;
    }


}
