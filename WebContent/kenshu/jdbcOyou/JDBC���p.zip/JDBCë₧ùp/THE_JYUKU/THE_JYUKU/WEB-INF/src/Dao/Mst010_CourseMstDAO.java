
package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Mst010_CourseMstBean;

public class Mst010_CourseMstDAO extends DataAccessObject {


		/**
		 * 登録処理を行います。
		 * @param MST010_COURSEMST Mst010_CourseMst
		 */
		public void create(Mst010_CourseMstBean Mst010_CourseMst) {
			update(createSQLForCreate(),
				new Object[] {
				Mst010_CourseMst.getid_course()
				,Mst010_CourseMst.getname_course()
				,Mst010_CourseMst.getstart_lecture()
				,Mst010_CourseMst.getend_lecture()
				,Mst010_CourseMst.gettuition()
				,Mst010_CourseMst.getdetails_course()
				,Mst010_CourseMst.getid_lastupdate()
				,Mst010_CourseMst.getdate_lastupdate()
				});
		}

		/**
		 * 更新処理を行います。
		 * @param MST010_COURSEMST Mst010_CourseMst
		 */
		public void update(Mst010_CourseMstBean Mst010_CourseMst) {
			update(createSQLForUpdate(),
				new Object[] {
				Mst010_CourseMst.getid_course()
				,Mst010_CourseMst.getname_course()
				,Mst010_CourseMst.getstart_lecture()
				,Mst010_CourseMst.getend_lecture()
				,Mst010_CourseMst.gettuition()
				,Mst010_CourseMst.getdetails_course()
				,Mst010_CourseMst.getid_lastupdate()
				,Mst010_CourseMst.getdate_lastupdate()
				,Mst010_CourseMst.getid_course()
				});
		}

		/**
		 * 主キー検索を行います。
		 * @param ID_COURSE コースID
		 * @return ID_COURSE
		 */
		public Mst010_CourseMstBean findByPrimaryKey(java.lang.Integer userno) {
			return (Mst010_CourseMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst010_CourseMstBean.class);
		}

		@Override
		public String[] getPKColumns() {
			return new String[] {"ID_COURSE"};
		}

		@Override
		public String[] getColumns() {
			return new String[] {"ID_COURSE"
				,"NAME_COURSE"
				,"START_LECTURE"
				,"END_LECTURE"
				,"TUITION"
				,"DETAILS_COURSE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};
		}

		@Override
		public String getTableName() {
			return "MST010_COURSEMST";
		}



		/**
		 * コースIDでの検索用SQL
		 */
		private static final String SQL_FIND_BY_ID_COURSE =
			"SELECT" +
			"	ID_COURSE" +
			"	,NAME_COURSE" +
			"	,START_LECTURE" +
			"	,END_LECTURE" +
			"	,TUITION" +
			"	,DETAILS_COURSE" +
			"	,ID_LASTUPDATE" +
			"	,DATE_LASTUPDATE" +
			" FROM" +
			"	MST010_COURSEMST" +
			" WHERE" +
			"	ID_COURSE = ?";

		/**
		 * 特定のコースIDと一致する行数を取得します。
		 */
		private static final String SQL_GET_COUNT_BY_ID_COURSE =
			"SELECT" +
			"	COUNT(*)" +
			" FROM" +
			"	MST010_COURSEMST" +
			" WHERE" +
			"	ID_COURSE = ?";

		/**
		 * USER表からユーザIDと一致する行数を検索します。
		 * @param id ユーザーID
		 * @return Integer 行数
		 */
		public int getCountById (String id) {

			int num = -1;

			PreparedStatement stmt = null;
			ResultSet rs = null;

			try {
				stmt = getConnection().prepareStatement(SQL_GET_COUNT_BY_ID_COURSE);
				System.out.println(SQL_GET_COUNT_BY_ID_COURSE);
				System.out.println("id:" + id);
				fillPreparedStatement(stmt, 1, id);
				rs = stmt.executeQuery();

				if(rs.next()) {
					num = rs.getInt("count(*)");
				} else {
					System.out.println("カウントが正しく取得できていません。");
				}
			} catch (SQLException e) {
				e.getMessage();
				e.printStackTrace();
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}

				return num;

		}

		/**
		 * コースIDでコースマスタを検索します。
		 * @param id コースID
		 * @return Mst010_CourseMst
		 */
		//PKのため検索結果は1人
		public Mst010_CourseMstBean findById(String id) {
			Mst010_CourseMstBean mst010_CourseMst = new Mst010_CourseMstBean();
			PreparedStatement stmt = null;
			ResultSet rs = null;
			try {
				stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_COURSE);
				System.out.println(SQL_FIND_BY_ID_COURSE);
				System.out.println("id:" + id);
				fillPreparedStatement(stmt, 1, id);
				rs = stmt.executeQuery();

				if (rs.next()) {
					mst010_CourseMst.setid_course(rs.getString("ID_COURSE"));
					mst010_CourseMst.setname_course(rs.getString("NAME_COURSE"));
					mst010_CourseMst.setstart_lecture(rs.getTimestamp("START_LECTURE"));
					mst010_CourseMst.setend_lecture(rs.getTimestamp("END_LECTURE"));
					mst010_CourseMst.settuition(rs.getInt("TUITION"));
					mst010_CourseMst.setdetails_course(rs.getString("DETAILS_COURSE"));
					mst010_CourseMst.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
					mst010_CourseMst.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));

				}

			} catch (SQLException e) {
				e.getMessage();
				e.printStackTrace();
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
			return mst010_CourseMst;


		}


}
