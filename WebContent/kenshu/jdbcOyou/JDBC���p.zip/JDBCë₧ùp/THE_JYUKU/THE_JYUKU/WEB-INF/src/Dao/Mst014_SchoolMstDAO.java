package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import bean.Mst014_SchoolMstBean;

public class Mst014_SchoolMstDAO extends DataAccessObject {

	/**
	 * 登録処理を行います。
	 *
	 * @param Mst014_SchoolMst
	 *            mst014_schoolmst
	 */
	public void create(Mst014_SchoolMstBean mst014_schoolmst) {
		update(createSQLForCreate(),new Object[] { mst014_schoolmst.getid_school(),
						mst014_schoolmst.getname_school(),
						mst014_schoolmst.getaddress_school(),
						mst014_schoolmst.getCategorize_school(),
						mst014_schoolmst.getdistrict_school(),
						mst014_schoolmst.getterm(),
						mst014_schoolmst.gettype_evaluation(),
						mst014_schoolmst.getflg_delete(),
						mst014_schoolmst.getid_lastupdate(),
						mst014_schoolmst.getdate_lastupdate() });
	}

	/**
	 * 更新処理を行います。
	 *
	 * @param Mst014_SchoolMst
	 *            mst014_schoolmst
	 */
	public void update(Mst014_SchoolMstBean mst014_schoolmst) {
		update(createSQLForUpdate(),
				new Object[] {
						mst014_schoolmst.getid_school(),
						mst014_schoolmst.getname_school(),
						mst014_schoolmst.getaddress_school(),
						mst014_schoolmst.getCategorize_school(),
						mst014_schoolmst.getdistrict_school(),
						mst014_schoolmst.getterm(),
						mst014_schoolmst.gettype_evaluation(),
						mst014_schoolmst.getflg_delete(),
						mst014_schoolmst.getid_lastupdate(),
						mst014_schoolmst.getdate_lastupdate(),
						mst014_schoolmst.getid_school()});
	}

	/**
	 * 主キー検索を行います。
	 *
	 * @param ID_SCHOOL
	 *            学校ID
	 * @return ID_SCHOOL
	 */
	public Mst014_SchoolMstBean findByPrimaryKey(java.lang.Integer userno) {
		return (Mst014_SchoolMstBean) query(createSQLForFindByPK(),
				new Object[] { userno }, Mst014_SchoolMstBean.class);
	}

	/**
	 * 学校IDで表を検索します。
	 *
	 * @param id_school
	 *            学校ID
	 * @return Mst014_SchoolMst
	 */
	// PKのため検索結果は1校
	public Mst014_SchoolMstBean findById(String id_school) {
		Mst014_SchoolMstBean mst014_SchoolMst = new Mst014_SchoolMstBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_SCHOOL);
			System.out.println(SQL_FIND_BY_ID_SCHOOL);
			System.out.println("id_school:" + id_school);
			fillPreparedStatement(stmt, 1, id_school);
			rs = stmt.executeQuery();

			if (rs.next()) {
				mst014_SchoolMst.setid_school(rs.getString("id_school"));
				mst014_SchoolMst.setname_school(rs.getString("name_school"));
				mst014_SchoolMst.setaddress_school(rs.getString("address_school"));
				mst014_SchoolMst.setcategorize_school(rs.getInt("categorize_school"));
				mst014_SchoolMst.setdistrict_school(rs.getString("district_school"));
				mst014_SchoolMst.setterm(rs.getInt("term"));
				mst014_SchoolMst.settype_evaluation(rs.getInt("type_evaluation"));
				mst014_SchoolMst.setflg_delete(rs.getInt("flg_delete"));
				mst014_SchoolMst.setid_lastupdate(rs.getString("id_lastupdate"));
				// 最終更新日(ミリ秒での現在時刻の取得)
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				mst014_SchoolMst.setdate_lastupdate(Timestamp.valueOf(timestamp.toString()));
			}
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return mst014_SchoolMst;
	}

	/**
	 * 学校IDでの検索用SQL
	 */
	private static final String SQL_FIND_BY_ID_SCHOOL = "SELECT"
			+ " ID_SCHOOL," + "	NAME_SCHOOL," + " ADDRESS_SCHOOL,"
			+ " CATEGORIZE_SCHOOL," + " DISTRICT_SCHOOL," + " TERM," + " TYPE_EVALUATION,"
			+ "	FLG_DELETE," + " ID_LASTUPDATE," + " DATE_LASTUPDATE  "
			+ " FROM" + " MST014_SCHOOLMST" + " WHERE" + " ID_SCHOOL = ?";

	/**
	 * PKに重複したデータがあるかを確認します。
	 * @param 
	 * @return 重複の有無
	 */
	public boolean isPKDuplicate(String id_school){
		String[] params = {id_school};
		return PKDuplicateCheck(params);
	}
	
	@Override
	public String[] getPKColumns() {
		return new String[] { "ID_SCHOOL" };
	}

	@Override
	public String[] getColumns() {
		return new String[] { "ID_SCHOOL", "NAME_SCHOOL", "ADDRESS_SCHOOL",
				"CATEGORIZE_SCHOOL",  "DISTRICT_SCHOOL", "TERM", "TYPE_EVALUATION",
				"FLG_DELETE", "ID_LASTUPDATE", "DATE_LASTUPDATE" };
	}

	@Override
	public String getTableName() {
		return "MST014_SCHOOLMST";
	}

}
