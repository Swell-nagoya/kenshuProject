package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import common.ServretCommon;

import Dao.CLS913DAO;
import Dao.ConnectionManager;
import Dao.Mst014_SchoolMstDAO;
import bean.CLS913Bean;
import bean.Mst001_UserMstBean;
import bean.Mst014_SchoolMstBean;

/**
 * ユーザマスタ画面から（登録、削除、更新画面に遷移） 検索はこのサーブレットで行う
 *
 * @author d-tanaka
 *
 */
public class CLS913_SchoolSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Sessionの取得
		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		if (session.getAttribute("loginSession") == null)
		{
			request.getRequestDispatcher("JSP/ERROR.jsp").forward(request,response);
			return;
		}
		Mst001_UserMstBean mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");

		// 過去に取得したパラメータを削除
		request.removeAttribute("alert");
		request.removeAttribute("cls913");
		request.removeAttribute("cls913list");
		session.removeAttribute("delete_id_school");

		// beanのbeanの取得
		CLS913Bean cls913 = new CLS913Bean();
		
		// Daoの取得
		CLS913DAO cls913dao = new CLS913DAO();
		Mst014_SchoolMstDAO mst014dao = new Mst014_SchoolMstDAO();
		
		// 取得予定のリスト
		List<CLS913Bean> list = new ArrayList<CLS913Bean>();

		if (request.getParameter("select") != null) {
			/**
			 * 検索機能 :入力値を格納
			 */
			// BeanのBeanに格納
			cls913.setMst014_SchoolMstBean(setInput_Mst014SchoolMstBean(request
					,new Mst014_SchoolMstBean()
					,mst001_UserMstBean.getId_user()));

			ConnectionManager.beginTransaction();
			list = cls913dao.Search(cls913);
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			session.setAttribute("cls913list", list);
			session.setAttribute("cls913", cls913);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS913_SchoolSearch.jsp").forward(request, response);
		}

		// 新規作成
		if (request.getParameter("create") != null) {
			// パラメータの取得
			session.removeAttribute("delete");
			session.removeAttribute("update");
			Mst014_SchoolMstBean mst014_SchoolMstBean = new Mst014_SchoolMstBean();
			
			String id_school = null;
			boolean isDuplicateCheck = true; 
			
			//PKの重複チェック
			ConnectionManager.beginTransaction();
			while(isDuplicateCheck){
				id_school = RandomStringUtils.randomAlphabetic(10);
				isDuplicateCheck = mst014dao.isPKDuplicate(id_school);
			}
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			mst014_SchoolMstBean.setid_school(id_school);
			cls913.setMst014_SchoolMstBean(mst014_SchoolMstBean);
			session.setAttribute("create", cls913);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS914_SchoolInsert.jsp").forward(request, response);
		}
		// 更新
		if (request.getParameter("update") != null) {
			Mst014_SchoolMstDAO dao = new Mst014_SchoolMstDAO();
			String id_school = request.getParameter("id_school");
			Mst014_SchoolMstBean mst014_SchoolMstBean = new Mst014_SchoolMstBean();

			ConnectionManager.beginTransaction();
			mst014_SchoolMstBean = dao.findById(id_school);
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			cls913.setMst014_SchoolMstBean(mst014_SchoolMstBean);
			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.setAttribute("update", cls913);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS914_SchoolInsert.jsp").forward(request, response);
		}

		// 削除
		if (request.getParameter("delete") != null) {
			Mst014_SchoolMstDAO dao = new Mst014_SchoolMstDAO();
			String id_school = request.getParameter("id_school");
			Mst014_SchoolMstBean mst014_SchoolMstBean = new Mst014_SchoolMstBean();

			ConnectionManager.beginTransaction();
			mst014_SchoolMstBean = dao.findById(id_school);
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			cls913.setMst014_SchoolMstBean(mst014_SchoolMstBean);
			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.setAttribute("delete", cls913);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS914_SchoolInsert.jsp").forward(request, response);
		}
	}

	public static Mst014_SchoolMstBean setInput_Mst014SchoolMstBean(HttpServletRequest request,Mst014_SchoolMstBean mst014_SchoolMst,String strIdUser)
	{
		//削除フラグの設定
		int delFlg = 0;
		if (request.getParameter("delete") != null)
		{
			delFlg = 1;
		}

		// 学校ID
		if(!StringUtils.isEmpty(request.getParameter("id_school"))){
			mst014_SchoolMst.setid_school(request.getParameter("id_school"));
		}
		// 学校名
		if(!StringUtils.isEmpty(request.getParameter("name_school"))){
			mst014_SchoolMst.setname_school(request.getParameter("name_school"));
		}
		// 学校種別
		if (!StringUtils.isEmpty(request.getParameter("categorize_school"))) {
			try {
				mst014_SchoolMst.setcategorize_school(Integer.parseInt(request.getParameter("categorize_school")));
			} catch (Exception e){
				// do nothing
			}
		}
		// 住所
		if (!StringUtils.isEmpty(request.getParameter("address_school"))) {
			mst014_SchoolMst.setaddress_school(request.getParameter("address_school"));
		}
		// 学区
		if (!StringUtils.isEmpty(request.getParameter("district_school"))) {
			mst014_SchoolMst.setdistrict_school(request.getParameter("district_school"));
		}
		// 学期
		if (!StringUtils.isEmpty(request.getParameter("term"))) {
			try {
				mst014_SchoolMst.setterm(Integer.parseInt(request.getParameter("term")));
			} catch (Exception e){
				// do nothing
			}
		}
		// 評価段階数
		if (!StringUtils.isEmpty(request.getParameter("type_evaluation"))) {
			try {
				mst014_SchoolMst.settype_evaluation(Integer.parseInt(request.getParameter("type_evaluation")));
			} catch (Exception e){
				// do nothing
			}
		}
		// 削除フラグ
		mst014_SchoolMst.setflg_delete(delFlg);
		//検索処理以外で実行
		if (request.getParameter("select") == null){
			if (!StringUtils.isEmpty(strIdUser)){
				// 最終更新IDは現在nullで入ります。
				mst014_SchoolMst.setid_lastupdate(strIdUser);
			}
			// 最終更新日(ミリ秒での現在時刻の取得)
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			mst014_SchoolMst.setdate_lastupdate(Timestamp.valueOf(timestamp.toString()));
		}
		return mst014_SchoolMst;
	}
}