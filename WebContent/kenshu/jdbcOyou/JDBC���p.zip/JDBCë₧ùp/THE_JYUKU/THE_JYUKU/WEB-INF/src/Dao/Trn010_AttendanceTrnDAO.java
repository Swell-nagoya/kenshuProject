
package Dao;

import java.sql.Timestamp;

import bean.Trn010_AttendanceTrnBean;

public class Trn010_AttendanceTrnDAO extends DataAccessObject {

        /**
         * 登録処理を行います。
         * @param Trn010_AttendanceTrn trn010_attendancetrn
         */
        public void create(Trn010_AttendanceTrnBean trn010_attendancetrn) {
            update(createSQLForCreate(),
                new Object[] {
                trn010_attendancetrn.getid_user()
                ,trn010_attendancetrn.getdate_lecture()
                ,trn010_attendancetrn.getstart_time_lecture()
                ,trn010_attendancetrn.getid_course()
                ,trn010_attendancetrn.getflg_absence()
                ,trn010_attendancetrn.getflg_late()
                ,trn010_attendancetrn.getflg_early()
                ,trn010_attendancetrn.getflg_substitute()
                ,trn010_attendancetrn.getflg_delete()
                ,trn010_attendancetrn.getid_lastupdate()
                ,trn010_attendancetrn.getdate_lastupdate()
                });
        }

        /**
         * 更新処理を行います。
         * @param Trn010_AttendanceTrn trn010_attendancetrn
         */
        public void update(Trn010_AttendanceTrnBean trn010_attendancetrn) {
            update(createSQLForUpdate(),
                new Object[] {
                trn010_attendancetrn.getid_user()
                ,trn010_attendancetrn.getdate_lecture()
                ,trn010_attendancetrn.getstart_time_lecture()
                ,trn010_attendancetrn.getid_course()
                ,trn010_attendancetrn.getflg_absence()
                ,trn010_attendancetrn.getflg_late()
                ,trn010_attendancetrn.getflg_early()
                ,trn010_attendancetrn.getflg_substitute()
                ,trn010_attendancetrn.getflg_delete()
                ,trn010_attendancetrn.getid_lastupdate()
                ,trn010_attendancetrn.getdate_lastupdate()
                ,trn010_attendancetrn.getid_user()
                ,trn010_attendancetrn.getdate_lecture()
                ,trn010_attendancetrn.getstart_time_lecture()
                });
        }

        public int update_PK(Trn010_AttendanceTrnBean trn010_attendancetrn,Timestamp date_lecture) {
            return update(createSQLForUpdate(),
                new Object[] {
                trn010_attendancetrn.getid_user()
                ,trn010_attendancetrn.getdate_lecture()
                ,trn010_attendancetrn.getstart_time_lecture()
                ,trn010_attendancetrn.getid_course()
                ,trn010_attendancetrn.getflg_absence()
                ,trn010_attendancetrn.getflg_late()
                ,trn010_attendancetrn.getflg_early()
                ,trn010_attendancetrn.getflg_substitute()
                ,trn010_attendancetrn.getflg_delete()
                ,trn010_attendancetrn.getid_lastupdate()
                ,trn010_attendancetrn.getdate_lastupdate()
                ,trn010_attendancetrn.getid_user()
                ,date_lecture
                ,trn010_attendancetrn.getstart_time_lecture()
                });
        }

        /**
         * 主キー検索を行います。
         * @param id_user ユーザID
         * @return id_user
         * @param date_lecture 開催日付
         * @return date_lecture
         * @param timetable_lecture 開催時間割
         * @return timetable_lecture
         */
        public Trn010_AttendanceTrnBean findByPrimaryKey(String userno,Timestamp date ,Timestamp hour) {
            return (Trn010_AttendanceTrnBean) query(createSQLForFindByPK(), new Object[]{userno, date, hour}, Trn010_AttendanceTrnBean.class);
        }

        @Override
        public String[] getPKColumns() {
            return new String[] {"id_user","date_lecture","start_time_lecture"};
        }

        @Override
        public String[] getColumns() {
            return new String[] {"ID_USER"
                ,"DATE_LECTURE"
                ,"START_TIME_LECTURE"
                ,"ID_COURSE"
                ,"FLG_ABSENCE"
                ,"FLG_LATE"
                ,"FLG_EARLY"
                ,"FLG_SUBSTITUTE"
                ,"FLG_DELETE"
                ,"ID_LASTUPDATE"
                ,"DATE_LASTUPDATE"
            };
        }

        @Override
        public String getTableName() {
            return "TRN010_ATTENDANCETRN";
        }

}
