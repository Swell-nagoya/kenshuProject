package Dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS907_SearchBean;
import bean.CLS907_SearchResutlBean;
import bean.CLS907_testConstantsBean;

/**
 * テスト情報の検索その他データの操作を行うクラス。
 */
public class CLS907DAO implements ITestDao {

	/**
	 * テスト定数enum
	 * jspでテスト表示の際、条件分岐に使用する。
	 * @author kume
	 *
	 */
	public static enum TestConstant{

		// 北辰テスト
		CRAMMER("HOKUSHIN"),

		// 塾内テスト
		OTHERS("JUKUNAI"),

		// 塾外テスト
		HOKUSHIN("JUKUGAI");

		private String type;

		// コンストラクタ
		private TestConstant(String type) {
			this.type = type;
		}

		// テスト種別Getter
		public String getType() {
			return type;
		}
	}

	/**
	 * 定数マスタからテスト一覧を取得する。
	 * @return list テスト定数一覧
	 */
	public static List<CLS907_testConstantsBean> getTestConstants() {

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		ResultSet set = null;

		// 定数リスト生成(種別が3つ固定の為、初期サイズを3で生成)
		List<CLS907_testConstantsBean> list = new ArrayList<>(3);

		try (CallableStatement stmt = conn.prepareCall("{call getTestConstants()}")) {
			// 定数取得スクリプト実行
			set = stmt.executeQuery();

			CLS907_testConstantsBean bean = null;

			while(set.next()){
				// テスト定数格納Bean生成
				bean = new CLS907_testConstantsBean();

				bean.setName_constant(set.getString("NAME_CONSTANT"));
				bean.setConstant(set.getString("CONSTANT"));
				list.add(bean);
			}

			ConnectionManager.close();

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				ConnectionManager.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return list;
	}

	/*
	 * DBに格納されている点数及び偏差値のデフォルト情報を
	 * 画面表示用に空文字に変換する。
	 * 点数：-1→空文字 偏差値：-10.00→空文字
	 * @param param dbから取得したデータ
	 * @return "" or param 変換済または変換不要データ
	 */
	public static String defaultToBlank(String param) {

		// デフォルト値ならば空文字返却
		if ("-1".equals(param)) {
			return "";
		} else if ("-10.00".equals(param)) {
			return "";
		// デフォルト値でないならばそのまま引数の値を返却。
		} else {
			return param;
		}
	}

	@Override
	public List<? extends Object> getTestResult(Object info) {
		// トランザクションの開始
				ConnectionManager.beginTransaction();
				// 接続開始
				Connection conn = ConnectionManager.getConnection();

				ResultSet set = null;
				// 検索結果一覧格納用リスト生成
				List<CLS907_SearchResutlBean> list = new ArrayList<>();

				try (CallableStatement stmt = conn.prepareCall("{call getTestInfo(?,?,?,?,?,?,?)}")) {

					CLS907_SearchBean searchInfo = (CLS907_SearchBean) info;

					stmt.setString(1, searchInfo.getSearchCategory());
					stmt.setString(2, searchInfo.getTestCategory());
					stmt.setString(3, searchInfo.getStart());
					stmt.setString(4, searchInfo.getEnd());
					stmt.setString(5, searchInfo.getTestID());
					stmt.setString(6, searchInfo.getTimes());
					stmt.setString(7, searchInfo.getUserID());

					// 検索スクリプト実行
					set = stmt.executeQuery();

					CLS907_SearchResutlBean bean = null;

					while(set.next()){
						// 検索結果Bean生成
						bean = new CLS907_SearchResutlBean();

						// 個人成績検索の場合、以下を取得
						if (searchInfo.getSearchCategory().equals("careerStatistics")) {

							bean.setUserID(set.getString("ID_USER"));
							bean.setUserName(set.getString("NAME_USER"));
							bean.setMarks_jap(defaultToBlank(set.getString("MARKS_JAP")));
							bean.setMarks_math(defaultToBlank(set.getString("MARKS_MATH")));
							bean.setMarks_siec(defaultToBlank(set.getString("MARKS_SIEC")));
							bean.setMarks_scty(defaultToBlank(set.getString("MARKS_SCTY")));
							bean.setMarks_eng(defaultToBlank(set.getString("MARKS_ENG")));
							bean.setDeviation_jap(defaultToBlank(set.getString("DEVIATION_JAP")));
							bean.setDeviation_math(defaultToBlank(set.getString("DEVIATION_MATH")));
							bean.setDeviation_siec(defaultToBlank(set.getString("DEVIATION_SIEC")));
							bean.setDeviation_scty(defaultToBlank(set.getString("DEVIATION_SCTY")));
							bean.setDeviation_eng(defaultToBlank(set.getString("DEVIATION_ENG")));
							bean.setDeviation_five(defaultToBlank(set.getString("DEVIATION_FIVE")));
							bean.setLast_update(set.getTimestamp("DATE_LASTUPDATE"));
						}
						bean.setTestID(set.getString("ID_TEST"));
						bean.setFiscal_year(set.getString("FISCAL_YEAR"));
						bean.setTimes(set.getString("TIMES"));
						bean.setDate_hold(set.getDate("DATE_HOLD"));
						list.add(bean);
					}

					ConnectionManager.close();

				} catch (SQLException e) {
					e.printStackTrace();
					try {
						ConnectionManager.close();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				return list;
	}
}
