package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import util.Message;
import util.StringUtil;
import Dao.CLS907DAO;
import Dao.DaoFactory;
import bean.CLS907_SearchBean;
import bean.CLS907_SearchResutlBean;
import bean.CLS907_testConstantsBean;

/**
 * 908成績検索画面の各遷移及び入力チェックを行うクラス。
 * 
 * 使用セッション変数
 * 
 * @author kume
 * 
 */
public class CLS907Servlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=Windows-31J");
		request.setCharacterEncoding("Windows-31J");

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		// テスト定数取得メソッド呼び出し
		List<CLS907_testConstantsBean> list = CLS907DAO.getTestConstants();

		// セッションに格納し、テスト検索画面に遷移
		session.setAttribute("TestConstants", list);
		request.getRequestDispatcher(
				"JSP/topmenu/menu/mastermente/CLS907_testResultSearch.jsp")
				.forward(request, response);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=Windows-31J");
		request.setCharacterEncoding("Windows-31J");

		HttpSession session = request.getSession(false);

		// セッションタイムアウトの場合、ログイン画面に戻る
		if (session == null) {
			request.getRequestDispatcher("JSP/timeout.jsp").forward(request,
					response);
			return;
		}

		// 遷移先パス
		String path = "JSP/topmenu/menu/mastermente/CLS908_testResultInsert.jsp";

		// エラー発生時遷移先パス
		String errorPage = "JSP/topmenu/menu/mastermente/CLS907_testResultSearch.jsp";

		List<CLS907_SearchResutlBean> list = null;
		if (session.getAttribute("SearchResultList") != null) {
			list = (List<CLS907_SearchResutlBean>) session
					.getAttribute("SearchResultList");
		}

		// ■検索ボタン押下時の処理
		if (request.getParameter("search") != null) {

			CLS908_Servlet.removeSession(session);

			// ラジオボタンから検索対象を取得
			String searchCategory = request.getParameter("searchCategory");

			// プルダウンからテスト種別を取得
			String testCategory = request.getParameter("testCategory");

			// 検索期間(開始と終了)を取得
			String start = request.getParameter("start");
			String end = request.getParameter("end");

			// テストIDを取得
			String testID = request.getParameter("testID");

			// 回次を取得
			String time = request.getParameter("time");

			// ユーザーIDを取得
			String userID = request.getParameter("userID");

			// ユーザ名を取得 Tanaka
			String userName = request.getParameter("userName");

			CLS907_SearchBean bean = new CLS907_SearchBean();
			bean.setSearchCategory(searchCategory);
			bean.setTestCategory(testCategory);
			bean.setStart(start);
			bean.setEnd(end);
			bean.setTestID(testID);
			bean.setTimes(time);
			bean.setUserID(userID);
			bean.setUserName(userName);
			bean.setMessage(null);

			// ↓以降は各パラメーターの入力チェックとフォーマットチェック
			// アラート表示用のストリングリスト生成
			List<String> alartList = new ArrayList<>(10);

			// 検索対象の入力チェック
			if (StringUtil.isEmpty(searchCategory)) {
				alartList.add(Message.getMessage("search.required"));
				bean.setMessage(alartList);
			}

			// テストの入力チェック
			if ("default".equals(testCategory)) {
				alartList.add(Message.getMessage("test.required"));
				bean.setMessage(alartList);
			}

			// 検索期間の入力チェック
			// 開始日だけ入力がある場合
			if (start.isEmpty() && !end.isEmpty()) {
				alartList.add(Message.getMessage("start_date.required"));
				bean.setMessage(alartList);
				// 終了日だけ入力がある場合
			} else if (!start.isEmpty() && end.isEmpty()) {
				alartList.add(Message.getMessage("end_date.required"));
				bean.setMessage(alartList);
				// 両方入力がある場合
			} else if (!start.isEmpty() && !end.isEmpty()) {

				if (!StringUtil.isValidDateFormat(start)) {
					// 開始日付フォーマットエラー
					bean.setStart("");
					alartList
							.add(Message.getMessage("start_date_format.error"));
					bean.setMessage(alartList);
				}

				if (!StringUtil.isValidDateFormat(end)) {
					// 終了日付フォーマットエラー
					bean.setEnd("");
					alartList.add(Message.getMessage("end_dateformat.error"));
					bean.setMessage(alartList);
				}

				if (StringUtil.isValidDateFormat(start, end)) {
					// 開始日付と終了日付の大小チェックを行う。
					if (!StringUtil.compareDate(start, end)) {
						bean.setStart("");
						bean.setEnd("");
						alartList.add(Message.getMessage("date_compare.error"));
						bean.setMessage(alartList);
					}
				}
			}
			session.setAttribute("SearchBean", bean);
			// 入力チェックでエラーがあった場合、この時点で再遷移
			if (alartList.size() > 0) {
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

			// 検索ロジックを呼び出し、セッションに格納。
			list = (List<CLS907_SearchResutlBean>) DaoFactory.getInstance(
					"Dao.CLS907DAO").getTestResult(bean);
			session.setAttribute("SearchResultList", list);

			// ページング機能開始(1ページ10件) //////////////////////
			// ここは検索ボタン押下時なので1ページ目の表示処理だけ行う。

			// 表示ページ番号
			int page = 1;
			// 表示先頭ページ
			int head = 0;

			// 総ページ数
			int allPageNum = list.size() / 10;

			// 剰余がある場合は1ページ分追加
			if (allPageNum % 10 != 0 || allPageNum == 0) {
				allPageNum++;
			}

			// 総検索から表示用の10件分を格納するリストを生成
			List<CLS907_SearchResutlBean> paginglist = new ArrayList<>(10);

			if (list.size() > 10) {
				// 1ページ目のデータを格納
				for (int i = head; i < 10; i++) {
					paginglist.add(list.get(i));
				}
			} else {
				paginglist = new ArrayList<>(list);
			}
			// セッションに総ページ数を格納
			session.setAttribute("allPageNum", allPageNum);
			// セッションに表示先頭ページを格納
			session.setAttribute("head", head);
			// セッションにページ番号を格納
			session.setAttribute("page", page);

			// ページング機能 終了//////////////////////

			// 検索項目をセッションに格納
			session.setAttribute("SearchBean", bean);
			// 初回ページングリストをセッションに格納
			session.setAttribute("PagingList", paginglist);

			request.getRequestDispatcher(errorPage).forward(request, response);

			// ■新規ボタン押下時の処理
		} else if (request.getParameter("new") != null) {

			// 2014-03-09 delete start
			// ■ 複数チェックボックスの入力チェック処理
			// 将来使用する可能性がある為、コメントアウトして残す。
			// // アラート表示用のストリングリスト生成
			// List<String> alartList = new ArrayList<>();
			//
			// String[] checked = request.getParameterValues("checkbox");
			//
			// if (checked.length > 1) {
			// alartList.add(Message.getMessage("one_row.required"));
			// CLS907_testResultSearchBean bean = (CLS907_testResultSearchBean)
			// session
			// .getAttribute("SearchBean");
			// bean.setErrorMessage(alartList);
			// session.setAttribute("SearchBean", bean);
			// request.getRequestDispatcher(errorPage).forward(request,
			// response);
			// return;
			// }
			// 2014-03-09 delete end

			List<CLS907_SearchResutlBean> selectedlist = (List<CLS907_SearchResutlBean>) session
					.getAttribute("SearchResultList");

			// サブミットボタンで選択された行データをセッションに格納
			session.setAttribute("selectedInfo", selectedlist.get(Integer
					.parseInt(request.getParameter("index"))));
			// 操作カテゴリをセッションに格納
			session.setAttribute("control", "新規");
			// 登録、編集画面に遷移
			request.getRequestDispatcher(path).forward(request, response);

			// ■削除ボタン押下時の処理
		} else if (request.getParameter("delete") != null) {

			// 操作カテゴリをセッションに格納して登録、編集画面に遷移
			// (対象データ個人成績を遷移先画面で確認後、削除実行する。)
			// ページをまたいで行データが選択された場合の計算処理
			int head = (Integer) session.getAttribute("head");
			int indexInPage = Integer.parseInt(request.getParameter("index"));

			List<CLS907_SearchResutlBean> selectedlist = (List<CLS907_SearchResutlBean>) session
					.getAttribute("SearchResultList");

			int index = head + indexInPage;

			// 選択行をセッションに格納
			session.setAttribute("index", index);
			// サブミットボタンで選択された行データをセッションに格納
			session.setAttribute("selectedInfo", selectedlist.get(index));

			session.setAttribute("control", "削除");
			request.getRequestDispatcher(path).forward(request, response);

			// ■修正ボタン押下時の処理
		} else if (request.getParameter("repear") != null) {

			// ページをまたいで行データが選択された場合の計算処理
			int head = (Integer) session.getAttribute("head");
			int indexInPage = Integer.parseInt(request.getParameter("index"));

			List<CLS907_SearchResutlBean> selectedlist = (List<CLS907_SearchResutlBean>) session
					.getAttribute("SearchResultList");

			int index = head + indexInPage;

			// 選択行をセッションに格納
			session.setAttribute("index", index);
			// サブミットボタンで選択された行データをセッションに格納
			session.setAttribute("selectedInfo", selectedlist.get(index));
			// 操作カテゴリをセッションに格納
			session.setAttribute("control", "修正");
			// 登録、編集画面に遷移
			request.getRequestDispatcher(path).forward(request, response);

			// ■閉じるボタン押下時の処理
		} else if (request.getParameter("close") != null) {

			// セッション情報を全て破棄
			CLS908_Servlet.removeSession(session);
			// 登録、編集画面に遷移
			request.getRequestDispatcher("JSP/topmenu/CLS002_top.jsp").forward(
					request, response);

			// ■ページングボタン押下時の処理
		} else if (request.getParameter("back") != null
				|| request.getParameter("next") != null) {

			// 表示先頭ページをセッションから取得
			int head = (Integer) session.getAttribute("head");
			// 表示ページ番号をセッションから取得
			int page = (Integer) session.getAttribute("page");

			// 「back」押下時
			if (request.getParameter("back") != null) {
				head = head - 10;
				// 表示ページ番号をマイナス
				page--;
				// 「next」押下時
			} else {
				head = head + 10;
				// 表示ページ番号をプラス
				page++;
			}

			// 総検索から表示用の10件分を格納するリストを生成
			List<CLS907_SearchResutlBean> paginglist = new ArrayList<>();

			// セッションから総リストを取得
			List<CLS907_SearchResutlBean> sessionlist = (ArrayList<CLS907_SearchResutlBean>) session
					.getAttribute("SearchResultList");

			if (sessionlist.size() > 10) {
				// 1ページ分のデータを格納
				for (int i = head; i < head + 10; i++) {
					if (sessionlist.size() - i > 0) {
						paginglist.add(sessionlist.get(i));
					}
				}
			} else {
				paginglist = new ArrayList<>(sessionlist);
			}
			// セッションの表示先頭ページを上書き
			session.setAttribute("head", head);
			// セッションのページ番号を上書き
			session.setAttribute("page", page);
			// セッションの作成リストを上書き
			session.setAttribute("PagingList", paginglist);

			request.getRequestDispatcher(errorPage).forward(request, response);
		}
	}
}
