package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import bean.Mst020_ConstantMstBean;

public class Mst020_ConstantMstDAO extends DataAccessObject {

	public String createSQLForSearchCommon(){
		String string = "SELECT " +
					"CONSTANT " +
				"FROM " +
					"MST020_CONSTANTMST " +
				"WHERE " +
					"DATE_START <= ? " +
					"AND ? <= DATE_END " +
					"AND " +
					"KIND_CONSTANT = ?";
				return string;
	}

	/**
	 * �o�^�������s���܂��B
	 * @param Mst020_ConstantMst mst020_constantmst
	 */
	public void create(Mst020_ConstantMstBean mst020_constantmst) {
		update(createSQLForCreate(),
			new Object[] {
			mst020_constantmst.getkind_constant()
			,mst020_constantmst.getdetailed_constant()
			,mst020_constantmst.getname_constant()
			,mst020_constantmst.getconstant()
			,mst020_constantmst.getflg_delete()
			,mst020_constantmst.getid_lastupdate()
			,mst020_constantmst.getdate_lastupdate()
			});
	}

	/**
	 * �X�V�������s���܂��B
	 * @param Mst020_ConstantMst mst020_constantmst
	 */
	public void update(Mst020_ConstantMstBean mst020_constantmst) {
		update(createSQLForUpdate(),
			new Object[] {
			mst020_constantmst.getkind_constant()
			,mst020_constantmst.getdetailed_constant()
			,mst020_constantmst.getname_constant()
			,mst020_constantmst.getconstant()
			,mst020_constantmst.getflg_delete()
			,mst020_constantmst.getid_lastupdate()
			,mst020_constantmst.getdate_lastupdate()
			});
	}

	/**
	 * ��L�[�������s���܂��B
	 * @param KIND_CONSTANT �萔���
	 * @return KIND_CONSTANT
	 * @param DETAILED_CONSTANT �萔�ڍ�
	 * @return DETAILED_CONSTANT
	 */
	public Mst020_ConstantMstBean findByPrimaryKey(java.lang.Integer userno) {
		return (Mst020_ConstantMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst020_ConstantMstBean.class);
	}

	@Override
	public String[] getPKColumns() {
		return new String[] {"KIND_CONSTANT","DETAILED_CONSTANT"};
	}

	@Override
	public String[] getColumns() {
		return new String[] {"KIND_CONSTANT"
			,"DETAILED_CONSTANT"
			,"NAME_CONSTANT"
			,"CONSTANT"
			,"FLG_DELETE"
			,"ID_LASTUPDATE"
			,"DATE_LASTUPDATE"
		};
	}

	@Override
	public String getTableName() {
		return "MST020_CONSTANTMST";
	}


	public List<String> getConstants(Timestamp date, String kind_constant){

		List<String> list = new ArrayList<>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try{
			String sql = createSQLForSearchCommon();
			System.out.println(sql);

			stmt = getConnection().prepareStatement(sql);

			stmt.setTimestamp(1, date);
			stmt.setTimestamp(2, date);
			stmt.setString(3, kind_constant);

			rs = stmt.executeQuery();
			while (rs.next()) {
				String string = new String();
				string = rs.getString("CONSTANT");
				list.add(string);
			}
			return list;

		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
public String createSQLForSerchGAKUNEN(){

		String sql="SELECT CONSTANT,NAME_CONSTANT FROM MST020_CONSTANTMST WHERE KIND_CONSTANT = 'GRADE' ORDER BY CONSTANT ASC";
		return sql;
	}
	public List<Mst020_ConstantMstBean> createSQLForGAKUNEN() {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = createSQLForSerchGAKUNEN();
		Mst020_ConstantMstBean bean = null;
		List<Mst020_ConstantMstBean> list = new ArrayList<>();

		try {
			stmt = getConnection().prepareStatement(sql);

			rs = stmt.executeQuery();
			while (rs.next()) {
				bean = new Mst020_ConstantMstBean();
				bean.setconstant(rs.getString("CONSTANT"));
				bean.setname_constant(rs.getString("NAME_CONSTANT"));
				list.add(bean);
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	return list;
	}



	public String createSQLForSerchDAY_OF_WEEK(){

		String sql="SELECT DETAILED_CONSTANT,NAME_CONSTANT FROM MST020_CONSTANTMST WHERE KIND_CONSTANT = 'DAY_OF_WEEK'";
		return sql;
	}
	public List<Mst020_ConstantMstBean> createSQLForDAY_OF_WEEK() {

		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = createSQLForSerchDAY_OF_WEEK();
		Mst020_ConstantMstBean bean = null;
		List<Mst020_ConstantMstBean> list = new ArrayList<>();

		try {
			stmt = getConnection().prepareStatement(sql);

			//stmt.setString(1, id_user);
			rs = stmt.executeQuery();
			while (rs.next()) {
				bean = new Mst020_ConstantMstBean();
				bean.setdetailed_constant(rs.getString("DETAILED_CONSTANT"));
				bean.setname_constant(rs.getString("NAME_CONSTANT"));
				list.add(bean);
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	return list;
	}
	/**
	 * getconstansで返却されるレコードが常に1つでなければならない定数値
	 * に対し、複数存在する場合にエラーを返却します。
	 * @param date
	 * @param kind_constant
	 * @return
	 */
	public String getSingleRcdConstant(Timestamp date, String kind_constant) {
		String constant = "";
		ConnectionManager.beginTransaction();
		List<String> constants = getConstants(date, kind_constant);
		try {
			ConnectionManager.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		if (constants.size() == 1) {
			constant = constants.get(0);
		} else {
			String mes_Error = kind_constant + "のレコードが複数存在します。";
			System.out.println(mes_Error);
			try {
				throw new Exception(mes_Error);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return constant;
	}
}
