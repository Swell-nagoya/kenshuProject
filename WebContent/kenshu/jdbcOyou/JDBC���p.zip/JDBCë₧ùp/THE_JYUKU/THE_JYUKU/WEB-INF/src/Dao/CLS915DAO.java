package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS915Bean;
import bean.Mst001_UserMstBean;
import bean.Mst010_CourseMstBean;
import bean.Trn005_SubstituteTrnBean;

public class CLS915DAO extends ConnectionManager {

	private String id_user;
	private String id_course;

	/**
	 * 振替情報とユーザー情報を取得するSQL文を作成します。 palam長が０の場合は、全検索を行います。
	 * 
	 * @param palam
	 *            条件にするカラム名(頭にテーブル名を記載してください）
	 * @return 作成するSQL文
	 */
	public String createSQLForSearch(List<String> palam) {

		Trn005_SubstituteTrnDAO trn005_SubstituteTrnDAO = new Trn005_SubstituteTrnDAO();
		Mst001_UserMstDAO mst001_UserMstDAO = new Mst001_UserMstDAO();
		Mst010_CourseMstDAO mst010_CourseMstDAO = new Mst010_CourseMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(mst001_UserMstDAO.join(mst001_UserMstDAO.add(
				mst001_UserMstDAO.getTableName(), ".",
				mst001_UserMstDAO.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst001_UserMstDAO.join(mst001_UserMstDAO.add(
				trn005_SubstituteTrnDAO.getTableName(), ".",
				trn005_SubstituteTrnDAO.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst001_UserMstDAO.join(mst001_UserMstDAO.add(
				mst010_CourseMstDAO.getTableName(), ".",
				mst010_CourseMstDAO.getColumns()), ", "));
		sb.append(" from ");
		sb.append(trn005_SubstituteTrnDAO.getTableName());
		sb.append(" left join ");
		sb.append(mst001_UserMstDAO.getTableName());
		sb.append(" on ");
		sb.append(mst001_UserMstDAO.getTableName() + "."
				+ mst001_UserMstDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(trn005_SubstituteTrnDAO.getTableName() + "."
				+ trn005_SubstituteTrnDAO.getPKColumns()[0]);
		sb.append(" left join ");
		sb.append(mst010_CourseMstDAO.getTableName());
		sb.append(" on ");
		sb.append(mst010_CourseMstDAO.getTableName() + "."
				+ mst010_CourseMstDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(trn005_SubstituteTrnDAO.getTableName() + "."
				+ trn005_SubstituteTrnDAO.getPKColumns()[1]);
		sb.append(" where ");
		// 2つ削除フラグを追加
		sb.append(" MST001_USERMST.FLG_DELETE = 0 ");
		sb.append(" and ");
		sb.append(" TRN005_SUBSTITUTETRN.FLG_DELETE = 0 ");
		sb.append(" and ");
		sb.append(trn005_SubstituteTrnDAO.getTableName()
				+ ".START_SUBSTITUTE >= SYSDATE() ");
		if (palam.size() != 0) {
			sb.append(" and ");
			for (int n = 0; n < palam.size(); n++) {
				if (palam.get(n).equals("ID_COURSE")) {
					sb.append(mst010_CourseMstDAO.getTableName() + ".");
				}
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		sb.append(" order by ");
		sb.append(mst001_UserMstDAO.getTableName() + "." + "KANA_NAME_USER");
		return sb.toString();
	}

	/**
	 * 振替トランからデータを取得します。
	 * 
	 * @param cls915
	 * @return List<CLS915Bean>
	 */

	public List<CLS915Bean> Search(CLS915Bean cls915) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = null;

		// 取得するパラメータ
		List<CLS915Bean> list = new ArrayList<CLS915Bean>();

		// 検索対象のカラム
		List<String> palam = new ArrayList<String>();

		// 検索対象のパラメータ
		List<Object> value = new ArrayList<Object>();

		// 共通で取得するユーザテーブルのBean
		trn005_SubstituteTrnBean = cls915.getTrn005_SubstituteTrnBean();

		// パラメーターの設定（ユーザーマスタ）
		if (trn005_SubstituteTrnBean.getid_user() != null) {
			id_user = trn005_SubstituteTrnBean.getid_user();
			palam.add("MST001_USERMST.ID_USER");
			value.add(id_user);
		}

		if (trn005_SubstituteTrnBean.getid_course() != null) {
			id_course = trn005_SubstituteTrnBean.getid_course();
			palam.add("ID_COURSE");
			value.add(id_course);
		}

		String sql = createSQLForSearch(palam);
		System.out.println(sql);

		try {
			stmt = getConnection().prepareStatement(sql);

			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}

			rs = stmt.executeQuery();

			while (rs.next()) {
				CLS915Bean cls915b2 = new CLS915Bean();
				Trn005_SubstituteTrnBean trn005_SubstituteTrnBean2 = new Trn005_SubstituteTrnBean();
				Mst001_UserMstBean mst001_UserMstBean2 = new Mst001_UserMstBean();
				Mst010_CourseMstBean mst010_CourseMstBean2 = new Mst010_CourseMstBean();

				trn005_SubstituteTrnBean2.setid_user(rs.getString("ID_USER"));
				trn005_SubstituteTrnBean2.setid_course(rs
						.getString("ID_COURSE"));
				trn005_SubstituteTrnBean2.setflg_absence(rs
						.getInt("FLG_ABSENCE"));
				trn005_SubstituteTrnBean2.setflg_late(rs.getInt("FLG_LATE"));
				trn005_SubstituteTrnBean2.setflg_early(rs.getInt("FLG_EARLY"));
				trn005_SubstituteTrnBean2.setflg_substitute(rs
						.getInt("FLG_SUBSTITUTE"));
				// trn005_SubstituteTrnBean2.settimetable_lecture(rs.getString("TIMETABLE_LECTURE"));
				trn005_SubstituteTrnBean2.setstart_lecture(rs
						.getTimestamp("START_LECTURE"));
				trn005_SubstituteTrnBean2.setend_lecture(rs
						.getTimestamp("END_LECTURE"));
				// trn005_SubstituteTrnBean2.settimetable_substitute(rs.getString("TIMETABLE_SUBSTITUTE"));
				trn005_SubstituteTrnBean2.setstart_substitute(rs
						.getTimestamp("START_SUBSTITUTE"));
				trn005_SubstituteTrnBean2.setend_substitute(rs
						.getTimestamp("END_SUBSTITUTE"));
				trn005_SubstituteTrnBean2
						.setflg_delete(rs.getInt("FLG_DELETE"));
				trn005_SubstituteTrnBean2.setid_lastupdate(rs
						.getString("ID_LASTUPDATE"));
				trn005_SubstituteTrnBean2.setdate_lastupdate(rs
						.getTimestamp("DATE_LASTUPDATE"));
				mst001_UserMstBean2.setName(rs.getString("NAME_USER"));
				mst010_CourseMstBean2.setname_course(rs
						.getString("NAME_COURSE"));

				cls915b2.setTrn005_SubstituteTrnBean(trn005_SubstituteTrnBean2);
				cls915b2.setMst001_UserMstBean(mst001_UserMstBean2);
				cls915b2.setMst010_CourseMstBean(mst010_CourseMstBean2);

				list.add(cls915b2);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
}
