package servlet;


import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.ConnectionManager;
import Dao.Trn014_ConfidentialTrnDAO;
import bean.Trn014_ConfidentialTrnBean;


/**
 * 内申点の登録用のサーブレットクラス
 *@author n-kuraoka
 */

public class CLS910_ConfidentialInsertServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();
		Trn014_ConfidentialTrnDAO trn014_ConfidentialTrnDAO = new Trn014_ConfidentialTrnDAO();

		//今の最終日更新日
		Timestamp date_compareupdate = new Timestamp(System.currentTimeMillis());

		//前画面の最終更新日
		Timestamp date_beforeupdate = new Timestamp(System.currentTimeMillis());
		trn014_ConfidentialTrnBean.setdate_lastupdate(Timestamp.valueOf(date_beforeupdate.toString()));

		/*
		 * //ユーザーテーブルの各更新日を取得する(更新/削除) if
		 * (request.getParameter("confidential_update_id_user") == null &&
		 * request.getParameter("confidential_delete_id_user") == null){
		 * ConnectionManager.beginTransaction(); date_compareupdate =
		 * trn014_ConfidentialTrnDAO
		 * .findByKey((String)request.getParameter("confidential_update_id_user"
		 * ) ,Integer.parseInt((String)request.getParameter(
		 * "confidential_update_fiscal_year"))
		 * ,Integer.parseInt((String)request.
		 * getParameter("confidential_update_times")) ).getdate_lastupdate();
		 * try { ConnectionManager.close(); } catch (SQLException e) { // TODO
		 * 自動生成された catch ブロック e.printStackTrace(); } }
		 */

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		session.removeAttribute("alart");

		/*
		 * トランテーブルをインサート
		 */

		// 登録
		if (request.getParameter("confidential_update_id_user") == null
				&& request.getParameter("confidential_delete_id_user") == null) {
			trn014_ConfidentialTrnBean.setid_user(request
					.getParameter("ID_USER"));
			trn014_ConfidentialTrnBean.setfiscal_year(Integer.parseInt(request
					.getParameter("FISCAL_YEAR")));
			trn014_ConfidentialTrnBean.settimes(Integer.parseInt(request
					.getParameter("TIMES")));
			trn014_ConfidentialTrnBean.settype_evaluation(Integer
					.parseInt(request.getParameter("TYPE_EVALUATION")));
			trn014_ConfidentialTrnBean.setconf_jap(Integer.parseInt(request
					.getParameter("CONF_JAP")));
			trn014_ConfidentialTrnBean.setconf_math(Integer.parseInt(request
					.getParameter("CONF_MATH")));
			trn014_ConfidentialTrnBean.setconf_siec(Integer.parseInt(request
					.getParameter("CONF_SIEC")));
			trn014_ConfidentialTrnBean.setconf_scty(Integer.parseInt(request
					.getParameter("CONF_SCTY")));
			trn014_ConfidentialTrnBean.setconf_eng(Integer.parseInt(request
					.getParameter("CONF_ENG")));
			trn014_ConfidentialTrnBean.setconf_tech(Integer.parseInt(request
					.getParameter("CONF_TECH")));
			trn014_ConfidentialTrnBean.setconf_gmst(Integer.parseInt(request
					.getParameter("CONF_GMST")));
			trn014_ConfidentialTrnBean.setconf_music(Integer.parseInt(request
					.getParameter("CONF_MUSIC")));
			trn014_ConfidentialTrnBean.setconf_arts(Integer.parseInt(request
					.getParameter("CONF_ARTS")));
			trn014_ConfidentialTrnBean.setflg_delete(0);
			trn014_ConfidentialTrnBean.setid_lastupdate(request
					.getParameter("id_lastupdate"));
			// ミリ秒での現在時刻の取得
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			trn014_ConfidentialTrnBean.setdate_lastupdate(Timestamp
					.valueOf(timestamp.toString()));

			// アラートメッセージ
			String alart;
			// 入力チェック
			ValidateServlet Validate = new ValidateServlet();
			alart = Validate.ConfidentialInsCheck(request);
			session.setAttribute("alart", alart);
			// 再入力時に前回の入力データを表示する
			// session.setAttribute();
			if (alart != null) {
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS910_ConfidentialInsert.jsp")
						.forward(request, response);
				return;
			}
			ConnectionManager.beginTransaction();
			try {
				trn014_ConfidentialTrnDAO.create(trn014_ConfidentialTrnBean);
				ConnectionManager.commit();
			} finally {
				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					// TODO 自動生成された catch ブロック
					e.printStackTrace();
				}
			}

			// 削除
		} else if (request.getParameter("confidential_delete_id_user") != null) {
			ConnectionManager.beginTransaction();
			try {
				trn014_ConfidentialTrnBean = trn014_ConfidentialTrnDAO
						.findByKey(
								request.getParameter("confidential_delete_id_user"),
								Integer.parseInt(request
										.getParameter("confidential_delete_fiscal_year")),
								Integer.parseInt(request
										.getParameter("confidential_delete_times")));
				ConnectionManager.commit();
			} finally {
				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					// TODO 自動生成された catch ブロック
					e.printStackTrace();
				}
			}

			trn014_ConfidentialTrnBean.setflg_delete(1);
			trn014_ConfidentialTrnBean.setid_lastupdate(request
					.getParameter("id_lastupdate"));
			// ミリ秒での現在時刻の取得
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			trn014_ConfidentialTrnBean.setdate_lastupdate(Timestamp
					.valueOf(timestamp.toString()));

			ConnectionManager.beginTransaction();
			try {
				trn014_ConfidentialTrnDAO.update(trn014_ConfidentialTrnBean);
			} finally {
				ConnectionManager.commit();
			}
			// 更新
		} else if (request.getParameter("confidential_update_id_user") != null) {
			trn014_ConfidentialTrnBean.setid_user(request
					.getParameter("confidential_update_id_user"));
			trn014_ConfidentialTrnBean.setfiscal_year(Integer.parseInt(request
					.getParameter("confidential_update_fiscal_year")));
			trn014_ConfidentialTrnBean.settimes(Integer.parseInt(request
					.getParameter("confidential_update_times")));
			trn014_ConfidentialTrnBean.settype_evaluation(Integer
					.parseInt(request.getParameter("TYPE_EVALUATION")));
			trn014_ConfidentialTrnBean.setconf_jap(Integer.parseInt(request
					.getParameter("CONF_JAP")));
			trn014_ConfidentialTrnBean.setconf_math(Integer.parseInt(request
					.getParameter("CONF_MATH")));
			trn014_ConfidentialTrnBean.setconf_siec(Integer.parseInt(request
					.getParameter("CONF_SIEC")));
			trn014_ConfidentialTrnBean.setconf_scty(Integer.parseInt(request
					.getParameter("CONF_SCTY")));
			trn014_ConfidentialTrnBean.setconf_eng(Integer.parseInt(request
					.getParameter("CONF_ENG")));
			trn014_ConfidentialTrnBean.setconf_tech(Integer.parseInt(request
					.getParameter("CONF_TECH")));
			trn014_ConfidentialTrnBean.setconf_gmst(Integer.parseInt(request
					.getParameter("CONF_GMST")));
			trn014_ConfidentialTrnBean.setconf_music(Integer.parseInt(request
					.getParameter("CONF_MUSIC")));
			trn014_ConfidentialTrnBean.setconf_arts(Integer.parseInt(request
					.getParameter("CONF_ARTS")));
			trn014_ConfidentialTrnBean.setflg_delete(0);
			trn014_ConfidentialTrnBean.setid_lastupdate(request
					.getParameter("id_lastupdate"));

			if (date_compareupdate.compareTo(date_beforeupdate) == 0) {
				ConnectionManager.beginTransaction();
				try {
					trn014_ConfidentialTrnDAO
							.update(trn014_ConfidentialTrnBean);
					ConnectionManager.commit();
				} finally {
					try {
						ConnectionManager.close();
					} catch (SQLException e) {
						// TODO 自動生成された catch ブロック
						e.printStackTrace();
					}
				}
			}
		} else {
			String e = "error";
			System.err.println(e);
		}

		System.out.println("キチンとここまで処理できましたよ！！やったね！！");

		// 過去に取得していたら破棄
		session.removeAttribute("permission");
		request.getRequestDispatcher(
				"JSP/topmenu/menu/mastermente/CLS909_ConfidentialSearch.jsp")
				.forward(request, response);
	}
}
