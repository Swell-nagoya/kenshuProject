package bean;

import java.sql.Timestamp;
import java.util.List;

public class CLS002_ForCalender {

    List<Integer> existLessonDays;
    List<Timestamp> existStartLessonDatetime;
    List<Timestamp> existEndLessonDatetime;
    String name_Cource;
    Timestamp startLecture;
    Timestamp endLecture;
    public List<Integer> getExistLessonDays() {
        return existLessonDays;
    }
    public void setExistLessonDays(List<Integer> existLessonDays) {
        this.existLessonDays = existLessonDays;
    }
    public String getName_Cource() {
        return name_Cource;
    }
    public void setName_Cource(String name_Cource) {
        this.name_Cource = name_Cource;
    }
    public Timestamp getStartLecture() {
        return startLecture;
    }
    public void setStartLecture(Timestamp startLecture) {
        this.startLecture = startLecture;
    }
    public Timestamp getEndLecture() {
        return endLecture;
    }
    public void setEndLecture(Timestamp endLecture) {
        this.endLecture = endLecture;
    }
    public List<Timestamp> getExistStartLessonDatetime() {
        return existStartLessonDatetime;
    }
    public void setExistStartLessonDatetime(List<Timestamp> existLessonDatetime) {
        this.existStartLessonDatetime = existLessonDatetime;
    }
    public List<Timestamp> getExistEndLessonDatetime() {
        return existEndLessonDatetime;
    }
    public void setExistEndLessonDatetime(List<Timestamp> existEndLessonDatetime) {
        this.existEndLessonDatetime = existEndLessonDatetime;
    }

}
