package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.CLS909DAO;
import Dao.ConnectionManager;
import Dao.Trn014_ConfidentialTrnDAO;
import bean.CLS909Bean;
import bean.Trn014_ConfidentialTrnBean;


/**
 * 内申点画面から（登録、削除、更新画面に遷移）
 * 検索はこのサーブレットで行う
 * @author m-hayashi
 *
 */
public class CLS909_ConfidentialSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		//Sessionの取得
		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		//過去に取得したパラメータを削除
		request.removeAttribute("cls915");
		request.removeAttribute("cls915list");
		request.removeAttribute("cls909Bean");

		//beanの取得
		CLS909Bean cls909Bean = new CLS909Bean();

		//Daoの取得
		CLS909DAO cls909Dao = new CLS909DAO();

		//取得予定のリスト
		List<CLS909Bean> list = new ArrayList<CLS909Bean>();

		if (request.getParameter("select") != null) {
			Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();

			if (!request.getParameter("ID_USER").equals("")) {
				trn014_ConfidentialTrnBean.setid_user(request.getParameter("ID_USER"));
			}
			if (!request.getParameter("KIKAN_START").equals("") &&
					!request.getParameter("KIKAN_END").equals("") &&
				request.getParameter("KIKAN_START").equals(request.getParameter("KIKAN_END"))) {
				trn014_ConfidentialTrnBean.setfiscal_year(Integer.parseInt(request.getParameter("KIKAN_START")));
			} else {
				if (!request.getParameter("KIKAN_START").equals("")) {
					trn014_ConfidentialTrnBean.setKikan_start(Integer.parseInt(request.getParameter("KIKAN_START")));
				}
				if (!request.getParameter("KIKAN_END").equals("")) {
					trn014_ConfidentialTrnBean.setKikan_end(Integer.parseInt(request.getParameter("KIKAN_END")));
				}
			}
			if (!request.getParameter("TIMES").equals("")) {
				trn014_ConfidentialTrnBean.settimes(Integer.parseInt(request.getParameter("TIMES")));
			}

			cls909Bean.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean);

			ConnectionManager.beginTransaction();

			list = cls909Dao.Search(cls909Bean);
			if (list.size() == 0){
				//検索結果なし
				String alart;
				alart = "検索結果がありませんでした。";
				session.setAttribute("alart", alart);
				session.removeAttribute("cls909");
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS909_ConfidentialSearch.jsp").forward(request, response);
				return;
			}
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			session.setAttribute("cls909", list);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS909_ConfidentialSearch.jsp").forward(request, response);
		}

		//新規作成
		if(request.getParameter("create") != null) {
			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.removeAttribute("alart");
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS910_ConfidentialInsert.jsp").forward(request, response);
		}

		//更新
		if (request.getParameter("update") != null) {
			Trn014_ConfidentialTrnDAO trn014_ConfidentialTrnDAO = new Trn014_ConfidentialTrnDAO();
			Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();

			String id_user = request.getParameter("id_user");
			int fiscal_year = Integer.parseInt(request.getParameter("fiscal_year"));
			int times = Integer.parseInt(request.getParameter("times"));

			ConnectionManager.beginTransaction();
			trn014_ConfidentialTrnBean = trn014_ConfidentialTrnDAO.findByKey(id_user ,fiscal_year ,times);

			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			cls909Bean.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean);

			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.setAttribute("update", cls909Bean);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS910_ConfidentialInsert.jsp").forward(request, response);

		}

		//削除
		if (request.getParameter("delete") != null) {
			Trn014_ConfidentialTrnDAO trn014_ConfidentialTrnDAO = new Trn014_ConfidentialTrnDAO();
			Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();

			String id_user = request.getParameter("id_user");
			int fiscal_year = Integer.parseInt(request.getParameter("fiscal_year"));
			int times = Integer.parseInt(request.getParameter("times"));

			ConnectionManager.beginTransaction();
			trn014_ConfidentialTrnBean = trn014_ConfidentialTrnDAO.findByKey(id_user ,fiscal_year ,times);

			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			cls909Bean.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean);

			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.setAttribute("delete", cls909Bean);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS910_ConfidentialInsert.jsp").forward(request, response);
		}
	}
}

