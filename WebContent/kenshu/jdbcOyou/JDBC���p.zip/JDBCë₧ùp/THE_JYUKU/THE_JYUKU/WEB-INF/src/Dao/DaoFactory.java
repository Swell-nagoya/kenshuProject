package Dao;

/**
 * DAOインスタンス生成担当のファクトリクラス
 * @author kume
 *
 */
public class DaoFactory {

	/**
	 * DAOクラスのインスタンスを返却する。
	 * @param className クラス名称
	 * @return instance クラスのインスタンス
	 */
	public static ITestDao getInstance(String className) {

		ITestDao instance = null;

		try {
			instance = (ITestDao) Class.forName(className).newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return instance;
	}
}
