package common;

public class CLS917Exception extends Exception{
	public CLS917Exception() {
		super();
		System.out.println("CLS917で内部エラーが発生しています。");
	}
}
