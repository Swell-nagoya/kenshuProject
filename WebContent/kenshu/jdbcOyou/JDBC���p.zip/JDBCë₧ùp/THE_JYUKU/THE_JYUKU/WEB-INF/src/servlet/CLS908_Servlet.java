package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.Message;
import util.StringUtil;
import Dao.CLS908DAO;
import Dao.DaoFactory;
import Validate.CLS908Validate;
import bean.CLS907_SearchBean;
import bean.CLS907_SearchResutlBean;
import bean.CLS908_InsertBean;
import bean.Mst001_UserMstBean;

public class CLS908_Servlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=Windows-31J");
		request.setCharacterEncoding("Windows-31J");

		HttpSession session = request.getSession(false);

		// セッションタイムアウトの場合、ログイン画面に戻る
		if (session == null) {
			request.getRequestDispatcher("JSP/timeout.jsp").forward(request,
					response);
			return;
		}

		// 処理完了時遷移先パス
		String path = "JSP/topmenu/menu/mastermente/CLS907_testResultSearch.jsp";

		// エラー発生時遷移先パス
		String errorPage = "JSP/topmenu/menu/mastermente/CLS908_testResultInsert.jsp";

		// 生徒ユーザーID取得
		String userID = null;
		if (request.getParameter("insert") != null) {
			userID = request.getParameter("userID").trim();
		}

		// セッションの検索条件Beanからテストカテゴリを取得し、登録情報Beanに格納。
		CLS907_SearchBean sessionTest
		= (CLS907_SearchBean) session.getAttribute("SearchBean");

		CLS908_InsertBean bean = new CLS908_InsertBean();
		bean.setTestCategory(sessionTest.getTestCategory());

		// セッションの選択行データからテストIDを取得し、登録情報Beanに格納。
		CLS907_SearchResutlBean testIDofBean =
				(CLS907_SearchResutlBean) session.getAttribute("selectedInfo");

		// ブラウザの予期しない動作によってNullPointerが発生する可能性があるため
		// 念のためチェックを行う。
		if (testIDofBean != null) {
			bean.setTestID(testIDofBean.getTestID());

			// 新規登録の場合はフォームからユーザIDを取得し、登録Beanに格納
			if (request.getParameter("insert") != null) {
				bean.setUserID(userID);

			// 修正、削除の場合はセッション情報からユーザIDと最終更新日付を取得。
			// 最終更新日付は修正、削除の際に比較対象に使用される。
			} else {
				bean.setUserID(testIDofBean.getUserID());
				if (testIDofBean.getLast_update() != null) {
					bean.setLast_update(testIDofBean.getLast_update().toString());
				}
			}
		}

		// セッションからログインIDを取得し、登録情報Beanに格納
		Mst001_UserMstBean mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");
		bean.setLast_up_user(mst001_UserMstBean.getId_user());

		// 国語点数取得
		String marks_jap = request.getParameter("marks_jap");
		// 数学点数取得
		String marks_math = request.getParameter("marks_math");
		// 理科点数取得
		String marks_siec = request.getParameter("marks_siec");
		// 社会点数取得
		String marks_scty = request.getParameter("marks_scty");
		// 英語点数取得
		String marks_eng = request.getParameter("marks_eng");

		// 国語偏差値取得
		String deviation_jap = request.getParameter("deviation_jap");
		// 数学偏差値取得
		String deviation_math = request.getParameter("deviation_math");
		// 理科偏差値取得
		String deviation_siec = request.getParameter("deviation_siec");
		// 社会偏差値取得
		String deviation_scty = request.getParameter("deviation_scty");
		// 英語偏差値取得
		String deviation_eng = request.getParameter("deviation_eng");
		// 5教科偏差値取得
		String deviation_five = request.getParameter("deviation_five");

		// 登録情報Beanに格納
		bean.setMarks_jap(marks_jap);
		bean.setMarks_math(marks_math);
		bean.setMarks_siec(marks_siec);
		bean.setMarks_scty(marks_scty);
		bean.setMarks_eng(marks_eng);
		bean.setDeviation_jap(deviation_jap);
		bean.setDeviation_math(deviation_math);
		bean.setDeviation_siec(deviation_siec);
		bean.setDeviation_scty(deviation_scty);
		bean.setDeviation_eng(deviation_eng);
		bean.setDeviation_five(deviation_five);
		bean.setMessage(null);

		// 選択行データをセッションから取得
		// 入力フォームの以降のチェック処理において、判定に通れば
		// セッションデータにnullを設定し表示優先度を「入力データ > セッションデータ」にする。
		// 他入力データにエラーが存在し、画面に再遷移した場合にこの設定が適用される。
		CLS907_SearchResutlBean sessionbean =
				(CLS907_SearchResutlBean) session.getAttribute("selectedInfo");

		// ↓以降は各パラメーターの入力チェックとフォーマットチェック
		// アラート表示用のストリングリスト生成
		List<String> alartList = new ArrayList<>(12);

		// 入力チェック用メソッド呼び出し
		alartList = CLS908Validate.validate(request, bean, sessionbean);

		// 登録ボタン押下時にはユーザーIDのチェックを行う
		if (request.getParameter("insert") != null) {

			if (StringUtil.isEmpty(userID)) {
				alartList.add(Message.getMessage("userid.required"));
				bean.setMessage(alartList);
				session.setAttribute("InsertBean", bean);

			}
		}
		session.setAttribute("InsertBean", bean);

		// 入力チェックでエラーがあった場合、この時点で再遷移
		if (alartList.size() > 0) {
			request.getRequestDispatcher(errorPage).forward(request,
					response);
			return;
		}

		// ■登録ボタン押下時の処理
		if (request.getParameter("insert") != null) {

			// ユーザーID存在チェックメソッド呼び出し
			if (!CLS908DAO.getUserCount(userID)) {
				bean.setUserID("");
				alartList.add(Message.getMessage("userID_notExist.error"));
				bean.setMessage(alartList);
				session.setAttribute("InsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

			// 登録実行メソッド呼び出し
			int result = CLS908DAO.testInsert(bean);

			// 一意制約違反
			if (result == 1062) {
				alartList.add(Message.getMessage("unique_constraint.error"));
				bean.setMessage(alartList);
				session.setAttribute("InsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;

			// 登録成功
			} else if (result == 0) {

				// セッション情報を全て破棄
				removeSession(session);
				// 登録完了メッセージを格納
				request.setAttribute("complete", Message.getMessage("insert.comp"));

				request.getRequestDispatcher(path).forward(request,
						response);
				return;

			// その他処理エラー
			} else {
				alartList.add(Message.getMessage("insert.fail"));
				bean.setMessage(alartList);
				session.setAttribute("InsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

		// ■削除ボタン押下時の処理
		} else if (request.getParameter("delete") != null) {

			testIDofBean.setTestCategory(bean.getTestCategory());
			// セッションからログインIDを取得し最終更新者IDに格納
			testIDofBean.setLast_up_user((String)session.getAttribute("logginSession"));
			int result = CLS908DAO.testDelete(testIDofBean);

			if (result == 1) {

				// セッション情報を全て破棄
				removeSession(session);
				// 削除完了メッセージを格納
				request.setAttribute("complete", Message.getMessage("delete.comp"));

				// テスト検索画面に戻る
				request.getRequestDispatcher(path).forward(request,
						response);
				return;
			} else {
				alartList.add(Message.getMessage("delete.fail"));
				bean.setMessage(alartList);
				session.setAttribute("InsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

		// ■修正ボタン押下時の処理
		} else if (request.getParameter("repear") != null) {

			// 個人成績の更新メソッド呼び出し
			int result = CLS908DAO.testUpdate(bean);

			// 更新件数が0件で失敗時の処理
			if (result == 0) {
				alartList.add(Message.getMessage("regist_fail.error"));

				bean.setMessage(alartList);
				session.setAttribute("InsertBean", bean);
				session.setAttribute("control", "修正");

				// 最新情報を表示するために、再度検索対象データの取得を行う。
				CLS907_SearchBean retryBean =
						(CLS907_SearchBean) session.getAttribute("SearchBean");
				// 検索メソッド呼び出し
				@SuppressWarnings("unchecked")
				List<CLS907_SearchResutlBean> list =
						(List<CLS907_SearchResutlBean>) DaoFactory.getInstance("CLS907DAO").getTestResult(retryBean);

				// 個人成績のセッション情報を上書き
				session.setAttribute("selectedInfo", list.get((Integer)session.getAttribute("index")));

				// テスト登録画面に再遷移
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;

			// 更新成功時の処理
			} else if (result == 1) {

				// セッション情報を全て破棄
				removeSession(session);
				// 修正完了メッセージを格納
				request.setAttribute("complete", Message.getMessage("update.comp"));

				// テスト検索画面に戻る
				request.getRequestDispatcher(path).forward(request,
						response);
				return;
			}

		// ■閉じるボタン押下時の処理
		} else if (request.getParameter("close") != null) {

			// セッション情報を全て破棄
			removeSession(session);

			// テスト検索画面に戻る
			request.getRequestDispatcher(path).forward(request,
					response);
			return;
		}
	}

	/**
	 * CLS907～CLS908関連のセッション情報を全て破棄する
	 * @param session セッション
	 */
	public static void removeSession(HttpSession session) {

		session.removeAttribute("SearchBean");
		session.removeAttribute("SearchResultList");
		session.removeAttribute("selectedInfo");
		session.removeAttribute("control");
		session.removeAttribute("InsertBean");
		session.removeAttribute("head");
		session.removeAttribute("page");
		session.removeAttribute("PagingList");
		session.removeAttribute("PagingList");
		session.removeAttribute("allPageNum");
	}

	/**
	 * CLS907～CLS908関連の任意のセッション情報を破棄する
	 * @param session セッション
	 * @param keys セッションキー
	 */
	public static void removeAnySession(HttpSession session, String... keys) {

		for (String key : keys) {
			session.removeAttribute(key);
		}
	}
}
