package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.CLS008DAO;
import Dao.ConnectionManager;
import Dao.Mst020_ConstantMstDAO;
import bean.CLS008Bean;
import bean.Mst001_UserMstBean;

/**
 * 更新はこのサーブレットで行う
 * @author hasumi
 *
 */
public class CLS008_TuitionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		//過去に取得したパラメータを削除
		request.removeAttribute("cls903");
		request.removeAttribute("totalTuition");

		session.removeAttribute("alart");

		//Daoの取得
		CLS008DAO cls008dao = new CLS008DAO();
		Mst020_ConstantMstDAO mst020ConstantMstDao = new Mst020_ConstantMstDAO();

		//取得予定のリスト
		List<CLS008Bean> list = new ArrayList<CLS008Bean>();

		//フォームの取得
		Mst001_UserMstBean mst001_login = (Mst001_UserMstBean)session.getAttribute("loginSession");

		//現在日付を取得
		Date date = new Date();
		Timestamp today = new Timestamp(date.getTime());

		//ログインユーザのID取得
		String userID = mst001_login.getId_user();
		System.out.println(userID);

		//トランザクション開始
		ConnectionManager.beginTransaction();
		//現在日時から消費税率取得
		List <String> ConsumptionTax = mst020ConstantMstDao.getConstants(today,"tax");
		double DblConsumptionTax = Double.parseDouble(ConsumptionTax.get(0));
		//ログインユーザの授業料金情報を取得してリストに格納
		list = cls008dao.Search(userID,DblConsumptionTax);
		double totalTuition = 0;
		for (int i = 0; i < list.size(); i++) {
			totalTuition = totalTuition + (list.get(i).getMst010_CourseMstBean().gettuition() );
		}
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DecimalFormat df=new DecimalFormat();
		df.setMaximumFractionDigits(0);
		
		System.out.println("キチンとここまで処理できましたよ！！やったね！！");

		session.setAttribute("cls008", list);
		session.setAttribute("totalTuition", df.format(totalTuition));
//		request.setAttribute("ConsumptionTax", Double.toString(ConsumptionTax));
		request.getRequestDispatcher("JSP/topmenu/menu/CLS008_Tuition.jsp").forward(request, response);




	}
}

