package bean;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * テスト検索結果情報格納クラス
 * @author kume
 *
 */
public class CLS905_SearchResultBean implements Serializable {

	// テストカテゴリ
	private String testCategory;
	// テストID
	private String testID;
	// 年度
	private String fiscal_year;
	// 回次
	private String times;
	// テスト種別
	private String test_type;
	// 開催日
	private Date date_hold;

	// 国語平均点
	private String average_jap;
	// 数学平均点
	private String average_math;
	// 理科平均点
	private String average_siec;
	// 社会平均点
	private String average_scty;
	// 英語平均点
	private String average_eng;

	// 最終更新日
	private Timestamp last_update;
	// 最終更新者ID
	private String last_up_user;

	public String getTestCategory() {
		return testCategory;
	}

	public void setTestCategory(String testCategory) {
		this.testCategory = testCategory;
	}

	public String getTestID() {
		return testID;
	}

	public void setTestID(String testID) {
		this.testID = testID;
	}

	public String getFiscal_year() {
		return fiscal_year;
	}

	public void setFiscal_year(String fiscal_year) {
		this.fiscal_year = fiscal_year;
	}

	public String getTimes() {
		return times;
	}

	public void setTimes(String times) {
		this.times = times;
	}
	
	public String getTest_type() {
		return test_type;
	}

	public void setTest_type(String test_type) {
		this.test_type = test_type;
	}

	public Date getDate_hold() {
		return date_hold;
	}

	public void setDate_hold(Date date_hold) {
		this.date_hold = date_hold;
	}

	public String getAverage_jap() {
		return average_jap;
	}

	public void setAverage_jap(String average_jap) {
		this.average_jap = average_jap;
	}

	public String getAverage_math() {
		return average_math;
	}

	public void setAverage_math(String average_math) {
		this.average_math = average_math;
	}

	public String getAverage_siec() {
		return average_siec;
	}

	public void setAverage_siec(String average_siec) {
		this.average_siec = average_siec;
	}

	public String getAverage_scty() {
		return average_scty;
	}

	public void setAverage_scty(String average_scty) {
		this.average_scty = average_scty;
	}

	public String getAverage_eng() {
		return average_eng;
	}

	public void setAverage_eng(String average_eng) {
		this.average_eng = average_eng;
	}

	public Timestamp getLast_update() {
		return last_update;
	}

	public void setLast_update(Timestamp last_update) {
		this.last_update = last_update;
	}

	public String getLast_up_user() {
		return last_up_user;
	}

	public void setLast_up_user(String last_up_user) {
		this.last_up_user = last_up_user;
	}

	@Override
	public String toString() {
		return "CLS905_SearchResultBean [testCategory=" + testCategory
				+ ", testID=" + testID + ", fiscal_year=" + fiscal_year
				+ ", times=" + times + ", test_type=" + test_type +	", date_hold=" + date_hold
				+ ", average_jap=" + average_jap + ", average_math="
				+ average_math + ", average_siec=" + average_siec
				+ ", average_scty=" + average_scty + ", average_eng="
				+ average_eng + ", last_update=" + last_update
				+ ", last_up_user=" + last_up_user + "]";
	}
}
