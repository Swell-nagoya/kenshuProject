package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS008Bean;
import bean.Mst001_UserMstBean;
import bean.Mst010_CourseMstBean;


public class CLS008DAO extends ConnectionManager {




	/**
	 * 生徒のユーザ情報と生徒情報を取得するSQL文を作成します。
	 * palam長が0の際は全検索を行います。
	 * @param palam 条件にするカラム名
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchTuition() {

		String string = "select	" +
					"MST001.NICKNAME	" +
					",MST010.NAME_COURSE	" +
					",MST010.TUITION	" +
				"from	" +
					"MST010_COURSEMST	MST010	" +
					",MST016_GETCOURSEMST	MST016	" +
					",MST003_GUARDIANMST	MST003	" +
					",MST002_STUDENTMST	MST002	" +
					",MST001_USERMST	MST001	" +
				"where	" +
					"MST002.ID_FAMILY	=	MST003.ID_FAMILY	" +
					"and	MST002.ID_USER	=	MST016.ID_USER	" +
					"and	MST002.ID_USER	=	MST001.ID_USER	" +
					"and	MST016.ID_COURSE	=	MST010.ID_COURSE	" +
					"and	NOW()	BETWEEN	MST010.START_LECTURE	and	MST010.END_LECTURE	" +
					"and	MST016.FLG_DELETE	=	0	" +
					"and	MST003.FLG_DELETE	=	0	" +
					"and	MST002.OUT_CRAMMER	IS	NULL	" +
					"and	MST001.FLG_DELETE	=	0	" +
					"and	MST003.ID_USER	=	?";
		return string;
	}



	/**
	 * 生徒データ、保護者データ、管理者データのいずれかを含むユーザデータを取得します。
	 * @param cls903d
	 * @return List<CLS903Bean>
	 */

	public List<CLS008Bean>  Search(String ID_Login,double ConsumptionTax) {

		PreparedStatement stmt = null;
		ResultSet rs = null;

//		Mst001_UserMstBean mst001_UserMst = null;
//		Mst002_StudentMstBean mst002_StudentMst = null;
//		Mst003_GuardianMstBean mst003_GuardianMst = null;
//		Mst010_CourseMstBean mst010_CourseMst = null;
//		Mst016_GetCourseMstBean mst016_GetCourseMst = null;

		//取得するパラメータ
		List<CLS008Bean> list = new ArrayList<CLS008Bean>();
		//検索対象のカラム

//		//共通で取得するユーザテーブルのBean
//		mst001_UserMst = cls008d.getMst001_UserMstBean();
		String sql = createSQLForSearchTuition();
		System.out.println(sql);


		try{
			stmt = getConnection().prepareStatement(sql);

				stmt.setString(1, ID_Login);

				rs = stmt.executeQuery();

				while (rs.next()) {
					CLS008Bean cls008d2 = new CLS008Bean();
					Mst001_UserMstBean mst001_UserMst = new Mst001_UserMstBean();
					Mst010_CourseMstBean mst010_CourseMst = new Mst010_CourseMstBean();
					mst001_UserMst.setNickname(rs.getString("NICKNAME"));
					mst010_CourseMst.setname_course(rs.getString("NAME_COURSE"));
					mst010_CourseMst.settuition((int)(rs.getInt("TUITION") * (100 + ConsumptionTax) / 100));
					cls008d2.setMst001_UserMstBean(mst001_UserMst);
					cls008d2.setMst010_CourseMstBean(mst010_CourseMst);
					list.add(cls008d2);
				}

				return list;


			} catch (SQLException e) {
				throw new RuntimeException(e);
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
			}
	}
}
