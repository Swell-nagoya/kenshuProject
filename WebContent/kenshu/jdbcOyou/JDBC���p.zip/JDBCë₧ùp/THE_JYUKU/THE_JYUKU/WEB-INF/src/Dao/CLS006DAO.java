package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS006Bean;
import bean.Mst001_UserMstBean;
import bean.Mst010_CourseMstBean;
import bean.Mst013_SubjectMstBean;
import bean.Mst017_TimeTableMstBean;
import bean.Trn010_AttendanceTrnBean;


public class CLS006DAO extends ConnectionManager {

    /**
     * 生徒が取得している集団授業の出席状況情報を取得するSQL文を作成します。
     * @return 作成するSQL文
     */

    public String createSQLForSearchStudent() {
        String string = "SELECT " +
                "MST001.NICKNAME" +
                ",MST013.NAME_SUBJECT " +
                ",TRN010.DATE_LECTURE " +
                ",MST010.NAME_COURSE " +
                ",TRN010.START_TIME_LECTURE " +
                ",MST011.END_TIME_LECTURE " +
                ",TRN010.FLG_ABSENCE " +
                ",TRN010.FLG_LATE " +
                ",TRN010.FLG_EARLY " +
                ",TRN010.FLG_SUBSTITUTE " +
            "FROM " +
                "MST001_USERMST MST001 " +
                ",MST010_COURSEMST MST010 " +
                ",MST011_COURSEMEISAIMST MST011 " +
                ",MST013_SUBJECTMST MST013 " +
                ",TRN010_ATTENDANCETRN TRN010 " +
            "WHERE " +
                "TRN010.ID_USER = MST001.ID_USER " +
                "and TRN010.ID_COURSE = MST011.ID_COURSE " +
                "and TRN010.ID_COURSE = MST010.ID_COURSE " +
                "and MST011.ID_SUBJECT = MST013.ID_SUBJECT " +
                "and DATE_FORMAT(TRN010.DATE_LECTURE,'%Y/%m') = ? " +
                "and MST001.ID_USER = ? " +
                "and MST001.FLG_DELETE = 0 " +
                "and TRN010.FLG_DELETE = 0 " +
            "ORDER BY " +
                "TRN010.DATE_LECTURE DESC " +
                ",MST011.START_LECTURE DESC " +
                ",MST010.NAME_COURSE ";
        return string;
    }



    /**
     * 生徒が取得している集団授業の出席状況情報を取得するSQL文を作成します。
     * @return 作成するSQL文
     */

    public String createSQLForSearchGuardian() {
        String string = "SELECT " +
                "MST001.NICKNAME" +
                ",MST013.NAME_SUBJECT " +
                ",TRN010.DATE_LECTURE " +
                ",MST010.NAME_COURSE " +
                ",TRN010.START_TIME_LECTURE " +
                ",MST011.END_TIME_LECTURE " +
                ",TRN010.FLG_ABSENCE " +
                ",TRN010.FLG_LATE " +
                ",TRN010.FLG_EARLY " +
                ",TRN010.FLG_SUBSTITUTE " +
            "FROM " +
                "MST001_USERMST MST001" +
                ",MST002_STUDENTMST MST002 " +
                ",MST003_GUARDIANMST MST003 " +
                ",MST010_COURSEMST MST010 " +
                ",MST011_COURSEMEISAIMST MST011 " +
                ",MST013_SUBJECTMST MST013 " +
                ",TRN010_ATTENDANCETRN TRN010 " +
            "WHERE " +
                "MST001.ID_USER = MST002.ID_USER " +
                "AND MST002.ID_USER = TRN010.ID_USER " +
                "AND MST003.ID_FAMILY = MST002.ID_FAMILY " +
                "AND TRN010.ID_COURSE = MST011.ID_COURSE " +
                "AND TRN010.ID_COURSE = MST010.ID_COURSE " +
                "AND MST011.ID_SUBJECT = MST013.ID_SUBJECT " +
                "AND DATE_FORMAT(TRN010.DATE_LECTURE,'%Y/%m') = ? " +
                "AND MST003.ID_USER = ? " +
                "AND MST002.OUT_CRAMMER IS NULL " +
                "AND MST003.FLG_DELETE = 0 " +
                "AND TRN010.FLG_DELETE = 0 " +
            "ORDER BY " +
                "TRN010.DATE_LECTURE DESC " +
                ",MST011.START_LECTURE DESC " +
                ",MST010.NAME_COURSE " ;
        return string;
    }


    /**
     * 生徒データ、保護者データ、管理者データのいずれかを含むユーザデータを取得します。
     * @param cls903d
     * @return List<CLS903Bean>
     */

    public List<CLS006Bean>  search(CLS006Bean cls006,String ID_Login,String Month_select,int permission) {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        //取得するパラメータ
        List<CLS006Bean> list = new ArrayList<CLS006Bean>();


        try{

            String sql = null;
            int student = 1;
            int guardian = 2;
            if(permission == student){
                sql = createSQLForSearchStudent();
            }else if(permission == guardian){
                sql = createSQLForSearchGuardian();
            }else {
                return list;
            }
            System.out.println(sql);

            stmt = getConnection().prepareStatement(sql);

            stmt.setString(1, Month_select);
            stmt.setString(2, ID_Login);

            rs = stmt.executeQuery();

            while (rs.next()) {
                CLS006Bean cls006d2 = new CLS006Bean();
                Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();
                Mst013_SubjectMstBean mst013_SubjectMstBean = new Mst013_SubjectMstBean();
                Mst017_TimeTableMstBean mst017_TimeTableMstBean = new Mst017_TimeTableMstBean();
                Mst010_CourseMstBean mst010_CourseMst = new Mst010_CourseMstBean();
                Trn010_AttendanceTrnBean trn010_AttendanceTrnBean = new Trn010_AttendanceTrnBean();
                mst001_UserMstBean.setNickname(rs.getString("NICKNAME"));
                mst013_SubjectMstBean.setname_subject(rs.getString("NAME_SUBJECT"));
                trn010_AttendanceTrnBean.setdate_lecture(rs.getTimestamp("DATE_LECTURE"));
                mst010_CourseMst.setname_course(rs.getString("NAME_COURSE"));
                mst017_TimeTableMstBean.setstart_lecture(rs.getTimestamp("START_TIME_LECTURE"));
                mst017_TimeTableMstBean.setend_lecture(rs.getTimestamp("END_TIME_LECTURE"));
                trn010_AttendanceTrnBean.setflg_absence(rs.getInt("FLG_ABSENCE"));
                trn010_AttendanceTrnBean.setflg_late(rs.getInt("FLG_LATE"));
                trn010_AttendanceTrnBean.setflg_early(rs.getInt("FLG_EARLY"));
                trn010_AttendanceTrnBean.setflg_substitute(rs.getInt("FLG_SUBSTITUTE"));
                cls006d2.setMst001_UserMstBean(mst001_UserMstBean);
                cls006d2.setMst010_CourseMstBean(mst010_CourseMst);
                cls006d2.setMst013_SubjectMstBean(mst013_SubjectMstBean);
                cls006d2.setMst017_TimeTableMstBean(mst017_TimeTableMstBean);
                cls006d2.setTrn010_AttendanceTrnBean(trn010_AttendanceTrnBean);
                list.add(cls006d2);
            }


            return list;


        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
