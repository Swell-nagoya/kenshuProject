package bean;

import java.sql.Timestamp;

/**
 * CLS906のBEAN
 * @author n-kuraoka
 *
 */
public class CLS009Bean {

    //ID_USER
    String id_user = null;

    //NAME_USER
    String name_user = null;

    //NAME_SUBJECT
    String name_subject = null;

    //DAY_LECTURE
    int day_lecture = 0;

    //ID_SUBJECT
    String id_subject = null;

    int flg_delete = 0;

    //ID_LASTUPDATE
    String id_lastupdate = null;

    //DATE_LASTUPDATE
    Timestamp date_lastupdate = null;

    //START_LECTURE
    Timestamp start_lecture = null;

    //END_LECTURE
    Timestamp end_lecture = null;

    //DATE_LECTURE
    Timestamp date_lecture = null;

    //NAME_TEACHER
    String name_teacher = null;

    //ID_COURCE
    String id_cource = null;

    //DATE_SUBSTITUTE
    Timestamp date_substitute = null;

    //timetable_substitute
    int timetable_substitute;

    //REPORT
    String report = null;

    //HOMEWORK
    String homework;
    /**
     * @return id_user
     */
    public String getId_user() {
        return id_user;
    }

    /**
     * @param id_user セットする id_user
     */
    public void setId_user(String id_user) {
        this.id_user = id_user;
    }

    /**
     * @return name_subject
     */
    public String getName_subject() {
        return name_subject;
    }

    /**
     * @param name_subject セットする name_subject
     */
    public void setName_subject(String name_subject) {
        this.name_subject = name_subject;
    }

    /**
     * @return day_lecture
     */
    public int getDay_lecture() {
        return day_lecture;
    }

    /**
     * @param day_lecture セットする day_lecture
     */
    public void setDay_lecture(int day_lecture) {
        this.day_lecture = day_lecture;
    }

    /**
     * @return id_subject
     */
    public String getId_subject() {
        return id_subject;
    }

    /**
     * @param id_subject セットする id_subject
     */
    public void setId_subject(String id_subject) {
        this.id_subject = id_subject;
    }

    /**
     * @return flg_delete
     */
    public int getFlg_delete() {
        return flg_delete;
    }

    /**
     * @param flg_delete セットする flg_delete
     */
    public void setFlg_delete(int flg_delete) {
        this.flg_delete = flg_delete;
    }

    /**
     * @return id_lastupdate
     */
    public String getId_lastupdate() {
        return id_lastupdate;
    }

    /**
     * @param id_lastupdate セットする id_lastupdate
     */
    public void setId_lastupdate(String id_lastupdate) {
        this.id_lastupdate = id_lastupdate;
    }

    /**
     * @return date_lastupdate
     */
    public Timestamp getDate_lastupdate() {
        return date_lastupdate;
    }

    /**
     * @param date_lastupdate セットする date_lastupdate
     */
    public void setDate_lastupdate(Timestamp date_lastupdate) {
        this.date_lastupdate = date_lastupdate;
    }

    /**
     * @return start_lecture
     */
    public Timestamp getStart_lecture() {
        return start_lecture;
    }

    /**
     * @param start_lecture セットする start_lecture
     */
    public void setStart_lecture(Timestamp start_lecture) {
        this.start_lecture = start_lecture;
    }

    /**
     * @return end_lecture
     */
    public Timestamp getEnd_lecture() {
        return end_lecture;
    }

    /**
     * @param end_lecture セットする end_lecture
     */
    public void setEnd_lecture(Timestamp end_lecture) {
        this.end_lecture = end_lecture;
    }

    /**
     * @return date_lecture
     */
    public Timestamp getDate_lecture() {
        return date_lecture;
    }

    /**
     * @param date_lecture セットする date_lecture
     */
    public void setDate_lecture(Timestamp date_lecture) {
        this.date_lecture = date_lecture;
    }

    /**
     * @return name_teacher
     */
    public String getName_teacher() {
        return name_teacher;
    }

    /**
     * @param name_teacher セットする name_teacher
     */
    public void setName_teacher(String name_teacher) {
        this.name_teacher = name_teacher;
    }

    /**
     * @return id_cource
     */
    public String getId_cource() {
        return id_cource;
    }

    /**
     * @param id_cource セットする id_cource
     */
    public void setId_cource(String id_cource) {
        this.id_cource = id_cource;
    }

    /**
     * @return date_substitute
     */
    public Timestamp getDate_substitute() {
        return date_substitute;
    }

    /**
     * @param date_substitute セットする date_substitute
     */
    public void setDate_substitute(Timestamp date_substitute) {
        this.date_substitute = date_substitute;
    }

    /**
     * @return timetable_substitute
     */
    public int getTimetable_substitute() {
        return timetable_substitute;
    }

    /**
     * @param timetable_substitute セットする timetable_substitute
     */
    public void setTimetable_substitute(int timetable_substitute) {
        this.timetable_substitute = timetable_substitute;
    }

    /**
     * @return report
     */
    public String getReport() {
        return report;
    }

    /**
     * @param report セットする report
     */
    public void setReport(String report) {
        this.report = report;
    }

    public String getHomework() {
        return homework;
    }

    public void setHomework(String homework) {
        this.homework = homework;
    }

    public String getName_user() {
        return name_user;
    }

    public void setName_user(String name_user) {
        this.name_user = name_user;
    }


}
