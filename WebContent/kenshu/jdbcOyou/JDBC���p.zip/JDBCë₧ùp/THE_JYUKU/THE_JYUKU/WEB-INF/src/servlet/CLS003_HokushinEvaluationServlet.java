package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.CLS003HokushinDAO;
import Dao.ConnectionManager;
import bean.CLS003Bean;
import bean.Mst001_UserMstBean;


/**
 *
 * @author hasumi
 *
 */
public class CLS003_HokushinEvaluationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);
		
		//過去に取得したパラメータを削除
		request.removeAttribute("cls003");

		session.removeAttribute("alart");


		//Daoの取得
		CLS003HokushinDAO cls003dao = new CLS003HokushinDAO();

		//取得予定のリスト
		List<CLS003Bean> list = new ArrayList<CLS003Bean>();

		//フォームの取得
		Mst001_UserMstBean mst001_login = (Mst001_UserMstBean)session.getAttribute("loginSession");
		int permission = mst001_login.getPermission();

		String userID = mst001_login.getId_user();
		String selectYear = null;
		String selectTimes = null;

		System.out.println(userID);

		ConnectionManager.beginTransaction();

		//menuパラメータに値が入っていない場合は成績画面から年度と学期を
		//選択してきた場合なのでパラメータ取得
		if(request.getParameter("menu") == null){
			selectYear = request.getParameter("YEAR");
			selectTimes = request.getParameter("TIMES");
		//それ以外の場合はメニュー画面からの遷移
		}else{
			//現在の日付から年月を取得
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
			Date today = new Date();
			selectYear = sdf.format(today);
			//回次は0とする（レコードを取得しないため）
			selectTimes = "0";
		}
		//DBからレコード取得
		list = cls003dao.Search(userID,selectYear,selectTimes,permission);

		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("キチンとここまで処理できましたよ！！やったね！！");

		//値をJSPに渡して終了
		session.setAttribute("cls003", list);
		request.setAttribute("YEAR",selectYear);
		request.setAttribute("TIMES",selectTimes);
		request.getRequestDispatcher("JSP/topmenu/menu/CLS003_HokushinEvaluation.jsp").forward(request, response);




	}
}

