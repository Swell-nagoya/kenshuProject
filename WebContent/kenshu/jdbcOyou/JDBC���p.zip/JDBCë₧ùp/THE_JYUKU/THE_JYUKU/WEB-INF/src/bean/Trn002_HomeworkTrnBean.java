

package bean;

import java.sql.Timestamp;

public class Trn002_HomeworkTrnBean {

	String id_course;
	Timestamp date_lecture;
	String homework;
	int flg_delete;
	String id_lastupdate;
	Timestamp date_lastupdate;

	/**
	 * @return id_course
	 */
	public String getId_course() {
		return id_course;
	}
	/**
	 * @param id_course セットする id_course
	 */
	public void setId_course(String id_course) {
		this.id_course = id_course;
	}
	/**
	 * @return date_lecture
	 */
	public Timestamp getDate_lecture() {
		return date_lecture;
	}
	/**
	 * @param date_lecture セットする date_lecture
	 */
	public void setDate_lecture(Timestamp date_lecture) {
		this.date_lecture = date_lecture;
	}
	/**
	 * @return homework
	 */
	public String getHomework() {
		return homework;
	}
	/**
	 * @param homework セットする homework
	 */
	public void setHomework(String homework) {
		this.homework = homework;
	}
	/**
	 * @return flg_delete
	 */
	public int getFlg_delete() {
		return flg_delete;
	}
	/**
	 * @param flg_delete セットする flg_delete
	 */
	public void setFlg_delete(int flg_delete) {
		this.flg_delete = flg_delete;
	}
	/**
	 * @return id_lastupdate
	 */
	public String getId_lastupdate() {
		return id_lastupdate;
	}
	/**
	 * @param id_lastupdate セットする id_lastupdate
	 */
	public void setId_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}
	/**
	 * @return date_lastupdate
	 */
	public Timestamp getDate_lastupdate() {
		return date_lastupdate;
	}
	/**
	 * @param date_lastupdate セットする date_lastupdate
	 */
	public void setDate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}

}
