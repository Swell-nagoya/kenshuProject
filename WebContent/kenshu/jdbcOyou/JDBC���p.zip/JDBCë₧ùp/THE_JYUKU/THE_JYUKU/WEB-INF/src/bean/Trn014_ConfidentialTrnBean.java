package bean;

import java.sql.Timestamp;

public class Trn014_ConfidentialTrnBean {
	// ユーザーID
	String id_user = null;
	// 年度
	int fiscal_year = 0;
	// 回次
	int times = 0;
	// 評価段階数
	int type_evaluation = 0;
	// 国語
	int conf_jap = 0;
	// 数学
	int conf_math = 0;
	// 理科
	int conf_siec = 0;
	// 社会
	int conf_scty = 0;
	// 英語
	int conf_eng = 0;
	// 技術家庭
	int conf_tech = 0;
	// 体育
	int conf_gmst = 0;
	// 音楽
	int conf_music = 0;
	// 美術
	int conf_arts = 0;
	// 削除フラグ
	int flg_delete = 0;
	// 最終更新ID
	String id_lastupdate = null;
	// 最終更新日
	Timestamp date_lastupdate;
	// 年度件数
	int yearCount = 0;
	// 回次件数
	int timesCount = 0;
	// 検索期間
	int parseInt = 0;
	// 検索期間(終了)
	int parseInt_end = 0;

	/**
	 * ユーザーIDを設定します。
	 * @param id_user
	 */
	public void setid_user(String id_user) {
		this.id_user = id_user;
	}

	/**
	 * 年度を設定します。
	 * @param fiscal_year
	 */
	public void setfiscal_year(int fiscal_year) {
		this.fiscal_year = fiscal_year;
	}

	/**
	 * 回次を設定します。
	 * @param times
	 */
	public void settimes(int times) {
		this.times = times;
	}

	/**
	 * 評価段階数を設定します。
	 * @param type_evaluation
	 */
	public void settype_evaluation(int type_evaluation) {
		this.type_evaluation = type_evaluation;
	}

	/**
	 * 国語を設定します。
	 * @param conf_jap
	 */
	public void setconf_jap(int conf_jap) {
		this.conf_jap = conf_jap;
	}

	/**
	 * 数学を設定します。
	 * @param conf_math
	 */
	public void setconf_math(int conf_math) {
		this.conf_math = conf_math;
	}

	/**
	 * 理科を設定します。
	 * @param conf_siec
	 */
	public void setconf_siec(int conf_siec) {
		this.conf_siec = conf_siec;
	}

	/**
	 * 社会を設定します。
	 * @param conf_scty
	 */
	public void setconf_scty(int conf_scty) {
		this.conf_scty = conf_scty;
	}

	/**
	 * 英語を設定します。
	 * @param conf_eng
	 */
	public void setconf_eng(int conf_eng) {
		this.conf_eng = conf_eng;
	}

	/**
	 * 技術家庭を設定します。
	 * @param conf_tech
	 */
	public void setconf_tech(int conf_tech) {
		this.conf_tech = conf_tech;
	}

	/**
	 * 体育を設定します。
	 * @param conf_gmst
	 */
	public void setconf_gmst(int conf_gmst) {
		this.conf_gmst = conf_gmst;
	}

	/**
	 * 音楽を設定します。
	 * @param conf_music
	 */
	public void setconf_music(int conf_music) {
		this.conf_music = conf_music;
	}

	/**
	 * 美術を設定します。
	 * @param conf_arts
	 */
	public void setconf_arts(int conf_arts) {
		this.conf_arts = conf_arts;
	}

	/**
	 * 削除フラグを設定します。
	 * @param flg_delete
	 */
	public void setflg_delete(int flg_delete) {
		this.flg_delete = flg_delete;
	}

	/**
	 * 最終更新IDを設定します。
	 * @param id_lastupdate
	 */
	public void setid_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}

	/**
	 * 最終更新日を設定します。
	 * @param date_lastupdate
	 */
	public void setdate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}

	/**
	 * ユーザーIDを取得します。
	 * @param id_user
	 */
	public String getid_user() {
		return id_user;
	}

	/**
	 * 年度を取得します。
	 * @param fiscal_year
	 */
	public int getfiscal_year() {
		return fiscal_year;
	}

	/**
	 * 回次を取得します。
	 * @param times
	 */
	public int gettimes() {
		return times;
	}

	/**
	 * 評価段階数を取得します。
	 * @param type_evaluation
	 */
	public int gettype_evaluation() {
		return type_evaluation;
	}

	/**
	 * 国語を取得します。
	 * @param conf_jap
	 */
	public int getconf_jap() {
		return conf_jap;
	}

	/**
	 * 数学を取得します。
	 * @param conf_math
	 */
	public int getconf_math() {
		return conf_math;
	}

	/**
	 * 理科を取得します。
	 * @param conf_siec
	 */
	public int getconf_siec() {
		return conf_siec;
	}

	/**
	 * 社会を取得します。
	 * @param conf_scty
	 */
	public int getconf_scty() {
		return conf_scty;
	}

	/**
	 * 英語を取得します。
	 * @param conf_eng
	 */
	public int getconf_eng() {
		return conf_eng;
	}

	/**
	 * 技術家庭を取得します。
	 * @param conf_tech
	 */
	public int getconf_tech() {
		return conf_tech;
	}

	/**
	 * 体育を取得します。
	 * @param conf_gmst
	 */
	public int getconf_gmst() {
		return conf_gmst;
	}

	/**
	 * 音楽を取得します。
	 * @param conf_music
	 */
	public int getconf_music() {
		return conf_music;
	}

	/**
	 * 美術を取得します。
	 * @param conf_arts
	 */
	public int getconf_arts() {
		return conf_arts;
	}

	/**
	 * 削除フラグを取得します。
	 * @param flg_delete
	 */
	public int getflg_delete() {
		return flg_delete;
	}

	/**
	 * 最終更新IDを取得します。
	 * @param id_lastupdate
	 */
	public String getid_lastupdate() {
		return id_lastupdate;
	}

	/**
	 * 最終更新日を取得します。
	 * @param date_lastupdate
	 */
	public Timestamp getdate_lastupdate() {
		return date_lastupdate;
	}

	/**
	 * yearCountを取得します。
	 * @return yearCount
	 */
	public int getYearCount() {
	    return yearCount;
	}

	/**
	 * yearCountを設定します。
	 * @param yearCount yearCount
	 */
	public void setYearCount(int yearCount) {
	    this.yearCount = yearCount;
	}

	/**
	 * timesCountを取得します。
	 * @return timesCount
	 */
	public int getTimesCount() {
	    return timesCount;
	}

	/**
	 * timesCountを設定します。
	 * @param timesCount timesCount
	 */
	public void setTimesCount(int timesCount) {
	    this.timesCount = timesCount;
	}

	public int getKikan_start() {
		// TODO 自動生成されたメソッド・スタブ
		return parseInt;
	}

	public int getKikan_end() {
		// TODO 自動生成されたメソッド・スタブ
		return parseInt_end;
	}

	public void setKikan_start(int parseInt) {
		this.parseInt = parseInt;
	}

	public void setKikan_end(int parseInt_end) {
		this.parseInt_end = parseInt_end;
	}
}