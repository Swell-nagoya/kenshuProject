package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.CLS002DAO;
import Dao.ConnectionManager;
import Dao.Mst020_ConstantMstDAO;
import bean.CLS002Bean;
import bean.CLS002_ForCalender;
import bean.Mst001_UserMstBean;

import common.ServretCommon;

public class CLS002_TOPServret extends HttpServlet {

        public void doPost(HttpServletRequest request,
                HttpServletResponse response)
                        throws ServletException, IOException {
            //よくわからないけどこうしたい下手くそな実装があったのでby倉岡
            doGet(request, response);
        }
        public void doGet(HttpServletRequest request,
                HttpServletResponse response)
                    throws ServletException, IOException {


            //DAOの生成
            CLS002DAO cls002dao = new CLS002DAO();

            //セッションの取得
            HttpSession session = request.getSession();

            //セッション情報を値にぶち込む
            Mst001_UserMstBean mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");
            String id_user = mst001_UserMstBean.getId_user();

            Calendar calendar = Calendar.getInstance();
            int month;
            int year;
            if (request.getParameter("year") != null){
                year = Integer.parseInt(request.getParameter("year"));
            } else {
                year = calendar.get(Calendar.YEAR);
            }
            if (request.getParameter("month") != null){
                month = Integer.parseInt(request.getParameter("month"));
                if (month > 12) {
                    month = 1;
                    year++;
                }
                if (month < 1) {
                    month = 12;
                    year--;
                }
            } else {
                month = calendar.get(Calendar.MONTH) + 1;
            }

            calendar.set(year, month, 1);
            //トランザクションを開く、各種DAOの実行
            ConnectionManager.beginTransaction();
            //グループ授業取得
            List<CLS002Bean> groupBeans = cls002dao.CourseSubjectTimeTableFindByUser(id_user);
            //定数マスタから休校日を取得
            Date date = new Date();
            Timestamp today = new Timestamp(date.getTime());
            Mst020_ConstantMstDAO mst020_ConstantMstDAO = new Mst020_ConstantMstDAO();
            List<String> restDays = mst020_ConstantMstDAO.getConstants(today, "REST_SCHOOL");
            List<String> max_carender_span = mst020_ConstantMstDAO.getConstants(today, "MAX_CARENDER_SPAN");
            List<String> min_carender_span = mst020_ConstantMstDAO.getConstants(today, "MIN_CARENDER_SPAN");

            List<CLS002Bean> substituteBeans = cls002dao.substituteFindByUser(id_user);
            List<CLS002Bean> homeworkBeans = cls002dao.getHomeWorkTimeTableList(id_user, month + 1);
            List<CLS002_ForCalender> calendarList = getLectureDays(calendar, groupBeans, substituteBeans);

            //トランザクションを開く
            try {
                ConnectionManager.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //セッション情報の削除、付与
            session.removeAttribute("calendarList");
            session.removeAttribute("restDays");
            session.removeAttribute("homeworkBeans");

            session.setAttribute("calendarList", calendarList);
            session.setAttribute("substituteBeans", substituteBeans);
            session.setAttribute("restDays", restDays);
            session.setAttribute("homeworkBeans", homeworkBeans);
            session.setAttribute("month", Integer.valueOf(month));
            session.setAttribute("year", Integer.valueOf(year));
            session.setAttribute("max_carender_span", (max_carender_span.size() > 0) ? max_carender_span.get(0) : null);
            session.setAttribute("min_carender_span", (min_carender_span.size() > 0) ? min_carender_span.get(0) : null);

            //次画面に飛ぶ
            if (request.getParameter("month") != null){
                request.getRequestDispatcher("JSP/topmenu/CLS002_top.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("JSP/topmenu/index.jsp").forward(request, response);
            }


        }

    /**
     * TIMESTAMP型にパースできないものを省き、指定月の休校日を取得する。
     * @param restDays
     * @return
     */
    public static List<String> getEnableRestDays(List<String> restDays, int month) {
        List<String> list = new ArrayList<>();
        for (String restDay : restDays) {
            try {
                Timestamp timestamp = Timestamp.valueOf(restDay);
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(timestamp.getTime());
                int date = calendar.get(Calendar.DATE);
                list.add(String.valueOf(date));
            } catch (Exception e) {
                System.out.println("cls002_休校日の定数値に不正な値が存在します。CONSTANT：" + restDay);
            }
        }
            return list;
        }
    public static List<CLS002_ForCalender> getLectureDays(Calendar calendar, List<CLS002Bean> list, List<CLS002Bean> substitute) {

        //日付の設定

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) - 1;

        //画面表示用のリストビーン
        List<CLS002_ForCalender> calendarBeans = new ArrayList<>();

        for (CLS002Bean bean : list) {
            CLS002_ForCalender calendarBean = new CLS002_ForCalender();
            calendarBean.setName_Cource(bean.getName_subject());
            calendarBean.setStartLecture(bean.getStart_time_lecture());
            calendarBean.setEndLecture(bean.getEnd_time_lecture());
            List<Integer> lectureDays = new ArrayList<>();
            for (int day = 1; day <= calendar.getActualMaximum(Calendar.DATE); day++) {
                calendar.set(year, month, day);
                if (ServretCommon.checkEnableLecture(bean, year, month, day)) {
                    switch (calendar.get(Calendar.DAY_OF_WEEK)) {
                    case Calendar.SUNDAY:
                        if (bean.getDay_lecture() == 6) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    case Calendar.MONDAY:
                        if (bean.getDay_lecture() == 0) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    case Calendar.TUESDAY:
                        if (bean.getDay_lecture() == 1) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    case Calendar.WEDNESDAY:
                        if (bean.getDay_lecture() == 2) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    case Calendar.THURSDAY:
                        if (bean.getDay_lecture() == 3) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    case Calendar.FRIDAY:
                        if (bean.getDay_lecture() == 4) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    case Calendar.SATURDAY:
                        if (bean.getDay_lecture() == 5) {
                            if (!isSubstitute(bean, year, month, day, substitute)) {
                                lectureDays.add(day);
                            }
                        }
                        break;
                    }
                }
            }
            calendarBean.setExistLessonDays(lectureDays);
            calendarBeans.add(calendarBean);
        }

        return calendarBeans;
    }
    private static Timestamp[] getCheckedSubstitute(CLS002Bean bean, int year, int month, int day, List<CLS002Bean> substitutes) {

        for (CLS002Bean substitute : substitutes) {
            if (bean.getId_cource().equals(substitute.getId_cource())) {
                int substitute_Year = Integer.parseInt(substitute.getDate_substitute().toString().split(" ")[0].split("-")[0]);
                int substitute_Month = Integer.parseInt(substitute.getDate_substitute().toString().split(" ")[0].split("-")[1]);
                int substitute_Day = Integer.parseInt(substitute.getDate_substitute().toString().split(" ")[0].split("-")[2]);

                if (substitute_Year == year
                 && substitute_Month == month
                 && substitute_Day == day) {
                    Timestamp[] timestamps = {substitute.getStart_lecture(),substitute.getEnd_lecture()};
                    return timestamps;
                }
            }
        }
        return null;
    }
    private static boolean isSubstitute(CLS002Bean bean, int year, int month, int day, List<CLS002Bean> substitutes) {

        for (CLS002Bean substitute : substitutes) {
            if (bean.getId_cource() != null && substitute.getId_cource() != null) {
                if (bean.getId_cource().equals(substitute.getId_cource())) {
                    int substitute_Year = Integer.parseInt(substitute.getDate_substitute().toString().split(" ")[0].split("-")[0]);
                    int substitute_Month = Integer.parseInt(substitute.getDate_substitute().toString().split(" ")[0].split("-")[1]);
                    int substitute_Day = Integer.parseInt(substitute.getDate_substitute().toString().split(" ")[0].split("-")[2]);

                    if (substitute_Year == year
                     && substitute_Month == month + 1
                     && substitute_Day == day) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}
