package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.CommonUtil;
import bean.CLS003Bean;
import bean.Mst001_UserMstBean;
import bean.Trn014_ConfidentialTrnBean;


public class CLS003ConfidentialDAO extends ConnectionManager {




	/**
	 * 成績を取得するSQL文を作成します。（生徒用）
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchCrammerStudent() {
		String string = "select " +
				"MST001.NICKNAME " +
				",TRN014.CONF_JAP " +
				",TRN014.CONF_MATH " +
				",TRN014.CONF_SIEC " +
				",TRN014.CONF_SCTY " +
				",TRN014.CONF_ENG " +
				",TRN014.CONF_TECH " +
				",TRN014.CONF_GMST " +
				",TRN014.CONF_MUSIC " +
				",TRN014.CONF_ARTS " +
			"from " +
				"MST001_USERMST MST001 " +
				",TRN014_CONFIDENTIALTRN TRN014 " +
			"where " +
				"MST001.ID_USER = ? " +
				"and MST001.ID_USER = TRN014.ID_USER " +
				"and TRN014.FISCAL_YEAR = ? " +
				"and TRN014.TIMES = ? " +
				"and TRN014.FLG_DELETE = 0 ";

		return string;
	}



	/**
	 * 成績を取得するSQL文を作成します。（保護者用）
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchGuardian() {
		String string = "select " +
				"MST001.NICKNAME " +
				",TRN014.CONF_JAP " +
				",TRN014.CONF_MATH " +
				",TRN014.CONF_SIEC " +
				",TRN014.CONF_SCTY " +
				",TRN014.CONF_ENG " +
				",TRN014.CONF_TECH " +
				",TRN014.CONF_GMST " +
				",TRN014.CONF_MUSIC " +
				",TRN014.CONF_ARTS " +
			"from " +
				"MST001_USERMST MST001 " +
				",MST002_STUDENTMST MST002 " +
				",MST003_GUARDIANMST MST003 " +
				",TRN014_CONFIDENTIALTRN TRN014 " +
			"where " +
				"MST003.ID_USER = ? " +
				"and MST001.ID_USER = TRN014.ID_USER " +
				"and MST002.ID_FAMILY = MST003.ID_FAMILY " +
				"and MST001.ID_USER = MST002.ID_USER " +
				"and TRN014.FISCAL_YEAR = ? " +
				"and TRN014.TIMES = ? " +
				"and TRN014.FLG_DELETE = 0 ";

		return string;
	}


	/**
	 * 年度を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */

	public String createSQLForGetFiscalYear() {
		String string = "select " +
				"TRN014.FISCAL_YEAR " +
			"from " +
				"TRN014_CONFIDENTIALTRN TRN014 " +
			"where " +
				"TRN014.FLG_DELETE = 0 " +
			"group by " +
				"TRN014.FISCAL_YEAR";
		return string;
	}


	/**
	 * 学期を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */
	public String createSQLForGetTimes() {
		String string = "select " +
				"TRN014.TIMES " +
			"from " +
				"TRN014_CONFIDENTIALTRN TRN014 " +
			"where " +
				"TRN014.ID_TEST = TRN014.ID_TEST " +
				"and TRN014.FLG_DELETE = 0 ";
		return string;
	}


	/**
	 * 年度を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */

	public String createSQLForGetMaxFiscalYear() {
		String string = "select " +
				"MAX(TRN014.FISCAL_YEAR) " +
			"from " +
				"TRN014_CONFIDENTIALTRN TRN014 " +
			"where " +
				"TRN014.FLG_DELETE = 0 ";
		return string;
	}

	/**
	 * 学期を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */
	public String createSQLForGetMaxTimes() {
		String string = "select " +
				"MAX(TRN014.TIMES) " +
			"from " +
				"TRN014_CONFIDENTIALTRN TRN014 " +
			"where " +
				"TRN014.FLG_DELETE = 0 ";
		return string;
	}

	/**
	 * 成績を取得します。
	 * @param
	 * @return List<CLS003Bean>
	 */

	public List<CLS003Bean>  Search(String LoginID,String FiscalYear,String Times,int permission) {

		PreparedStatement stmt = null;
		ResultSet rs = null;

		//取得するパラメータ
		List<CLS003Bean> list = new ArrayList<CLS003Bean>();


		try{
			String sql = null;
			int student = 1;
			int guardian = 2;
			//年度のMAXを取得するSQL取得
			sql = createSQLForGetMaxFiscalYear();
			System.out.println(sql);
			stmt = getConnection().prepareStatement(sql);
			rs = stmt.executeQuery();
			//年度のMAX取得
			while (rs.next()) {
				CLS003Bean cls003d2 = new CLS003Bean();
				Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();
				trn014_ConfidentialTrnBean.setYearCount(rs.getInt("MAX(TRN014.FISCAL_YEAR)"));
				cls003d2.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean);
				list.add(cls003d2);
			}
			sql = createSQLForGetMaxTimes();
			System.out.println(sql);
			stmt = getConnection().prepareStatement(sql);

			rs = stmt.executeQuery();
			//学期の最大値を取得
			while (rs.next()) {
				CLS003Bean cls003d2 = new CLS003Bean();
				Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();
				trn014_ConfidentialTrnBean.setTimesCount(rs.getInt("MAX(TRN014.TIMES)"));
				cls003d2.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean);
				list.add(cls003d2);
			}
			//権限によって流すSQLを分ける
			if(permission == student){
				sql = createSQLForSearchCrammerStudent();
			}else if(permission == guardian){
				sql = createSQLForSearchGuardian();
			}else {
				return list;
			}
			System.out.println(sql);

			//成績を取得
			stmt = getConnection().prepareStatement(sql);
			int intFiscalYear = Integer.parseInt(FiscalYear);
			int intTimes = Integer.parseInt(Times);
			stmt.setString(1, LoginID);
			stmt.setInt(2, intFiscalYear);
			stmt.setInt(3, intTimes);

			rs = stmt.executeQuery();
			int count = CommonUtil.getCountResult(rs);

			while (rs.next()) {
				CLS003Bean cls003d2 = new CLS003Bean();
				Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();
				Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = new Trn014_ConfidentialTrnBean();
				mst001_UserMstBean.setNickname(rs.getString("NICKNAME"));
				trn014_ConfidentialTrnBean.setconf_jap(rs.getInt("CONF_JAP"));
				trn014_ConfidentialTrnBean.setconf_math(rs.getInt("CONF_MATH"));
				trn014_ConfidentialTrnBean.setconf_siec(rs.getInt("CONF_SIEC"));
				trn014_ConfidentialTrnBean.setconf_scty(rs.getInt("CONF_SCTY"));
				trn014_ConfidentialTrnBean.setconf_eng(rs.getInt("CONF_ENG"));
				trn014_ConfidentialTrnBean.setconf_arts(rs.getInt("CONF_ARTS"));
				trn014_ConfidentialTrnBean.setconf_tech(rs.getInt("CONF_TECH"));
				trn014_ConfidentialTrnBean.setconf_gmst(rs.getInt("CONF_GMST"));
				trn014_ConfidentialTrnBean.setconf_music(rs.getInt("CONF_MUSIC"));


				cls003d2.setMst001_UserMstBean(mst001_UserMstBean);
				cls003d2.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean);
				cls003d2.setCount(count);

				list.add(cls003d2);
			}


			return list;


		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
}
