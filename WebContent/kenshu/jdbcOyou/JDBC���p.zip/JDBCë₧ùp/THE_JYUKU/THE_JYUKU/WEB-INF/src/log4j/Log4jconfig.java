package log4j;

import org.apache.log4j.Logger;

/**
 * Log4j用の設定クラス
 * ここにログの掃き出しの各種設定を行う（予定）
 * @author n-kuraoka
 *
 */

public class Log4jconfig {


	static Logger log = Logger.getLogger(Log4jconfig.class.getName());


}
