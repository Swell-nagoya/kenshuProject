
package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import bean.Trn001_ReportTrnBean;

public class Trn001_ReportTrnDAO extends DataAccessObject {

        /**
         * �o�^�������s���܂��B
         * @param Trn001_ReportTrn trn001_reporttrn
         */
        public void create(Trn001_ReportTrnBean trn001_reporttrn) {
            update(createSQLForCreate(),
                new Object[] {
                trn001_reporttrn.getid_course()
                ,trn001_reporttrn.getdate_lecture()
                ,trn001_reporttrn.getreport()
                ,trn001_reporttrn.getflg_delete()
                ,trn001_reporttrn.getid_lastupdate()
                ,trn001_reporttrn.getdate_lastupdate()
                });
        }

        /**
         * �X�V�������s���܂��B
         * @param Trn001_ReportTrn trn001_reporttrn
         */
        public void update(Trn001_ReportTrnBean trn001_reporttrn) {
            update(createSQLForUpdate(),
                new Object[] {
                trn001_reporttrn.getid_course()
                ,trn001_reporttrn.getdate_lecture()
                ,trn001_reporttrn.getreport()
                ,trn001_reporttrn.getflg_delete()
                ,trn001_reporttrn.getid_lastupdate()
                ,trn001_reporttrn.getdate_lastupdate()
                ,trn001_reporttrn.getid_course()
                ,trn001_reporttrn.getdate_lecture()
                });
        }

        /**
         * PK�������ɍX�V�������s���܂��B
         * @param Trn001_ReportTrn trn001_reporttrn
         * @param Timestamp date_lecture
         */
        public void update_PK(Trn001_ReportTrnBean trn001_reporttrn,Timestamp date_lecture) {
            update(createSQLForUpdate(),
                new Object[] {
                trn001_reporttrn.getid_course()
                ,trn001_reporttrn.getdate_lecture()
                ,trn001_reporttrn.getreport()
                ,trn001_reporttrn.getflg_delete()
                ,trn001_reporttrn.getid_lastupdate()
                ,trn001_reporttrn.getdate_lastupdate()
                ,trn001_reporttrn.getid_course()
                ,date_lecture
                });
        }
        /**
         * ��L�[�������s���܂��B
         * @param id_course �R�[�XID
         * @return id_course
         * @param date_lecture �J�Ó�
         * @return date_lecture
         */
        public Trn001_ReportTrnBean findByPrimaryKey(String userno,Timestamp date) {
            return (Trn001_ReportTrnBean) query(createSQLForFindByPK(), new Object[]{userno, date}, Trn001_ReportTrnBean.class);
        }

        private static final String SQL_Date_Lecture_Check = "SELECT ID_COURSE,DATE_LECTURE FROM TRN001_REPORTTRN WHERE ID_COURSE = ? AND DATE_LECTURE = ?";

        public boolean Date_Lecture_Cheak(String id_course ,Timestamp date_lecture){

            boolean bool= true;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                stmt = getConnection().prepareStatement(SQL_Date_Lecture_Check);
                stmt.setString(1, id_course);
                stmt.setTimestamp(2, date_lecture);
                rs = stmt.executeQuery();
            if (rs.next()) {
                bool=false;
            }

            } catch (SQLException e) {
                e.getMessage();
                e.printStackTrace();
            } finally {
                if (stmt != null) {
                    try {
                        stmt.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
            return bool;
        }
        @Override
        public String[] getPKColumns() {
            return new String[] {"id_course","date_lecture"};
        }

        @Override
        public String[] getColumns() {
            return new String[] {"ID_COURSE"
                ,"DATE_LECTURE"
                ,"REPORT"
                ,"FLG_DELETE"
                ,"ID_LASTUPDATE"
                ,"DATE_LASTUPDATE"
            };
        }

        @Override
        public String getTableName() {
            return "TRN001_REPORTTRN";
        }

}
