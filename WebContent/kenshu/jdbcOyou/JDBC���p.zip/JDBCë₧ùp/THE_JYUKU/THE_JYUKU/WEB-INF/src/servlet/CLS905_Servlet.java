package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import util.Message;
import util.StringUtil;
import Dao.CLS906DAO;
import Dao.CLS907DAO;
import Dao.DaoFactory;
import bean.CLS905_SearchBean;
import bean.CLS905_SearchResultBean;
import bean.CLS907_SearchResutlBean;
import bean.CLS907_testConstantsBean;

/**
 * 905テストの検索を行う
 * @author kume
 *
 */
public class CLS905_Servlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=Windows-31J");
		request.setCharacterEncoding("Windows-31J");

		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		//テスト検索・登録に関連するセッション情報を削除
		CLS906_Servlet.removeSession(session);

		// テスト定数取得メソッド呼び出し
		List<CLS907_testConstantsBean> list = CLS907DAO.getTestConstants();

		// セッションに格納し、テスト検索画面に遷移
		session.setAttribute("TestConstants", list);
		request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS905_TestSearch.jsp").forward(request, response);
	}

	@SuppressWarnings("unchecked")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=UTF-8");
		request.setCharacterEncoding("UTF-8");

		HttpSession session = request.getSession(false);

		// セッションタイムアウトの場合、ログイン画面に戻る
		if (session == null) {
			request.getRequestDispatcher("JSP/timeout.jsp").forward(request,
					response);
			return;
		}

		// 遷移先パス
		String path = "JSP/topmenu/menu/mastermente/CLS906_TestInsert.jsp";

		// エラー発生時遷移先パス
		String errorPage = "JSP/topmenu/menu/mastermente/CLS905_TestSearch.jsp";

		List<CLS905_SearchResultBean> list = null;
		if (session.getAttribute("905SearchResultList") != null) {
			list = (List<CLS905_SearchResultBean>) session
					.getAttribute("905SearchResultList");
		}

		// ■検索ボタン押下時の処理
		if (request.getParameter("search") != null) {

			CLS908_Servlet.removeSession(session);

			// プルダウンからテスト種別を取得
			String testCategory = request.getParameter("testCategory");

			// 検索期間(開始と終了)を取得
			String start = request.getParameter("start");
			String end = request.getParameter("end");

			// テストIDを取得
			String testID = request.getParameter("testID");

			// 回次を取得
			String time = request.getParameter("time");

			CLS905_SearchBean bean = new CLS905_SearchBean();
			bean.setSearchCategory("test");
			bean.setTestCategory(testCategory);
			bean.setStart(start);
			bean.setEnd(end);
			bean.setTestID(testID);
			bean.setTimes(time);
			bean.setMessage(null);

			// ↓以降は各パラメーターの入力チェックとフォーマットチェック
			// アラート表示用のストリングリスト生成
			List<String> alartList = new ArrayList<>(10);

			// テストの入力チェック
			if ("default".equals(testCategory)) {
				alartList.add(Message.getMessage("test.required"));
				bean.setMessage(alartList);
			}

			// 検索期間の入力チェック
			// 開始日だけ入力がある場合
			if (start.isEmpty() && !end.isEmpty()) {
				alartList.add(Message.getMessage("start_date.required"));
				bean.setMessage(alartList);
			// 終了日だけ入力がある場合
			} else if (!start.isEmpty() && end.isEmpty()) {
				alartList.add(Message.getMessage("end_date.required"));
				bean.setMessage(alartList);
			// 両方入力がある場合
			} else if (!start.isEmpty() && !end.isEmpty()) {

				if (!StringUtil.isValidDateFormat(start)) {
					// 開始日付フォーマットエラー
					bean.setStart("");
					alartList.add(Message.getMessage("start_date_format.error"));
					bean.setMessage(alartList);
				}

				if (!StringUtil.isValidDateFormat(end)) {
					// 終了日付フォーマットエラー
					bean.setEnd("");
					alartList.add(Message.getMessage("end_dateformat.error"));
					bean.setMessage(alartList);
				}

				if (StringUtil.isValidDateFormat(start, end)) {
					// 開始日付と終了日付の大小チェックを行う。
					if (!StringUtil.compareDate(start, end)) {
						bean.setStart("");
						bean.setEnd("");
						alartList.add(Message.getMessage("date_compare.error"));
						bean.setMessage(alartList);
					}
				}
			}
			session.setAttribute("cls905SearchBean", bean);
			// 入力チェックでエラーがあった場合、この時点で再遷移
			if (alartList.size() > 0) {
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

			// 検索ロジックを呼び出し、セッションに格納。
			list = (List<CLS905_SearchResultBean>) DaoFactory.getInstance("Dao.CLS905DAO").getTestResult(bean);

			session.setAttribute("905SearchResultList", list);

			// ページング機能開始(1ページ10件) //////////////////////
			// ここは検索ボタン押下時なので1ページ目の表示処理だけ行う。

			// 表示ページ番号
			int page = 1;
			// 表示先頭ページ
			int head = 0;

			// 総ページ数
			int allPageNum = list.size() / 10;

			// 剰余がある場合は1ページ分追加
			if (allPageNum % 10 != 0 || allPageNum == 0) {
				allPageNum++;
			}

			// 総検索から表示用の10件分を格納するリストを生成
			List<CLS905_SearchResultBean> paginglist = new ArrayList<>(10);

			if (list.size() > 10) {
				// 1ページ目のデータを格納
				for (int i = head; i < 10; i++) {
					paginglist.add(list.get(i));
				}
			} else {
				paginglist = new ArrayList<>(list);
			}
			// セッションに総ページ数を格納
			session.setAttribute("905allPageNum", allPageNum);
			// セッションに表示先頭ページを格納
			session.setAttribute("905head", head);
			// セッションにページ番号を格納
			session.setAttribute("905page",page);

			// ページング機能 終了//////////////////////

			// 検索項目をセッションに格納
			session.setAttribute("cls905SearchBean", bean);
			// 初回ページングリストをセッションに格納
			session.setAttribute("905PagingList", paginglist);

			request.getRequestDispatcher(errorPage).forward(request, response);

		// ■新規ボタン押下時の処理
		} else if (request.getParameter("new") != null) {


			session.setAttribute("testID", CLS906DAO.getTestID() + 1);

			// 操作カテゴリをセッションに格納
			session.setAttribute("control", "新規");
			// 登録、編集画面に遷移
			request.getRequestDispatcher(path).forward(request, response);

		// ■削除ボタン押下時の処理
		} else if (request.getParameter("delete") != null) {

			// 操作カテゴリをセッションに格納して登録、編集画面に遷移
			// (対象データ個人成績を遷移先画面で確認後、削除実行する。)
			// ページをまたいで行データが選択された場合の計算処理
			int head = (Integer)session.getAttribute("905head");
			int indexInPage = Integer.parseInt(request.getParameter("index"));

			List<CLS907_SearchResutlBean> selectedlist =
					(List<CLS907_SearchResutlBean>) session.getAttribute("905SearchResultList");

			int index = head + indexInPage;

			// 選択行をセッションに格納
			session.setAttribute("905index", index);
			// サブミットボタンで選択された行データをセッションに格納
			session.setAttribute("testSelectedInfo",
					selectedlist.get(index));

			session.setAttribute("control", "削除");
			request.getRequestDispatcher(path).forward(request, response);

		// ■修正ボタン押下時の処理
		} else if (request.getParameter("repear") != null) {

			// ページをまたいで行データが選択された場合の計算処理
			int head = (Integer)session.getAttribute("905head");
			int indexInPage = Integer.parseInt(request.getParameter("index"));

			List<CLS907_SearchResutlBean> selectedlist =
					(List<CLS907_SearchResutlBean>) session.getAttribute("905SearchResultList");

			int index = head + indexInPage;

			// 選択行をセッションに格納
			session.setAttribute("905index", index);
			// サブミットボタンで選択された行データをセッションに格納
			session.setAttribute("testSelectedInfo",
					selectedlist.get(index));
			// 操作カテゴリをセッションに格納
			session.setAttribute("control", "修正");
			// 登録、編集画面に遷移
			request.getRequestDispatcher(path).forward(request, response);

		// ■閉じるボタン押下時の処理
//		} else if (request.getParameter("close") != null) {
//
//			// セッション情報を全て破棄
//			CLS906_Servlet.removeSession(session);
//			// 登録、編集画面に遷移
//			request.getRequestDispatcher("JSP/topmenu/CLS002_top.jsp").forward(request, response);
//
		// ■ページングボタン押下時の処理
		} else if (request.getParameter("back") != null || request.getParameter("next") != null) {

			// 表示先頭ページをセッションから取得
			int head = (Integer) session.getAttribute("905head");
			// 表示ページ番号をセッションから取得
			int page = (Integer) session.getAttribute("905page");

			// 「back」押下時
			if (request.getParameter("back") != null) {
				head = head - 10;
				// 表示ページ番号をマイナス
				page--;
			// 「next」押下時
			} else {
				head = head + 10;
				// 表示ページ番号をプラス
				page++;
			}

			// 総検索から表示用の10件分を格納するリストを生成
			List<CLS905_SearchResultBean> paginglist = new ArrayList<>();

			// セッションから総リストを取得
			List<CLS905_SearchResultBean> sessionlist
				= (ArrayList<CLS905_SearchResultBean>) session.getAttribute("905SearchResultList");

			if (sessionlist.size() > 10) {
				// 1ページ分のデータを格納
				for (int i = head; i < head + 10; i++) {
					if (sessionlist.size() - i > 0) {
						paginglist.add(sessionlist.get(i));
					}
				}
			} else {
				paginglist = new ArrayList<>(sessionlist);
			}

			// セッションの表示先頭ページを上書き
			session.setAttribute("905head", head);
			// セッションのページ番号を上書き
			session.setAttribute("905page",page);
			// セッションの作成リストを上書き
			session.setAttribute("905PagingList", paginglist);

			request.getRequestDispatcher(errorPage).forward(request,
					response);
		}
	}
}

