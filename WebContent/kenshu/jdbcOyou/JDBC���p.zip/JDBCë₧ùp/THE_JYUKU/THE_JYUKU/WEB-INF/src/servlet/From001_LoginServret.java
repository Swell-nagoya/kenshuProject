package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.Mst001_UserMstDAO;

/**
 * ログイン画面からTOP画面へのサーブレットクラス
 * <pre>
 * 	ログイン成功⇒TOP画面
 * 失敗⇒ログイン画面
 * </pre>
 */

public class From001_LoginServret extends HttpServlet {


	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		//セッションの取得
		HttpSession session = request.getSession();

		//以前に取得したログイン情報の削除
		session.removeAttribute("loginSession");

		//以前に取得したアラート文の削除
		session.removeAttribute("alertmessage");

		//DAOの取得
		Mst001_UserMstDAO dao = new Mst001_UserMstDAO();


		//ID,Passの取得
		String IDParam = request.getParameter("roginID");
		String PassParam = request.getParameter("pass");

		//ログイン用sessionの取得
		session = dao.getLogin(session, IDParam, PassParam);

		//ログイン用sessionがnullでなければTOP画面に遷移
		if (session.getAttribute("loginSession") != null) {
			request.getRequestDispatcher("/CLS002_TOPServret").forward(request, response);

		//nullであればアラートを表示したログイン画面に遷移
		} else {
			//エラー画面に遷移
			request.getRequestDispatcher("JSP/login.jsp").forward(request, response);
		}
	}
}
