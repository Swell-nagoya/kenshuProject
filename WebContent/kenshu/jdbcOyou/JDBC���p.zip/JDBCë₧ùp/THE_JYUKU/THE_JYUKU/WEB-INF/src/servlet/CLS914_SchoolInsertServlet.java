package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.ConnectionManager;
import Dao.Mst014_SchoolMstDAO;
import bean.CLS913Bean;
import bean.Mst001_UserMstBean;
import bean.Mst014_SchoolMstBean;

import common.ServretCommon;

/**
 * （登録、削除、更新画面に遷移） 検索はこのサーブレットで行う
 *
 * @author d-tanaka
 *
 */
public class CLS914_SchoolInsertServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Sessionの取得
        HttpSession session = request.getSession();

        // loginSessionのチェック
        ServretCommon.checkLoginSession(request, response, session);

        if (session.getAttribute("loginSession") == null) {
            request.getRequestDispatcher("/JSP/redirectToError.jsp").forward(request,
                    response);
            return;
        }
        Mst001_UserMstBean mst001_UserMstBean = (Mst001_UserMstBean) session
                .getAttribute("loginSession");

        // 過去に取得したパラメータを削除
        request.removeAttribute("cls913");
        request.removeAttribute("cls913list");
        request.removeAttribute("alart");
        session.removeAttribute("insert");

        // beanの取得
        Mst014_SchoolMstBean mst014_SchoolMst = new Mst014_SchoolMstBean();
        // BeanのBeanの取得
        CLS913Bean cls913 = new CLS913Bean();
        // Mst014Daoの取得
        Mst014_SchoolMstDAO schoolMstdao = new Mst014_SchoolMstDAO();
        // アラート表示用のストリング
        String alart;

        // 新規登録
        if (request.getParameter("insert") != null) {
            // BeanのBeanに格納
            cls913.setMst014_SchoolMstBean(CLS913_SchoolSearchServlet
                    .setInput_Mst014SchoolMstBean(request, mst014_SchoolMst,
                            mst001_UserMstBean.getId_user()));
            mst014_SchoolMst = cls913.getMst014_SchoolMstBean();

            // 入力チェック
            ValidateServlet Validate = new ValidateServlet();
            alart = Validate.SchoolCheck(request);
            if (alart != null) {
                session.setAttribute("insert", cls913);
                request.setAttribute("alart", alart);
                request.getRequestDispatcher(
                        "JSP/topmenu/menu/mastermente/CLS914_SchoolInsert.jsp")
                        .forward(request, response);
                return;
            }

            // DB登録処理
            ConnectionManager.beginTransaction();
            try {
                schoolMstdao.create(mst014_SchoolMst);
                ConnectionManager.commit();
            } catch (RuntimeException e) {
                e.printStackTrace();
                ConnectionManager.rollback();
                request.getRequestDispatcher("/JSP/redirectToError.jsp").forward(request,
                        response);
            } finally {
                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    request.getRequestDispatcher("/JSP/redirectToError.jsp").forward(
                            request, response);
                } finally {
                    session.removeAttribute("cls913");
                }
            }
            alart = "登録が完了しました。";
            request.setAttribute("alart", alart);
            request.getRequestDispatcher(
                    "JSP/topmenu/menu/mastermente/CLS913_SchoolSearch.jsp")
                    .forward(request, response);
            // 修正
        } else if (request.getParameter("update") != null) {
            // BeanのBeanに格納
            cls913.setMst014_SchoolMstBean(CLS913_SchoolSearchServlet
                    .setInput_Mst014SchoolMstBean(request, mst014_SchoolMst,
                            mst001_UserMstBean.getId_user()));
            mst014_SchoolMst = cls913.getMst014_SchoolMstBean();

            // 入力チェック
            ValidateServlet Validate = new ValidateServlet();
            alart = Validate.SchoolCheck(request);
            if (alart != null) {
                session.setAttribute("update", cls913);
                request.setAttribute("alart", alart);
                request.getRequestDispatcher(
                        "JSP/topmenu/menu/mastermente/CLS914_SchoolInsert.jsp")
                        .forward(request, response);
                return;
            }

            // 更新処理
            ConnectionManager.beginTransaction();
            try {
                schoolMstdao.update(mst014_SchoolMst);
                ConnectionManager.commit();
            } catch (RuntimeException e) {
                e.printStackTrace();
                ConnectionManager.rollback();
                request.getRequestDispatcher("/JSP/redirectToError.jsp").forward(request,
                        response);
            } finally {
                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    request.getRequestDispatcher("/JSP/redirectToError.jsp").forward(
                            request, response);
                } finally {
                    session.removeAttribute("cls913");
                }
            }
            cls913.setMst014_SchoolMstBean(mst014_SchoolMst);
            session.removeAttribute("delete");
            session.removeAttribute("update");
            session.removeAttribute("cls913");
            session.removeAttribute("cls913list");
            request.getRequestDispatcher(
                    "JSP/topmenu/menu/mastermente/CLS913_SchoolSearch.jsp")
                    .forward(request, response);
            return;

            // 削除
        } else if (request.getParameter("delete") != null) {
            ConnectionManager.beginTransaction();
            try {
                // スクールIDから検索
                cls913.setMst014_SchoolMstBean(CLS913_SchoolSearchServlet
                        .setInput_Mst014SchoolMstBean(request, schoolMstdao
                                .findById(request
                                        .getParameter("delete_id_school")),
                                mst001_UserMstBean.getId_user()));
                mst014_SchoolMst = cls913.getMst014_SchoolMstBean();
                // 削除フラグをたてる
                schoolMstdao.update(mst014_SchoolMst);
                ConnectionManager.commit();
            } catch (RuntimeException e) {
                e.printStackTrace();
                ConnectionManager.rollback();
                request.getRequestDispatcher("JSP/ERROR.jsp").forward(request,
                        response);
            } finally {
                try {
                    ConnectionManager.close();
                    request.getRequestDispatcher(
                            "JSP/topmenu/menu/mastermente/CLS913_SchoolSearch.jsp")
                            .forward(request, response);
                } catch (SQLException e) {
                    e.printStackTrace();
                    request.getRequestDispatcher("JSP/ERROR.jsp").forward(
                            request, response);
                } finally {
                    session.removeAttribute("delete");
                    session.removeAttribute("update");
                    session.removeAttribute("cls913");
                    session.removeAttribute("cls913list");
                }
            }

        }
    }
}