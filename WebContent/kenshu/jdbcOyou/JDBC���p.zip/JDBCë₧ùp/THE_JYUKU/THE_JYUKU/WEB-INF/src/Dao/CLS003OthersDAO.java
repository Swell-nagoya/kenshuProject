package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS003Bean;
import bean.Mst001_UserMstBean;
import bean.Trn012_OtherstestTrnBean;
import bean.Trn015_TestTrnBean;


public class CLS003OthersDAO extends ConnectionManager {




	/**
	 * 選択したテストの成績を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchCrammerStudent() {
		String string = "select " +
				"MST001.NICKNAME, " +
				"Trn012.MARKS_JAP, " +
				"Trn012.DEVIATION_JAP, " +
				"Trn012.MARKS_MATH, " +
				"Trn012.DEVIATION_MATH, " +
				"Trn012.MARKS_SIEC, " +
				"Trn012.DEVIATION_SIEC, " +
				"Trn012.MARKS_SCTY, " +
				"Trn012.DEVIATION_SCTY, " +
				"Trn012.MARKS_ENG, " +
				"Trn012.DEVIATION_ENG, " +
				"Trn012.DEVIATION_FIVE, " +
				"TRN015.AVERAGE_JAP, " +
				"TRN015.AVERAGE_MATH, " +
				"TRN015.AVERAGE_SIEC, " +
				"TRN015.AVERAGE_SCTY, " +
				"TRN015.AVERAGE_ENG " +
			"from " +
				"MST001_USERMST MST001, " +
				"TRN012_OTHERSTESTTRN Trn012, " +
				"TRN015_TESTTRN TRN015 " +
			"where " +
				"MST001.ID_USER = ? " +
				"and MST001.ID_USER = Trn012.ID_USER " +
				"and Trn012.ID_TEST = TRN015.ID_TEST " +
				"and TRN015.FISCAL_YEAR = ? " +
				"and TRN015.TIMES = ? ";

		return string;
	}



	/**
	 * 選択したテストの成績を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchGuardian() {
		String string = "select " +
				"MST001.NICKNAME, " +
				"Trn012.MARKS_JAP, " +
				"Trn012.DEVIATION_JAP, " +
				"Trn012.MARKS_MATH, " +
				"Trn012.DEVIATION_MATH, " +
				"Trn012.MARKS_SIEC, " +
				"Trn012.DEVIATION_SIEC, " +
				"Trn012.MARKS_SCTY, " +
				"Trn012.DEVIATION_SCTY, " +
				"Trn012.MARKS_ENG, " +
				"Trn012.DEVIATION_ENG, " +
				"Trn012.DEVIATION_FIVE, " +
				"TRN015.AVERAGE_JAP, " +
				"TRN015.AVERAGE_MATH, " +
				"TRN015.AVERAGE_SIEC, " +
				"TRN015.AVERAGE_SCTY, " +
				"TRN015.AVERAGE_ENG " +
			"from " +
				"MST001_USERMST MST001, " +
				"MST002_STUDENTMST MST002, " +
				"MST003_GUARDIANMST MST003, " +
				"TRN012_OTHERSTESTTRN Trn012, " +
				"TRN015_TESTTRN TRN015 " +
			"where " +
				"MST003.ID_USER = ? " +
				"and MST001.ID_USER = Trn012.ID_USER " +
				"and MST002.ID_FAMILY = MST003.ID_FAMILY " +
				"and MST001.ID_USER = MST002.ID_USER " +
				"and Trn012.ID_TEST = TRN015.ID_TEST " +
				"and TRN015.FISCAL_YEAR = ? " +
				"and TRN015.TIMES = ? ";

		return string;
	}


	/**
	 * 選択したテストの開催年度を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */

	public String createSQLForGetFiscalYear() {
		String string = "select " +
				"TRN015.FISCAL_YEAR " +
			"from " +
				"TRN015_TESTTRN TRN015 " +
				",TRN012_OTHERSTESTTRN Trn012 " +
			"where " +
				"Trn012.ID_TEST = TRN015.ID_TEST " +
			"group by " +
				"TRN015.FISCAL_YEAR";
		return string;
	}


	/**
	 * 選択したテストの開催回次を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */
	public String createSQLForGetTimes() {
		String string = "select " +
				"TRN015.TIMES " +
			"from " +
				"TRN015_TESTTRN TRN015 " +
				",TRN012_OTHERSTESTTRN Trn012 " +
			"where " +
				"Trn012.ID_TEST = TRN015.ID_TEST ";
		return string;
	}

	/**
	 * 選択したテストの開催年度を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */

	public String createSQLForGetMaxFiscalYear() {
		String string = "select " +
				"MAX(TRN015.FISCAL_YEAR) " +
			"from " +
				"TRN015_TESTTRN TRN015 " +
				",TRN012_OTHERSTESTTRN Trn012 " +
			"where " +
				"Trn012.ID_TEST = TRN015.ID_TEST " +
			"group by " +
				"TRN015.FISCAL_YEAR";
		return string;
	}

	/**
	 * 選択したテストの開催回次を取得するSQL文を作成します。
	 * @return 作成するSQL文
	 */
	public String createSQLForGetMaxTimes() {
		String string = "select " +
				"MAX(TRN015.TIMES) " +
			"from " +
				"TRN015_TESTTRN TRN015 " +
				",TRN012_OTHERSTESTTRN Trn012 " +
			"where " +
				"Trn012.ID_TEST = TRN015.ID_TEST ";
		return string;
	}

	/**
	 * 生徒データ、保護者データ、管理者データのいずれかを含むユーザデータを取得します。
	 * @param
	 * @return List<CLS003Bean>
	 */

	public List<CLS003Bean>  Search(String LoginID,String FiscalYear,String Times,int permission) {

		PreparedStatement stmt = null;
		ResultSet rs = null;

		//取得するパラメータ
		List<CLS003Bean> list = new ArrayList<CLS003Bean>();


		try{
			String sql = null;
			int student = 1;
			int guardian = 2;
			//年度のMAX取得
			sql = createSQLForGetMaxFiscalYear();
			System.out.println(sql);
			stmt = getConnection().prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				CLS003Bean cls003d2 = new CLS003Bean();
				Trn015_TestTrnBean trn015_TestTrnBean = new Trn015_TestTrnBean();
				trn015_TestTrnBean.setYearCount(rs.getInt("MAX(TRN015.FISCAL_YEAR)"));
				cls003d2.setTrn015_TestTrnBean(trn015_TestTrnBean);
				list.add(cls003d2);
			}
			//回次のMAX取得
			sql = createSQLForGetMaxTimes();
			System.out.println(sql);
			stmt = getConnection().prepareStatement(sql);

			rs = stmt.executeQuery();
			while (rs.next()) {
				CLS003Bean cls003d2 = new CLS003Bean();
				Trn015_TestTrnBean trn015_TestTrnBean = new Trn015_TestTrnBean();
				trn015_TestTrnBean.setTimesCount(rs.getInt("MAX(TRN015.TIMES)"));
				cls003d2.setTrn015_TestTrnBean(trn015_TestTrnBean);
				list.add(cls003d2);
			}
			//権限によって流すSQLを分ける
			if(permission == student){
				sql = createSQLForSearchCrammerStudent();
			}else if(permission == guardian){
				sql = createSQLForSearchGuardian();
			}else {
				return list;
			}
			System.out.println(sql);
			//テスト結果を取得
			stmt = getConnection().prepareStatement(sql);
			int intFiscalYear = Integer.parseInt(FiscalYear);
			int intTimes = Integer.parseInt(Times);
			stmt.setString(1, LoginID);
			stmt.setInt(2, intFiscalYear);
			stmt.setInt(3, intTimes);

			rs = stmt.executeQuery();
			int count = util.CommonUtil.getCountResult(rs);

			while (rs.next()) {
				CLS003Bean cls003d2 = new CLS003Bean();
				Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();
				Trn012_OtherstestTrnBean Trn012_OthersTestTrnBean = new Trn012_OtherstestTrnBean();
				Trn015_TestTrnBean trn015_TestTrnBean = new Trn015_TestTrnBean();
				mst001_UserMstBean.setNickname(rs.getString("NICKNAME"));
				Trn012_OthersTestTrnBean.setmarks_jap(rs.getInt("MARKS_JAP"));
				Trn012_OthersTestTrnBean.setdeviation_jap(rs.getInt("DEVIATION_JAP"));
				Trn012_OthersTestTrnBean.setmarks_math(rs.getInt("MARKS_MATH"));
				Trn012_OthersTestTrnBean.setdeviation_math(rs.getInt("DEVIATION_MATH"));
				Trn012_OthersTestTrnBean.setmarks_siec(rs.getInt("MARKS_SIEC"));
				Trn012_OthersTestTrnBean.setdeviation_siec(rs.getInt("DEVIATION_SIEC"));
				Trn012_OthersTestTrnBean.setmarks_scty(rs.getInt("MARKS_SCTY"));
				Trn012_OthersTestTrnBean.setdeviation_scty(rs.getInt("DEVIATION_SCTY"));
				Trn012_OthersTestTrnBean.setmarks_eng(rs.getInt("MARKS_ENG"));
				Trn012_OthersTestTrnBean.setdeviation_eng(rs.getInt("DEVIATION_ENG"));
				Trn012_OthersTestTrnBean.setdeviation_five(rs.getInt("DEVIATION_FIVE"));
				trn015_TestTrnBean.setaverage_jap(rs.getInt("AVERAGE_JAP"));
				trn015_TestTrnBean.setaverage_math(rs.getInt("AVERAGE_MATH"));
				trn015_TestTrnBean.setaverage_siec(rs.getInt("AVERAGE_SIEC"));
				trn015_TestTrnBean.setaverage_scty(rs.getInt("AVERAGE_SCTY"));
				trn015_TestTrnBean.setaverage_eng(rs.getInt("AVERAGE_ENG"));


				cls003d2.setMst001_UserMstBean(mst001_UserMstBean);
				cls003d2.setTrn012_OtherstestTrnBean(Trn012_OthersTestTrnBean);
				cls003d2.setTrn015_TestTrnBean(trn015_TestTrnBean);
				cls003d2.setCount(count);

				list.add(cls003d2);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
}
