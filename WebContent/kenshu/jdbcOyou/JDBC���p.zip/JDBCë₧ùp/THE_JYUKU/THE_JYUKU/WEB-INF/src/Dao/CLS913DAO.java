package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import bean.CLS913Bean;
import bean.Mst014_SchoolMstBean;

public class CLS913DAO extends DataAccessObject {

	// 学校マスタのカラム
	private String id_school;
	private String name_school;
	private int categorize_school;
	private String address_school;
	private String district_school;
	private int term;
	private int type_evaluation;
	private int flg_delete;
	private String id_lastupdate;
	private Timestamp date_lastupdate;

	/**
	 * 登録処理を行います。
	 *
	 * @param mst014_SchoolMst
	 *            mst014_SchoolMst
	 */
	public void create(Mst014_SchoolMstBean mst014_SchoolMst) {
		update(createSQLForCreate(),
				new Object[] { mst014_SchoolMst.getid_school(),
						mst014_SchoolMst.getname_school(),
						mst014_SchoolMst.getaddress_school(),
						mst014_SchoolMst.getdistrict_school(),
						mst014_SchoolMst.getterm(),
						mst014_SchoolMst.gettype_evaluation(),
						mst014_SchoolMst.getflg_delete(),
						mst014_SchoolMst.getid_lastupdate(),
						mst014_SchoolMst.getdate_lastupdate() });
	}

	/**
	 * 学校IDに基づき、学校検索を行うSQL文を作成します。
	 *
	 * @param id_school
	 *            　 　学校ID
	 *
	 * @return 作成するSQL文
	 */
	public String createSQLForSearchSchool() {
		String SQLforFindbyID = "SELECT NAME_SCHOOL WHERE ID_SCHOOL =? ";
		return SQLforFindbyID;
	}

	/**
	 * 学校IDに基づき、学校検索を行います。
	 *
	 * @param id_school
	 *            　 　学校ID
	 *
	 * @return 検索結果
	 */
	public Mst014_SchoolMstBean SearchSchool(String id_school) {
		ResultSet rs = null;
		String SQL = null;
		PreparedStatement stmt = null;
		Mst014_SchoolMstBean mst014_SchoolMstBean = new Mst014_SchoolMstBean();

		SQL = createSQLForSearchSchool();
		System.out.println(SQL);
		try {
			stmt = getConnection().prepareStatement(SQL);
			rs = stmt.executeQuery();
			while (rs.next()) {
				mst014_SchoolMstBean.getname_school();
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return mst014_SchoolMstBean;
	}

	/**
	 * 生徒のユーザ情報と生徒情報を取得するSQL文を作成します。 palam長が0の際は全検索を行います。
	 *
	 * @param palam
	 *            条件にするカラム名
	 * @return 作成するSQL文
	 */
	private String createSQLSearchMST014_SCHOOLMST(List<String> palam) {
		String sql = "select"
				+ " ID_SCHOOL"
				+ ", NAME_SCHOOL"
				+ ", CATEGORIZE_SCHOOL"
				+ ", ADDRESS_SCHOOL"
				+ ", DISTRICT_SCHOOL"
				+ ", TERM"
				+ ", TYPE_EVALUATION"
				+ ", FLG_DELETE"
				+ ", ID_LASTUPDATE"
				+ ", DATE_LASTUPDATE"
				+ " from "
				+ " MST014_SCHOOLMST ";
		if (palam.size() > 0) {
			sql += "where ";
			for (int n = 0; n < palam.size(); n++) {
				sql += palam.get(n) + " = ?";
				if (n != palam.size() - 1) {
					sql += " and ";
				}
			}
		}
		return sql;
	}

	/**
	 * 学校データを取得します。
	 *
	 * @param cls913d
	 * @return List<CLS913Bean>
	 */

	public List<CLS913Bean> Search(CLS913Bean cls913d) {

		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = null;
		Mst014_SchoolMstBean mst014_SchoolMst = null;

		// 取得するパラメータ
		List<CLS913Bean> list = new ArrayList<CLS913Bean>();

		// 検索対象のカラム
		List<String> palam = new ArrayList<String>();

		// 検索対象のパラメータ⇒Object?
		List<Object> value = new ArrayList<Object>();

		// 取得する学校テーブルのBean
		mst014_SchoolMst = cls913d.getMst014_SchoolMstBean();

		// パラメーターの設定（ユーザーマスタ）
		if (!StringUtils.isEmpty(mst014_SchoolMst.getid_school())) {
			id_school = mst014_SchoolMst.getid_school();
			palam.add("id_school");
			value.add(id_school);
		}

		if (!StringUtils.isEmpty(mst014_SchoolMst.getname_school())) {
			name_school = mst014_SchoolMst.getname_school();
			palam.add("name_school");
			value.add(name_school);
		}

		if (!String.valueOf(mst014_SchoolMst.getCategorize_school()).equals("null")){
			categorize_school = mst014_SchoolMst.getCategorize_school();
			palam.add("categorize_school");
			value.add(categorize_school);
		}

		if (!StringUtils.isEmpty(mst014_SchoolMst.getaddress_school())) {
			address_school = mst014_SchoolMst.getaddress_school();
			palam.add("address_school");
			value.add(address_school);
		}

		if (!StringUtils.isEmpty(mst014_SchoolMst.getdistrict_school())) {
			district_school = mst014_SchoolMst.getdistrict_school();
			palam.add("district_school");
			value.add(district_school);
		}

		mst014_SchoolMst = cls913d.getMst014_SchoolMstBean();
		if (!String.valueOf(mst014_SchoolMst.getterm()).equals("null") && mst014_SchoolMst.getterm() != 0) {
			// 1の位が0の場合、学校全体の検索になるので、valueに渡さない、
			if (mst014_SchoolMst.getterm() % 10 != 0
					&& mst014_SchoolMst.getterm() != 0) {
				term = mst014_SchoolMst.getterm();
				palam.add("term");
				value.add(term);
			}
		}

		if (!String.valueOf(mst014_SchoolMst.gettype_evaluation()).equals("null") && mst014_SchoolMst.gettype_evaluation() != 0) {
			type_evaluation = mst014_SchoolMst.gettype_evaluation();
			palam.add("type_evaluation");
			value.add(type_evaluation);
		}

		flg_delete = 0;
		palam.add("flg_delete");
		value.add(flg_delete);

		if (!String.valueOf(mst014_SchoolMst.getid_lastupdate()).equals("null") && mst014_SchoolMst.getid_lastupdate() != null) {
			id_lastupdate = mst014_SchoolMst.getid_lastupdate();
			palam.add("id_lastupdate");
			value.add(id_lastupdate);
		}

		if (mst014_SchoolMst.getdate_lastupdate() != null) {
			date_lastupdate = mst014_SchoolMst.getdate_lastupdate();
			palam.add("date_lastupdate");
			value.add(date_lastupdate);
		}

		sql = createSQLSearchMST014_SCHOOLMST(palam);
		System.out.println(sql);

		try {
			stmt = getConnection().prepareStatement(sql);

			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}
			rs = stmt.executeQuery();

			while (rs.next()) {
				CLS913Bean cls913d2 = new CLS913Bean();
				Mst014_SchoolMstBean mst014_SchoolMst2 = new Mst014_SchoolMstBean();

				mst014_SchoolMst2.setid_school(rs.getString("id_school"));
				mst014_SchoolMst2.setname_school(rs.getString("name_school"));
				mst014_SchoolMst2.setaddress_school(rs.getString("address_school"));
				mst014_SchoolMst2.setcategorize_school(rs.getInt("CATEGORIZE_SCHOOL"));
				mst014_SchoolMst2.setdistrict_school(rs.getString("district_school"));
				mst014_SchoolMst2.setterm(rs.getInt("term"));
				mst014_SchoolMst2.settype_evaluation(rs.getInt("type_evaluation"));
				mst014_SchoolMst2.setflg_delete(rs.getInt("flg_delete"));
				mst014_SchoolMst2.setid_lastupdate(rs.getString("id_lastupdate"));
				mst014_SchoolMst2.setdate_lastupdate(rs.getTimestamp("date_lastupdate"));
				cls913d2.setMst014_SchoolMstBean(mst014_SchoolMst2);
				list.add(cls913d2);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	@Override
	public String[] getPKColumns() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public String[] getColumns() {
		return new String[] { "ID_SCHOOL", "NAME_SCHOOL", "ADDRESS_SCHOOL",
				"DISTRICT_SCHOOL", "TERM", "TYPE_EVALUATION", "FLG_DELETE",
				"ID_LASTUPDATE", "DATE_LASTUPDATE" };

	}

	@Override
	public String getTableName() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}
}