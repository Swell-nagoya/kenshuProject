package bean;

public class CLS915Bean {

	Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = null;
	Mst001_UserMstBean mst001_UserMstBean = null;
	Mst010_CourseMstBean mst010_CourseMstBean = null;

	/**
	 * Trn005_SubstituteTrnBeanを設定します。
	 * @param Trn005_SubstituteTrnBean
	 */
	public Trn005_SubstituteTrnBean getTrn005_SubstituteTrnBean() {
		return trn005_SubstituteTrnBean;
	}

	/**
	 * Trn005_SubstituteTrnBeanを取得します。
	 * @return Trn005_SubstituteTrnBean
	 */
	public void setTrn005_SubstituteTrnBean(Trn005_SubstituteTrnBean trn005_SubstituteTrnBean) {
		this.trn005_SubstituteTrnBean = trn005_SubstituteTrnBean;
	}

	/**
	 * Mst001_UserMstBeanを設定します。
	 * @param Mst001_UserMstBean
	 */
	public Mst001_UserMstBean getMst001_UserMstBean() {
		return mst001_UserMstBean;
	}

	/**
	 * Mst001_UserMstBeanを取得します。
	 * @return Mst001_UserMstBean
	 */
	public void setMst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
		this.mst001_UserMstBean = mst001_UserMstBean;
	}

	/**
	 * Mst010_CourseMstBeanを設定します。
	 * @param Mst001_UserMstBean
	 */
	public Mst010_CourseMstBean getMst010_CourseMstBean() {
		return mst010_CourseMstBean;
	}

	/**
	 * Mst010_CourseMstBeanを取得します。
	 * @return Mst001_UserMstBean
	 */
	public void setMst010_CourseMstBean(Mst010_CourseMstBean mst010_CourseMstBean) {
		this.mst010_CourseMstBean = mst010_CourseMstBean;
	}


}
