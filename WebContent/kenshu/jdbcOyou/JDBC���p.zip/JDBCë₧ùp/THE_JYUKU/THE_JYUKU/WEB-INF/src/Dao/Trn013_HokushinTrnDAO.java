				
package Dao;				
				
import bean.Trn013_HokushinTrnBean;				
				
public class Trn013_HokushinTrnDAO extends DataAccessObject {				
				
		/**		
		 * �o�^�������s���܂��B		
		 * @param Trn013_HokushinTrn trn013_hokushintrn		
		 */		
		public void create(Trn013_HokushinTrnBean trn013_hokushintrn) {		
			update(createSQLForCreate(),	
				new Object[] {
				trn013_hokushintrn.getid_user()
				,trn013_hokushintrn.getid_test()
				,trn013_hokushintrn.getmarks_jap()
				,trn013_hokushintrn.getdeviation_jap()
				,trn013_hokushintrn.getmarks_math()
				,trn013_hokushintrn.getdeviation_math()
				,trn013_hokushintrn.getmarks_siec()
				,trn013_hokushintrn.getdeviation_siec()
				,trn013_hokushintrn.getmarks_scty()
				,trn013_hokushintrn.getdeviation_scty()
				,trn013_hokushintrn.getmarks_eng()
				,trn013_hokushintrn.getdeviation_eng()
				,trn013_hokushintrn.getdeviation_five()
				,trn013_hokushintrn.getflg_delete()
				,trn013_hokushintrn.getid_lastupdate()
				,trn013_hokushintrn.getdate_lastupdate()
				});
		}		

		/**		
		 * �X�V�������s���܂��B		
		 * @param Trn013_HokushinTrn trn013_hokushintrn		
		 */		
		public void update(Trn013_HokushinTrnBean trn013_hokushintrn) {		
			update(createSQLForUpdate(),	
				new Object[] {
				trn013_hokushintrn.getid_user()
				,trn013_hokushintrn.getid_test()
				,trn013_hokushintrn.getmarks_jap()
				,trn013_hokushintrn.getdeviation_jap()
				,trn013_hokushintrn.getmarks_math()
				,trn013_hokushintrn.getdeviation_math()
				,trn013_hokushintrn.getmarks_siec()
				,trn013_hokushintrn.getdeviation_siec()
				,trn013_hokushintrn.getmarks_scty()
				,trn013_hokushintrn.getdeviation_scty()
				,trn013_hokushintrn.getmarks_eng()
				,trn013_hokushintrn.getdeviation_eng()
				,trn013_hokushintrn.getdeviation_five()
				,trn013_hokushintrn.getflg_delete()
				,trn013_hokushintrn.getid_lastupdate()
				,trn013_hokushintrn.getdate_lastupdate()
				});
		}		

		/**		
		 * ��L�[�������s���܂��B		
		 * @param id_user ���[�U�[ID		
		 * @return id_user		
		 * @param id_test �e�X�gID		
		 * @return id_test		
		 */		
		public Trn013_HokushinTrnBean findByPrimaryKey(java.lang.Integer userno) {		
			return (Trn013_HokushinTrnBean) query(createSQLForFindByPK(), new Object[]{userno}, Trn013_HokushinTrnBean.class);	
		}		

		@Override		
		public String[] getPKColumns() {		
			return new String[] {"id_user","id_test"};	
		}		

		@Override		
		public String[] getColumns() {		
			return new String[] {"ID_USER"	
				,"ID_TEST"
				,"MARKS_JAP"
				,"DEVIATION_JAP"
				,"MARKS_MATH"
				,"DEVIATION_MATH"
				,"MARKS_SIEC"
				,"DEVIATION_SIEC"
				,"MARKS_SCTY"
				,"DEVIATION_SCTY"
				,"MARKS_ENG"
				,"DEVIATION_ENG"
				,"DEVIATION_FIVE"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};	
		}		

		@Override		
		public String getTableName() {	
			return "TRN013_HOKUSHINTRN";
		}	

}			
