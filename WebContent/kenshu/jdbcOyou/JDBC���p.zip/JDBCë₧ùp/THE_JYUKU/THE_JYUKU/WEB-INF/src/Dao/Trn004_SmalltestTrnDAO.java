
package Dao;

import java.sql.Timestamp;

import bean.Trn004_SmalltestTrnBean;

public class Trn004_SmalltestTrnDAO extends DataAccessObject {

        /**
         * 登録処理を行います。
         * @param Trn004_SmalltestTrn trn004_smalltesttrn
         */
        public void create(Trn004_SmalltestTrnBean trn004_smalltesttrn) {
            update(createSQLForCreate(),
                new Object[] {
                trn004_smalltesttrn.getid_course()
                ,trn004_smalltesttrn.getdate_lecture()
                ,trn004_smalltesttrn.getid_user()
                ,trn004_smalltesttrn.getflg_passtest()
                ,trn004_smalltesttrn.getcount_chalenge()
                ,trn004_smalltesttrn.getflg_delete()
                ,trn004_smalltesttrn.getid_lastupdate()
                ,trn004_smalltesttrn.getdate_lastupdate()
                });
        }

        /**
         * 更新処理を行います。
         * @param Trn004_SmalltestTrn trn004_smalltesttrn
         */
        public void update(Trn004_SmalltestTrnBean trn004_smalltesttrn) {
            update(createSQLForUpdate(),
                new Object[] {
                trn004_smalltesttrn.getid_course()
                ,trn004_smalltesttrn.getdate_lecture()
                ,trn004_smalltesttrn.getid_user()
                ,trn004_smalltesttrn.getflg_passtest()
                ,trn004_smalltesttrn.getcount_chalenge()
                ,trn004_smalltesttrn.getflg_delete()
                ,trn004_smalltesttrn.getid_lastupdate()
                ,trn004_smalltesttrn.getdate_lastupdate()
                ,trn004_smalltesttrn.getid_course()
                ,trn004_smalltesttrn.getdate_lecture()
                ,trn004_smalltesttrn.getid_user()
                });
        }

        public int update_PK(Trn004_SmalltestTrnBean trn004_smalltesttrn,Timestamp date_lecture) {
            return update(createSQLForUpdate(),
                new Object[] {
                trn004_smalltesttrn.getid_course()
                ,trn004_smalltesttrn.getdate_lecture()
                ,trn004_smalltesttrn.getid_user()
                ,trn004_smalltesttrn.getflg_passtest()
                ,trn004_smalltesttrn.getcount_chalenge()
                ,trn004_smalltesttrn.getflg_delete()
                ,trn004_smalltesttrn.getid_lastupdate()
                ,trn004_smalltesttrn.getdate_lastupdate()
                ,trn004_smalltesttrn.getid_course()
                ,date_lecture
                ,trn004_smalltesttrn.getid_user()
            });
        }
        /**
         * 主キー検索を行います。
         * @param id_course コース
         * @return id_course
         * @param date_lecture 開催日
         * @return date_lecture
         * @param id_user ユーザーID
         * @return id_user
         */
        public Trn004_SmalltestTrnBean findByPrimaryKey(String userno,Timestamp date,String userid) {
            return (Trn004_SmalltestTrnBean) query(createSQLForFindByPK(), new Object[]{userno, date, userid}, Trn004_SmalltestTrnBean.class);
        }

        @Override
        public String[] getPKColumns() {
            return new String[] {"id_course","date_lecture","id_user"};
        }

        @Override
        public String[] getColumns() {
            return new String[] {"ID_COURSE"
                ,"DATE_LECTURE"
                ,"ID_USER"
                ,"FLG_PASSTEST"
                ,"COUNT_CHALENGE"
                ,"FLG_DELETE"
                ,"ID_LASTUPDATE"
                ,"DATE_LASTUPDATE"
            };
        }

        @Override
        public String getTableName() {
            return "TRN004_SMALLTESTTRN";
        }

}
