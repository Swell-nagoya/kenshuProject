function setWait() {
    document.body.style.cursor = 'wait';
}
function setSchooldisabled() {
    fOBJ = document.UISearchform
    var pm = document.UISearchform.permission
    if (pm[2].checked) {
        for (i=1; i<6; i++){
            fOBJ["SCHOOL"+ i].disabled = true;
        }
        alert(pm + fOBJ["SCHOOL"+ i].value  + fOBJ["SCHOOL"+ i].disabled)
    } else {
        for (j=1; j<6; j++){
            fOBJ["SCHOOL"+ j].disabled = false;
        }
    }
}
function mdlgUser() {
    var valueIdUser = "user"
    var valueIdFamily = ""
    if(document.form1.ID_USER.value != null && document.form1.ID_USER.value != "") {
        valueIdUser = document.form1.ID_USER.value
    }
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog.jsp?&id_user=' + valueIdUser + '&id_family=' + valueIdFamily + '&name_user=' + document.form1.NAME_USER.value, window,"resizable: no; center;");
    if(rv[0] == "undefined" || rv[0] == null){
        rv[0] = "";
        return;
    }
    if(rv[1] == "undefined" || rv[1] == null || rv[1] == ""){
        rv[1] = "";
        return;
    }
    document.form1.ID_USER.value = rv[0];
    document.form1.NAME_USER.value = rv[1];
}
function mdlgCourse() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.ID_COURSE.value, window,"resizable: no; center;");
    document.form1.ID_COURSE.value = rv[0];
    document.form1.NAME_COURSE.value = rv[1];
}
function mdlgCourse1() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.ID_COURSE1.value, window,"resizable: no; center;");
    document.form1.ID_COURSE1.value = rv[0];
    document.form1.NAME_COURSE1.value = rv[1];
}
function mdlgCourse2() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.ID_COURSE2.value, window,"resizable: no; center;");
    document.form1.ID_COURSE2.value = rv[0];
    document.form1.NAME_COURSE2.value = rv[1];
}
function mdlgCourse3() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.ID_COURSE3.value, window,"resizable: no; center;");
    document.form1.ID_COURSE3.value = rv[0];
    document.form1.NAME_COURSE3.value = rv[1];
}
function mdlgCourse4() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.ID_COURSE4.value, window,"resizable: no; center;");
    document.form1.ID_COURSE4.value = rv[0];
    document.form1.NAME_COURSE4.value = rv[1];
}
function mdlgCourse5() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.ID_COURSE5.value, window,"resizable: no; center;");
    document.form1.ID_COURSE5.value = rv[0];
    document.form1.NAME_COURSE5.value = rv[1];
}
function mdlgCourse6() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.KOJIN_ID_COURSE1.value, window,"resizable: no; center;");
    document.form1.KOJIN_ID_COURSE1.value = rv[0];
    document.form1.KOJIN_NAME_COURSE1.value = rv[1];
}
function mdlgCourse7() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.KOJIN_ID_COURSE2.value, window,"resizable: no; center;");
    document.form1.KOJIN_ID_COURSE2.value = rv[0];
    document.form1.KOJIN_NAME_COURSE2.value = rv[1];
}
function mdlgCourse8() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.KOJIN_ID_COURSE3.value, window,"resizable: no; center;");
    document.form1.KOJIN_ID_COURSE3.value = rv[0];
    document.form1.KOJIN_NAME_COURSE3.value = rv[1];
}
function mdlgCourse9() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.KOJIN_ID_COURSE4.value, window,"resizable: no; center;");
    document.form1.KOJIN_ID_COURSE4.value = rv[0];
    document.form1.KOJIN_NAME_COURSE4.value = rv[1];
}
function mdlgCourse10() {
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog_Course.jsp?&id_course=' + document.form1.KOJIN_ID_COURSE5.value, window,"resizable: no; center;");
    document.form1.KOJIN_ID_COURSE5.value = rv[0];
    document.form1.KOJIN_NAME_COURSE5.value = rv[1];
}
function mdlgFamily() {
    var valueIdFamily = "family"
    var valueIdUser = ""
    if(document.form1.ID_FAMILY.value != null && document.form1.ID_FAMILY.value != "") {
        valueIdFamily = document.form1.ID_FAMILY.value
    }
    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog.jsp?&id_user=' + valueIdUser  + '&id_family=' + valueIdFamily + '&name_user=' + document.form1.NAME_USER.value, window,"resizable: no; center;");
    if(rv[0] == "undefined" || rv[0] == null){
        rv[0] = "";
        return;
    }
    document.form1.ID_FAMILY.value = rv[0];
}
function mdlgCls7() {
    var valueIdUser = "user"
    var valueIdFamily = ""
    var valueNameUser = ""
    if(document.testResultSearch.userID.value != null && document.testResultSearch.userID.value != "") {
        valueIdUser = document.testResultSearch.userID.value
    }
    if(document.testResultSearch.userName.value != null && document.testResultSearch.userName.value != ""){
        valueNameUser  = document.testResultSearch.userName.value
    }

    rv = window.showModalDialog('/THE_JYUKU/JSP/topmenu/menu/mastermente/Dialog.jsp?&id_user=' + valueIdUser + '&id_family='
            + valueIdFamily + '&name_user='
            + valueNameUser, window,"resizable: no; center;");
    if(rv[0] == "undefined" || rv[0] == null){
        if(valueIdUser = "user"){
            document.testResultSearch.userID.value = "";
        }else {
            document.testResultSearch.userID.value = valueIdUser;
        }
    } else {
        document.testResultSearch.userID.value = rv[0];
    }

    if(rv[1] == "undefined" || rv[1] == null || rv[1] == ""){
        document.testResultSearch.userName.value = valueNameUser;
    } else {
        document.testResultSearch.userName.value = rv[1];
    }
}