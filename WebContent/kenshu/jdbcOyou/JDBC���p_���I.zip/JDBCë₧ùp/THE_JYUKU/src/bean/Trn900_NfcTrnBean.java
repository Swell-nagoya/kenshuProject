package bean;

import java.sql.Timestamp;


public class Trn900_NfcTrnBean {
	String id_user;
	Timestamp date_access;
	int time_incrammer = 0;
	int time_outcrammer = 0;
	int flag_delete = 0;
	/**
	 * @param id_user �Z�b�g���� id_user
	 */
	public void setId_user(String id_user) {
		this.id_user = id_user;
	}
	/**
	 * @param date_access �Z�b�g���� date_access
	 */
	public void setDate_access(Timestamp date_access) {
		this.date_access = date_access;
	}
	/**
	 * @param time_incrammer �Z�b�g���� time_incrammer
	 */
	public void setTime_incrammer(int time_incrammer) {
		this.time_incrammer = time_incrammer;
	}
	/**
	 * @param time_outcrammer �Z�b�g���� time_outcrammer
	 */
	public void setTime_outcrammer(int time_outcrammer) {
		this.time_outcrammer = time_outcrammer;
	}
	/**
	 * @param flag_delete �Z�b�g���� flag_delete
	 */
	public void setFlag_delete(int flag_delete) {
		this.flag_delete = flag_delete;
	}
	/**
	 * @return id_user
	 */
	public String getId_user() {
		return id_user;
	}
	/**
	 * @return date_access
	 */
	public Timestamp getDate_access() {
		return date_access;
	}
	/**
	 * @return time_incrammer
	 */
	public int getTime_incrammer() {
		return time_incrammer;
	}
	/**
	 * @return time_outcrammer
	 */
	public int getTime_outcrammer() {
		return time_outcrammer;
	}
	/**
	 * @return flag_delete
	 */
	public int getFlag_delete() {
		return flag_delete;
	}


}
