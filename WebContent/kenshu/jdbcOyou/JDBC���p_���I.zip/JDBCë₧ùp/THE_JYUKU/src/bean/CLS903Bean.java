package bean;

import java.util.ArrayList;
import java.util.List;

public class CLS903Bean {

		Mst001_UserMstBean mst001_UserMstBean = null;
		Mst002_StudentMstBean mst002_StudentMstBean = null;
		Mst003_GuardianMstBean mst003_GuardianMstBean = null;
		Mst004_AdministratorMstBean mst004_AdministratorMstBean = null;
		CLS903_SearchResultBean cls903_SearchResultBean = new CLS903_SearchResultBean();
		List<Mst016_GetCourseMstBean> beans = new ArrayList<>();
		List<Mst010_CourseMstBean> mst010_CourseMstBeans = new ArrayList<>();
		List<List<Mst014_SchoolMstBean>> mst014_SchoolLists = new ArrayList<>();


		/**
		 * @return mstLists
		 */
		public List<List<Mst014_SchoolMstBean>> getMst014_SchoolLists() {
			return mst014_SchoolLists;
		}

		/**
		 * @param mstLists セットする mstLists
		 */
		public void setMst014_SchoolLists(List<List<Mst014_SchoolMstBean>> mst014_SchoolLists) {
			this.mst014_SchoolLists = mst014_SchoolLists;
		}



		/**
		 * @return mst010_CourseMstBeans
		 */
		public List<Mst010_CourseMstBean> getMst010_CourseMstBeans() {
			return mst010_CourseMstBeans;
		}

		/**
		 * @param mst010_CourseMstBeans セットする mst010_CourseMstBeans
		 */
		public void setMst010_CourseMstBeans(
				List<Mst010_CourseMstBean> mst010_CourseMstBeans) {
			this.mst010_CourseMstBeans = mst010_CourseMstBeans;
		}

		/**
		 * @return beans
		 */
		public List<Mst016_GetCourseMstBean> getBeans() {
			return beans;
		}

		/**
		 * @param beans セットする beans
		 */
		public void setBeans(List<Mst016_GetCourseMstBean> beans) {
			this.beans = beans;
		}
		/**
		 * Mst001_UserMstを設定します。
		 * @param Mst001_userMstBean
		 */
		public void setMst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
			this.mst001_UserMstBean = mst001_UserMstBean;
		}

		/**
		 * Mst001_UserMstを取得します。
		 * @return Mst001_UserMstBean
		 */
		public Mst001_UserMstBean getMst001_UserMstBean() {
			return mst001_UserMstBean;
		}

		/**
		 * Mst002_StudentMstを設定します。
		 * @param Mst002_StudentMst
		 */
		public void setMst002_StudentMstBean(Mst002_StudentMstBean mst002_StudentMstBean) {
			this.mst002_StudentMstBean = mst002_StudentMstBean;
		}

		/**
		 * Mst002_StudentMstを取得します。
		 * @return Mst002_StudentMst
		 */
		public Mst002_StudentMstBean getMst002_StudentMstBean () {
			return mst002_StudentMstBean;
		}

		/**
		 * Mst003_GuardianMstを設定します。
		 * @param Mst003_GuardianMst
		 */
		public void  setMst003_GuardianMstBean(Mst003_GuardianMstBean mst003_GuardianMstBean) {
			this.mst003_GuardianMstBean = mst003_GuardianMstBean;
		}

		/**
		 * Mst003_GuardianMstを取得します。
		 * @return Mst003_GuardianMst
		 */
		public Mst003_GuardianMstBean getMst003_GuardianMstBean () {
			return mst003_GuardianMstBean;
		}

		/**
		 * Mst004_AdministratorMstBeanを設定します。
		 * @param Mst004_AdministratorMstBean
		 */
		public void setMst004_AdministratorMstBean(Mst004_AdministratorMstBean mst004_AdministratorMstBean) {
			this.mst004_AdministratorMstBean = mst004_AdministratorMstBean;

		}
		/**
		 * Mst004_AdministratorMstBeanを取得します。
		 * @return Mst004_AdministratorMstBean
		 */
		public Mst004_AdministratorMstBean getMst004_AdministratorMstBean() {
			return mst004_AdministratorMstBean;
		}

		public CLS903_SearchResultBean getCls903_SearchResultBean() {
			return cls903_SearchResultBean;
		}

		public void setCls903_SearchResultBean(CLS903_SearchResultBean cls903_SearchResultBean) {
			this.cls903_SearchResultBean = cls903_SearchResultBean;
		}



}
