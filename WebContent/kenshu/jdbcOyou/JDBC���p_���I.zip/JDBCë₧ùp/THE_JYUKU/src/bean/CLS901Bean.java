package bean;

import java.util.ArrayList;
import java.util.List;
import bean.Mst011_CourseMeisaiMstBean;
import bean.Mst010_CourseMstBean;
import bean.Mst020_ConstantMstBean;


public class CLS901Bean {
	/*学年*/
	List<Mst020_ConstantMstBean> gakunen = new ArrayList<>();
	/*曜日*/
	List<Mst020_ConstantMstBean> dayofweek = new ArrayList<>();
	/*時間割*/
	List<Integer> gikanwari = new ArrayList<>();
	/*mst010*/
	Mst010_CourseMstBean mst010_coursemst = new Mst010_CourseMstBean();
	/*mst011*/
	Mst011_CourseMeisaiMstBean mst011_coursemeisaimst = new Mst011_CourseMeisaiMstBean();
	/*trn001のbean*/
	Trn001_ReportTrnBean trn001_reporttrn = new Trn001_ReportTrnBean();
	/*trn002のbean*/
	Trn002_HomeworkTrnBean trn002_homeworktrn = new Trn002_HomeworkTrnBean();
	/*trn004のbean*/
	Trn004_SmalltestTrnBean trn004_smalltesttrn = new Trn004_SmalltestTrnBean();
	/*trn010のbean*/
	Trn010_AttendanceTrnBean trn010_Attendancetrn = new Trn010_AttendanceTrnBean();
	 
	/** 
	 * @return gakunen
	 */
	public List<Mst020_ConstantMstBean> getGakunen(){
		return gakunen;
	}
	/**
	 * 
	 * @param gakunen
	 */
	public void setGakunen(List<Mst020_ConstantMstBean> gakunen){
		this.gakunen = gakunen;
	}
	/**
	 * 
	 * @return dayofweek
	 */
	public List<Mst020_ConstantMstBean> getDayOfWeek(){
		return dayofweek;
	}
	/**
	 * 
	 * @param dayofweek
	 */
	public void setDayOfWeek(List<Mst020_ConstantMstBean> dayofweek){
		this.dayofweek = dayofweek;
	}
	/**
	 * 
	 * @return gikanwari
	 */
	public List<Integer> getGikanwari(){
		return gikanwari;
	}
	/**
	 * 
	 * @param gikanwari
	 */
	public void setGikanwari(List<Integer> gikanwari){
		this.gikanwari = gikanwari;
	}
	
	public Mst010_CourseMstBean getMst010_CourseMstBean(){
		return mst010_coursemst;
	}
	
	public void setMst010_CourseMstBean(Mst010_CourseMstBean mst010_coursemst){
		this.mst010_coursemst = mst010_coursemst;
	}
	
	public Mst011_CourseMeisaiMstBean getMst011_CourseMeisaiMstBean(){
		return mst011_coursemeisaimst;
	}
	
	public void setMst011_CourseMeisaiMstBean(Mst011_CourseMeisaiMstBean mst011_coursemeisaimst){
		this.mst011_coursemeisaimst = mst011_coursemeisaimst;
	}
	
	public Trn001_ReportTrnBean getTrn001_ReportTrnBean(){
		return trn001_reporttrn;
	}
	
	public void setTrn001_ReportTrnBean(Trn001_ReportTrnBean trn001_reporttrn){
		this.trn001_reporttrn = trn001_reporttrn;
	}
	
	public Trn002_HomeworkTrnBean getTrn002_HomeworkTrnBean(){
		return trn002_homeworktrn;
	}
	
	public void setTrn002_HomeworkTrnBean(Trn002_HomeworkTrnBean trn002_homeworktrn){
		this.trn002_homeworktrn = trn002_homeworktrn;
	}
	
	public Trn004_SmalltestTrnBean getTrn004_SmalltestTrnBean(){
		return trn004_smalltesttrn;
	}
	
	public void setTrn004_SmalltestTrnBean(Trn004_SmalltestTrnBean trn004_smalltesttrn){
		this.trn004_smalltesttrn = trn004_smalltesttrn;
	}
	
	public Trn010_AttendanceTrnBean getTrn010_AttendanceTrnBean(){
		return trn010_Attendancetrn;
	}
	
	public void setTrn010_AttendanceTrnBean(Trn010_AttendanceTrnBean trn010_Attendancetrn){
		this.trn010_Attendancetrn = trn010_Attendancetrn;
	}
}
