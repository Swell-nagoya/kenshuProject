package bean;

import java.sql.Timestamp;

public class Mst002_StudentMstBean {

	/**
	 * STUDENTMST表のDTOクラス
	 * <pre>
	 * 	生徒のデータを格納します。
	 * </pre>
	 */

	//ユーザーID
	String id_user = null;

	//家族ID
	String id_family = null;

	//学年
	int grade = 0;

	//小学校ID
	String id_elementary = null;

	//中学校ID
	String id_junior_high_school = null;

	//高校ID
	String id_high_school = null;

	//大学ID
	String id_university = null;

	//入塾日
	Timestamp in_crammer = null;

	//退塾日
	Timestamp out_crammer = null;

	//FLG_SENDENTERMAIL
	int flg_sendentermail = -1;
	//FLG_SENDEXITMAIL
	int flg_sendexitmail = -1;
	//最終更新ID
	String id_lastupdate = null;

	//最終更新日
	Timestamp date_lastupdate = null;




	/**
	 * ユーザIDを設定します。
	 * @param id_user ID_USER
	 */
	public void setId_user(String id_user) {
		this.id_user = id_user;
	}

	/**
	 * 家族IDを設定します。
	 * @param id_family ID_FAMILY
	 */
	public void setId_family(String id_family) {
		this.id_family = id_family;
	}

	/**
	 * 学年を設定します。
	 * @param grade
	 */
	public void setGrade(int grade) {
		this.grade= grade;
	}

	/**
	 * 小学生IDを設定します。
	 * ID_ELEMENTARY_SCHOOL
	 * @param id_elementary
	 */
	public void setId_elementary(String id_elementary) {
		this.id_elementary= id_elementary;
	}


	/**
	 * 中学生IDを設定します。
	 * ID_JUNIOR_HIGH_SCHOOL
	 * @param id_junior_high_school
	 */
	public void setId_junior_high_school(String id_junior_high_school) {
		this.id_junior_high_school = id_junior_high_school;
	}

	/**
	 * 高校性IDを設定します。
	 * ID_HIGH_SCHOOL
	 * @param id_high_school
	 */
	public void setId_high_school (String id_high_school) {
		this.id_high_school = id_high_school;
	}

	/**
	 * 大学生IDを設定します。
	 * ID_UNIVERSITY
	 * @palam id_university
	 */
	;
	public void setId_university (String id_university) {
		this.id_university= id_university;
	}

	//IN_CRAMMER
	/**
	 * 入塾日を設定します。
	 * IN_CRAMMER
	 * @param in_crammer
	 */
	public void setIn_crammer(Timestamp in_crammer) {
		this.in_crammer = in_crammer;
	}


	/**
	 * 退塾日を設定します。
	 * OUT_CRAMMER
	 * @param out_crammer
	 */
	public void setOut_crammer(Timestamp out_crammer) {
		this.out_crammer = out_crammer;
	}

	/**
	 * 最終更新IDを設定します。
	 * @param phone 最終更新ID
	 */
	public void setId_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}

	/**
	 * 最終更新日を設定します。
	 * @param date_last 最終更新日
	 */
	public void setDate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}


	/**
	 * ユーザIDを取得します。
	 * @param id_user ID_USER
	 */
	public String getId_user() {
		return id_user;
	}

	/**
	 * 家族IDを取得します。
	 * @param id_family ID_FAMILY
	 */
	public String getId_family() {
		return id_family;
	}

	/**
	 * 権限を取得します。
	 * @param grade
	 */
	public int getGrade() {
		return grade;
	}

	/**
	 * 小学生IDを取得します。
	 * @param id_elementary
	 */
	public String getId_elementary() {
		return id_elementary;
	}


	/**
	 * 中学生IDを取得します。
	 * @param id_junior_high_school
	 */
	public String getId_junior_high_school() {
		return id_junior_high_school;
	}

	/**
	 * 高校性IDを取得します。
	 * ID_HIGH_SCHOOL
	 * @param id_high_school
	 */
	public String getId_high_school () {
		return id_high_school;
	}

	/**
	 * 大学生IDを取得します。
	 * ID_UNIVERSITY
	 * @palam id_university
	 */
	;
	public String getId_university () {
		return id_university;
	}

	//IN_CRAMMER
	/**
	 * 入塾日を取得します。
	 * IN_CRAMMER
	 * @param in_carmmer
	 */
	public Timestamp getIn_crammer() {
		return in_crammer;
	}


	/**
	 * 退塾日を取得します。
	 * OUT_CRAMMER
	 * @param out_crammer
	 */
	public Timestamp getOut_crammer() {
		return out_crammer;
	}

	/**
	 * 最終更新IDを取得します。
	 * @param mail 最終更新ID
	 */
	public String getLastupdate_id() {
		return this.id_lastupdate;
	}
	/**
	 * 最終更新日を取得します。
	 * @param mail 最終更新日
	 */
	public Timestamp getLastupdate_date() {
		return this.date_lastupdate;
	}

	/**
	 * @return flg_sendentermail
	 */
	public int getFlg_sendentermail() {
		return flg_sendentermail;
	}

	/**
	 * @param flg_sendentermail セットする flg_sendentermail
	 */
	public void setFlg_sendentermail(int flg_sendentermail) {
		this.flg_sendentermail = flg_sendentermail;
	}

	/**
	 * @return flg_sendexitmail
	 */
	public int getFlg_sendexitmail() {
		return flg_sendexitmail;
	}

	/**
	 * @param flg_sendexitmail セットする flg_sendexitmail
	 */
	public void setFlg_sendexitmail(int flg_sendexitmail) {
		this.flg_sendexitmail = flg_sendexitmail;
	}

	/**
	 * @return id_lastupdate
	 */
	public String getId_lastupdate() {
		return id_lastupdate;
	}

	/**
	 * @return date_lastupdate
	 */
	public Timestamp getDate_lastupdate() {
		return date_lastupdate;
	}

}
