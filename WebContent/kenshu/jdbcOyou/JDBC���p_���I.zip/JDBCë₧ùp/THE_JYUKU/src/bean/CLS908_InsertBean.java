package bean;

import java.io.Serializable;
import java.util.List;

/**
 * 新規テスト結果登録用Beanクラス
 * @author kume
 *
 */
public class CLS908_InsertBean implements Serializable {

	// テストトラン
	private String testCategory;

	// テストID
	private String testID;

	// ユーザーID
	private String userID;

	// 国語点数
	private String marks_jap;
	// 数学点数
	private String marks_math;
	// 理科点数
	private String marks_siec;
	// 社会点数
	private String marks_scty;
	// 英語点数
	private String marks_eng;

	// 国語偏差値
	private String deviation_jap;
	// 数学偏差値
	private String deviation_math;
	// 理科偏差値
	private String deviation_siec;
	// 社会偏差値
	private String deviation_scty;
	// 英語偏差値
	private String deviation_eng;
	// 5教科偏差値
	private String deviation_five;

	// 最終更新者ID
	private String last_up_user;
	// 最終更新日付
	private String last_update;
	// メッセージ格納用リスト
	private List<String> message;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getMarks_jap() {
		return marks_jap;
	}

	public void setMarks_jap(String marks_jap) {
		this.marks_jap = marks_jap;
	}

	public String getMarks_math() {
		return marks_math;
	}

	public void setMarks_math(String marks_math) {
		this.marks_math = marks_math;
	}

	public String getMarks_siec() {
		return marks_siec;
	}

	public void setMarks_siec(String marks_siec) {
		this.marks_siec = marks_siec;
	}

	public String getMarks_scty() {
		return marks_scty;
	}

	public void setMarks_scty(String marks_scty) {
		this.marks_scty = marks_scty;
	}

	public String getMarks_eng() {
		return marks_eng;
	}

	public void setMarks_eng(String marks_eng) {
		this.marks_eng = marks_eng;
	}

	public String getDeviation_jap() {
		return deviation_jap;
	}

	public void setDeviation_jap(String deviation_jap) {
		this.deviation_jap = deviation_jap;
	}

	public String getDeviation_math() {
		return deviation_math;
	}

	public void setDeviation_math(String deviation_math) {
		this.deviation_math = deviation_math;
	}

	public String getDeviation_siec() {
		return deviation_siec;
	}

	public void setDeviation_siec(String deviation_siec) {
		this.deviation_siec = deviation_siec;
	}

	public String getDeviation_scty() {
		return deviation_scty;
	}

	public void setDeviation_scty(String deviation_scty) {
		this.deviation_scty = deviation_scty;
	}

	public String getDeviation_eng() {
		return deviation_eng;
	}

	public void setDeviation_eng(String deviation_eng) {
		this.deviation_eng = deviation_eng;
	}

	public String getDeviation_five() {
		return deviation_five;
	}

	public void setDeviation_five(String deviation_five) {
		this.deviation_five = deviation_five;
	}

	public List<String> getMessage() {
		return message;
	}

	public void setMessage(List<String> message) {
		this.message = message;
	}

	public String getTestCategory() {
		return testCategory;
	}

	public void setTestCategory(String testCategory) {
		this.testCategory = testCategory;
	}

	public String getTestID() {
		return testID;
	}

	public void setTestID(String testID) {
		this.testID = testID;
	}

	public String getLast_up_user() {
		return last_up_user;
	}

	public void setLast_up_user(String last_up_user) {
		this.last_up_user = last_up_user;
	}

	public String getLast_update() {
		return last_update;
	}

	public void setLast_update(String last_update) {
		this.last_update = last_update;
	}

	@Override
	public String toString() {
		return "CLS908_testResultInsertBean [testCategory=" + testCategory
				+ ", testID=" + testID + ", userID=" + userID + ", marks_jap="
				+ marks_jap + ", marks_math=" + marks_math + ", marks_siec="
				+ marks_siec + ", marks_scty=" + marks_scty + ", marks_eng="
				+ marks_eng + ", deviation_jap=" + deviation_jap
				+ ", deviation_math=" + deviation_math + ", deviation_siec="
				+ deviation_siec + ", deviation_scty=" + deviation_scty
				+ ", deviation_eng=" + deviation_eng + ", deviation_five="
				+ deviation_five + ", last_up_user=" + last_up_user
				+ ", last_update=" + last_update + ", errorMessage="
				+ message + "]";
	}
}
