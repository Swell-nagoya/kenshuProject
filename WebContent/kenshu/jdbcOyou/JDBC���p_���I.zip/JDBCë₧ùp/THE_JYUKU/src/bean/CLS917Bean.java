package bean;

public class CLS917Bean {
	//�\�����ڗp�̃I�u�W�F�N�g���擾���܂��B
	Trn900_NfcTrnBean bean;
	Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();
	/**
	 * @return bean
	 */
	public Trn900_NfcTrnBean getBean() {
		return bean;
	}
	/**
	 * @param bean �Z�b�g���� bean
	 */
	public void setBean(Trn900_NfcTrnBean bean) {
		this.bean = bean;
	}
	/**
	 * @return userMstBean
	 */
	public Mst001_UserMstBean getMst001_UserMstBean() {
		return mst001_UserMstBean;
	}
	/**
	 * @param userMstBean �Z�b�g���� userMstBean
	 */
	public void setmst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
		this.mst001_UserMstBean = mst001_UserMstBean;
	}




}
