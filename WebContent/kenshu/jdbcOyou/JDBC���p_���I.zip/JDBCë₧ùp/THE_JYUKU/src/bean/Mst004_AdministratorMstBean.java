package bean;

import java.sql.Timestamp;

public class Mst004_AdministratorMstBean {

	/**
	 * Administrator表のDTOクラス
	 * <pre>
	 * 	管理者のデータを格納します。
	 * </pre>
	 */

	//ユーザーID
	String id_user;

	//学年
	int grade;

	//住所
	String address;

	//小学校ID
	String id_elementary;

	//中学校ID
	String id_junior_high_school;

	//高校ID
	String id_high_school;

	//大学ID
	String id_university;

	//入塾日
	Timestamp in_crammer;

	//退塾日
	Timestamp out_crammer;

	//最終更新ID
	String id_lastupdate;

	//最終更新日
	Timestamp date_lastupdate;


	/**
	 * ユーザIDを設定します。
	 * @param id_user ID_USER
	 */
	public void setId_user(String id_user) {
		this.id_user = id_user;
	}

	/**
	 * 学年を設定します。
	 * @param grade
	 */
	public void setGrade(int grade) {
		this.grade= grade;
	}

	/**
	 * 住所を設定します。
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * 小学生IDを設定します。
	 * ID_ELEMENTARY_SCHOOL
	 * @param id_elementary
	 */
	public void setId_elementary(String id_elementary) {
		this.id_elementary= id_elementary;
	}


	/**
	 * 中学生IDを設定します。
	 * ID_JUNIOR_HIGH_SCHOOL
	 * @param id_junior_high_school
	 */
	public void setId_junior_high_school(String id_junior_high_school) {
		this.id_junior_high_school = id_junior_high_school;
	}

	/**
	 * 高校性IDを設定します。
	 * ID_HIGH_SCHOOL
	 * @param id_high_school
	 */
	public void setId_high_school (String id_high_school) {
		this.id_high_school = id_high_school;
	}

	/**
	 * 大学生IDを設定します。
	 * ID_UNIVERSITY
	 * @palam id_university
	 */
	;
	public void setId_university (String id_university) {
		this.id_university= id_university;
	}

	//IN_CRAMMER
	/**
	 * 入塾日を設定します。
	 * IN_CRAMMER
	 * @param in_carmmer
	 */
	public void setIn_crammer(Timestamp in_crammer) {
		this.in_crammer = in_crammer;
	}


	/**
	 * 退塾日を設定します。
	 * OUT_CRAMMER
	 * @param out_crammer
	 */
	public void setOut_crammer(Timestamp out_crammer) {
		this.out_crammer = out_crammer;
	}

	/**
	 * 最終更新IDを設定します。
	 * @param phone 最終更新ID
	 */
	public void setId_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}

	/**
	 * 最終更新日を設定します。
	 * @param date_last 最終更新日
	 */
	public void setDate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}


	/**
	 * ユーザIDを取得します。
	 * @param id_user ID_USER
	 */
	public String getId_user() {
		return id_user;
	}


	/**
	 * 学年を取得します。
	 * @param grade
	 */
	public int getGrade() {
		return grade;
	}

	/**
	 * 住所を設定します。
	 * @param address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * 小学生IDを取得します。
	 * @param id_elementary
	 */
	public String getId_elementary() {
		return id_elementary;
	}


	/**
	 * 中学生IDを取得します。
	 * @param id_junior_high_school
	 */
	public String getId_junior_high_school() {
		return id_junior_high_school;
	}

	/**
	 * 高校性IDを取得します。
	 * ID_HIGH_SCHOOL
	 * @param id_high_school
	 */
	public String getId_high_school () {
		return id_high_school;
	}

	/**
	 * 大学生IDを取得します。
	 * ID_UNIVERSITY
	 * @palam id_university
	 */
	;
	public String getId_university () {
		return id_university;
	}

	//IN_CRAMMER
	/**
	 * 入塾日を取得します。
	 * IN_CRAMMER
	 * @param in_carmmer
	 */
	public Timestamp getIn_crammer() {
		return in_crammer;
	}


	/**
	 * 退塾日を取得します。
	 * OUT_CRAMMER
	 * @param out_crammer
	 */
	public Timestamp getOut_crammer() {
		return out_crammer;
	}

	/**
	 * 最終更新IDを取得します。
	 * @param mail 最終更新ID
	 */
	public String getLastupdate_id() {
		return this.id_lastupdate;
	}
	/**
	 * 最終更新日を取得します。
	 * @param mail 最終更新日
	 */
	public Timestamp getLastupdate_date() {
		return this.date_lastupdate;
	}

}
