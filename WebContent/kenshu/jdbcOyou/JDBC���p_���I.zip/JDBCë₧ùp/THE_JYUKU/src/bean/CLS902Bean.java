package bean;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * CLS902TeachResultInsert.jspの初期表示に必要なデータを格納するBean
 */
public class CLS902Bean {

	String sousin = null;
	//コースID
	String id_course = null;
	//コース名
	String name_course = null;
	//開催日
	String date_lecture = null;
	//開催曜日
	String day_lecture = null;
	//開催時間割
	Timestamp start_timetable_lecture = null;
	Timestamp end_timetable_lecture = null;
	//対象学年
	String target =null;
	//ユーザーID,ユーザー名
	List<Mst001_UserMstBean> list = new ArrayList<Mst001_UserMstBean>();

	public String getsousin(){
		return sousin;
	}
	public void setsousin(String sousin){
		this.sousin = sousin;
	}
	public String getid_course(){
		return id_course;
	}
	public void setid_course(String id_course){
		this.id_course = id_course;
	}
	public String getname_course(){
		return name_course;
	}
	public void setname_course(String name_course){
		this.name_course = name_course;
	}
	public String getdate_lecture(){
		return date_lecture;
	}
	public void setdate_lecture(String date_lecture){
		this.date_lecture = date_lecture;
	}
	public String getday_lecture(){
		return day_lecture;
	}
	public void setday_lecture(String day_lecture){
		this.day_lecture = day_lecture;
	}
	public void setStart_timetable_lecture(Timestamp start_timetable_lecture){
		this.start_timetable_lecture = start_timetable_lecture;
	}
	public Timestamp getStart_timetable_lecture(){
		return start_timetable_lecture;
	}

	public void setEnd_timetable_lecture(Timestamp end_timetable_lecture){
		this.end_timetable_lecture = end_timetable_lecture;
	}
	public Timestamp getEnd_timetable_lecture(){
		return end_timetable_lecture;
	}
	public String gettarget(){
		return target;
	}
	public void settarget(String target){
		this.target = target;
	}
	public List<Mst001_UserMstBean> getlist(){
		return list;
	}
	public void setlist(List<Mst001_UserMstBean> list){
		this.list = list;
	}
}
