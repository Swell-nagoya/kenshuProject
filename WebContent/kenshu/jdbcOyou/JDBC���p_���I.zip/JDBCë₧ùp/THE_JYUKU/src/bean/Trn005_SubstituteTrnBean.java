

package bean;

import java.sql.Timestamp;

public class Trn005_SubstituteTrnBean {

	//ユーザID
	String id_user = null;
	//コースID
	String id_course = null;
	//欠席フラグ
	int flg_absence = 0;
	//遅刻フラグ
	int flg_late = 0;
	//早退フラグ
	int flg_early = 0;
	//振替フラグ
	int flg_substitute = 0;
	//開催時間割
	//String timetable_lecture = null;
	Timestamp start_lecture = null;
	Timestamp end_lecture = null;
	//開催日付
//	Timestamp date_lecture = null;
	//振替時間割
	//String timetable_substitute = null;
	Timestamp start_substitute = null;
	Timestamp end_substitute = null;
	//振替日付
//	Timestamp date_substitute = null;
	//削除フラグ
	int flg_delete = 0;
	//最終更新ID
	String id_lastupdate = null;
	//最終更新日
	Timestamp date_lastupdate = null;

	/**
	 * ユーザIDを設定します。
	 * @param id_user
	 */
	public void setid_user(String id_user) {
		this.id_user = id_user;
	}

	/**
	 * コースIDを設定します。
	 * @param id_course
	 */
	public void setid_course(String id_course) {
		this.id_course = id_course;
	}

	/**
	 * 欠席フラグを設定します。
	 * @param flg_absence
	 */
	public void setflg_absence(int flg_absence) {
		this.flg_absence = flg_absence;
	}

	/**
	 * 遅刻フラグを設定します。
	 * @param flg_late
	 */
	public void setflg_late(int flg_late) {
		this.flg_late = flg_late;
	}

	/**
	 * 早退フラグを設定します。
	 * @param flg_early
	 */
	public void setflg_early(int flg_early) {
		this.flg_early = flg_early;
	}

	/**
	 * 振替フラグを設定します。
	 * @param flg_substitute
	 */
	public void setflg_substitute(int flg_substitute) {
		this.flg_substitute = flg_substitute;
	}

	/**
	 * 開催時間割を設定します。timetable_substitute
	 * @param timetable_lecture
	 */
	public void setstart_lecture(Timestamp start_lecture) {
		this.start_lecture = start_lecture;
	}
	public void setend_lecture(Timestamp end_lecture) {
		this.end_lecture = end_lecture;
	}

	/**
	 * 開催日付を設定します。
	 * @param date_lecture
	 */
//	public void setdate_lecture(Timestamp date_lecture) {
//		this.date_lecture = date_lecture;
//	}

	/**
	 * 振替時間割を設定します。
	 * @param timetable_substitute
	 */
//	public void settimetable_substitute(String timetable_substitute) {
//		this.timetable_substitute = timetable_substitute;
//	}
	public void setstart_substitute(Timestamp start_substitute) {
		this.start_substitute = start_substitute;
	}
	public void setend_substitute(Timestamp end_substitute) {
		this.end_substitute = end_substitute;
	}

	/**
	 * 振替日付を設定します。
	 * @param date_substitute
	 */
//	public void setdate_substitute(Timestamp date_substitute) {
//		this.date_substitute = date_substitute;
//	}

	/**
	 * 削除フラグを設定します。
	 * @param flg_delete
	 */
	public void setflg_delete(int flg_delete) {
		this.flg_delete = flg_delete;
	}

	/**
	 * 最終更新IDを設定します。
	 * @param id_lastupdate
	 */
	public void setid_lastupdate(String id_lastupdate) {
		this.id_lastupdate = id_lastupdate;
	}

	/**
	 * 最終更新日を設定します。
	 * @param date_lastupdate
	 */
	public void setdate_lastupdate(Timestamp date_lastupdate) {
		this.date_lastupdate = date_lastupdate;
	}

	/**
	 * ユーザIDを取得します。
	 * @param id_user
	 */
	public String getid_user() {
		return id_user;
	}

	/**
	 * コースIDを取得します。
	 * @param id_course
	 */
	public String getid_course() {
		return id_course;
	}

	/**
	 * 欠席フラグを取得します。
	 * @param flg_absence
	 */
	public int getflg_absence() {
		return flg_absence;
	}

	/**
	 * 遅刻フラグを取得します。
	 * @param flg_late
	 */
	public int getflg_late() {
		return flg_late;
	}

	/**
	 * 早退フラグを取得します。
	 * @param flg_early
	 */
	public int getflg_early() {
		return flg_early;
	}

	/**
	 * 振替フラグを取得します。
	 * @param flg_substitute
	 */
	public int getflg_substitute() {
		return flg_substitute;
	}

	/**
	 * 開催時間割を取得します。
	 * @param timetable_lecture timetable_substitute
	 */
	public Timestamp getstart_lecture() {
		return start_lecture;
	}

	public Timestamp getend_lecture() {
		return end_lecture;
	}

	/**
	 * 開催日付を取得します。
	 * @param date_lecture
	 */
//	public Timestamp getdate_lecture() {
//		return date_lecture;
//	}

	/**
	 * 振替時間割を取得します。
	 * @param timetable_substitute
	 */
//	public String gettimetable_substitute() {
//		return timetable_substitute;
//	}
	
	public Timestamp getstart_substitute() {
		return start_substitute;
	}

	public Timestamp getend_substitute() {
		return end_substitute;
	}

	/**
	 * 振替日付を取得します。
	 * @param date_substitute
	 */
//	public Timestamp getdate_substitute() {
//		return date_substitute;
//	}

	/**
	 * 削除フラグを取得します。
	 * @param flg_delete
	 */
	public int getflg_delete() {
		return flg_delete;
	}

	/**
	 * 最終更新IDを取得します。
	 * @param id_lastupdate
	 */
	public String getid_lastupdate() {
		return id_lastupdate;
	}

	/**
	 * 最終更新日を取得します。
	 * @param date_lastupdate
	 */
	public Timestamp getdate_lastupdate() {
		return date_lastupdate;
	}

}
