

package bean;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Trn010_AttendanceTrnBean {

    //ユーザーＩＤ
    private String id_user = null;
    //授業実施日
    private Timestamp date_lecture = null;
    //授業開始時間
    private Timestamp start_time_lecture = null;
    //コースＩＤ
    private String id_course = null;
    //欠席フラグ
    private int flg_absence = 0;
    //遅刻フラグ
    private int flg_late = 0;
    //早退フラグ
    private int flg_early = 0;
    //振替フラグ
    private int flg_substitute = 0;
    //削除フラグ
    private int flg_delete = 0;
    //最終更新者ＩＤ
    private String id_lastupdate = null;
    //最終更新日
    private Timestamp date_lastupdate = null;

    /**
     * ���[�UID��ݒ肵�܂��B
     * @param id_user
     */
    public void setid_user(String id_user) {
        this.id_user = id_user;
    }

    /**
     * �J�Ó�t��ݒ肵�܂��B
     * @param date_lecture
     */
    public void setdate_lecture(Timestamp date_lecture) {
        this.date_lecture = date_lecture;
    }

    /**
     * �J�Î��Ԋ���ݒ肵�܂��B
     * @param timetable_lecture
     */
    public void setstart_time_lecture(Timestamp start_time_lecture) {
        this.start_time_lecture = start_time_lecture;
    }

    /**
     * ���ȃt���O��ݒ肵�܂��B
     * @param flg_absence
     */
    public void setflg_absence(int flg_absence) {
        this.flg_absence = flg_absence;
    }

    /**
     * �x���t���O��ݒ肵�܂��B
     * @param flg_late
     */
    public void setflg_late(int flg_late) {
        this.flg_late = flg_late;
    }

    /**
     * ���ރt���O��ݒ肵�܂��B
     * @param flg_early
     */
    public void setflg_early(int flg_early) {
        this.flg_early = flg_early;
    }

    /**
     * �U�փt���O��ݒ肵�܂��B
     * @param flg_substitute
     */
    public void setflg_substitute(int flg_substitute) {
        this.flg_substitute = flg_substitute;
    }

    /**
     * �폜�t���O��ݒ肵�܂��B
     * @param flg_delete
     */
    public void setflg_delete(int flg_delete) {
        this.flg_delete = flg_delete;
    }

    /**
     * �ŏI�X�VID��ݒ肵�܂��B
     * @param id_lastupdate
     */
    public void setid_lastupdate(String id_lastupdate) {
        this.id_lastupdate = id_lastupdate;
    }

    /**
     * �ŏI�X�V���ݒ肵�܂��B
     * @param date_lastupdate
     */
    public void setdate_lastupdate(Timestamp date_lastupdate) {
        this.date_lastupdate = date_lastupdate;
    }

    /**
     * ���[�UID���擾���܂��B
     * @param id_user
     */
    public String getid_user() {
        return id_user;
    }

    /**
     * �J�Ó�t���擾���܂��B
     * @param date_lecture
     */
    public Timestamp getdate_lecture() {
        return date_lecture;
    }

    /**
     * �J�Î��Ԋ����擾���܂��B
     * @param timetable_lecture
     */
    public Timestamp getstart_time_lecture() {
        return start_time_lecture;
    }

    /**
     * ���ȃt���O���擾���܂��B
     * @param flg_absence
     */
    public int getflg_absence() {
        return flg_absence;
    }

    /**
     * �x���t���O���擾���܂��B
     * @param flg_late
     */
    public int getflg_late() {
        return flg_late;
    }

    /**
     * ���ރt���O���擾���܂��B
     * @param flg_early
     */
    public int getflg_early() {
        return flg_early;
    }

    /**
     * �U�փt���O���擾���܂��B
     * @param flg_substitute
     */
    public int getflg_substitute() {
        return flg_substitute;
    }

    /**
     * �폜�t���O���擾���܂��B
     * @param flg_delete
     */
    public int getflg_delete() {
        return flg_delete;
    }

    /**
     * �ŏI�X�VID���擾���܂��B
     * @param id_lastupdate
     */
    public String getid_lastupdate() {
        return id_lastupdate;
    }

    /**
     * �ŏI�X�V����擾���܂��B
     * @param date_lastupdate
     */
    public Timestamp getdate_lastupdate() {
        return date_lastupdate;
    }
    //出欠用のリスト      2014/1/4 Tanaka
    List<Trn010_AttendanceTrnBean> list_attend = new ArrayList<Trn010_AttendanceTrnBean>();
    public List<Trn010_AttendanceTrnBean> getlistattend(){
        return list_attend;
    }
    public void setlistattend(List<Trn010_AttendanceTrnBean> list_attend){
        this.list_attend = list_attend;
    }

    /**
     * id_courseを取得します。
     * @return id_course
     */
    public String getid_course() {
        return id_course;
    }

    /**
     * id_courseを設定します。
     * @param id_course id_course
     */
    public void setid_course(String id_course) {
        this.id_course = id_course;
    }
}
