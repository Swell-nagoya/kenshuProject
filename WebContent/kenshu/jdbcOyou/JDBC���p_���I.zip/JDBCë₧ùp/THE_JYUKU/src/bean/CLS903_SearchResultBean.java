package bean;


/**
 * 検索結果出力用のフォーム
 * @author n-kuraoka
 *
 * TODO 今後このフォームを元に画面出力するように
 * 組みなおす
 */
public class CLS903_SearchResultBean {


	//暫定で学校名のみ対応する
	public String name_elementary_school;
	public String name_junior_high_school;
	public String name_high_school;
	public String name_university;

	public String getName_elementary_school() {
		return name_elementary_school;
	}
	public void setName_elementary_school(String name_elementary_school) {
		this.name_elementary_school = name_elementary_school;
	}
	public String getName_junior_high_school() {
		return name_junior_high_school;
	}
	public void setName_junior_high_school(String name_junior_high_school) {
		this.name_junior_high_school = name_junior_high_school;
	}
	public String getName_high_school() {
		return name_high_school;
	}
	public void setName_high_school(String name_high_school) {
		this.name_high_school = name_high_school;
	}
	public String getName_university() {
		return name_university;
	}
	public void setName_university(String name_university) {
		this.name_university = name_university;
	}

}
