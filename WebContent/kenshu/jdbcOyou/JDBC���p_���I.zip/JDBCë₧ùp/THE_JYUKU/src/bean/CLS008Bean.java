package bean;

public class CLS008Bean {

		Mst001_UserMstBean mst001_UserMstBean = null;
		Mst002_StudentMstBean mst002_StudentMstBean = null;
		Mst003_GuardianMstBean mst003_GuardianMstBean = null;
		Mst010_CourseMstBean mst010_CourseMstBean = null;
		Mst016_GetCourseMstBean mst016_GetCourseMstBean = null;


		/**
		 * Mst001_UserMstを設定します。
		 * @param Mst001_userMstBean
		 */
		public void setMst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
			this.mst001_UserMstBean = mst001_UserMstBean;
		}

		/**
		 * Mst001_UserMstを取得します。
		 * @return Mst001_UserMstBean
		 */
		public Mst001_UserMstBean getMst001_UserMstBean() {
			return mst001_UserMstBean;
		}

		/**
		 * Mst002_StudentMstを設定します。
		 * @param Mst002_StudentMst
		 */
		public void setMst002_StudentMstBean(Mst002_StudentMstBean mst002_StudentMstBean) {
			this.mst002_StudentMstBean = mst002_StudentMstBean;
		}

		/**
		 * Mst002_StudentMstを取得します。
		 * @return Mst002_StudentMst
		 */
		public Mst002_StudentMstBean getMst002_StudentMstBean () {
			return mst002_StudentMstBean;
		}

		/**
		 * Mst003_GuardianMstを設定します。
		 * @param Mst003_GuardianMst
		 */
		public void  setMst003_GuardianMstBean(Mst003_GuardianMstBean mst003_GuardianMstBean) {
			this.mst003_GuardianMstBean = mst003_GuardianMstBean;
		}

		/**
		 * Mst003_GuardianMstを取得します。
		 * @return Mst003_GuardianMst
		 */
		public Mst003_GuardianMstBean getMst003_GuardianMstBean () {
			return mst003_GuardianMstBean;
		}

		/**
		 * Mst010_CourseMstBeanを設定します。
		 * @param mst010_CourseMstBean
		 */
		public void setMst010_CourseMstBean(Mst010_CourseMstBean mst010_CourseMstBean) {
			this.mst010_CourseMstBean = mst010_CourseMstBean;

		}


		/**
		 * Mst010_CourseMstBeanを取得します。
		 * @return mst010_CourseMstBean
		 */
		public Mst010_CourseMstBean getMst010_CourseMstBean() {
			return mst010_CourseMstBean;
		}
		/**
		 * Mst016_GetCourseMstBeanを設定します。
		 * @param mst016_GetCourseMstBean
		 */
		public void setMst016_GetCourseMstBean(Mst016_GetCourseMstBean mst016_GetCourseMstBean) {
			this.mst016_GetCourseMstBean = mst016_GetCourseMstBean;

		}


		/**
		 * Mst016_GetCourseMstBeanを取得します。
		 * @return mst016_GetCourseMstBean
		 */
		public Mst016_GetCourseMstBean getMst016_getCourseMstBean() {
			return mst016_GetCourseMstBean;
		}

}
