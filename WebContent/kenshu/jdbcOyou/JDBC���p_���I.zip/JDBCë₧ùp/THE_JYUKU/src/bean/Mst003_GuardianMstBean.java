package bean;

import java.sql.Timestamp;

	public class Mst003_GuardianMstBean {

		/**
		 * Guardian表のDTOクラス
		 * <pre>
		 * 保護者のデータを格納します。
		 * </pre>
		 */


		//ユーザーID
		private String id_user;

		//家族ID
		private String id_family;

		//住所
		private String address;

		//削除フラグ
		private int flg_delete;

		//最終更新ID
		private String id_lastupdate;

		//最終更新日
		private Timestamp date_lastupdate;

		/**
		 * ユーザIDを設定します。
		 * @param id_user ID_USER
		 */
		public void setId_user(String id_user) {
			this.id_user = id_user;
		}

		/**
		 * 家族IDを設定します。
		 * @param id_family ID_FAMILY
		 */
		public void setId_family(String id_family) {
			this.id_family = id_family;
		}


		/**
		 * 住所を設定します。
		 * @param address
		 */
		public void setAddress(String address) {
			this.address = address;
		}

		/**
		 * DELETE_FLG
		 * 削除フラグを設定します。
		 * @param flg_delete 削除フラグ
		 */
		public void setFlg_delete(int flg_delete) {
			this.flg_delete = flg_delete;
		}

		/**
		 * 最終更新IDを設定します。
		 * @param phone 最終更新ID
		 */
		public void setId_lastupdate(String id_lastupdate) {
			this.id_lastupdate = id_lastupdate;
		}

		/**
		 * 最終更新日を設定します。
		 * @param date_last 最終更新日
		 */
		public void setDate_lastupdate(Timestamp date_lastupdate) {
			this.date_lastupdate = date_lastupdate;
		}


		/**
		 * ユーザIDを取得します。
		 * @param id_user ID_USER
		 */
		public String getId_user() {
			return id_user;
		}

		/**
		 * 家族IDを取得します。
		 * @param id_family ID_FAMILY
		 */
		public String getId_family() {
			return id_family;
		}

		/**
		 * 住所を設定します。
		 * @param address
		 */
		public String getAddress() {
			return address;
		}

		/**
		 * DELETE_FLG
		 * 削除フラグを設定します。
		 * @param flg_delete 削除フラグ
		 */
		public int getFlg_delete() {
			return flg_delete;
		}

		/**
		 * 最終更新IDを取得します。
		 * @param mail 最終更新ID
		 */
		public String getLastupdate_id() {
			return this.id_lastupdate;
		}
		/**
		 * 最終更新日を取得します。
		 * @param mail 最終更新日
		 */
		public Timestamp getLastupdate_date() {
			return this.date_lastupdate;
		}


}
