package bean;

public class CLS909Bean {

		Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = null;
		Mst001_UserMstBean mst001_UserMstBean = null;

		/**
		 * Mst001_UserMstBeanを設定します。
		 * @param Mst001_UserMstBean
		 */
		public Mst001_UserMstBean getMst001_UserMstBean() {
			return mst001_UserMstBean;
		}

		/**
		 * Mst001_UserMstBeanを設定します。
		 * @param Mst001_UserMstBean
		 */
		public void setMst001_UserMstBean(Mst001_UserMstBean mst001_UserMstBean) {
			this.mst001_UserMstBean = mst001_UserMstBean;
		}

		/**
		 * Trn014_confidentialTrnを設定します。
		 * @param Trn014_ConfidentialTrnBean
		 */
		public void setTrn014_ConfidentialTrnBean(Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean) {
			this.trn014_ConfidentialTrnBean = trn014_ConfidentialTrnBean;
		}

		/**
		 * Trn014_confidentialTrnを取得します。
		 * @return Trn014_confidentialTrnBean
		 */
		public Trn014_ConfidentialTrnBean getTrn014_ConfidentialTrnBean() {
			return trn014_ConfidentialTrnBean;
		}
}
