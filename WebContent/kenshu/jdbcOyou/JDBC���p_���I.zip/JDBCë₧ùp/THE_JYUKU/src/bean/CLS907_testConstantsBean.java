package bean;

import java.io.Serializable;

/**
 * テスト定数格納クラス
 * @author kume
 *
 */
public class CLS907_testConstantsBean implements Serializable {

	private String name_constant;

	private String constant;

	public String getName_constant() {
		return name_constant;
	}

	public void setName_constant(String name_constant) {
		this.name_constant = name_constant;
	}

	public String getConstant() {
		return constant;
	}

	public void setConstant(String constant) {
		this.constant = constant;
	}

	@Override
	public String toString() {
		return "CLS907_testConstantsBean [name_constant=" + name_constant
				+ ", constant=" + constant + "]";
	}
}
