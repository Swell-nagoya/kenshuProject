package bean;

import java.io.Serializable;
import java.util.List;

/**
 * テスト検索情報格納クラス
 * @author kume
 *
 */
public class CLS907_SearchBean implements Serializable {

	// 検索カテゴリ
	private String searchCategory;
	// テストカテゴリ
	private String testCategory;
	// 検索期間開始日
	private String start;
	// 検索期間終了日
	private String end;
	// テストID
	private String testID;
	// 回次
	private String times;
	// ユーザーID
	private String userID;
	// ユーザーName
	private String userName;
	// エラー格納用リスト
	private List<String> message;

	public String getSearchCategory() {
		return searchCategory;
	}

	public void setSearchCategory(String searchCategory) {
		this.searchCategory = searchCategory;
	}

	public String getTestCategory() {
		return testCategory;
	}

	public void setTestCategory(String testCategory) {
		this.testCategory = testCategory;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public String getTestID() {
		return testID;
	}

	public void setTestID(String testID) {
		this.testID = testID;
	}

	public String getTimes() {
		return times;
	}

	public void setTimes(String time) {
		this.times = time;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<String> getMessage() {
		return message;
	}

	public void setMessage(List<String> message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "CLS907_testResultSearchBean [searchCategory=" + searchCategory
				+ ", testCategory=" + testCategory + ", start=" + start
				+ ", end=" + end + ", testID=" + testID + ", times=" + times
				+ ", userID=" + userID + ", errorMessage=" + message + "]";
	}
}
