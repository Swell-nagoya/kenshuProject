package servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import Validate.Validate;

public class ValidateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String msg_error = null;

	// (登録情報変更)
	public String ChangeInfoCheck(HttpServletRequest request) {

		// ニックネーム(NULL or 長さが40以下ならエラー)
		if (StringUtils.isEmpty(request.getParameter("NICKNAME"))
				|| request.getParameter("NICKNAME").length() > 40) {
			msg_error = "ニックネームが入力エラーです。入力して下さい。";
			// メールアドレス(NULLならエラー) ⇒メールアドレスチェックメソッドを倉岡に頼む！
		} else if (StringUtils.isEmpty(request.getParameter("MAIL_ADDRESS"))) {
			msg_error = "メールアドレスが入力エラーです。入力して下さい。";
		} else if (StringUtils.isEmpty(request.getParameter("PASSWORD"))) {
			msg_error = "パスワードが入力されていません。";
		} else if (StringUtils.isEmpty(request.getParameter("NEWPASSWORD"))) {
			msg_error = "新パスワードが入力されていません。";
		} else if (StringUtils.isEmpty(request.getParameter("REPASSWORD"))) {
			msg_error = "新パスワード(再)が入力されていません。";
		} else if (!StringUtils.equals(request.getParameter("NEWPASSWORD"),
				request.getParameter("REPASSWORD"))) {
			msg_error = "新パスワードと新パスワード(再)が一致しません。";
		}
		return msg_error;
	}

	// (学校登録)
	public String SchoolCheck(HttpServletRequest request) {
		/** チェックフラグ(1以上ならエラー) **/
		int numLeng = 4;
		int[] num = new int[numLeng];
		for (int i = 0; i < num.length; i++) {
			num[i] = i + 1;
		}

		// 学校ID(数字以外 or NULLならエラー)
		if (StringUtils.isEmpty(request.getParameter("id_school"))) {
			msg_error = "学校IDが入力エラーです。";
			// 学校名(NULL or 全角でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("name_school"))
				|| !Validate.onlyZennkaku(request.getParameter("name_school"))) {
			msg_error = "学校名が入力エラーです。全角で入力して下さい。";
			// 学校種別(NULL or 数字以外ならエラー)
		} else if (request.getParameter("categorize_school") == null) {
			if (StringUtils.isEmpty(request.getParameter("categorize_school"))
					|| !Validate.isNum(request
							.getParameter("categorize_school"))
					|| !Validate.isNum(request
							.getParameter("categorize_school1"))
					|| !Validate.isNum(request
							.getParameter("categorize_school2"))
					|| !Validate.isNum(request
							.getParameter("categorize_school3"))
					|| !Validate.isNum(request
							.getParameter("categorize_school4"))
					|| !Validate.checkNum(num,
							request.getParameter("categorize_school"))) {
				msg_error = "学校種別はいずれかを入力して下さい。";
			}
			// 住所(NULL or 全角でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("address_school"))
				|| !Validate.onlyZennkaku(request
						.getParameter("address_school"))) {
			msg_error = "住所が入力エラーです。全角200文字以内で入力して下さい。";
			// 学区(全角でないならエラー)
		} else if (!Validate.onlyZennkaku(request
				.getParameter("district_school"))
				|| StringUtils.isEmpty(request.getParameter("district_school"))) {
			msg_error = "学区が入力エラーです。";
		} else {
			int numLeng2 = 3;
			int[] num2 = new int[numLeng2];
			for (int i = 0; i < num2.length; i++) {
				num2[i] = 3;
				if (i == 1) {
					num2[i] = 5;
				} else if (i == 2) {
					num2[i] = 10;
				}
			}
			// 学期(数字の"2"か"3"以外ならエラー)
			if (!(StringUtils.equals(request.getParameter("term"), "2") || StringUtils
					.equals(request.getParameter("term"), "3"))) {
				msg_error = "学期が入力エラーです。2か3を入力して下さい。";
				// 評価段階数(数字以外ならエラー)
			} else if (!Validate.isNum(request.getParameter("type_evaluation"))
					|| Validate.checkNum(num2,
							request.getParameter("type_evaluation")) == false) {
				msg_error = "評価段階数が入力エラーです。3か5か10を入力して下さい。";
			}
		}
		return msg_error;
	}

	// (振替参照)
	public String SubstituteCheck(HttpServletRequest request) {
		// ユーザID(NULLならエラー)
		if (StringUtils.isEmpty(request.getParameter("ID_USER"))) {
			msg_error = "ユーザIDが入力エラーです。入力して下さい。";
			// コースID(数字でない or NULLならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("ID_COURCE"))
				|| !Validate.isNum(request.getParameter("ID_COURCE"))) {
			msg_error = "コースIDが入力エラーです。";
		}
		return msg_error;
	}

	// (内申点登録)
	public String ConfidentialInsCheck(HttpServletRequest request) {
		// チェック用
		int numLeng2 = 3;
		int[] num2 = new int[numLeng2];
		for (int i = 0; i < num2.length; i++) {
			num2[i] = 3;
			if (i == 1) {
				num2[i] = 5;
			} else if (i == 2) {
				num2[i] = 10;
			}
		}
		// ユーザID(NULLならエラー)
		if (request.getParameter("ID_USER") == "") {
			msg_error = "ユーザIDが入力エラーです。入力して下さい。";
			// 年度(NULL or 数字でないならエラー)　⇒　半角数字4桁チェックメソッドを倉岡に頼む！
		} else if (StringUtils.isEmpty(request.getParameter("FISCAL_YEAR"))
				|| !Validate.isNum((request.getParameter("FISCAL_YEAR")))) {
			msg_error = "年度が入力エラーです。半角数字4桁で入力して下さい。";
			// 回次(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("TIMES"))
				|| !Validate.isNum((request.getParameter("TIMES")))) {
			msg_error = "回次が入力エラーです。";
			// 評価段階数(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("TYPE_EVALUATION"))
				|| !Validate.isNum((request.getParameter("TYPE_EVALUATION")))
				|| !Validate.checkNum(num2,
						request.getParameter("TYPE_EVALUATION"))) {
			msg_error = "評価段階数が入力エラーです。3か5か10を入力して下さい。";
			// 国語内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_JAP"))
				|| !Validate.isNum((request.getParameter("CONF_JAP")))) {
			msg_error = "国語内申点が入力エラーです。";
			// 数学内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_MATH"))
				|| !Validate.isNum((request.getParameter("CONF_MATH")))) {
			msg_error = "数学内申点が入力エラーです。";
			// 理科内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_SIEC"))
				|| !Validate.isNum((request.getParameter("CONF_SIEC")))) {
			msg_error = "理科内申点が入力エラーです。";
			// 社会内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_SCTY"))
				|| !Validate.isNum((request.getParameter("CONF_SCTY")))) {
			msg_error = "社会内申点が入力エラーです。";
			// 英語内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_ENG"))
				|| !Validate.isNum((request.getParameter("CONF_ENG")))) {
			msg_error = "英語内申点が入力エラーです。";
			// 技術家庭内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_TECH"))
				|| !Validate.isNum((request.getParameter("CONF_TECH")))) {
			msg_error = "技術家庭内申点が入力エラーです。";
			// 体育内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_GMST"))
				|| !Validate.isNum((request.getParameter("CONF_GMST")))) {
			msg_error = "体育内申点が入力エラーです。";
			// 音楽内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_MUSIC"))
				|| !Validate.isNum((request.getParameter("CONF_MUSIC")))) {
			msg_error = "音楽内申点が入力エラーです。";
			// 美術内申点(NULL or 数字でないならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("CONF_ARTS"))
				|| !Validate.isNum((request.getParameter("CONF_ARTS")))) {
			msg_error = "美術内申点が入力エラーです。";
		}
		return msg_error;
	}

	// (振替登録)　⇒振替フラグはnullでも0とするか？
	public String SubstituteInsCheck(HttpServletRequest request) {
		// ユーザID(NULLならエラー) ⇒ 数字のみではないのか？
		if (StringUtils.isEmpty(request.getParameter("ID_USER"))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_update_id_user"))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_delete_id_user"))) {
			msg_error = "ユーザIDが入力エラーです。入力して下さい。";
			// コースID(数字でない or NULLならエラー)
		} else if (StringUtils.isEmpty(request.getParameter("ID_COURSE"))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_update_id_course"))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_delete_id_course"))) {
			msg_error = "コースIDが入力エラーです。";
			// ☆ 欠席フラグ(数字でない or NULLならエラー)
		} else if ((StringUtils.isEmpty(request.getParameter("FLG_ABSENCE")) || !Validate
				.isZeoOrOne(request.getParameter("FLG_ABSENCE")))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_delete_flg_absence"))) {
			msg_error = "欠席フラグが入力エラーです。0か1を入力して下さい。";
			// ☆遅刻フラグ(数字でない or NULLならエラー)
		} else if ((StringUtils.isEmpty(request.getParameter("FLG_LATE")) || !Validate
				.isZeoOrOne(request.getParameter("FLG_LATE")))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_delete_flg_late"))) {
			msg_error = "遅刻フラグが入力エラーです。0か1を入力して下さい。";
			// ☆早退フラグ(数字でない or NULLならエラー)
		} else if ((StringUtils.isEmpty(request.getParameter("FLG_EARLY")) || !Validate
				.isZeoOrOne(request.getParameter("FLG_EARLY")))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_delete_flg_early"))) {
			msg_error = "早退フラグが入力エラーです。0か1を入力して下さい。";
			// ☆振替フラグ(数字でない or NULLならエラー)
		} else if ((StringUtils.isEmpty(request.getParameter("FLG_SUBSTITUTE")) || !Validate
				.isZeoOrOne(request.getParameter("FLG_SUBSTITUTE")))
				&& StringUtils.isEmpty(request
						.getParameter("substitute_delete_flg_substitute"))) {
			msg_error = "振替フラグが入力エラーです。0か1を入力して下さい。";
			// 開催時間割(数字でない or nullならエラー)
		}/*
		 * else if
		 * (StringUtils.isEmpty(request.getParameter("TIMETABLE_LECTURE")) ||
		 * !Validate.isNum(request.getParameter("TIMETABLE_LECTURE"))) {
		 * msg_error = "開催時間割が入力エラーです。"; // 開催日付(日付でない or nullならエラー) } else if
		 * ((StringUtils.isEmpty(request.getParameter("DATE_LECTURE")) &&
		 * StringUtils.isEmpty(request.getParameter("DATE_LECTURE_MONTH")) &&
		 * StringUtils.isEmpty(request.getParameter("DATE_LECTURE_DAY"))) ){
		 * msg_error = "開催日付が入力エラーです。"; // 振替時間割(数字でない or nullならエラー) } else if
		 * (StringUtils.isEmpty(request.getParameter("TIMETABLE_SUBSTITUTE")) ||
		 * !Validate.isNum(request.getParameter("TIMETABLE_SUBSTITUTE"))) {
		 * msg_error = "振替時間割が入力エラーです。"; // 振替日付(日付でない or nullならエラー) } else if
		 * ((StringUtils.isEmpty(request.getParameter("DATE_SUBSTITUTE")) &&
		 * StringUtils.isEmpty(request.getParameter("DATE_SUBSTITUTE_MONTH")) &&
		 * StringUtils.isEmpty(request.getParameter("DATE_SUBSTITUTE_DAY")))){
		 * msg_error = "振替日付が入力エラーです。"; }
		 */
		return msg_error;
	}
}