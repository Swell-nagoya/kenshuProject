package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import bean.Mst001_UserMstBean;


/**
 * 検索はこのサーブレットで行う
 * @author hasumi
 *
 */
public class CLS007_ChangeInfoServlet extends HttpServlet {
	private static final String COMPLETE_MESSAGE = "登録情報を変更しました。";
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		//Sessionの取得
		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		//beanの取得
		Mst001_UserMstBean Mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");;


		int permission = Mst001_UserMstBean.getPermission();
		session.setAttribute("permission", permission);
//		session.setAttribute("update", Mst001_UserMstBean);
		request.getRequestDispatcher("JSP/topmenu/menu/CLS007_ChangeInfo.jsp").forward(request, response);
	}
}

