package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import Dao.CLS911DAO;
import Dao.ConnectionManager;
import Dao.Mst001_UserMstDAO;
import Dao.Mst020_ConstantMstDAO;
import bean.CLS911Bean;
import bean.Mst001_UserMstBean;
import bean.Mst010_CourseMstBean;
import bean.Mst011_CourseMeisaiMstBean;
import bean.Mst013_SubjectMstBean;
import bean.Mst017_TimeTableMstBean;

import common.ServretCommon;

/**
 * ユーザマスタ画面から（登録、削除、更新画面に遷移）
 * 検索はこのサーブレットで行う
 * @author n-kuraoka
 *
 */
public class CourseSearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
                    throws ServletException, IOException {

        //Sessionの取得
        HttpSession session = request.getSession();

        // loginSessionのチェック
        ServretCommon.checkLoginSession(request, response, session);

        //過去に取得したパラメータを削除
        request.removeAttribute("courseSearch");
        request.removeAttribute("courseSearchlist");

        //beanの取得
        CLS911Bean cls911 = new CLS911Bean();

        //Daoの取得
        CLS911DAO cls911dao = new CLS911DAO();

        //取得予定のリスト
        List<CLS911Bean> list = new ArrayList<CLS911Bean>();

        //各種プルダウン用の値の取得
        Mst020_ConstantMstDAO mst020_ConstantMstDAO = new Mst020_ConstantMstDAO();
        List<String> Constant_Course_Gakunen = new ArrayList<>();
        List<Mst013_SubjectMstBean> mst013_SubjectMstBeans = new ArrayList<>();
        List<String> Constant_Course_Day_Of_Week = new ArrayList<>();
        List<Mst017_TimeTableMstBean>  mst017_TimeTableMstBeans = new ArrayList<>();
        List<Mst001_UserMstBean>  mst001_UserMstBeans = new ArrayList<>();

        ConnectionManager.beginTransaction();
        Constant_Course_Gakunen = mst020_ConstantMstDAO.getConstants(new Timestamp(System.currentTimeMillis()), "GRADE");
        mst013_SubjectMstBeans = cls911dao.SearchMst013ByFlg_delete(0);
        Constant_Course_Day_Of_Week = mst020_ConstantMstDAO.getConstants(new Timestamp(System.currentTimeMillis()), "DAY_OF_WEEK");
        mst017_TimeTableMstBeans = cls911dao.SearchMst017();
        mst001_UserMstBeans = cls911dao.SearchMst001ByPermissionAndFlg_delete(3,0);

        try {
            ConnectionManager.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        cls911.setConstant_Course_Gakunen(Constant_Course_Gakunen);
        cls911.setConstant_Course_Day_Of_Week(Constant_Course_Day_Of_Week);
        cls911.setMst013_SubjectMstBeans(mst013_SubjectMstBeans);
        cls911.setMst017_TimeTableMstBeans(mst017_TimeTableMstBeans);
        cls911.setMst001_UserMstBeans(mst001_UserMstBeans);

        if (request.getParameter("select") == null){
        //初期表示と月曜日の検索を可能にするための処理
        Mst011_CourseMeisaiMstBean mst011_CourseMeisaiMst = new Mst011_CourseMeisaiMstBean();
        mst011_CourseMeisaiMst.setday_lecture(Integer.parseInt("-1"));
        cls911.setMst011_CourseMeisaiMstBean(mst011_CourseMeisaiMst);
        session.setAttribute("courseSearch", cls911);
        request.setAttribute("id_course", request.getAttribute("id_course"));
        request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CourseSearch.jsp").forward(request, response);
        }

        if (request.getParameter("select") != null) {

            String id_user = request.getParameter("id_user");

            Mst001_UserMstDAO mst001_usermstdao = new Mst001_UserMstDAO();
            Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();

            ConnectionManager.beginTransaction();
            mst001_UserMstBean = mst001_usermstdao.findById(id_user);
            try {
                ConnectionManager.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            cls911.setMst001_UserMstBean(mst001_UserMstBean);

            /**
             * 検索機能
             * コースマスタ コースID、コース名、開催期間(開始)、開催期間(終了)、授業料、コース内容
             * コース詳細マスタ 対象学年、科目ID、開催曜日、開催時間割、担当講師IDを入力する
             */


            //以下検索内容。JSPを参考に同じ内容をコピーしていく

            Mst010_CourseMstBean mst010_CourseMst = new Mst010_CourseMstBean();
            Mst011_CourseMeisaiMstBean mst011_CourseMeisaiMst = new Mst011_CourseMeisaiMstBean();

            if (!request.getParameter("NAME_COURSE").equals("")){
                mst010_CourseMst.setname_course(request.getParameter("NAME_COURSE"));
            }

            //開催期間はTimestamp形式に変換
//			if (!request.getParameter("START_LECTURE_YEAR").equals("") && !request.getParameter("START_LECTURE_MONTH").equals("") && !request.getParameter("START_LECTURE_DATE").equals("")) {
//				String start_lecture = request.getParameter("START_LECTURE_YEAR") + "-" + request.getParameter("START_LECTURE_MONTH") + "-" + request.getParameter("START_LECTURE_DATE") + " " + "00:00:00";
//				System.out.println(start_lecture);
//				if (Validate.isDate(start_lecture)) {
//					mst010_CourseMst.setstart_lecture(Timestamp.valueOf(start_lecture));
//				}
//			}
//
//			if (!request.getParameter("END_LECTURE_YEAR").equals("") && !request.getParameter("END_LECTURE_MONTH").equals("") && !request.getParameter("END_LECTURE_DATE").equals("")) {
//				String end_lecture = request.getParameter("END_LECTURE_YEAR") + "-" + request.getParameter("END_LECTURE_MONTH") + "-" + request.getParameter("END_LECTURE_DATE") + " " + "00:00:00";
//				System.out.println(end_lecture);
//				if (Validate.isDate(end_lecture)) {
//					mst010_CourseMst.setend_lecture(Timestamp.valueOf(end_lecture));
//				}
//			}
//
//			if (!request.getParameter("TUITION").equals("")) {
//				mst010_CourseMst.settuition(Integer.parseInt(request.getParameter("TUITION")));
//			}
//
            if (request.getParameter("DETAILS_COURSE") != null) {
                mst010_CourseMst.setdetails_course(request.getParameter("DETAILS_COURSE"));
            }

            cls911.setMst010_CourseMstBean(mst010_CourseMst);

            int target = 0;
            if (request.getParameter("GRADE") != "0") {
                if (!StringUtils.isEmpty(request.getParameter("GRADE")))
                {
                    target +=Integer.parseInt(request.getParameter("GRADE"));
                }
            }

            if(request.getParameter("SCHOOL") != null) {
                if (request.getParameter("SCHOOL").equals("小学校")) {
                    target = 10;
                    if (request.getParameter("GRADE") != "") {
                        target +=Integer.parseInt(request.getParameter("GRADE"));
                    }
                    mst011_CourseMeisaiMst.settarget(target);
                } else if (request.getParameter("SCHOOL").equals("中学校")) {
                    target = 20;
                    if (request.getParameter("GRADE") != "") {
                        target +=Integer.parseInt(request.getParameter("GRADE"));
                    }
                    mst011_CourseMeisaiMst.settarget(target);
                } else if (request.getParameter("SCHOOL").equals("高校")) {
                    target = 30;
                    if (request.getParameter("GRADE") != "") {
                        target += Integer.parseInt(request.getParameter("GRADE"));
                    }
                    mst011_CourseMeisaiMst.settarget(target);
                } else {
                    System.out.println("正しく学年が処理されていません");
                }
            }

            if (!request.getParameter("ID_SUBJECT").equals("")) {
                mst011_CourseMeisaiMst.setid_subject(request.getParameter("ID_SUBJECT"));
            }
            if (request.getParameter("DAY_LECTURE") != "-1") {
                mst011_CourseMeisaiMst.setday_lecture(Integer.parseInt(request.getParameter("DAY_LECTURE")));
            }
            if (request.getParameter("START_TIMETABLE_LECTURE") != null) {
                mst011_CourseMeisaiMst.setstart_time_lecture(Timestamp.valueOf(request.getParameter("START_TIMETABLE_LECTURE")));
            }
            if (request.getParameter("END_TIMETABLE_LECTURE") != null) {
                mst011_CourseMeisaiMst.setend_time_lecture(Timestamp.valueOf(request.getParameter("END_TIMETABLE_LECTURE")));
            }
            if (!request.getParameter("ID_TEACHER").equals("")) {
                mst011_CourseMeisaiMst.setid_teacher(request.getParameter("ID_TEACHER"));
            }
            cls911.setMst011_CourseMeisaiMstBean(mst011_CourseMeisaiMst);


            ConnectionManager.beginTransaction();

            list = cls911dao.Search(cls911);

            try {
                ConnectionManager.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            session.setAttribute("courseSearchlist", list);
            session.setAttribute("courseSearch", cls911);
            request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CourseSearch.jsp").forward(request, response);
        }
    }
}
