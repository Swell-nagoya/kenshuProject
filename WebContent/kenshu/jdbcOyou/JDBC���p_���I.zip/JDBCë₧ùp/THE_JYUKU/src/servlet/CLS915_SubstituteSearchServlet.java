package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.CLS915DAO;
import Dao.ConnectionManager;
import Dao.Trn005_SubstituteTrnDAO;
import bean.CLS915Bean;
import bean.Trn005_SubstituteTrnBean;


/**
 * 振替画面から（登録、削除、更新画面に遷移）
 * 検索はこのサーブレットで行う
 * @author m-hayashi
 *
 */
public class CLS915_SubstituteSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		//Sessionの取得
		HttpSession session = request.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		//過去に取得したパラメータを削除
		session.removeAttribute("alart");
		request.removeAttribute("cls915");
		request.removeAttribute("cls915list");
		request.removeAttribute("cls915Bean");

		//beanの取得
		CLS915Bean cls915Bean = new CLS915Bean();

		//Daoの取得
		CLS915DAO cls915Dao = new CLS915DAO();

		//取得予定のリスト
		List<CLS915Bean> list = new ArrayList<CLS915Bean>();

		if (request.getParameter("select") != null) {
			Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = new Trn005_SubstituteTrnBean();

			if (!request.getParameter("ID_USER").equals("")) {
				trn005_SubstituteTrnBean.setid_user(request.getParameter("ID_USER"));
			}
			if (!request.getParameter("ID_COURSE").equals("")) {
				trn005_SubstituteTrnBean.setid_course(request.getParameter("ID_COURSE"));
			}

			cls915Bean.setTrn005_SubstituteTrnBean(trn005_SubstituteTrnBean);

			ConnectionManager.beginTransaction();

			list = cls915Dao.Search(cls915Bean);

			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			session.setAttribute("cls915", list);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS915_SubstituteSearch.jsp").forward(request, response);

		}

		//新規作成
		if(request.getParameter("create") != null) {
			session.removeAttribute("delete");
			session.removeAttribute("update");
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS916_SubstituteInsert.jsp").forward(request, response);
		}

		//修正ボタン押下時
		if (request.getParameter("update") != null) {
			Trn005_SubstituteTrnDAO trn005_SubstituteTrnDAO = new Trn005_SubstituteTrnDAO();
			Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = new Trn005_SubstituteTrnBean();

			String id_user = request.getParameter("id_user");
			String id_course = request.getParameter("id_course");
			String start_lecture = request.getParameter("start_lecture");
			ConnectionManager.beginTransaction();
			trn005_SubstituteTrnBean = trn005_SubstituteTrnDAO.findByKey(id_user,id_course,start_lecture);

			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			cls915Bean.setTrn005_SubstituteTrnBean(trn005_SubstituteTrnBean);

			session.removeAttribute("alart");
			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.setAttribute("update", cls915Bean);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS916_SubstituteInsert.jsp").forward(request, response);

		}

		//削除ボタン押下時
		if (request.getParameter("delete") != null) {
			Trn005_SubstituteTrnDAO trn005_SubstituteTrnDAO = new Trn005_SubstituteTrnDAO();
			Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = new Trn005_SubstituteTrnBean();

			String id_user = request.getParameter("id_user");
			String id_course = request.getParameter("id_course");
			String start_lecture = request.getParameter("start_lecture");
			ConnectionManager.beginTransaction();
			trn005_SubstituteTrnBean = trn005_SubstituteTrnDAO.findByKey(id_user,id_course,start_lecture);

			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			cls915Bean.setTrn005_SubstituteTrnBean(trn005_SubstituteTrnBean);

			session.removeAttribute("alart");
			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.setAttribute("delete", cls915Bean);
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS916_SubstituteInsert.jsp").forward(request, response);
		}
	}
}

