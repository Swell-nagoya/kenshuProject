package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.CLS903DAO;
import Dao.ConnectionManager;
import Dao.Mst001_UserMstDAO;
import Dao.Mst002_StudentMstDAO;
import Dao.Mst003_GuardianMstDAO;
import Dao.Mst004_AdministratorMstDAO;
import Dao.Mst020_ConstantMstDAO;
import bean.CLS903Bean;
import bean.Mst001_UserMstBean;
import bean.Mst002_StudentMstBean;
import bean.Mst003_GuardianMstBean;
import bean.Mst004_AdministratorMstBean;
import bean.Mst010_CourseMstBean;
import bean.Mst014_SchoolMstBean;
import bean.Mst016_GetCourseMstBean;
import common.LoginException;
import common.ServretCommon;

/**
 * ユーザマスタ画面から（登録、削除、更新画面に遷移） 検索はこのサーブレットで行う
 * 
 * @author n-kuraoka
 * 
 */
public class CLS903_UserInfoSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Daoの取得
	CLS903DAO cls903dao = new CLS903DAO();
	Mst020_ConstantMstDAO mst020_ConstantMstDAO = new Mst020_ConstantMstDAO();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Sessionの取得
		HttpSession session = request.getSession();

		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		// 過去に取得したパラメータを削除
		request.removeAttribute("cls903");
		request.removeAttribute("cls903list");
		request.removeAttribute("Map_AllSchoolList");

		// beanの取得
		CLS903Bean cls903 = new CLS903Bean();

		// 取得予定のリスト
		List<CLS903Bean> list = new ArrayList<CLS903Bean>();

		if (request.getParameter("select") != null) {

			/**
			 * 検索機能 生徒/保護者/管理者 登録項目選択 氏名、氏名(ｶﾅ)、性別、学校、学年を入力する
			 */
			if (request.getParameter("permission") == null) {
				request.setAttribute("alart", "生徒か保護者か管理者かを選択して下さい。");
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS903_UserInfoSearch.jsp")
						.forward(request, response);
				return;
			}

			Mst001_UserMstBean mst001_UserMst = new Mst001_UserMstBean();

			// 共通項目
			mst001_UserMst.setPermission(Integer.parseInt(request
					.getParameter("permission")));
			if (!request.getParameter("NAME_USER").equals("")) {
				mst001_UserMst.setName(request.getParameter("NAME_USER"));
			}

			if (!request.getParameter("KANA_NAME_USER").equals("")) {
				mst001_UserMst.setKana_name(request
						.getParameter("KANA_NAME_USER"));
			}

			if (request.getParameter("SEX") != null) {
				mst001_UserMst.setSex(Integer.parseInt(request
						.getParameter("SEX")));
			}

			cls903.setMst001_UserMstBean(mst001_UserMst);

			// 生徒の場合
			if (Integer.parseInt(request.getParameter("permission")) == 1) {
				Mst002_StudentMstBean mst002_StudentMst = new Mst002_StudentMstBean();
				int grade = 0;
				if (request.getParameter("SCHOOL") != null) {
					if (request.getParameter("SCHOOL").equals("小学校")) {
						grade = 10;
						mst002_StudentMst.setGrade(grade);
					} else if (request.getParameter("SCHOOL").equals("中学校")) {
						grade = 20;
						mst002_StudentMst.setGrade(grade);
					} else if (request.getParameter("SCHOOL").equals("高校")) {
						grade = 30;
						mst002_StudentMst.setGrade(grade);
					} else if (request.getParameter("SCHOOL").equals("大学")) {
						grade = 40;
						mst002_StudentMst.setGrade(grade);
					} else {
						System.out.println("正しく学年が処理されていません");
					}
				}
				cls903.setMst002_StudentMstBean(mst002_StudentMst);

				ConnectionManager.beginTransaction();

				list = cls903dao.Search(cls903);

				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				session.setAttribute("cls903list", list);
				session.setAttribute("cls903", cls903);
				session.setAttribute("Map_AllSchoolList",
						getMap_AllSchoolList());
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS903_UserInfoSearch.jsp")
						.forward(request, response);

				// 保護者の場合
			} else if (Integer.parseInt(request.getParameter("permission")) == 2) {
				Mst003_GuardianMstBean mst003_GuardianMst = new Mst003_GuardianMstBean();
				cls903.setMst003_GuardianMstBean(mst003_GuardianMst);

				ConnectionManager.beginTransaction();
				list = cls903dao.Search(cls903);

				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				session.setAttribute("cls903list", list);
				session.setAttribute("cls903", cls903);
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS903_UserInfoSearch.jsp")
						.forward(request, response);

				// 管理者の場合
			} else if (Integer.parseInt(request.getParameter("permission")) == 3) {

				Mst004_AdministratorMstBean mst004_AdministratorMst = new Mst004_AdministratorMstBean();

				// int grade = 0;
				// if(request.getParameter("SCHOOL") != null) {
				// if (request.getParameter("SCHOOL").equals("小学校")) {
				// grade = 10;
				// if (!request.getParameter("GRADE").equals("")) {
				// grade +=Integer.parseInt(request.getParameter("GRADE"));
				// }
				// mst004_AdministratorMst.setGrade(grade);
				// } else if (request.getParameter("SCHOOL").equals("中学校")) {
				// grade = 20;
				// if (!request.getParameter("GRADE").equals("")) {
				// grade +=Integer.parseInt(request.getParameter("GRADE"));
				// }
				// mst004_AdministratorMst.setGrade(grade);
				// } else if (request.getParameter("SCHOOL").equals("高校")) {
				// grade = 30;
				// if (!request.getParameter("GRADE").equals("")) {
				// grade += Integer.parseInt(request.getParameter("SCHOOL"));
				// }
				// mst004_AdministratorMst.setGrade(grade);
				// } else {
				// System.out.println("正しく学年が処理されていません");
				// }
				// }
				cls903.setMst004_AdministratorMstBean(mst004_AdministratorMst);

				ConnectionManager.beginTransaction();

				list = cls903dao.Search(cls903);

				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				session.setAttribute("cls903list", list);
				session.setAttribute("cls903", cls903);
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS903_UserInfoSearch.jsp")
						.forward(request, response);

			}

		}

		// 新規作成
		if (request.getParameter("create") != null) {

			if (request.getParameter("permission") == null) {

				session.setAttribute("alart", "権限を入力してください");
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS903_UserInfoSearch.jsp")
						.forward(request, response);

			} else {
				// パラメータの取得
				int permission = Integer.parseInt(request
						.getParameter("permission"));
				// if (permission == 1 || permission == 3) {
				// List<List<Mst014_SchoolMstBean>> mst014Lists = new
				// ArrayList<>();
				// List<Mst014_SchoolMstBean> juniorSchoolBeans = new
				// ArrayList<>();
				// List<Mst014_SchoolMstBean> junior_High_SchoolBeans = new
				// ArrayList<>();
				// List<Mst014_SchoolMstBean> High_SchoolBeans = new
				// ArrayList<>();
				// List<Mst014_SchoolMstBean> college = new ArrayList<>();
				// ConnectionManager.beginTransaction();
				// juniorSchoolBeans = cls903dao.SearchMST014_SCHOOLMST(1);
				// junior_High_SchoolBeans =
				// cls903dao.SearchMST014_SCHOOLMST(2);
				// High_SchoolBeans = cls903dao.SearchMST014_SCHOOLMST(3);
				// college = cls903dao.SearchMST014_SCHOOLMST(3);

				// mst014Lists.add(juniorSchoolBeans);
				// mst014Lists.add(junior_High_SchoolBeans);
				// mst014Lists.add(High_SchoolBeans);
				// mst014Lists.add(college);
				// cls903.setMst014_SchoolLists(mst014Lists);
				// }

				session.removeAttribute("permission");
				session.removeAttribute("delete");
				session.removeAttribute("update");
				session.removeAttribute("Map_AllSchoolList");
				session.setAttribute("create", cls903);
				if (permission == 1 || permission == 3) {
					session.setAttribute("Map_AllSchoolList",
							getMap_AllSchoolList());
				}
				session.setAttribute("permission", permission);
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS904_UserInfoInsert.jsp")
						.forward(request, response);

			}
		}
		// 更新
		if (request.getParameter("update") != null) {
			Mst001_UserMstDAO dao = new Mst001_UserMstDAO();
			String id_user = request.getParameter("id_user");
			Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();

			ConnectionManager.beginTransaction();
			mst001_UserMstBean = dao.findById(id_user);
			List<String> constant_Conrce = mst020_ConstantMstDAO.getConstants(
					new Timestamp(System.currentTimeMillis()), "Course");
			// 小学校の学校取得
			try {

				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			int permission = mst001_UserMstBean.getPermission();
			session.removeAttribute("permission");
			session.setAttribute("permission", permission);

			// 生徒
			if (permission == 1) {
				Mst002_StudentMstBean mst002_StudentMstBean = new Mst002_StudentMstBean();
				Mst002_StudentMstDAO mst002_StudentMstDAO = new Mst002_StudentMstDAO();
				List<Mst016_GetCourseMstBean> beans = new ArrayList<>();
				List<Mst010_CourseMstBean> mst010_CourseMstBeans = new ArrayList<>();

				ConnectionManager.beginTransaction();
				mst002_StudentMstBean = mst002_StudentMstDAO
						.findById_user(id_user);
				beans = cls903dao.SearchMst016ById_user(id_user);
				mst010_CourseMstBeans = cls903dao
						.GetNAME_COURSEByID_COURSE(beans);

				try {

					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cls903.setMst001_UserMstBean(mst001_UserMstBean);
				cls903.setMst002_StudentMstBean(mst002_StudentMstBean);
				cls903.setBeans(beans);
				cls903.setMst010_CourseMstBeans(mst010_CourseMstBeans);

				session.removeAttribute("delete");
				session.removeAttribute("update");
				session.removeAttribute("Map_AllSchoolList");
				session.removeAttribute("Constant_Course");
				session.setAttribute("update", cls903);
				session.setAttribute("Map_AllSchoolList",
						getMap_AllSchoolList());
				session.setAttribute("Constant_Course", constant_Conrce.get(0));
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS904_UserInfoInsert.jsp")
						.forward(request, response);

			}

			// 保護者
			if (permission == 2) {
				Mst003_GuardianMstBean mst003_GuardianMstBean = new Mst003_GuardianMstBean();
				Mst003_GuardianMstDAO mst003_GuardianMstDAO = new Mst003_GuardianMstDAO();

				ConnectionManager.beginTransaction();
				mst003_GuardianMstBean = mst003_GuardianMstDAO
						.findById_user(id_user);
				try {

					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cls903.setMst001_UserMstBean(mst001_UserMstBean);
				cls903.setMst003_GuardianMstBean(mst003_GuardianMstBean);
				session.removeAttribute("delete");
				session.removeAttribute("update");
				session.setAttribute("update", cls903);
				session.removeAttribute("Constant_Course");
				session.setAttribute("Constant_Course", constant_Conrce.get(0));
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS904_UserInfoInsert.jsp")
						.forward(request, response);
			}

			// 管理者
			if (permission == 3) {
				Mst004_AdministratorMstBean mst004_AdministratorMstBean = new Mst004_AdministratorMstBean();
				Mst004_AdministratorMstDAO mst004_AdministratorMstDAO = new Mst004_AdministratorMstDAO();
				List<Mst016_GetCourseMstBean> beans = new ArrayList<>();
				List<Mst010_CourseMstBean> mst010_CourseMstBeans = new ArrayList<>();

				ConnectionManager.beginTransaction();
				mst004_AdministratorMstBean = mst004_AdministratorMstDAO
						.findById_user(id_user);
				beans = cls903dao.SearchMst016ById_user(id_user);
				mst010_CourseMstBeans = cls903dao
						.GetNAME_COURSEByID_COURSE(beans);
				try {

					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cls903.setMst001_UserMstBean(mst001_UserMstBean);
				cls903.setMst004_AdministratorMstBean(mst004_AdministratorMstBean);
				cls903.setBeans(beans);
				cls903.setMst010_CourseMstBeans(mst010_CourseMstBeans);

				session.removeAttribute("delete");
				session.removeAttribute("update");
				session.removeAttribute("Map_AllSchoolList");
				session.setAttribute("update", cls903);
				session.setAttribute("Map_AllSchoolList",
						getMap_AllSchoolList());
				session.removeAttribute("Constant_Course");
				session.setAttribute("Constant_Course", constant_Conrce.get(0));
				request.getRequestDispatcher(
						"JSP/topmenu/menu/mastermente/CLS904_UserInfoInsert.jsp")
						.forward(request, response);

			}
		}
		// 削除
		if (request.getParameter("delete") != null) {

			Mst020_ConstantMstDAO mst020_ConstantMstDAO = new Mst020_ConstantMstDAO();

			Mst001_UserMstDAO dao = new Mst001_UserMstDAO();
			String id_user = request.getParameter("id_user");
			Mst001_UserMstBean mst001_UserMstBean = new Mst001_UserMstBean();

			ConnectionManager.beginTransaction();
			mst001_UserMstBean = dao.findById(id_user);
			List<String> Constant_Course = mst020_ConstantMstDAO.getConstants(
					new Timestamp(System.currentTimeMillis()), "Course");

			try {

				ConnectionManager.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			int permission = mst001_UserMstBean.getPermission();
			session.removeAttribute("permission");
			session.setAttribute("permission", permission);

			// 生徒
			if (permission == 1) {
				Mst002_StudentMstBean mst002_StudentMstBean = new Mst002_StudentMstBean();
				Mst002_StudentMstDAO mst002_StudentMstDAO = new Mst002_StudentMstDAO();
				List<Mst010_CourseMstBean> mst010_CourseMstBeans = new ArrayList<>();
				List<Mst016_GetCourseMstBean> beans = new ArrayList<>();

				ConnectionManager.beginTransaction();
				mst002_StudentMstBean = mst002_StudentMstDAO
						.findById_user(id_user);
				beans = cls903dao.SearchMst016ById_user(id_user);
				mst010_CourseMstBeans = cls903dao
						.GetNAME_COURSEByID_COURSE(beans);

				try {

					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cls903.setMst001_UserMstBean(mst001_UserMstBean);
				cls903.setMst002_StudentMstBean(mst002_StudentMstBean);
				cls903.setBeans(beans);
				cls903.setMst010_CourseMstBeans(mst010_CourseMstBeans);
			}

			// 保護者
			if (permission == 2) {
				Mst003_GuardianMstBean mst003_GuardianMstBean = new Mst003_GuardianMstBean();
				Mst003_GuardianMstDAO mst003_GuardianMstDAO = new Mst003_GuardianMstDAO();

				ConnectionManager.beginTransaction();
				mst003_GuardianMstBean = mst003_GuardianMstDAO
						.findById_user(id_user);
				try {

					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cls903.setMst001_UserMstBean(mst001_UserMstBean);
				cls903.setMst003_GuardianMstBean(mst003_GuardianMstBean);
			}

			// 管理者
			if (permission == 3) {
				Mst004_AdministratorMstBean mst004_AdministratorMstBean = new Mst004_AdministratorMstBean();
				Mst004_AdministratorMstDAO mst004_AdministratorMstDAO = new Mst004_AdministratorMstDAO();
				List<Mst016_GetCourseMstBean> beans = new ArrayList<>();
				List<Mst010_CourseMstBean> mst010_CourseMstBeans = new ArrayList<>();
				ConnectionManager.beginTransaction();
				mst004_AdministratorMstBean = mst004_AdministratorMstDAO
						.findById_user(id_user);
				beans = cls903dao.SearchMst016ById_user(id_user);
				mst010_CourseMstBeans = cls903dao
						.GetNAME_COURSEByID_COURSE(beans);
				try {

					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

				cls903.setMst001_UserMstBean(mst001_UserMstBean);
				cls903.setMst004_AdministratorMstBean(mst004_AdministratorMstBean);
				cls903.setBeans(beans);
				cls903.setMst010_CourseMstBeans(mst010_CourseMstBeans);
			}

			session.removeAttribute("delete");
			session.removeAttribute("update");
			session.removeAttribute("Constant_Course");
			session.removeAttribute("Map_AllSchoolList");
			if (permission == 1 || permission == 3) {
				session.setAttribute("Map_AllSchoolList",
						getMap_AllSchoolList());
			}
			session.setAttribute("delete", cls903);
			session.setAttribute("Constant_Course", Constant_Course.get(0));
			request.getRequestDispatcher(
					"JSP/topmenu/menu/mastermente/CLS904_UserInfoInsert.jsp")
					.forward(request, response);
		}
	}

	/**
	 * 学校種別ごとに全ての一覧を取得し,Mapに登録します。 Mapには各学校種別が以下のように設定されます。
	 * 
	 * n_Categorize_School(*1) *1：nには各学校に割り当てられた番号が入る。
	 * 
	 * ＃各学校種別に対応する番号 1:小学校 2:中学校 3:高校 4:大学
	 * 
	 * @return　Map<String, List<Mst014_SchoolMstBean>>
	 */
	public Map<String, List<Mst014_SchoolMstBean>> getMap_AllSchoolList() {
		Map<String, List<Mst014_SchoolMstBean>> map = new HashMap<>();
		String str_categorize_School = "";
		int categorize_School = 0;

		// 学校種別の固定値取得
		Date date = new Date();
		Timestamp today = new Timestamp(date.getTime());
		str_categorize_School = mst020_ConstantMstDAO.getSingleRcdConstant(
				today, "Length_Categorize_Sc");

		try {
			categorize_School = Integer.parseInt(str_categorize_School);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

		ConnectionManager.beginTransaction();
		for (int n = 0; n <= categorize_School; n++) {
			List<Mst014_SchoolMstBean> list = cls903dao
					.SearchMST014_SCHOOLMST(n);
			map.put(n + "_Categorize_School", list);
		}
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return map;
	}

}
