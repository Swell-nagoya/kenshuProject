package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.Message;
import Dao.CLS906DAO;
import Validate.CLS906Validate;
import bean.CLS905_SearchResultBean;
import bean.CLS906_InsertBean;
import bean.Mst001_UserMstBean;

public class CLS906_Servlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html; charset=Windows-31J");
		request.setCharacterEncoding("Windows-31J");

		HttpSession session = request.getSession(false);

		// セッションタイムアウトの場合、ログイン画面に戻る
		if (session == null) {
			request.getRequestDispatcher("JSP/timeout.jsp").forward(request,
					response);
			return;
		}

		// 処理完了時遷移先パス
		String path = "JSP/topmenu/menu/mastermente/CLS905_TestSearch.jsp";

		// エラー発生時遷移先パス
		String errorPage = "JSP/topmenu/menu/mastermente/CLS906_TestInsert.jsp";

		CLS906_InsertBean bean = new CLS906_InsertBean();

		// セッションからログインIDを取得し、登録情報Beanに格納
		Mst001_UserMstBean mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");
		bean.setLast_up_user(mst001_UserMstBean.getId_user());

		// 年度取得
		String fiscal_year = request.getParameter("fiscal_year");
		// 回次取得
		String times = request.getParameter("times");
		
		// テスト種別取得
		String test_type = request.getParameter("test_type");
		// 開催日取得
		String date_hold = request.getParameter("date_hold");

		// 国語平均点取得
		String average_jap = request.getParameter("average_jap");
		// 数学平均点取得
		String average_math = request.getParameter("average_math");
		// 理科平均点取得
		String average_siec = request.getParameter("average_siec");
		// 社会平均点取得
		String average_scty = request.getParameter("average_scty");
		// 英語取得
		String average_eng = request.getParameter("average_eng");

		// 登録情報Beanに格納
		bean.setFiscal_year(fiscal_year);
		bean.setTimes(times);
		bean.setTest_type(test_type);
		bean.setDate_hold(date_hold);
		bean.setAverage_jap(average_jap);
		bean.setAverage_math(average_math);
		bean.setAverage_siec(average_siec);
		bean.setAverage_scty(average_scty);
		bean.setAverage_eng(average_eng);

		// 選択行データをセッションから取得
		// 入力フォームの以降のチェック処理において、判定に通れば
		// セッションデータにnullを設定し表示優先度を「入力データ > セッションデータ」にする。
		// 他入力データにエラーが存在し、画面に再遷移した場合にこの設定が適用される。
		CLS905_SearchResultBean sessionbean =
				(CLS905_SearchResultBean) session.getAttribute("testSelectedInfo");

		// ↓以降は各パラメーターの入力チェックとフォーマットチェック
		// アラート表示用のストリングリスト生成
		List<String> alartList = new ArrayList<>(12);

		// 入力チェック用メソッド呼び出し
		alartList = CLS906Validate.validate(request, bean, sessionbean);
		session.setAttribute("testInsertBean", bean);

		// 入力チェックでエラーがあった場合、この時点で再遷移
		if (alartList.size() > 0) {
			request.getRequestDispatcher(errorPage).forward(request,
					response);
			return;
		}

		// ■登録ボタン押下時の処理
		if (request.getParameter("insert") != null) {

			// 回次重複チェックメソッド呼び出し
			if(!CLS906DAO.duplicationCheck(bean.getTimes())){
				bean.setTimes("");
				alartList.add(Message.getMessage("times_duplication.error"));
				bean.setMessage(alartList);
				session.setAttribute("testInsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

			// 登録実行メソッド呼び出し
			CLS906DAO dao = new CLS906DAO();
			int testID = (int)session.getAttribute("testID");
			bean.setTestID(Integer.toString(testID));
			int result = dao.testInsert(bean);

			// 一意制約違反
			if (result == 1062) {
				alartList.add(Message.getMessage("unique_constraint.error"));
				bean.setMessage(alartList);
				session.setAttribute("testInsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;

			// 登録成功
			} else if (result == 1) {

				// セッション情報を全て破棄
				removeSession(session);
				// 登録完了メッセージを格納
				request.setAttribute("complete", Message.getMessage("insert.comp"));

				request.getRequestDispatcher(path).forward(request,
						response);
				return;

			// その他処理エラー
			} else {
				alartList.add(Message.getMessage("insert.fail"));
				bean.setMessage(alartList);
				session.setAttribute("testInsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

		// ■削除ボタン押下時の処理
		} else if (request.getParameter("delete") != null) {

			// 削除実行メソッド呼び出し
			CLS906DAO dao = new CLS906DAO();
			bean.setTestID((String) request.getParameter("testID"));
			int result = dao.testDelete(sessionbean);

			if (result != 1) {
				alartList.add(Message.getMessage("delete.fail"));
				bean.setMessage(alartList);
				session.setAttribute("testInsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

			// セッション情報を全て破棄
			removeSession(session);
			// 登録完了メッセージを格納
			request.setAttribute("complete", Message.getMessage("delete.comp"));

			request.getRequestDispatcher(path).forward(request,
					response);
			return;

		// ■修正ボタン押下時の処理
		} else if (request.getParameter("repear") != null) {

			// 修正したときに回次を重複させることができたので
			// 回次重複チェックメソッドを呼び出すように
			if(!bean.getTimes().equals(sessionbean.getTimes())){
				if(!CLS906DAO.duplicationCheck(bean.getTimes())){
					bean.setTimes("");
					alartList.add(Message.getMessage("times_duplication.error"));
					bean.setMessage(alartList);
					session.setAttribute("testInsertBean", bean);
					request.getRequestDispatcher(errorPage).forward(request,
						response);
					return;
				}
			}

			// 更新実行メソッド呼び出し
			CLS906DAO dao = new CLS906DAO();
			bean.setTestID((String) request.getParameter("testID"));
			int result = dao.testUpdate(bean, sessionbean);

			if (result != 1) {
				alartList.add(Message.getMessage("update.fail"));
				bean.setMessage(alartList);
				session.setAttribute("testInsertBean", bean);
				request.getRequestDispatcher(errorPage).forward(request,
						response);
				return;
			}

			// セッション情報を全て破棄
			removeSession(session);
			// 登録完了メッセージを格納
			request.setAttribute("complete", Message.getMessage("update.comp"));

			request.getRequestDispatcher(path).forward(request,
					response);
			return;
		// ■閉じるボタン押下時の処理
		}// else if (request.getParameter("close") != null) {
//
//			// セッション情報を全て破棄
//			removeSession(session);
//
//			// テスト検索画面に戻る
//			request.getRequestDispatcher(path).forward(request,
//					response);
//			return;
//		}
	}

	/**
	 * CLS907～CLS908関連のセッション情報を全て破棄する
	 * @param session セッション
	 */
	public static void removeSession(HttpSession session) {

		session.removeAttribute("cls905SearchBean");
		session.removeAttribute("905SearchResultList");
		session.removeAttribute("testSelectedInfo");
		session.removeAttribute("control");
		session.removeAttribute("testInsertBean");
		session.removeAttribute("905head");
		session.removeAttribute("905page");
		session.removeAttribute("905PagingList");
		session.removeAttribute("905allPageNum");
	}

	/**
	 * CLS907～CLS908関連の任意のセッション情報を破棄する
	 * @param session セッション
	 * @param keys セッションキー
	 */
	public static void removeAnySession(HttpSession session, String... keys) {

		for (String key : keys) {
			session.removeAttribute(key);
		}
	}
}
