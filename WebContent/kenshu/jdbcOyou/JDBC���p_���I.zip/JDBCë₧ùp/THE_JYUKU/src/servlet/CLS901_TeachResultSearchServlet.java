package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.StringUtil;
import Dao.CLS901DAO;
import Dao.ConnectionManager;
import Dao.Mst017_TimeTableMstDAO;
import Dao.Mst020_ConstantMstDAO;
import Validate.Validate;
import bean.CLS901Bean;
import bean.Mst010_CourseMstBean;
import bean.Mst011_CourseMeisaiMstBean;
import bean.Trn001_ReportTrnBean;
import bean.Trn002_HomeworkTrnBean;
import bean.Trn004_SmalltestTrnBean;

import common.ServretCommon;


public class CLS901_TeachResultSearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
                    throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        if(request.getParameter("Search")!=null){
            String alart = null;
            //入力チェック(検索期間)
            if(request.getParameter("YEAR") != ""){
                if(Validate.isYear(request.getParameter("YEAR"))){
                    alart = "正しい年を入力して下さい。";
                    request.setAttribute("alart", alart);
                    request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
                    return;
                }
            }
            if(request.getParameter("MONTH") != ""){
                if(Validate.isMonth(request.getParameter("MONTH"))){
                    alart = "正しい月を入力して下さい。";
                    request.setAttribute("alart", alart);
                    request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
                    return;
                }
            }
            if(request.getParameter("DATE") != ""){
                if(Validate.isDay(request.getParameter("DATE"))){
                    alart = "正しい日を入力して下さい。";
                    request.setAttribute("alart", alart);
                    request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
                    return;
                }
            }

            CommonServlet commonServlet = new CommonServlet();
            //授業検索
            if(Integer.parseInt(request.getParameter("Search"))==1){

                //取得するパラメータ
                List<CLS901Bean> list = new ArrayList<CLS901Bean>();

                CLS901DAO cls901dao = new CLS901DAO();
                CLS901Bean cls901bean = new CLS901Bean();
                Mst010_CourseMstBean mst010_coursemst = new Mst010_CourseMstBean();
                Mst011_CourseMeisaiMstBean mst011_coursemeisaimst = new Mst011_CourseMeisaiMstBean();

                if (!request.getParameter("ID_COURSE").equals("")) {
                    mst010_coursemst.setid_course(request.getParameter("ID_COURSE"));
                    mst011_coursemeisaimst.setid_course(request.getParameter("ID_COURSE"));
                }
                if (!request.getParameter("Gakunen").equals("default")) {
                    mst011_coursemeisaimst.settarget(Integer.parseInt(request.getParameter("Gakunen")));
                }
                if (!request.getParameter("Week").equals("default")) {
                    mst011_coursemeisaimst.setday_lecture(Integer.parseInt(request.getParameter("Week")));
                }else{
                    mst011_coursemeisaimst.setday_lecture(-1);
                }
                if (!StringUtil.isEmpty(request.getParameter("StartGikanwariHH"))) {
                    if (!StringUtil.isEmpty(request.getParameter("StartGikanwariMM"))) {
                        mst011_coursemeisaimst.setstart_time_lecture(commonServlet.changeTimestampForCourse(request.getParameter("StartGikanwariHH"), request.getParameter("StartGikanwariMM")));
                    }
                }
                if (!request.getParameter("YEAR").equals("")) {
                    if(!request.getParameter("MONTH").equals("")){
                        if(!request.getParameter("DATE").equals("")){
                            String start_day = request.getParameter("YEAR") + "-" + request.getParameter("MONTH") + "-" + request.getParameter("DATE") + " " + "00:00:00";
                            mst010_coursemst.setstart_lecture(Timestamp.valueOf(start_day));
                            mst011_coursemeisaimst.setstart_lecture(Timestamp.valueOf(start_day));
                        }
                    }
                }

                cls901bean.setMst010_CourseMstBean(mst010_coursemst);
                cls901bean.setMst011_CourseMeisaiMstBean(mst011_coursemeisaimst);
                ConnectionManager.beginTransaction();
                list = cls901dao.Search(cls901bean);
                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                request.setAttribute("jyugyou", list);
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);

            //授業実績検索
            }else if(Integer.parseInt(request.getParameter("Search"))==2){
                //取得するパラメータ
                List<CLS901Bean> list = new ArrayList<CLS901Bean>();
                CLS901DAO cls901dao = new CLS901DAO();
                CLS901Bean cls901bean = new CLS901Bean();
                Mst010_CourseMstBean mst010_coursemst = new Mst010_CourseMstBean();
                Mst011_CourseMeisaiMstBean mst011_coursemeisaimst = new Mst011_CourseMeisaiMstBean();
                Trn001_ReportTrnBean trn001_reporttrn = new Trn001_ReportTrnBean();
                Trn002_HomeworkTrnBean trn002_homeworktrn = new Trn002_HomeworkTrnBean();
                Trn004_SmalltestTrnBean trn004_smalltesttrn = new Trn004_SmalltestTrnBean();

                if (!request.getParameter("ID_COURSE").equals("")) {
                    mst010_coursemst.setid_course(request.getParameter("ID_COURSE"));
                    mst011_coursemeisaimst.setid_course(request.getParameter("ID_COURSE"));
                    trn001_reporttrn.setid_course(request.getParameter("ID_COURSE"));
                    trn002_homeworktrn.setId_course(request.getParameter("ID_COURSE"));
                    trn004_smalltesttrn.setid_course(request.getParameter("ID_COURSE"));
                }
                if (!request.getParameter("Gakunen").equals("default")) {
                    mst011_coursemeisaimst.settarget(Integer.parseInt(request.getParameter("Gakunen")));
                }
                if (!request.getParameter("Week").equals("default")) {
                    mst011_coursemeisaimst.setday_lecture(Integer.parseInt(request.getParameter("Week")));
                }else{
                    mst011_coursemeisaimst.setday_lecture(-1);
                }
                if (!StringUtil.isEmpty(request.getParameter("StartGikanwariHH"))) {
                    if (!StringUtil.isEmpty(request.getParameter("StartGikanwariMM"))) {
                        mst011_coursemeisaimst.setstart_time_lecture(commonServlet.changeTimestampForCourse(request.getParameter("StartGikanwariHH"), request.getParameter("StartGikanwariMM")));
                    }
                }
                String year = null;
                String month = null;
                String date = null;
                String start_day = null;
                if (request.getParameter("YEAR").equals("")) {
                    year = "0001";
                } else {
                    year = request.getParameter("YEAR");
                }
                if(request.getParameter("MONTH").equals("")){
                    month = "01";
                }else {
                    month =request.getParameter("MONTH");
                }
                if(request.getParameter("DATE").equals("")){
                    date = "01";
                    start_day = year + "-" + month + "-" + date + " " + "00:00:00";
                    if(Validate.isDate(start_day)){
                        mst010_coursemst.setstart_lecture(Timestamp.valueOf(start_day));
                        mst011_coursemeisaimst.setstart_lecture(Timestamp.valueOf(start_day));
                    }
                }else {
                    date = request.getParameter("DATE");
                    start_day = year + "-" + month + "-" + date + " " + "00:00:00";
                    if(Validate.isDate(start_day)){
                        mst010_coursemst.setstart_lecture(Timestamp.valueOf(start_day));
                        mst011_coursemeisaimst.setstart_lecture(Timestamp.valueOf(start_day));
                    }
                }
                cls901bean.setMst010_CourseMstBean(mst010_coursemst);
                cls901bean.setMst011_CourseMeisaiMstBean(mst011_coursemeisaimst);
                ConnectionManager.beginTransaction();
                list = cls901dao.SearchJisseki(cls901bean);

                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                request.setAttribute("jisseki", list);
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
                return;
            }
        }else{

            //Sessionの取得
            HttpSession session = request.getSession();

            // loginSessionのチェック
            ServretCommon.checkLoginSession(request, response, session);

            //データを取得
            CLS901Bean bean = new CLS901Bean();
            Mst020_ConstantMstDAO mst020_constantmstdao = new Mst020_ConstantMstDAO();
            Mst017_TimeTableMstDAO mst017_timetablemstdao = new Mst017_TimeTableMstDAO();

            ConnectionManager.beginTransaction();
            bean.setGakunen(mst020_constantmstdao.createSQLForGAKUNEN());
            bean.setDayOfWeek(mst020_constantmstdao.createSQLForDAY_OF_WEEK());
            bean.setGikanwari(mst017_timetablemstdao.createSQLForGIKANWARI());
            try {
                ConnectionManager.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            session.setAttribute("data", bean);
            request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
        }
    }
}
