package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.ServretCommon;

import Dao.CLS009DAO;
import Dao.CLS903DAO;
import Dao.ConnectionManager;
import Dao.Mst001_UserMstDAO;
import Dao.Mst003_GuardianMstDAO;
import bean.CLS009Bean;
import bean.Mst001_UserMstBean;
import bean.Mst003_GuardianMstBean;
import bean.Mst016_GetCourseMstBean;

/**
 * 生徒の直近の授業とその内容を取得する
 * CLS009用のサーブレット
 * @author n-kuraoka
 */
public class CLS009_SelectReportForGuardiansServlet extends HttpServlet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		Mst001_UserMstBean mst001_UserMstBean = null;
		Mst001_UserMstDAO userMstDAO = new Mst001_UserMstDAO();
		Mst003_GuardianMstDAO guardianMstDAO = new Mst003_GuardianMstDAO();
		Mst003_GuardianMstBean bean = new Mst003_GuardianMstBean();
		CLS009DAO cls009dao = new CLS009DAO();
		String id_user = null;
		HttpSession session = req.getSession();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(req, resp, session);
		
		if (session.getAttribute("loginSession") != null) {
			mst001_UserMstBean = (Mst001_UserMstBean) session.getAttribute("loginSession");
			id_user = mst001_UserMstBean.getId_user();
		}

		//cls009のインスタンス
		List<CLS009Bean> beans = new ArrayList<>();
		ConnectionManager.beginTransaction();
		bean = guardianMstDAO.findById_user(id_user);
		List<String> id_Students = cls009dao.getId_UserofChildren(bean.getId_family());
		for (String id_Student : id_Students) {
			List<Mst016_GetCourseMstBean> mst016_GetCourseMstBeans = CLS903DAO.getInstance().SearchMst016ById_user(id_Student);
			//対象授業の情報を取得する
			for (Mst016_GetCourseMstBean mst016_GetCourseMstBean : mst016_GetCourseMstBeans) {
				CLS009Bean cls009Bean = cls009dao.PersonalSubjectTimeTableFindByUser(id_Student, mst016_GetCourseMstBean);
				if (cls009Bean != null) {
					cls009Bean.setName_user(userMstDAO.findById(id_Student).getName());
					beans.add(cls009Bean);
				}
			}
		}
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//対象コースIDから直近の授業を取得する
//		reportTrnBeans = cls009dao.listTrn001_ReportTrn(beans);
//
//		for (CLS009Bean cls009bean : cls009bean) {
//			for (List<cls>)
//
//		}


		session.setAttribute("beans", beans);
		//JSP
		req.getRequestDispatcher("JSP/topmenu/menu/CLS009_searchReportForGuardians.jsp").forward(req, resp);

	}
}
