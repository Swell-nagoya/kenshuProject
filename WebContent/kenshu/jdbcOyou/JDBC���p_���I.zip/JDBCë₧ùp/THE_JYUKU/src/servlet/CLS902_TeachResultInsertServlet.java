package servlet;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.StringUtil;
import Dao.CLS902DAO;
import Dao.CLS911DAO;
import Dao.ConnectionManager;
import Dao.Trn001_ReportTrnDAO;
import Dao.Trn002_HomeworkTrnDAO;
import Dao.Trn004_SmalltestTrnDAO;
import Dao.Trn010_AttendanceTrnDAO;
import Validate.Validate;
import bean.CLS902Bean;
import bean.Mst001_UserMstBean;
import bean.Trn001_ReportTrnBean;
import bean.Trn002_HomeworkTrnBean;
import bean.Trn004_SmalltestTrnBean;
import bean.Trn010_AttendanceTrnBean;

import common.ServretCommon;

/**
 * Servlet implementation class CLS902_TeachResultInsertServlet
 */
public class CLS902_TeachResultInsertServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    CLS902DAO cls902dao = new CLS902DAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Mst001_UserMstBean> list = new ArrayList<Mst001_UserMstBean>();
        CLS902Bean cls902 = new CLS902Bean();
        CommonServlet commonServlet = new CommonServlet();

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        //Sessionの取得
        HttpSession session = request.getSession();

        // loginSessionのチェック
        ServretCommon.checkLoginSession(request, response, session);

        session.removeAttribute("alart");
        //アラート表示用のストリング
        String alart;

        Mst001_UserMstBean mst001_login = (Mst001_UserMstBean)session.getAttribute("loginSession");
        String id_user_login = mst001_login.getId_user();

        //比較対象の最終日更新日
        Timestamp date_compareupdate = null;
        //更新直前の最終更新日
        Timestamp date_beforeupdate = null;

        if(request.getParameter("exit")!=null){
            //検索画面に戻る
            session.removeAttribute("trn001");
            session.removeAttribute("trn002");
            session.removeAttribute("trn004");
            session.removeAttribute("trn010");
            request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
            return;
        }

        //cls902jspの初期表示パラメータの送信
        if(request.getParameter("sousin")!=null){
            List<Trn004_SmalltestTrnBean> listtest = new ArrayList<Trn004_SmalltestTrnBean>();
            List<Trn010_AttendanceTrnBean> listattend = new ArrayList<Trn010_AttendanceTrnBean>();
            Trn001_ReportTrnBean trn001_reporttrn = new Trn001_ReportTrnBean();
            Trn001_ReportTrnDAO trn001_reportdao = new Trn001_ReportTrnDAO();
            Trn002_HomeworkTrnBean trn002_homeworktrn = new Trn002_HomeworkTrnBean();
            Trn002_HomeworkTrnDAO trn002_homeworkdao = new Trn002_HomeworkTrnDAO();
            Trn004_SmalltestTrnBean trn004_smalltesttrn = new Trn004_SmalltestTrnBean();
            Trn004_SmalltestTrnDAO trn004_smalltestdao = new Trn004_SmalltestTrnDAO();
            Trn010_AttendanceTrnBean trn010_attendancetrn = new Trn010_AttendanceTrnBean();
            Trn010_AttendanceTrnDAO trn010_attendacedao = new Trn010_AttendanceTrnDAO();
            String id_course;
            //新規登録ボタンが押されたとき
            if(request.getParameter("sousin").equals("新規登録")){
                cls902.setsousin(request.getParameter("sousin"));
                id_course = request.getParameter("insert_id_course");
                cls902.setid_course(id_course);
                cls902.setday_lecture(request.getParameter("insert_day_of_week"));
                cls902.setStart_timetable_lecture(Timestamp.valueOf(request.getParameter("insert_start_time_lecture")));
                cls902.setEnd_timetable_lecture(Timestamp.valueOf(request.getParameter("insert_end_time_lecture")));
                cls902.settarget(request.getParameter("insert_target"));
                cls902.setname_course(request.getParameter("insert_name_course"));

                //mst016からUSER_IDとユーザー名取得
                ConnectionManager.beginTransaction();
                list = cls902dao.getNAME(id_course);
                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                cls902.setlist(list);
                session.setAttribute("cls902", cls902);
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
            //修正ボタンが押されたとき
            }else if(request.getParameter("sousin").equals("修正")){
                cls902.setsousin(request.getParameter("sousin"));
                id_course = request.getParameter("update_id_course");
                cls902.setid_course(id_course);
                cls902.setdate_lecture(request.getParameter("update_date_lecture"));
                cls902.setday_lecture(request.getParameter("update_day_of_week"));
                cls902.setStart_timetable_lecture(Timestamp.valueOf(request.getParameter("update_start_time_lecture")));
                cls902.setEnd_timetable_lecture(Timestamp.valueOf(request.getParameter("update_end_time_lecture")));
                cls902.settarget(request.getParameter("update_target"));
                //trn004からUSER_IDとユーザー名取得
                ConnectionManager.beginTransaction();
                list = cls902dao.getNAME(id_course);

                //コース名の取得
                cls902.setname_course(new CLS911DAO().GetNameCourse(id_course));

                //修正前のレポート内容をBeanに格納
                trn001_reporttrn = trn001_reportdao.findByPrimaryKey(id_course, Timestamp.valueOf(cls902.getdate_lecture()));
                trn001_reporttrn = (trn001_reporttrn == null) ? new Trn001_ReportTrnBean() : trn001_reporttrn;

                if(request.getParameter("date_lastupdate") != null){
                    trn001_reporttrn.setdate_lastupdate(Timestamp.valueOf(request.getParameter("date_lastupdate")));
                }
                //修正前の宿題をBeanに格納
                trn002_homeworktrn = trn002_homeworkdao.findByPrimaryKey(id_course, Timestamp.valueOf(cls902.getdate_lecture()));
                trn002_homeworktrn = (trn002_homeworktrn == null) ? new Trn002_HomeworkTrnBean() : trn002_homeworktrn;

                trn002_homeworktrn.setDate_lecture(Timestamp.valueOf(cls902.getdate_lecture()));
                Trn004_SmalltestTrnBean cls902test = new Trn004_SmalltestTrnBean();
                Trn010_AttendanceTrnBean cls902attend = new Trn010_AttendanceTrnBean();
                for (int i = 0;i < list.size();i++){
                    //修正前の小テスト内容をBeanに格納
                    trn004_smalltesttrn = trn004_smalltestdao.findByPrimaryKey(id_course,Timestamp.valueOf(cls902.getdate_lecture()),list.get(i).getId_user());
                    listtest.add((trn004_smalltesttrn == null) ? new Trn004_SmalltestTrnBean() : trn004_smalltesttrn);
                    cls902test.setlisttest(listtest);
                    //修正前の出欠をBeanに格納
                    trn010_attendancetrn = trn010_attendacedao.findByPrimaryKey(list.get(i).getId_user(), Timestamp.valueOf(cls902.getdate_lecture()), cls902.getStart_timetable_lecture());
                    listattend.add((trn010_attendancetrn == null) ? new Trn010_AttendanceTrnBean() : trn010_attendancetrn);
                    cls902attend.setlistattend(listattend);
                }

                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                cls902.setlist(list);
                session.setAttribute("cls902", cls902);
                session.setAttribute("trn001", trn001_reporttrn);
                session.setAttribute("trn002", trn002_homeworktrn);
                session.setAttribute("trn004", cls902test);
                session.setAttribute("trn010", cls902attend);
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
            //削除ボタンが押されたとき
            }else if(request.getParameter("sousin").equals("削除")){
                cls902.setdate_lecture(request.getParameter("delete_date_lecture"));
                cls902.setsousin(request.getParameter("sousin"));
                id_course = request.getParameter("delete_id_course");
                cls902.setid_course(id_course);
                cls902.setday_lecture(request.getParameter("delete_day_of_week"));
                cls902.setStart_timetable_lecture(Timestamp.valueOf(request.getParameter("delete_start_time_lecture")));
                cls902.setEnd_timetable_lecture(Timestamp.valueOf(request.getParameter("delete_end_time_lecture")));
                cls902.settarget(request.getParameter("delete_target"));

                //trn004からUSER_IDとユーザー名取得
                ConnectionManager.beginTransaction();
                list = cls902dao.getNAME(id_course);

                //コース名の取得
                cls902.setname_course(new CLS911DAO().GetNameCourse(id_course));

                //修正前のレポート内容をBeanに格納
                trn001_reporttrn = trn001_reportdao.findByPrimaryKey(id_course, Timestamp.valueOf(cls902.getdate_lecture()));
                //修正前の宿題をBeanに格納
                trn002_homeworktrn = trn002_homeworkdao.findByPrimaryKey(id_course, Timestamp.valueOf(cls902.getdate_lecture()));
                Trn004_SmalltestTrnBean cls902test = new Trn004_SmalltestTrnBean();
                Trn010_AttendanceTrnBean cls902attend = new Trn010_AttendanceTrnBean();
                for (int i = 0;i < list.size();i++){
                    //修正前の小テスト内容をBeanに格納
                    trn004_smalltesttrn = trn004_smalltestdao.findByPrimaryKey(id_course,Timestamp.valueOf(cls902.getdate_lecture()),list.get(i).getId_user());
                    listtest.add((trn004_smalltesttrn == null) ? new Trn004_SmalltestTrnBean() : trn004_smalltesttrn);
                    cls902test.setlisttest(listtest);
                    //修正前の出欠をBeanに格納
                    trn010_attendancetrn = trn010_attendacedao.findByPrimaryKey(list.get(i).getId_user(), Timestamp.valueOf(cls902.getdate_lecture()), cls902.getStart_timetable_lecture());
                    listattend.add((trn010_attendancetrn == null) ? new Trn010_AttendanceTrnBean() : trn010_attendancetrn);
                    cls902attend.setlistattend(listattend);
                }

                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                cls902.setlist(list);
                session.setAttribute("cls902", cls902);
                session.setAttribute("trn001", trn001_reporttrn);
                session.setAttribute("trn002", trn002_homeworktrn);
                session.setAttribute("trn004", cls902test);
                session.setAttribute("trn010", cls902attend);
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
            }
        }
        //新規、更新、削除機能
        if(request.getParameter("start")!=null){

            //Beanの取得
            Trn001_ReportTrnBean trn001_reporttrn = new Trn001_ReportTrnBean();
            Trn002_HomeworkTrnBean trn002_homeworktrn = new Trn002_HomeworkTrnBean();
            Trn004_SmalltestTrnBean trn004_smalltesttrn = new Trn004_SmalltestTrnBean();
            Trn010_AttendanceTrnBean trn010_attendancetrn = new Trn010_AttendanceTrnBean();
            //Daoの取得
            Trn001_ReportTrnDAO trn001_reporttrndao = new Trn001_ReportTrnDAO();
            Trn002_HomeworkTrnDAO trn002_homeworktrndao = new Trn002_HomeworkTrnDAO();
            Trn004_SmalltestTrnDAO trn004_smalltestdao = new Trn004_SmalltestTrnDAO();
            Trn010_AttendanceTrnDAO trn010_attendancedao = new Trn010_AttendanceTrnDAO();
            //登録処理
            if(request.getParameter("start").equals("新規登録")){

                /*
                 * 未入力チェックが終わったら、Timestamp型に変換可能なString値に変換
                 *///誕生日はTimestamp形式に変換
                String start_day = request.getParameter("START_YEAR") + "-" + request.getParameter("START_MONTH") + "-" + request.getParameter("START_DATE") + " " + "00:00:00";
                Timestamp update_time = new Timestamp(System.currentTimeMillis());
                if (Validate.isDate(start_day) == false) {
                    System.out.println("開催日は正しく入力して下さい");
                    alart ="開催日は正しく入力してください。";
                    //sessionに持たせる
                    session.setAttribute("alart", alart);
                    //次の画面に行く
                    request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
                    return;
                }
                //PK被りチェック
                ConnectionManager.beginTransaction();
                boolean bool = trn001_reporttrndao.Date_Lecture_Cheak(request.getParameter("course"),Timestamp.valueOf(start_day));
                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                if (bool == false) {
                    System.out.println("同じコースID内で、開催日が被っています");
                    alart ="開催日が一致しています。変更してください。";
                    //sessionに持たせる
                    request.setAttribute("alart", alart);
                    //次の画面に行く
                    request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
                    return;
                }
                //beanに入力データをセット
                trn001_reporttrn.setid_course(request.getParameter("course"));
                trn001_reporttrn.setdate_lecture(Timestamp.valueOf(start_day));
                trn001_reporttrn.setreport(request.getParameter("report"));
                trn001_reporttrn.setflg_delete(0);
                trn001_reporttrn.setid_lastupdate(id_user_login);
                trn001_reporttrn.setdate_lastupdate(update_time);

                trn002_homeworktrn.setId_course(request.getParameter("course"));
                trn002_homeworktrn.setDate_lecture(Timestamp.valueOf(start_day));
                trn002_homeworktrn.setHomework(request.getParameter("homework"));
                trn002_homeworktrn.setFlg_delete(0);
                trn002_homeworktrn.setId_lastupdate(id_user_login);
                trn002_homeworktrn.setDate_lastupdate(update_time);

                trn004_smalltesttrn.setid_course(request.getParameter("course"));
                trn004_smalltesttrn.setdate_lecture(Timestamp.valueOf(start_day));
                trn004_smalltesttrn.setcount_chalenge(1);
                trn004_smalltesttrn.setflg_delete(0);
                trn004_smalltesttrn.setid_lastupdate(id_user_login);
                trn004_smalltesttrn.setdate_lastupdate(update_time);

                trn010_attendancetrn.setdate_lecture(Timestamp.valueOf(start_day));

                if (!StringUtil.isEmpty(request.getParameter("StartGikanwariHH"))) {
                    if (!StringUtil.isEmpty(request.getParameter("StartGikanwariMM"))) {
                        trn010_attendancetrn.setstart_time_lecture(commonServlet.changeTimestampForCourse(request.getParameter("StartGikanwariHH"), request.getParameter("StartGikanwariMM")));
                    }
                }
                //trn010_attendancetrn.setstart_time_lecture(Timestamp.valueOf(request.getParameter("jikanwari")));
                trn010_attendancetrn.setid_course(request.getParameter("course"));
                trn010_attendancetrn.setflg_substitute(0);
                trn010_attendancetrn.setflg_delete(0);
                trn010_attendancetrn.setid_lastupdate(id_user_login);
                trn010_attendancetrn.setdate_lastupdate(update_time);
                //登録実行
                ConnectionManager.beginTransaction();
                trn001_reporttrndao.create(trn001_reporttrn);
                trn002_homeworktrndao.create(trn002_homeworktrn);
                for(int count=0;count<Integer.parseInt(request.getParameter("count"));count++){
                    trn004_smalltesttrn.setid_user(request.getParameter("id_user"+count));
                    if(request.getParameter("goukaku"+count)!=null){
                        trn004_smalltesttrn.setflg_passtest(Integer.parseInt(request.getParameter("goukaku"+count)));
                    }else{
                        trn004_smalltesttrn.setflg_passtest(0);
                    }
                    trn004_smalltestdao.create(trn004_smalltesttrn);
                }
                for(int count=0;count<Integer.parseInt(request.getParameter("count"));count++){
                    trn010_attendancetrn.setid_user(request.getParameter("id_user"+count));
                    if(request.getParameter("kesseki"+count)!=null){
                        trn010_attendancetrn.setflg_absence(Integer.parseInt(request.getParameter("kesseki"+count)));
                    }else{
                        trn010_attendancetrn.setflg_absence(0);
                    }
                    if(request.getParameter("tikoku"+count)!=null){
                        trn010_attendancetrn.setflg_late(Integer.parseInt(request.getParameter("tikoku"+count)));
                    }else{
                        trn010_attendancetrn.setflg_late(0);
                    }
                    if(request.getParameter("soutai"+count)!=null){
                        trn010_attendancetrn.setflg_early(Integer.parseInt(request.getParameter("soutai"+count)));
                    }else{
                        trn010_attendancetrn.setflg_early(0);
                    }
                    trn010_attendancedao.create(trn010_attendancetrn);
                }
                ConnectionManager.commit();
                try {
                    ConnectionManager.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                System.out.println("登録成功");
                request.setAttribute("alart", "登録完了しました。");
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);

            /*更新機能*/
            }else if(request.getParameter("start").equals("修正")){
                CLS902Bean cls902Bean = (CLS902Bean)session.getAttribute("cls902");
                /*
                 * 未入力チェックが終わったら、Timestamp型に変換可能なString値に変換
                 *///誕生日はTimestamp形式に変換
                String start_day = cls902Bean.getdate_lecture();

                Trn001_ReportTrnBean trn001_reporttrnbean = new Trn001_ReportTrnBean();
                Trn004_SmalltestTrnBean trn004_smalltrnbean = new Trn004_SmalltestTrnBean();
                list = cls902dao.getNAME(request.getParameter("course"));

                //DBとの整合性チェック
                if (validateStudentNum(request, response, request.getParameter("course"), list, Integer.parseInt(request.getParameter("count")))) return;

                    for(int count = 0; count<Integer.parseInt(request.getParameter("count")); count++){
                        //この画面特有の入力チェック
                        //出欠どちらも選択している場合
                        if(request.getParameter("syusseki"+count)!=null && request.getParameter("kesseki"+count)!=null){
                            System.out.println("(出席)と(欠席)は同時にチェック出来ません。");
                            alart ="(出席)と(欠席)は同時にチェック出来ません。";
                            //requestに持たせる
                            request.setAttribute("alart", alart);
                            //次の画面に行く
                            request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
                            return;
                        //出欠どちらかが選択されていない場合
                        } else if (request.getParameter("syusseki"+count)=="" && request.getParameter("kesseki"+count)==""){
                            System.out.println("出席と欠席はどちらかを選択して下さい。");
                            alart ="出席と欠席はどちらかを選択して下さい。";
                            //requestに持たせる
                            request.setAttribute("alart", alart);
                            //次の画面に行く
                            request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
                        //欠席が選択されていて、遅刻早退も選択しちゃってる場合
                        }else if (request.getParameter("kesseki"+count)!=null && (request.getParameter("tikoku"+count)!=null || request.getParameter("soutai"+count)!=null)){
                        System.out.println("欠席の場合は欠席のみを選択して下さい。");
                        alart ="欠席の場合は欠席のみを選択して下さい。";
                        //requestに持たせる
                        request.setAttribute("alart", alart);
                        //次の画面に行く
                        request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
                        return;
                    }
                }
                //Select文の結果を格納するBean
                //beanに入力データをセット
                trn001_reporttrn = (Trn001_ReportTrnBean)session.getAttribute("trn001");
                trn002_homeworktrn = (Trn002_HomeworkTrnBean)session.getAttribute("trn002");
                trn004_smalltesttrn = (Trn004_SmalltestTrnBean)session.getAttribute("trn004");
                trn010_attendancetrn = (Trn010_AttendanceTrnBean)session.getAttribute("trn010");

                //一部セットし直し
                trn001_reporttrn.setdate_lecture(Timestamp.valueOf(start_day));
                trn001_reporttrn.setreport(request.getParameter("report"));
                trn001_reporttrn.setid_lastupdate(id_user_login);

                trn002_homeworktrn.setDate_lecture(Timestamp.valueOf(start_day));
                trn002_homeworktrn.setHomework(request.getParameter("homework"));
                trn002_homeworktrn.setId_lastupdate(id_user_login);

                trn004_smalltesttrn.setid_course(trn001_reporttrn.getid_course());
                trn004_smalltesttrn.setdate_lecture(Timestamp.valueOf(start_day));
                trn004_smalltesttrn.setid_lastupdate(id_user_login);

                trn010_attendancetrn.setid_course(request.getParameter("course"));
                trn010_attendancetrn.setdate_lecture(Timestamp.valueOf(start_day));
                trn010_attendancetrn.setid_lastupdate(id_user_login);
                trn010_attendancetrn.setstart_time_lecture(cls902Bean.getStart_timetable_lecture());

//				//PKチェック
//				ConnectionManager.beginTransaction();
//				boolean bool = trn001_reporttrndao.Date_Lecture_Cheak(request.getParameter("course"),Timestamp.valueOf(start_day));
//				try {
//					ConnectionManager.close();
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//				if (bool == false) {
//					System.out.println("同じコースID内で、開催日が被っています");
//					alart ="開催日が一致しています。変更してください。";
//					//sessionに持たせる
//					session.setAttribute("alart", alart);
//					//次の画面に行く
//					request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
//					return;
//				}
                //Servlet上での最終更新日
            //画面表示時とServlet開始時の最終更新日
                date_compareupdate = Timestamp.valueOf(request.getParameter("date_lastupdate"));
                date_beforeupdate = date_compareupdate;

                Timestamp update_time = new Timestamp(System.currentTimeMillis());
                trn001_reporttrn.setdate_lastupdate(update_time);
                trn002_homeworktrn.setDate_lastupdate(update_time);
                trn004_smalltesttrn.setdate_lastupdate(update_time);
                trn010_attendancetrn.setdate_lastupdate(update_time);

                //排他的処理　JSPとServlet上の最終更新日を比較　イコールでなかったら更新作業停止
                if(date_compareupdate.compareTo(date_beforeupdate) == 0){
                    //更新実行
                    ConnectionManager.beginTransaction();
                    if (trn001_reporttrndao.findByPrimaryKey(trn001_reporttrn.getid_course(), trn001_reporttrn.getdate_lecture())  != null) {
                        trn001_reporttrndao.update_PK(trn001_reporttrn, trn010_attendancetrn.getdate_lecture());
                    } else {
                        trn001_reporttrndao.create(trn001_reporttrnbean);
                    }
                    if (trn002_homeworktrndao.findByPrimaryKey(trn002_homeworktrn.getId_course(), trn002_homeworktrn.getDate_lecture()) != null) {
                        trn002_homeworktrndao.update_PK(trn002_homeworktrn,trn010_attendancetrn.getdate_lecture());
                    } else {
                        trn002_homeworktrndao.create(trn002_homeworktrn);
                    }

                    for(int count = 0; count<Integer.parseInt(request.getParameter("count")); count++){
                        trn004_smalltesttrn.setid_user(request.getParameter("id_user" + count));
                        //インサート済みチェック
                        if(request.getParameter("zyuken" + count) != null){
                            trn004_smalltesttrn.setcount_chalenge(Integer.parseInt(request.getParameter("zyuken" + count)));
                        } else {
                            //通常この分岐にはとおり得ない
                            try {
                                throw new Exception("内部エラーが発生しました。");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if(request.getParameter("goukaku" + count) != null){
                            trn004_smalltesttrn.setflg_passtest(Integer.parseInt(request.getParameter("goukaku" + count)));
                        } else {
                            trn004_smalltesttrn.setflg_passtest(0);
                        }
                        if (trn004_smalltestdao.update_PK(trn004_smalltesttrn,trn004_smalltesttrn.getdate_lecture()) == 0) {
                            trn004_smalltestdao.create(trn004_smalltesttrn);
                        }
                    }
                    for(int count = 0; count < Integer.parseInt(request.getParameter("count")); count++){
                        trn010_attendancetrn.setid_user(request.getParameter("id_user"+count));
                        //欠席フラグ
                        if(request.getParameter("kesseki" + count) != null){
                            trn010_attendancetrn.setflg_absence(Integer.parseInt(request.getParameter("kesseki" + count)));
                        } else {
                            trn010_attendancetrn.setflg_absence(0);
                        }
                        //遅刻フラグ
                        if(request.getParameter("tikoku" + count) != null){
                            trn010_attendancetrn.setflg_late(Integer.parseInt(request.getParameter("tikoku" + count)));
                        } else {
                            trn010_attendancetrn.setflg_late(0);
                        }
                        //早退フラグ
                        if(request.getParameter("soutai" + count) != null){
                            trn010_attendancetrn.setflg_early(Integer.parseInt(request.getParameter("soutai" + count)));
                        } else {
                            trn010_attendancetrn.setflg_early(0);
                        }
                        if (trn010_attendancedao.update_PK(trn010_attendancetrn,trn010_attendancetrn.getdate_lecture()) == 0) {
                            trn010_attendancedao.create(trn010_attendancetrn);
                        }
                    }
                    ConnectionManager.commit();
                    System.out.println("修正成功");
                    request.setAttribute("alart", "修正成功しました。");
                }else{
                    System.out.println("修正失敗");
                    request.setAttribute("alart", "修正失敗しました。");
                }
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);

            //削除機能
            }else if(request.getParameter("start").equals("削除")){
                //beanに入力データをセット
                trn001_reporttrn = (Trn001_ReportTrnBean)session.getAttribute("trn001");
                trn002_homeworktrn = (Trn002_HomeworkTrnBean)session.getAttribute("trn002");

//				ConnectionManager.beginTransaction();
//				trn001_reporttrn = trn001_reporttrndao.findByPrimaryKey(request.getParameter("course"),Timestamp.valueOf(request.getParameter("date_lecture")));
//				trn002_homeworktrn = trn002_homeworktrndao.findByPrimaryKey(request.getParameter("course"),Timestamp.valueOf(request.getParameter("date_lecture")));
//				try {
//					ConnectionManager.close();
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
                trn001_reporttrn.setflg_delete(1);
                trn001_reporttrn.setid_lastupdate(id_user_login);
                //削除フラグをセット
                trn002_homeworktrn.setFlg_delete(1);
                trn002_homeworktrn.setId_lastupdate(id_user_login);

                //削除実行
                //画面表示時とServlet開始時の最終更新日
                date_compareupdate = Timestamp.valueOf(request.getParameter("date_lastupdate"));
                date_beforeupdate = trn001_reporttrn.getdate_lastupdate();

                Timestamp update_time = new Timestamp(System.currentTimeMillis());
                trn001_reporttrn.setdate_lastupdate(update_time);
                trn002_homeworktrn.setDate_lastupdate(update_time);

                //排他的処理　JSPとServlet上の最終更新日を比較　イコールでなかったら更新作業停止
                if(date_compareupdate.compareTo(date_beforeupdate) == 0){
                    try {
                        //削除実行
                        ConnectionManager.beginTransaction();
                        trn001_reporttrndao.update_PK(trn001_reporttrn,trn001_reporttrn.getdate_lecture());
                        trn002_homeworktrndao.update_PK(trn002_homeworktrn,trn001_reporttrn.getdate_lecture());

                        for(int count=0; count<Integer.parseInt(request.getParameter("count")); count++){
                            trn004_smalltesttrn = trn004_smalltestdao.findByPrimaryKey(request.getParameter("course"),trn001_reporttrn.getdate_lecture(),request.getParameter("id_user" + count));
                            if (trn004_smalltesttrn != null) {
                                trn004_smalltesttrn.setflg_delete(1);
                                trn004_smalltesttrn.setid_lastupdate(id_user_login);
                                trn004_smalltestdao.update_PK(trn004_smalltesttrn,trn001_reporttrn.getdate_lecture());
                            } else {
                                throw new Exception("小テストトラン更新失敗");
                            }
                        }
                        for(int count=0;count<Integer.parseInt(request.getParameter("count"));count++){
                            trn010_attendancetrn = trn010_attendancedao.findByPrimaryKey(
                                    request.getParameter("id_user"+count),
                                    trn001_reporttrn.getdate_lecture(),
                                    commonServlet.changeTimestampForCourse(request.getParameter("StartGikanwariHH"),
                                            request.getParameter("StartGikanwariMM")));
                            if (trn010_attendancetrn != null) {
                                trn010_attendancetrn.setid_course(request.getParameter("course"));
                                trn010_attendancetrn.setflg_delete(1);
                                trn010_attendancetrn.setid_lastupdate(id_user_login);
                                trn010_attendancedao.update_PK(trn010_attendancetrn,trn001_reporttrn.getdate_lecture());
                            } else {
                                throw new Exception("出欠席トラン更新失敗");
                            }
                        }
                        ConnectionManager.commit();
                        System.out.println("削除成功");
                        session.setAttribute("alart", "削除が完了しました。");
                    } catch(Exception e) {
                        e.printStackTrace();
                        ConnectionManager.rollback();
                        System.out.println("削除失敗");
                        session.setAttribute("alart", "削除が失敗しました。");
                    } finally {
                        try {
                            ConnectionManager.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }else{
                    System.out.println("削除失敗");
                    session.setAttribute("alart", "削除が失敗しました。");
                }
                request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS901_TeachResultSearch.jsp").forward(request, response);
            }
        }
    }
    /**
     * 画面で表示されている対象の授業受講中の人数が、DBに格納されている人数と同じ
     * かどうかを確認する。
     * 誤っている場合には検索画面に遷移する。
     * @param count
     * @throws IOException
     * @throws ServletException
     */
    public boolean validateStudentNum(HttpServletRequest request,
                                    HttpServletResponse response,
                                    String id_course,
                                    List<Mst001_UserMstBean> list,
                                    int count) throws ServletException, IOException {
        list = cls902dao.getNAME(id_course);
        if (count == list.size()) {
            String alart ="(出席)と(欠席・遅刻・早退)は同時にチェック出来ません。";
            System.out.println(alart);
            //requestに持たせる
            request.setAttribute("alart", alart);
            //次の画面に行く
            request.getRequestDispatcher("/JSP/topmenu/menu/mastermente/CLS902_TeachResultInsert.jsp").forward(request, response);
            return true;
        }
        return false;
    }
}

