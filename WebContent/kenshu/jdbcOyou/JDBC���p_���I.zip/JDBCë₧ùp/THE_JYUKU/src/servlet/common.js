function setWait() {
	document.body.style.cursor = 'wait';
}
