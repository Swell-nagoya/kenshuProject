package servlet;


import org.apache.commons.lang3.RandomStringUtils;

import common.ServretCommon;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.Mst004_AdministratorMstDAO;
import Dao.ConnectionManager;
import Dao.Mst002_StudentMstDAO;
import Dao.Mst003_GuardianMstDAO;
import Dao.Mst001_UserMstDAO;
import Validate.Validate;
import bean.Mst001_UserMstBean;
import bean.Mst002_StudentMstBean;
import bean.Mst003_GuardianMstBean;
import bean.Mst004_AdministratorMstBean;


/**
 * ユーザの登録用のサーブレットクラス
 *@author n-kuraoka
 */

public class CreateUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private String out_crammer = null;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		HttpSession session = request.getSession();
		session.removeAttribute("alart");
		//フォームの取得
		Mst001_UserMstBean mst001_UserMst = new Mst001_UserMstBean();
		
		// loginSessionのチェック
		ServretCommon.checkLoginSession(request, response, session);

		//アラート表示用のストリング
		String alart;

		Mst001_UserMstDAO mst001_userdao = new Mst001_UserMstDAO();

		ConnectionManager.beginTransaction();

		//比較対象の最終日更新日
		Timestamp date_compareupdate = null ;
		//更新直前の最終更新日
		Timestamp date_beforeupdate;
		//ユーザーテーブルの各更新日を取得する
		if (request.getParameter("id_user_delete") != null) {
			ConnectionManager.beginTransaction();
			date_compareupdate = mst001_userdao.findById((String)request.getParameter("id_user_delete")).getDate_lastupdate();
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}

		} else if (request.getParameter("id_user_update") != null) {
			ConnectionManager.beginTransaction();
			date_compareupdate = mst001_userdao.findById((String)request.getParameter("id_user_update")).getDate_lastupdate();
			try {
				ConnectionManager.close();
			} catch (SQLException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
		}

		//ユーザIDはインサート時に自動発番
		String userID = null;

		try {
			ConnectionManager.close();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		//各パラメータの入力チェック
		//削除の場合のみここですべての処理を行う
		if (request.getParameter("id_user_delete") != null && request.getParameter("permission") == null) {

			if (request.getParameter("YEAR_OUT_CRAMMER") == null || request.getParameter("MONTH_OUT_CRAMMER") == null || request.getParameter("DATE_OUT_CRAMMER") == null) {
				System.out.println("退塾日を記入してください");
				alart = "退塾日を記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);

			} else {
				out_crammer = request.getParameter("YEAR_OUT_CRAMMER") + "-" + request.getParameter("MONTH_OUT_CRAMMER") + "-" + request.getParameter("DATE_OUT_CRAMMER") + " " + "00:00:00";
				System.out.println(out_crammer);
			}


			String id_user = request.getParameter("id_user_delete");

			if (out_crammer != null) {
				if ((Integer)session.getAttribute("permission") == 1) {
					Mst002_StudentMstDAO mst002_StudentMstDAO = new Mst002_StudentMstDAO();
					Mst002_StudentMstBean mst002_StudentMstBean = new Mst002_StudentMstBean();
					ConnectionManager.beginTransaction();
					mst002_StudentMstBean = mst002_StudentMstDAO.findById_user(id_user);
					Timestamp timestamp = new Timestamp(System.currentTimeMillis());
					mst002_StudentMstBean.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));
					try {
						ConnectionManager.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					mst002_StudentMstBean.setOut_crammer(Timestamp.valueOf(out_crammer));
					/*
					 * 再度更新日時を取得して各Timestampを比較する
					 */

					ConnectionManager.beginTransaction();
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_delete")).getDate_lastupdate();
					if(date_compareupdate.compareTo(date_beforeupdate) == 0) {
						mst002_StudentMstDAO.update(mst002_StudentMstBean);
						ConnectionManager.commit();
					} else {
							try {
								ConnectionManager.close();
							} catch (SQLException e) {
								e.printStackTrace();
							}
						System.out.println("DBが更新されていません");
						alart ="DBが更新されていません";
						//sessionに持たせる
						session.setAttribute("alart", alart);
						//次の画面に行く
						request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
						return;
					}
				}
				if ((Integer)session.getAttribute("permission") == 3) {
					Mst004_AdministratorMstDAO administratorMstDAO = new Mst004_AdministratorMstDAO();
					Mst004_AdministratorMstBean administratorMstBean = new Mst004_AdministratorMstBean();
					ConnectionManager.beginTransaction();
					Timestamp timestamp = new Timestamp(System.currentTimeMillis());
					administratorMstBean = administratorMstDAO.findById_user(id_user);
					administratorMstBean.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));
					try {
						ConnectionManager.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					administratorMstBean.setOut_crammer(Timestamp.valueOf(out_crammer));

					ConnectionManager.beginTransaction();
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_delete")).getDate_lastupdate();
					if(date_compareupdate.compareTo(date_beforeupdate) == 0) {
						administratorMstDAO.update(administratorMstBean);
						ConnectionManager.commit();
					} else {
						try {
							ConnectionManager.close();
						} catch (SQLException e) {
							// TODO 自動生成された catch ブロック
							e.printStackTrace();
						}
						System.out.println("DBが更新されていません");
						alart ="DBが更新されていません";
						//sessionに持たせる
						session.setAttribute("alart", alart);
						//次の画面に行く
						request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
						return;
					}
				}
			} else {
				Mst003_GuardianMstDAO mst003_GuardianMstDAO = new Mst003_GuardianMstDAO();
				Mst003_GuardianMstBean mst003_GuardianMstBean = new Mst003_GuardianMstBean();
				ConnectionManager.beginTransaction();

				mst003_GuardianMstBean = mst003_GuardianMstDAO.findById_user(id_user);
				mst003_GuardianMstBean.setFlg_delete(1);
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				mst003_GuardianMstBean.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));
				try {
					ConnectionManager.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				ConnectionManager.beginTransaction();
				date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_delete")).getDate_lastupdate();
				if(date_compareupdate.compareTo(date_beforeupdate) == 0) {
					mst003_GuardianMstDAO.update(mst003_GuardianMstBean);
					ConnectionManager.commit();
				} else {
					try {
						ConnectionManager.close();
					} catch (SQLException e) {
						// TODO 自動生成された catch ブロック
						e.printStackTrace();
					}
					System.out.println("DBが更新されていません");
					alart ="DBが更新されていません";
					//sessionに持たせる
					session.setAttribute("alart", alart);
					//次の画面に行く
					request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
					return;
				}
			}
		request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster.jsp").forward(request, response);

		return;

		} else {
			//共通パラメータの未記入チェック
			if (request.getParameter("PASSWORD").equals("")) {
				System.out.println("passが空文字です。");
				alart ="パスワードを記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("REPASSWORD").equals("")) {
				System.out.println("REPASSWORDが空文字です。");
				alart ="パスワード(再)を記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("NAME_USER").equals("")) {
				System.out.println("nameが空文字です。");
				alart ="氏名を記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("KANA_NAME_USER").equals("")) {
				System.out.println("kana_nameが空文字です。");
				alart ="氏名(ｶﾅ)を記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("SEX") == null ) {
				System.out.println("sexがnullです。");
				alart ="性別を選択してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("NICKNAME").equals("")) {
				System.out.println("ニックネームが空文字です。");
				alart ="ニックネームを記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;


			} else if (request.getParameter("BIRTHDAY_YEAR").equals("") || request.getParameter("BIRTHDAY_MONTH").equals("") || request.getParameter("BIRTHDAY_DATE").equals("")) {
				System.out.println("birthday_yearが空文字です。");
				alart ="生年月日が未記入です";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("PHONE_NUMBER").equals("")) {
				System.out.println("phoneが空文字です。");
				alart ="電話番号を記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (request.getParameter("MAIL_ADDRESS").equals("")) {
				System.out.println("mailが空文字です。");
				alart ="メールアドレスを記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

				/*
				 * ここまでが共通のパラメータ
				 * 以下権限別
				 */
			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 2)
					&& request.getParameter("ID_FAMILY").equals("")) {
				System.out.println("ID_FAMILYが空文字です。");
				alart ="家族IDが未記入です";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& (request.getParameter("IN_CRAMMER_YEAR").equals("") || request.getParameter("IN_CRAMMER_MONTH").equals("") || request.getParameter("IN_CRAMMER_DATE").equals(""))) {
				System.out.println("IN_CRAMMERが空文字です。");
				alart ="入塾日が未記入です";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (((Integer)session.getAttribute("permission") == 2 || (Integer)session.getAttribute("permission") == 3)
					&& (request.getParameter("ADDRESS").equals(""))) {
				System.out.println("ADDRESSが空文字です。");
				alart ="住所が未記入です";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& request.getParameter("SCHOOL") == null) {
				System.out.println("学校を選択してください");
				alart ="学校が選択されていません。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& request.getParameter("GRADE").equals("")) {
				System.out.println("GRADEが空文字です。");
				alart ="学年が選択されていません";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

				/*
				 * ここからは入力チェック
				 * 共通パラメータのチェックから
				 */
			} else if (Validate.isZennkaku(request.getParameter("NAME_USER")) == false) {
				System.out.println("氏名は全角で記入してください");
				alart ="氏名は全角で記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (Validate.isKana(request.getParameter("KANA_NAME_USER")) == false) {
				System.out.println("氏名(ｶﾅ)は半角カタカナで記入してください");
				alart ="氏名(ｶﾅ)は半角カタカナで記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (Validate.isNum(request.getParameter("BIRTHDAY_YEAR")) == false
					|| Validate.isNum(request.getParameter("BIRTHDAY_MONTH")) == false
					|| Validate.isNum(request.getParameter("BIRTHDAY_DATE")) == false) {
				System.out.println("生年月日を正しく入力してください");
				alart ="生年月日は半角数字で記入してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;


			} else if (Validate.isNum(request.getParameter("PHONE_NUMBER")) == false) {
				System.out.println("電話番号を正しく入力してください");
				alart ="電話番号は半角数字で、ハイフン「-」抜きで入力してください";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (Validate.isMail(request.getParameter("MAIL_ADDRESS")) == false) {
				System.out.println("無効なメールアドレスです。");
				alart ="無効なメールアドレスです。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (!request.getParameter("PASSWORD").equals(request.getParameter("REPASSWORD"))) {
				System.out.println("パスワードが異なる");
				alart ="パスワードとパスワード(再)が一致しません。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

				/*
				 * 次に権限毎のパラメータの入力チェック
				 */
			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 2)
					&& Validate.isHannkaku(request.getParameter("ID_FAMILY")) == false) {
				System.out.println("家族IDを正しく入力して下さい");
				alart ="家族IDを正しく入力して下さい。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;


				/*
				 * 学校を見て小学校なら6年まで、中高生は3年までを選択されていなかったらはじく
				 * また数字かどうかの確認も行う
				 */
			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& (Validate.isNum(request.getParameter("GRADE")) == false)) {
				System.out.println("学年は数字で入力してください");
				alart ="学年は数字で入力して下さい。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
						&&((Integer.parseInt(request.getParameter("SCHOOL")) == 1 && Integer.parseInt(request.getParameter("GRADE")) > 6)
						|| (Integer.parseInt(request.getParameter("SCHOOL")) == 2 && Integer.parseInt(request.getParameter("GRADE")) > 3)
						|| (Integer.parseInt(request.getParameter("SCHOOL")) == 3 && Integer.parseInt(request.getParameter("GRADE")) > 3))) {
				System.out.println("学年を正しく入力してください。");
				alart ="学年を正しく入力して下さい。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行くt
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;
				/*
				 * 学校のIDを選択する際に、SCHOOLを見て、この塾に入ってからの学校のIDが取得できなかったらはじく
				 * ここでは登録を行うので、大体の場合は登録するIDは一つだが、マイノリティの場合もあるので、最低一つ以上のIDを持っていて
				 * かつ、その時の学校のIDが最低でも入っていなければはじく(滞在中の学校が大学も含まれる?（講師？？））
				 * そんで自分の学年よりも上の学校のIDを選択した場合にもアウト（とっても醜いので頑張って読んでください）
				 */
			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& ((Integer.parseInt(request.getParameter("GRADE")) ==1 && (Integer.parseInt(request.getParameter("ID_ELEMENTARY_SCHOOL")) == 0 || Integer.parseInt(request.getParameter("ID_JUNIOR_HIGH_SCHOOL")) != 0 || Integer.parseInt(request.getParameter("ID_HIGH_SCHOOL")) != 0 || Integer.parseInt(request.getParameter("ID_HIGH_SCHOOL")) != 0))
					|| (Integer.parseInt(request.getParameter("GRADE")) == 2 && (Integer.parseInt(request.getParameter("ID_JUNIOR_HIGH_SCHOOL")) == 0 || Integer.parseInt(request.getParameter("ID_HIGH_SCHOOL")) != 0 || Integer.parseInt(request.getParameter("ID_HIGH_SCHOOL")) != 0))
					|| (Integer.parseInt(request.getParameter("GRADE")) == 3 && (Integer.parseInt(request.getParameter("ID_HIGH_SCHOOL")) == 0  || Integer.parseInt(request.getParameter("ID_HIGH_SCHOOL")) != 0))
					|| (Integer.parseInt(request.getParameter("GRADE")) == 4 && Integer.parseInt(request.getParameter("ID_UNIVERSITY")) == 0))){
				System.out.println("現在の学校が選択されていません");
				alart ="現在の学校が選択されていません。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;

			} else if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& (Validate.isNum(request.getParameter("IN_CRAMMER_YEAR")) == false || Validate.isNum(request.getParameter("IN_CRAMMER_MONTH")) == false || Validate.isNum(request.getParameter("IN_CRAMMER_DATE")) == false)) {
				System.out.println("入塾日は数字で記入してください");
				alart ="入塾日は数字で記入してください。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
				return;
				/*
				 * ここから登録の処理を行う
				 */

			}
				/*
				 * 未入力チェックが終わったら、Timestamp型に変換可能なString値に変換
				 *///誕生日はTimestamp形式に変換
			String birthday = request.getParameter("BIRTHDAY_YEAR") + "-" + request.getParameter("BIRTHDAY_MONTH") + "-" + request.getParameter("BIRTHDAY_DATE") + " " + "00:00:00";
			System.out.println(birthday);
			/*			if (Validate.isDate(birthday) == false) {
				System.out.println("誕生日は正しく入力して下さい");
				alart ="誕生日は正しく入力してください。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
			}


*/			//入塾日はTimestamp型に直してから
			String in_crammer = request.getParameter("IN_CRAMMER_YEAR") + "-" + request.getParameter("IN_CRAMMER_MONTH") + "-" + request.getParameter("IN_CRAMMER_DATE") + " " + "00:00:00";
			System.out.println(in_crammer);
			/*			if (((Integer)session.getAttribute("permission") == 1 || (Integer)session.getAttribute("permission") == 3)
					&& Validate.isDate(in_crammer) == false) {
				System.out.println("入塾日は正しく入力して下さい");
				alart ="入塾日は正しく入力してください。";
				//sessionに持たせる
				session.setAttribute("alart", alart);
				//次の画面に行く
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
			}
*/
			//更新時,削除時はこの処理は行わない
			if (request.getParameter("id_user_update") == null) {

				//重複チェック
				int count = -1;


				//共通データの実装を先に行う
				while (count != 0) {
					//RandomStringUtilsのrandomAlphabeticは半角英数字（大文字、小文字のどちらも含む）をString値で渡す
					userID = RandomStringUtils.randomAlphabetic(10);

					ConnectionManager.beginTransaction();

					count = mst001_userdao.getCountById(userID);
					System.out.println(count);
					try {
						ConnectionManager.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}

					if (count == 1) {
						System.out.println("重複しています。");
					}
					if (count == -1) {
						System.out.println("DBから正しく値を取得していません。");
					}

				}

			//更新、削除時の場合
			} else if (request.getParameter("id_user_update") != null) {
				userID = request.getParameter("id_user_update");
			} else if (request.getParameter("id_user_delete") != null){
				userID = request.getParameter("id_user_delete");
			} else {
				String e = "error";
				System.err.println(e);
			}

			System.out.println(userID);
			mst001_UserMst.setId_user(userID);

			mst001_UserMst.setName(request.getParameter("NAME_USER"));
			mst001_UserMst.setKana_name(request.getParameter("KANA_NAME_USER"));

			mst001_UserMst.setPass(request.getParameter("PASSWORD"));

			mst001_UserMst.setSex(Integer.parseInt(request.getParameter("SEX")));
			mst001_UserMst.setNickname(request.getParameter("NICKNAME"));


			mst001_UserMst.setBirthday(Timestamp.valueOf(birthday));
			mst001_UserMst.setPhone(request.getParameter("PHONE_NUMBER"));
			mst001_UserMst.setMail(request.getParameter("MAIL_ADDRESS"));
			mst001_UserMst.setPermission((Integer)session.getAttribute("permission"));

			//hiddenで取得
			mst001_UserMst.setId_lastupdate(request.getParameter("id_lastupdate"));
			//ミリ秒での現在時刻の取得
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			mst001_UserMst.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));
			System.out.println(timestamp.toString());
			/*
			 * ここまでで必須の入力はおしまい
			 * 次にユーザが	生徒だった場合の処理
			 * 生徒データを格納するクラスSTUDENTを呼び出す。
			 */
			if ((Integer)session.getAttribute("permission") == 1) {
				Mst002_StudentMstBean student = new Mst002_StudentMstBean();
				student.setId_user(userID);
				student.setId_family(request.getParameter("ID_FAMILY"));

				int grade = 0;
				//学年はschoolとgradeを見て作成
				if (Integer.parseInt(request.getParameter("SCHOOL")) == 1) {
					grade = 10;
					grade +=Integer.parseInt(request.getParameter("GRADE"));
					student.setGrade(grade);
				} else if (Integer.parseInt(request.getParameter("SCHOOL")) == 2) {
					grade = 20;
					grade +=Integer.parseInt(request.getParameter("GRADE"));
					student.setGrade(grade);
				} else if (Integer.parseInt(request.getParameter("SCHOOL")) == 3) {
					grade = 30;
					grade += Integer.parseInt(request.getParameter("SCHOOL"));
					student.setGrade(grade);
				} else {
					System.out.println("正しく学年が処理されていません");
				}

				/*
				 * 各学校のIDは入れられるようなら値を格納する
				 * 「ああ入れたい」ではなく「しょうがないから挿入する」イメージ
				 *  具体的にはDAOで見るからとりあえず入れられるなら挿入する。
				 */
				if (request.getParameter("ID_ELEMENTARY_SCHOOL") != null) {
					student.setId_elementary(request.getParameter("ID_ELEMENTARY_SCHOOL"));

				} else {
					student.setId_elementary("NULL");
				}
				if (request.getParameter("ID_JUNIOR_HIGH_SCHOOL") != null) {
					student.setId_junior_high_school(request.getParameter("ID_JUNIOR_HIGH_SCHOOL"));
				} else {
					student.setId_high_school("NULL");
				}
				if (request.getParameter("ID_HIGH_SCHOOL") != null) {
					student.setId_high_school(request.getParameter("ID_HIGH_SCHOOL"));
				} else {
					student.setId_high_school("NULL");
				}
				if (request.getParameter("ID_UNIVERSITY") != null) {
					student.setId_university(request.getParameter("ID_UNIVERSITY"));
				} else {
					student.setId_university("NULL");
				}
				student.setIn_crammer(Timestamp.valueOf(in_crammer));

				student.setId_lastupdate(request.getParameter("id_lastupdate"));
				//ミリ秒での現在時刻の取得
				student.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));

				/*
				 * 生徒の場合のインサートの処理はここまででOK！！DAOにぶち込む
				 * インサートする際の留意点として、各ぶち込むテーブルの更新日を見る
				 * トランザクションを開いた時とインサート後で、更新日に変更がなければコミットをかける
				 *
				 * まずはユーザテーブルにインサート
				 * ユーザの場合はnullはないはず、特になんも考えないでOK？（取り敢えずぶちこんでみる）
				 */


				Mst001_UserMstDAO userdao = new Mst001_UserMstDAO();

				//更新,削除時はこの処理は行わない
				if (request.getParameter("id_user_update") == null) {
					/*
					 * ユーザテーブルインサート
					 */

					ConnectionManager.beginTransaction();
					userdao.create(mst001_UserMst);
					ConnectionManager.commit();


				} else if (request.getParameter("id_user_update") != null) {
					ConnectionManager.beginTransaction();
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_update")).getDate_lastupdate();
					if(date_compareupdate.compareTo(date_beforeupdate) == 0) {
						userdao.update(mst001_UserMst);
						ConnectionManager.commit();
					} else {
						try {
							ConnectionManager.close();
						} catch (SQLException e) {
							// TODO 自動生成された catch ブロック
							e.printStackTrace();
						}
						System.out.println("DBが更新されていません");
						alart ="DBが更新されていません";
						//sessionに持たせる
						session.setAttribute("alart", alart);
						//次の画面に行く
						request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
						return;
					}
				} else {
					String e = "error";
					System.err.println(e);
				}
				/*
				 * 次にSTUDENTテーブルをインサート
				 * NULLもあるのでCUSTUMDAOのインサートを使う
				 */
				Mst002_StudentMstDAO studentDAO = new Mst002_StudentMstDAO();

				//更新時はこの処理は行わない
				if (request.getParameter("id_user_update") == null) {
					ConnectionManager.beginTransaction();
					studentDAO.create(student);
					ConnectionManager.commit();
				} else if (request.getParameter("id_user_update") != null) {
					ConnectionManager.beginTransaction();
						studentDAO.update(student);
						ConnectionManager.commit();
				} else {
					String e = "error";
					System.err.println(e);
				}


				System.out.println("キチンとここまで処理できましたよ！！やったね！！");

				//過去に取得していたら破棄
				session.removeAttribute("permission");

				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster.jsp").forward(request, response);

			}	else if ((Integer)session.getAttribute("permission") == 2) {

				Mst003_GuardianMstBean mst003_GuardianMst = new Mst003_GuardianMstBean();

				mst003_GuardianMst.setId_user(userID);
				mst003_GuardianMst.setId_family(request.getParameter("ID_FAMILY"));
				mst003_GuardianMst.setAddress(request.getParameter("ADDRESS"));
				mst003_GuardianMst.setFlg_delete(0);
				mst003_GuardianMst.setId_lastupdate(request.getParameter("id_lastupdate"));
				//ミリ秒での現在時刻の取得
				mst003_GuardianMst.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));


				Mst001_UserMstDAO userdao = new Mst001_UserMstDAO();

				//更新、削除時はこの処理は行わない
				if (request.getParameter("id_user_update") == null) {
					/*
					 * ユーザテーブルインサート
					 */
					ConnectionManager.beginTransaction();
					userdao.create(mst001_UserMst);
					ConnectionManager.commit();

				//以下は更新時の場合
				} else if (request.getParameter("id_user_update") != null) {
					ConnectionManager.beginTransaction();
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_update")).getDate_lastupdate();
					if(date_compareupdate.compareTo(date_beforeupdate) == 0) {
						userdao.update(mst001_UserMst);
						ConnectionManager.commit();
					} else {
						try {
							ConnectionManager.close();
						} catch (SQLException e) {
							// TODO 自動生成された catch ブロック
							e.printStackTrace();
						}
						System.out.println("DBが更新されていません");
						alart ="DBが更新されていません";
						//sessionに持たせる
						session.setAttribute("alart", alart);
						//次の画面に行く
						request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
						return;
					}
				} else {
					String e = "error";
					System.err.println(e);
				}



				/*
				 * 次にSTUDENTテーブルをインサート
				 * NULLもあるのでCUSTUMDAOのインサートを使う
				 */
					Mst003_GuardianMstDAO guardianDAO = new Mst003_GuardianMstDAO();

				//更新、削除時はこの処理は行わない
				if (request.getParameter("id_user_update") == null) {
					ConnectionManager.beginTransaction();
					guardianDAO.create(mst003_GuardianMst);
					ConnectionManager.commit();

				} else if (request.getParameter("id_user_update") != null) {
					ConnectionManager.beginTransaction();
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_update")).getDate_lastupdate();
					if (date_compareupdate.compareTo(date_beforeupdate) == 0) {
						guardianDAO.update(mst003_GuardianMst);
						ConnectionManager.commit();

					} else {
						try {
							ConnectionManager.close();
						} catch (SQLException e) {
							// TODO 自動生成された catch ブロック
							e.printStackTrace();
						}
						System.out.println("DBが更新されていません");
						alart ="DBが更新されていません";
						//sessionに持たせる
						session.setAttribute("alart", alart);
						//次の画面に行く
						request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
						return;
					}

				} else {
					String e = "error";
					System.err.println(e);
				}

				System.out.println("キチンとここまで処理できましたよ！！やったね！！");

				//過去に取得していたら破棄
				session.removeAttribute("permission");

				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster.jsp").forward(request, response);



			} else if((Integer)session.getAttribute("permission") == 3) {
				Mst004_AdministratorMstBean mst004_AdministratorMst = new Mst004_AdministratorMstBean();

				mst004_AdministratorMst.setId_user(userID);
				mst004_AdministratorMst.setGrade(Integer.parseInt(request.getParameter("GRADE")));
				mst004_AdministratorMst.setAddress("ADDRESS");

				int grade = 0;
				//学年はschoolとgradeを見て作成
				if (Integer.parseInt(request.getParameter("SCHOOL")) == 1) {
					grade = 10;
					grade +=Integer.parseInt(request.getParameter("GRADE"));
					mst004_AdministratorMst.setGrade(grade);
				} else if (Integer.parseInt(request.getParameter("SCHOOL")) == 2) {
					grade = 20;
					grade +=Integer.parseInt(request.getParameter("GRADE"));
					mst004_AdministratorMst.setGrade(grade);
				} else if (Integer.parseInt(request.getParameter("SCHOOL")) == 3) {
					grade = 30;
					grade += Integer.parseInt(request.getParameter("SCHOOL"));
					mst004_AdministratorMst.setGrade(grade);
				} else {
					System.out.println("正しく学年が処理されていません");
				}

				/*
				 * 各学校のIDは入れられるようなら値を格納する
				 * 「ああ入れたい」ではなく「しょうがないから挿入する」イメージ
				 *  具体的にはDAOで見るからとりあえず入れられるなら挿入する。
				 */
				if (request.getParameter("ID_ELEMENTARY_SCHOOL") != null) {
					mst004_AdministratorMst.setId_elementary(request.getParameter("ID_ELEMENTARY_SCHOOL"));

				} else {
					mst004_AdministratorMst.setId_elementary("NULL");
				}
				if (request.getParameter("ID_JUNIOR_HIGH_SCHOOL") != null) {
					mst004_AdministratorMst.setId_junior_high_school(request.getParameter("ID_JUNIOR_HIGH_SCHOOL"));
				} else {
					mst004_AdministratorMst.setId_high_school("NULL");
				}
				if (request.getParameter("ID_HIGH_SCHOOL") != null) {
					mst004_AdministratorMst.setId_high_school(request.getParameter("ID_HIGH_SCHOOL"));
				} else {
					mst004_AdministratorMst.setId_high_school("NULL");
				}
				if (request.getParameter("ID_UNIVERSITY") != null) {
					mst004_AdministratorMst.setId_university(request.getParameter("ID_UNIVERSITY"));
				} else {
					mst004_AdministratorMst.setId_university("NULL");
				}
				mst004_AdministratorMst.setIn_crammer(Timestamp.valueOf(in_crammer));

				mst004_AdministratorMst.setId_lastupdate(request.getParameter("id_lastupdate"));
				//ミリ秒での現在時刻の取得
				mst004_AdministratorMst.setDate_lastupdate(Timestamp.valueOf(timestamp.toString()));

				/*
				 * 生徒の場合のインサートの処理はここまででOK！！DAOにぶち込む
				 * インサートする際の留意点として、各ぶち込むテーブルの更新日を見る
				 * トランザクションを開いた時とインサート後で、更新日に変更がなければコミットをかける
				 *
				 * まずはユーザテーブルにインサート
				 * ユーザの場合はnullはないはず、特になんも考えないでOK？（取り敢えずぶちこんでみる）
				 */


				Mst001_UserMstDAO userdao = new Mst001_UserMstDAO();

				//更新、削除時はこの処理は行わない
				if (request.getParameter("id_user_update") == null) {
					/*
					 * ユーザテーブルインサート
					 */
					ConnectionManager.beginTransaction();
					userdao.create(mst001_UserMst);
					ConnectionManager.commit();

				//以下は更新、削除時の場合
				} else if (request.getParameter("id_user_update") != null) {
					ConnectionManager.beginTransaction();
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_update")).getDate_lastupdate();
					if (date_compareupdate.compareTo(date_beforeupdate) == 0) {
						userdao.update(mst001_UserMst);
						ConnectionManager.commit();
					} else {
						try {
							ConnectionManager.close();
						} catch (SQLException e) {
							// TODO 自動生成された catch ブロック
							e.printStackTrace();
						}
						System.out.println("DBが更新されていません");
						alart ="DBが更新されていません";
						//sessionに持たせる
						session.setAttribute("alart", alart);
						//次の画面に行く
						request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster/createuser.jsp").forward(request, response);
						return;
					}
				} else {
					String e = "error";
					System.err.println(e);
				}

				/*
				 * 次にSTUDENTテーブルをインサート
				 * NULLもあるのでCUSTUMDAOのインサートを使う
				 */
				Mst004_AdministratorMstDAO administratorDAO = new Mst004_AdministratorMstDAO();

				//更新、削除時はこの処理は行わない
				if (request.getParameter("id_user_update") == null) {
					ConnectionManager.beginTransaction();
					administratorDAO.create(mst004_AdministratorMst);
					ConnectionManager.commit();

				//以下は更新時の場合
				} else if (request.getParameter("id_user_update") != null) {
					date_beforeupdate = mst001_userdao.findById((String)request.getParameter("id_user_update")).getDate_lastupdate();
					ConnectionManager.beginTransaction();
					administratorDAO.update(mst004_AdministratorMst);
					ConnectionManager.commit();
				} else {
					String e = "error";
					System.err.println(e);
				}

				System.out.println("キチンとここまで処理できましたよ！！やったね！！");

				//過去に取得していたら破棄
				session.removeAttribute("permission");

				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/usermaster.jsp").forward(request, response);

			}
		}
	}
}
