package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.CLS917DAO;
import Dao.ConnectionManager;
import Dao.Trn900_nfctrnDAO;
import Validate.Changer;
import Validate.Validate;
import bean.CLS917Bean;
import bean.Trn900_NfcTrnBean;
import common.CLS917Exception;
import common.ServretCommon;

/**
 *	NFCマスタの追加、検索、削除の共通サーブレット。
 *
 * この画面のエンハンスまたはコピーして実装を行う際には、以下の点を留意して実装を行う事
 *
 * ・機能ごとの共通パラメータチェック
 * 	 NFCマスタでは、追加ボタン押下時に検索時のパラメータチェック
 *   も実施している。
 *
 * ・削除は物理削除
 *   ユースケースを考えた際に、論理削除でなくとも良いと考えられるため
 *   対象レコードにたいして物理削除を行っている。
 *   もし、論理削除に変える必要がある際には、DB上のPKの設定を変える必要があり、
 *   またIndexの追加が必要と思われる。
 *
 *
 * ・doGetにおいて独自Exceptionをthrowしないこと
 *   NFCマスタでは、CLS917Exceptionという独自Exceptionを実装している
 *   もし独自Exceptionを作成した場合には、doGetでスローすると、その上位の処理で
 *   エラーが発生してしまうため、（catchされない）必ず下位の処理においてtry～catchすること
 *
 * ・HttpSessionのインスタンス数
 *   今回実装を少しミスったかなと思っているものとしては
 *   機能ごとにHttpSessionのインスタンス数がいくつなのかわかりにくい
 *   ことだと思っています。(すみません)
 *   まだ、シーケンスをおえばすぐ数えられるが、
 *   もし余裕あればシングルトンで作成して欲しい。
 * @author n-kuraoka
 * @since 塾HP新規時に作成
 */

public class CLS917_NfcSearchServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {

		try {
			//登録、検索
			if (request.getParameter("mode") != null) {
				if (request.getParameter("mode").equals("sel")) {
					selectNFCInfo(request, response);
				}
				if (request.getParameter("mode").equals("add")) {
					addNFCInfo(request, response);
				}
			}

			//削除
			if (request.getParameter("delete") != null) {
				deleteNFCInfo(request, response);
			}
		} catch (CLS917Exception e) {
			e.printStackTrace();
		}

		if (request.getParameter("mode") == null) {
			if (request.getParameter("delete") == null) {
				HttpSession session = request.getSession();
				
				// loginSessionのチェック
				ServretCommon.checkLoginSession(request, response, session);
				
				//古いセッション上の情報を削除
				removeCls917SessionAttribute(session);
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
			}
		}
	}

	/**
	 * 指定レコードの物理削除を行う。
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void deleteNFCInfo(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		String date_access = null;
		String id_user = null;
		if (request.getParameter("date_access") != null) {
			if (!request.getParameter("date_access").equals("")) {
				date_access = request.getParameter("date_access");
			}
		}
		if (request.getParameter("ID_USER") != null) {
			if (!request.getParameter("ID_USER").equals("")) {
				id_user = request.getParameter("ID_USER");
			}
		}
		if (id_user != null
		 && date_access != null) {
			try {
				if (deleteNFCInfo(id_user, date_access)) {
					//古いセッション上の情報を削除
					removeCls917SessionAttribute(session);
					session.setAttribute("alart", "削除しました。");
					//更新データを画面出力する
					session.setAttribute("ID_USER", request.getParameter("ID_USER"));
					session.setAttribute("cls917list", getSelListForDel(request));
					session.setAttribute("selDate", getselDateListForDel(request));
					request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
				} else {
					//古いセッション上の情報を削除
					removeCls917SessionAttribute(session);
					session.setAttribute("alart", "削除に失敗しました。");
					session.setAttribute("ID_USER", request.getParameter("ID_USER"));
					session.setAttribute("cls917list", getSelListForDel(request));
					session.setAttribute("selDate", getselDateListForDel(request));
					request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
				}
			} catch (CLS917Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 削除時にパラメータチェックと削除を行う。
	 * @param id_user
	 * @param date_access
	 * @return
	 * @throws CLS917Exception
	 */
	private boolean deleteNFCInfo(String id_user, String date_access) throws CLS917Exception {
		Trn900_NfcTrnBean bean = null;
		Trn900_nfctrnDAO nfctrnDAO = new Trn900_nfctrnDAO();
		ConnectionManager.beginTransaction();
		if (CLS917DAO.getInstance().getNfcTrnData(id_user, date_access) != null) {
			bean = CLS917DAO.getInstance().getNfcTrnData(id_user, date_access);
		}
		bean.setFlag_delete(1);
		nfctrnDAO.delete(bean);
		ConnectionManager.commit();
		return true;
	}
	/**
	 * 登録時にパラメータチェックと登録を行う。
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 * @throws CLS917Exception
	 */
	private void addNFCInfo(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, CLS917Exception {

		//登録情報のパラメータのチェック
		if (!checkAddParameter(request, response)) return;

		//登録を行う。
		if (createNFCInfo(request, response)) {
			HttpSession session = request.getSession();
			//古いセッション上の情報を削除
			removeCls917SessionAttribute(session);
			session.setAttribute("alart", "追加しました。");
			//更新データを画面出力する
			session.setAttribute("selDate", getselDateList(request));
			session.setAttribute("ID_USER", request.getParameter("ID_USER"));
			session.setAttribute("cls917list", getSelList(request));
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
		}
	}

	/**
	 * 登録を行う。
	 * @param request
	 * @return
	 * @throws CLS917Exception
	 * @throws IOException
	 * @throws ServletException
	 */
	private boolean createNFCInfo(HttpServletRequest request, HttpServletResponse response) throws CLS917Exception, ServletException, IOException {
		Trn900_NfcTrnBean bean = new Trn900_NfcTrnBean();
		String strday = request.getParameter("year") +
				"-" + request.getParameter("month") +
				"-" + request.getParameter("date") +
				" " + Changer.addZeroforInt(Integer.parseInt(request.getParameter("hour"))) +
				":" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("minute"))) +
				":" + "00";
		if (!Validate.isDate(strday)) {
			HttpSession session = request.getSession();
			removeCls917SessionAttribute(session);
			session.setAttribute("selDate", getselDateList(request));
			session.setAttribute("alart", "正しい日付を入力して下さい。");
			session.setAttribute("ID_USER", request.getParameter("ID_USER"));
			session.setAttribute("cls917list", getSelList(request));
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);

			return false;
		}

		bean.setId_user(request.getParameter("ID_USER"));
		bean.setDate_access(Timestamp.valueOf(strday));

		if (request.getParameter("time_incrammer") != null) {
			bean.setTime_incrammer(1);
		}

		if (request.getParameter("time_outcrammer") != null) {
			bean.setTime_outcrammer(1);
		}
		Trn900_nfctrnDAO dao = new Trn900_nfctrnDAO();
		ConnectionManager.beginTransaction();
		if (CLS917DAO.getInstance().getNfcTrnData(bean.getId_user(), strday) != null) {
			HttpSession session = request.getSession();
			//古いセッション上の情報を削除
			removeCls917SessionAttribute(session);
			session.setAttribute("selDate", getselDateList(request));
			session.setAttribute("alart", "対象のユーザに対して同一の時間を登録することはできません。");
			session.setAttribute("ID_USER", request.getParameter("ID_USER"));
			session.setAttribute("cls917list", getSelList(request));
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);

			return false;
		}
		dao.create(bean);
		ConnectionManager.commit();
		return true;
	}

	/**
	 * NFCレコード追加時のパラメータチェックを行う。
	 * チェックされた場合にはその際に指定したパラメータを残し、また指定日、ユーザにおいて
	 * 検索を行う。
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 * @throws CLS917Exception
	 */
	private boolean checkAddParameter(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, CLS917Exception {
		if (request.getParameter("time_incrammer") == null
				&& request.getParameter("time_outcrammer") == null) {
			setSessionAndRequestDispacherForAdd(request, response
					, "入退室を選択してください。"
					, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
			return false;
		}
		if (request.getParameter("hour") != null) {
			if (request.getParameter("hour").equals("")) {
				setSessionAndRequestDispacherForAdd(request, response
						, "時刻を入力してください。"
						, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
				return false;
			}
		}
		if (request.getParameter("minute") != null) {
			if (request.getParameter("hour").equals("")) {
				setSessionAndRequestDispacherForAdd(request, response
						, "時刻を入力してください。"
						, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
				return false;
			}
			if (!Validate.isNum((String)request.getParameter("hour"))) {
				setSessionAndRequestDispacherForAdd(request, response
						, "時刻の値を見直してください。"
						, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
				return false;
			}
			if (!Validate.isNum((String)request.getParameter("minute"))) {
				setSessionAndRequestDispacherForAdd(request, response
						, "時刻の値を見直してください。"
						, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
				return false;
			}
			if (Integer.parseInt(request.getParameter("hour")) > 25
			 || Integer.parseInt(request.getParameter("minute")) > 60) {
				setSessionAndRequestDispacherForAdd(request, response
						, "時刻の値を見直してください。"
						, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
				return false;
			}
			if (request.getParameter("date").equals("0")) {
				setSessionAndRequestDispacherForAdd(request, response
						, "登録の際には、日付を指定してください。"
						, "JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp");
			}
		}
		return checkSelParameter(request, response);

	}
	/**
	 * 追加時のセッション情報の付与と画面遷移を行う。
	 * @param request
	 * @param response
	 * @param alart
	 * @param url
	 * @throws CLS917Exception
	 * @throws ServletException
	 * @throws IOException
	 */
	private void setSessionAndRequestDispacherForAdd(
			HttpServletRequest request, HttpServletResponse response,
			String alart, String url) throws CLS917Exception, ServletException, IOException {
		HttpSession session = request.getSession();
		session.setAttribute("ID_USER", request.getParameter("ID_USER"));
		session.setAttribute("selDate", getselDateList(request));
		session.setAttribute("cls917list", getSelList(request));
		session.setAttribute("alart", alart);
		request.getRequestDispatcher(url).forward(request, response);
	}

	/**
	 * 日にちの各パラメータをリストに設定する
	 * リストの先頭から順に年、月、日にちが格納される。
	 * @param request
	 * @return
	 */
	private ArrayList<String> getselDateList(HttpServletRequest request) {
		ArrayList<String> arrayList = new ArrayList<>();
		arrayList.add(request.getParameter("year"));
		arrayList.add(request.getParameter("month"));
		arrayList.add(request.getParameter("date"));
		return arrayList;
	}
	/**
	 * 日にちの各パラメータをリストに設定する
	 * リストの先頭から順に年、月、日にちが格納される。
	 * @param request
	 * @return
	 */
	private ArrayList<String> getselDateListForDel(HttpServletRequest request) {
		String date_access = request.getParameter("date_access");
		ArrayList<String> arrayList = new ArrayList<>();
		arrayList.add(date_access.split("[-]")[0]);
		arrayList.add(String.valueOf(Integer.parseInt(date_access.split("[-]")[1])));
		arrayList.add(String.valueOf(Integer.parseInt(date_access.split("[-]")[2].split("[ ]")[0])));
		return arrayList;
	}

	/**
	 * 指定された日にち、ユーザで検索を行う。
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 * @throws CLS917Exception
	 */
	private void selectNFCInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, CLS917Exception {
		//Sessionの取得
		HttpSession session = request.getSession();


		//取得予定のリスト
		List<CLS917Bean> list = new ArrayList<CLS917Bean>();

		//検索対象のパラメータチェック
		if(!checkSelParameter(request, response)) return;

		//古いセッション上の情報を削除
		removeCls917SessionAttribute(session);

		//DAOから情報取得を行う
		list = getSelList(request);
		session.setAttribute("ID_USER", request.getParameter("ID_USER"));
		session.setAttribute("selDate", getselDateList(request));
		//cls917list
		session.setAttribute("cls917list", list);
		request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
	}

	/**
	 * 古いセッション情報を破棄する
	 * @param session
	 */
	private void removeCls917SessionAttribute(HttpSession session) {
		//過去に取得したパラメータを削除
		session.removeAttribute("ID_USER");
		session.removeAttribute("cls917list");
		session.removeAttribute("alart");
		session.removeAttribute("selDate");
	}

	/**
	 * 指定された日にち、ユーザで検索を行う。
	 * @param request
	 * @return 指定された日にち、ユーザで検索を行ったリスト
	 * @throws CLS917Exception
	 */
	private List<CLS917Bean> getSelList(HttpServletRequest request) throws CLS917Exception {
		//パラメータをDAOに送るためのフォーマットに書き換える
		if (request.getParameter("ID_USER").isEmpty()) {
			return null;
		}
		if (request.getParameter("date").equals("0")) {
			return getSelMonthList(request);
		}
		List<CLS917Bean> list = new ArrayList<>();

		String startday = request.getParameter("year") +
				"-" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("month"))) +
				"-" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("date"))) +
				" " + "00:00:00";
		String endday = request.getParameter("year") +
				"-" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("month"))) +
				"-" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("date")) + 1) +
				" " + "00:00:00";
		//Daoの取得
		CLS917DAO cls917dao = CLS917DAO.getInstance();
		ConnectionManager.beginTransaction();

		list = cls917dao.getUserListByColumns(request.getParameter("ID_USER"), startday, endday);
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 日にちに「指定なし」を指定した場合に、対象のユーザ、対象月で検索を行いリストを返却する。
	 * @param request
	 * @return
	 * @throws CLS917Exception
	 */
	private List<CLS917Bean> getSelMonthList(HttpServletRequest request) throws CLS917Exception {
		List<CLS917Bean> list = new ArrayList<>();
		String startday = request.getParameter("year") +
				"-" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("month"))) +
				"-" + "01" +
				" " + "00:00:00";
		String endday = request.getParameter("year") +
				"-" + Changer.addZeroforInt(Integer.parseInt(request.getParameter("month")) + 1) +
				"-" + "01" +
				" " + "00:00:00";
		//Daoの取得
		CLS917DAO cls917dao = CLS917DAO.getInstance();
		ConnectionManager.beginTransaction();
		list = cls917dao.getUserListByColumns(request.getParameter("ID_USER"), startday, endday);
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 指定レコードを削除した際に、その実施対象の日、ユーザで再度検索して表示する。
	 *
	 * @param request
	 * @return 削除を実施した日、ユーザで検索を行ったリスト
	 * @throws CLS917Exception
	 */
	private List<CLS917Bean> getSelListForDel(HttpServletRequest request) throws CLS917Exception {
		List<CLS917Bean> list = new ArrayList<>();
		CLS917Bean bean = new CLS917Bean();
		//パラメータをDAOに送るためのフォーマットに書き換える
		String date_access = request.getParameter("date_access");
		String startday = date_access.split("[-]")[0] +
				"-" + Changer.addZeroforInt(Integer.parseInt(date_access.split("[-]")[1])) +
				"-" + Changer.addZeroforInt(Integer.parseInt(date_access.split("[-]")[2].split("[ ]")[0])) +
				" " + "00:00:00";
		String endday = date_access.split("[-]")[0] +
				"-" + Changer.addZeroforInt(Integer.parseInt(date_access.split("[-]")[1])) +
				"-" + Changer.addZeroforInt(Integer.parseInt(date_access.split("[-]")[2].split("[ ]")[0]) + 1) +
				" " + "00:00:00";
		//Daoの取得
		CLS917DAO cls917dao = CLS917DAO.getInstance();
		ConnectionManager.beginTransaction();
		list = cls917dao.getUserListByColumns(request.getParameter("ID_USER"), startday, endday);
		try {
			ConnectionManager.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * 検索、登録時のパラメータチェックを行う。
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	private boolean checkSelParameter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * 検索に必要なパラメータが欠けている場合には
		 * 前回検索した場合のセッション情報は削除せずに
		 * 画面遷移を行う。
		 */
		//入力パラメータのチェック
		HttpSession session = request.getSession();
		if (request.getParameter("ID_USER") != null) {
			if(request.getParameter("ID_USER").equals("")) {
				session.setAttribute("alart", "ユーザIDを記入して下さい。");
				request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
				return false;
			}
		}
		if (request.getParameter("year").equals("")
		 || request.getParameter("month").equals("")
		 || request.getParameter("date").equals("")) {
			session.setAttribute("alart", "日付を設定してください。");
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
			return false;
		}
		if (request.getParameter("year") == null
		 || request.getParameter("month") == null
		 || request.getParameter("date") == null) {
			session.setAttribute("alart", "日付を設定してください。");
			request.getRequestDispatcher("JSP/topmenu/menu/mastermente/CLS917_NfcSearch.jsp").forward(request, response);
			return false;
		}
		return true;
	}

}
