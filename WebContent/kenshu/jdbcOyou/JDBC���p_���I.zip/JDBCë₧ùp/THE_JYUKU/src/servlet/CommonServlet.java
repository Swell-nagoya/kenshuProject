package servlet;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServlet;

import org.apache.commons.lang3.time.DateUtils;

public class CommonServlet extends HttpServlet {
	String timeHH = null;
	String timeMM = null;

	public String getTimeHH(){
		return this.timeHH;
	}

    public void setTimeHH(String timeHH)
    {
    	this.timeHH = timeHH;
    }

	public String getTimeMM(){
		return this.timeMM;
	}

    public void setTimeMM(String timeMM)
    {
    	this.timeMM = timeMM;
    }

	// コース時間用タイムスタップ変更メソッド
	public Timestamp changeTimestampForCourse(String strTimeHH,String strTimeMM) {
		Timestamp ts = null;
		try{
			String targetDatetime = "2999-12-31 "+ strTimeHH +":"+ strTimeMM + ":00";
			ts = new Timestamp(DateUtils.parseDate(targetDatetime, new String[] {"yyyy-MM-dd HH:mm:ss"}).getTime());
		}catch(Exception ex){}
		return ts;
	}

	// コース時間用　時間/分を格納
	public void divTimestampForCourea(Timestamp ts) {
		if (ts != null)
		{
			setTimeHH(new SimpleDateFormat("HH").format(ts));
			setTimeMM(new SimpleDateFormat("mm").format(ts));
		}
	}
}