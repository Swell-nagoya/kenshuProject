package Validate;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import util.Message;
import util.StringUtil;
import Dao.CLS906DAO;
import bean.CLS905_SearchResultBean;
import bean.CLS906_InsertBean;

/**
 * 906テスト登録の入力チェッククラス
 * @author dell
 *
 */
public class CLS906Validate {

	/**
	 * 点数及び偏差値の入力チェックを行う。
	 * @param request リクエスト
	 * @param insertBean 登録情報Bean
	 * @param sessionBean 作業対象の成績セッションBean
	 * @return
	 */
	public static List<String> validate(HttpServletRequest request,
			CLS906_InsertBean insertBean,
			CLS905_SearchResultBean sessionBean) {

		List<String> list = new ArrayList<>();

		// 年度の未入力チェック
		if (StringUtil.isEmpty(insertBean.getFiscal_year())) {
			list.add(Message.getMessage("fiscal_year.required"));
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getFiscal_year() != null) {
				sessionBean.setFiscal_year(null);	
			}
		} else {
			// 数値チェック
			if (!StringUtil.isNumeric(insertBean.getFiscal_year())) {
				insertBean.setFiscal_year("");
				list.add(Message.getMessage("year.format.error"));
				insertBean.setMessage(list);
			}
			
			// 桁数チェック
			if (!StringUtil.isYearInRange(insertBean.getFiscal_year())) {
				insertBean.setFiscal_year("");
				list.add(Message.getMessage("year.range.error"));
				insertBean.setMessage(list);
			}
		}

		// 回次の未入力チェック
		if (StringUtil.isEmpty(insertBean.getTimes())) {
			list.add(Message.getMessage("times.required"));
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getTimes() != null) {
				sessionBean.setTimes(null);
			}
		} else {
			// 数値チェック
			if (!StringUtil.isNumeric(insertBean.getTimes())) {
				insertBean.setTimes("");
				list.add(Message.getMessage("times.format.error"));
				insertBean.setMessage(list);
			}
			
			// 回次重複チェックメソッド呼び出し

			if(!insertBean.getTimes().equals(sessionBean.getTimes())){
				if(!CLS906DAO.duplicationCheck(insertBean.getTimes())){
					insertBean.setTimes("");
					list.add(Message.getMessage("times_duplication.error"));
					insertBean.setMessage(list);
				}
			}
		}

		// 開催日の入力チェック
		if (!StringUtil.isEmpty(insertBean.getDate_hold())){
			if (!StringUtil.isValidDateFormat(insertBean.getDate_hold())) {
				insertBean.setDate_hold("");
				list.add(Message.getMessage("date_format.error"));
				insertBean.setMessage(list);

				if (sessionBean != null && sessionBean.getDate_hold() != null) {
					sessionBean.setDate_hold(null);
				}
			}
		}

		// 国語平均点の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getAverage_jap())) {
			list.add(Message.getMessage("average_jap.invalid"));
			insertBean.setAverage_jap("");
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getAverage_jap() != null) {
				sessionBean.setAverage_jap(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setAverage_jap(null);
			}
		}

		// 数学平均点の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getAverage_math())) {
			list.add(Message.getMessage("average_math.invalid"));
			insertBean.setAverage_math("");
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getAverage_math() != null) {
				sessionBean.setAverage_math(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setAverage_math(null);
			}
		}

		// 理科平均点の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getAverage_siec())) {
			list.add(Message.getMessage("average_siec.invalid"));
			insertBean.setAverage_siec("");
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getAverage_siec() != null) {
				sessionBean.setAverage_siec(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setAverage_siec(null);
			}
		}

		// 社会平均点の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getAverage_scty())) {
			list.add(Message.getMessage("average_scty.invalid"));
			insertBean.setAverage_scty("");
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getAverage_scty() != null) {
				sessionBean.setAverage_scty(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setAverage_scty(null);
			}
		}

		// 英語平均点の半角数値チェック
		if (!StringUtil.isValidDeviation(insertBean.getAverage_eng())) {
			list.add(Message.getMessage("average_eng.invalid"));
			insertBean.setAverage_eng("");
			insertBean.setMessage(list);

			if (sessionBean != null && sessionBean.getAverage_eng() != null) {
				sessionBean.setAverage_eng(null);
			}

		} else {
			if (request.getParameter("repear") != null) {
				sessionBean.setAverage_eng(null);
			}
		}

		return list;
	}
}
