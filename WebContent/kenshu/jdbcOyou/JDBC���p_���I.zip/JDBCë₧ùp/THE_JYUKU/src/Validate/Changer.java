package Validate;

import java.sql.Timestamp;
import java.util.Calendar;

import org.apache.commons.lang3.time.DateUtils;

/**
 * 主に値の変換を行う各メソッドを格納するクラス
 *
 * @author n-kuraoka
 *
 */

public class Changer {

	/**
	 * MST002_STUDENTMST,MST004_ADMINISTRATORMSTの学年(GRADE)から現在の学校を取得する
	 *
	 * @param int grade 学年のID
	 * @return 現在所属する学校（小学校、中学校、高校、大学、その他のいずれか）
	 */
	public static String getSchool_Grade(int grade) {
		if (grade < 20 && grade > 10) {
			return "小学校";
		} else if (grade < 30 && grade > 20) {
			return "中学校";
		} else if (grade < 40 && grade > 30) {
			return "高校";
		} else if (grade < 50 && grade > 40) {
			return "大学";
		} else if (grade < 60 && grade > 50) {
			return "大学院";
		} else if (grade == 99) {
			return "その他";
		}
		return "該当なし";
	}


	/**
	 * MST014_SCHOOLMSTの学校種別(Categorize_school)から現在の学校を取得する
	 *
	 * @param int grade 学年のID
	 * @return 現在所属する学校（1:小学校 2:中学校 3:高校 4:大学）
	 */
	public static String getCategorize_school(int Categorize_school) {
		if (Categorize_school == 1) {
			return "小学校";
		} else if (Categorize_school == 2) {
			return "中学校";
		} else if (Categorize_school == 3) {
			return "高校";
		} else if (Categorize_school == 4) {
			return "大学";
		} else {
			return "未登録";
		}
	}


	/**
	 * 現在所属する学校の学年を取得します。
	 *
	 * @param grade
	 * @return 学年
	 */
	public static int getNum_Grade(int grade) {
		if (grade < 20 && grade > 10) {
			return grade - 10;
		} else if (grade < 30 && grade > 20) {
			return grade - 20;
		} else if (grade < 40 && grade > 30) {
			return grade - 30;
		} else if (grade < 50 && grade > 40) {
			return grade - 40;
		} else if (grade < 60 && grade > 50) {
			return grade - 50;
		} else if (grade == 99) {
			return 0;
		}
		return 0;
	}

	/**
	 * 現在所属する学校の学年を取得します。
	 *
	 * @param grade
	 * @return 学年
	 */
	public static String getName_Grade(int grade) {
		if (grade < 20 && grade > 10) {
			return "小" + Integer.toString(grade - 10);
		} else if (grade < 30 && grade > 20) {
			return "中" + Integer.toString(grade - 20);
		} else if (grade < 40 && grade > 30) {
			return "高" + Integer.toString(grade - 30);
		} else if (grade < 50 && grade > 40) {
			return "大" + Integer.toString(grade - 40);
		} else if (grade < 60 && grade > 50) {
			return "院" + Integer.toString(grade - 50);
		} else if (grade == 99) {
			return "";
		}
		return "";
	}

	/**
	 * 性別を取得します。
	 *
	 * @palam sexnum 性別
	 * @return 性別
	 */
	public static String getSex(int sex) {
		if (sex == 1) {
			return "男";
		}
		if (sex == 2) {
			return "女";
		}
		return "該当なし";
	}

	/**
	 *
	 * @param timestamp
	 * @return
	 */
	public static int getDay(Timestamp timestamp) {
		String[] daystr = timestamp.toString().split(" ");
		String[] daydatestr = daystr[0].split("-");
		return Integer.parseInt(daydatestr[2]);
	}

	/**
	 * Timestamp型の時間のみ(00:00)の型に変換して出力します。
	 *
	 * @param timestamp
	 * @return
	 */
	public static String getTime(Timestamp timestamp) {
		String timestr = null;

		timestr = timestamp.toString();

		String[] strings = timestr.split(" ");
		String[] strings2 = strings[1].split(":");
		return strings2[0] + ":" + strings2[1];
	}

	/**
	 * カレンダー用の曜日の取得メソッド
	 *
	 * @param day日付
	 * @return 曜日用の変数
	 */
	public static int day_week(int day) {

		// 曜日の管理用num　（月曜日が１～日曜日が7）
		int day_week = 0;
		Calendar calendar = Calendar.getInstance();
		// 年の取得
		int year = calendar.get(Calendar.YEAR);
		// 月の取得(実際の値はこの値の＋１した値)
		int month = calendar.get(Calendar.MONTH);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(year, month, day);
		switch (calendar2.get(Calendar.DAY_OF_WEEK)) {
		case Calendar.SUNDAY:
			day_week = 7;
			break;
		case Calendar.MONDAY:
			day_week = 1;
			break;
		case Calendar.TUESDAY:
			day_week = 2;
			break;
		case Calendar.WEDNESDAY:
			day_week = 3;
			break;
		case Calendar.THURSDAY:
			day_week = 4;
			break;
		case Calendar.FRIDAY:
			day_week = 5;
			break;
		case Calendar.SATURDAY:
			day_week = 6;
			break;
		}

		return day_week;
	}

	public static String addZeroforInt (int num) {
		String addZeronum;
		if (num < 10) {
			addZeronum = "0" + String.valueOf(num);
		} else {
			addZeronum = String.valueOf(num);
		}
		return addZeronum;
	}

	// コース時間用タイムスタップ変更メソッド
	public static String changeTimestampToString(Timestamp ts) {
		String str = null;
		try{
			str = new Timestamp(DateUtils.parseDate(ts.toString(), new String[] {"yyyy-MM-dd"}).getTime()).toString();
		}catch(Exception ex){}
		return str;
	}
}
