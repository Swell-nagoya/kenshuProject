package Validate;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Validate {

	// 各入力フォームのチェック用のクラス


	/**
	 * 年確認
	 * 2014-9999以外の文字が使われていた際にfalseを返す
	 * @param String
	 * 				num 数字
	 * @return boolean
	 */
	public static boolean isYear(String num){
		return !num.matches("[2014-9999]*");
	}

	/**
	 * 日付確認
	 * 0-31以外の文字が使われていた際にfalseを返す
	 * @param String
	 * 				num 数字
	 * @return boolean
	 */
	public static boolean isDay(String num){
		return !num.matches("[0-31]*");
	}

	/**
	 * 月確認
	 * 0-12以外の文字が使われていた際にfalseを返す
	 * @param String
	 * 				num 数字
	 * @return boolean
	 */
	public static boolean isMonth(String num){
		return !num.matches("[0-12]*");
	}


	/**
	 * 0-9以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            num 数字
	 * @return boolean
	 */
	public static boolean isNum(String num) {
		return !num.matches("[^0-9]*");
	}

	/**
	 * 0-1以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            num 数字
	 * @return boolean
	 */
	public static boolean isZeoOrOne(String num) {
		return !num.matches("[^0-1]*");
	}

	/**
	 * 指定の数字以外が使われていた際にfalseを返す
	 *
	 * @param int[] num 指定の数字
	 * @param String
	 *            request 入力された値
	 *
	 * @return boolean
	 */
	public static boolean checkNum(int[] num, String req_strvalue) {
		for (int i = 0; i < num.length; i++) {
			if (num[i] == Integer.parseInt(req_strvalue)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 半角カタカナ以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            kana カタカナ
	 * @return boolean
	 */
	public static boolean isKana(String kana) {

		return kana.matches("^[ｱ-ﾝﾞﾟｧ-ｫｬ-ｮｰ｡｢｣､]+$");
	}

	/**
	 * 全角以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            zennkaku 全角文字
	 * @return boolean
	 */
	public static boolean isZennkaku(String zennkaku) {

		return !zennkaku.matches("[^ -~｡-ﾟ\t]");
	}

	/**
	 * (進化版！) 全角以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            zennkaku 全角文字
	 * @return boolean
	 */
	public static boolean onlyZennkaku(String zennkaku) {
		int flg_error = 0;
		for (int i = 0; i < zennkaku.length(); i++) {
			char checkstr = zennkaku.charAt(i);
			if ((checkstr <= '\u007e') || // 英数字
					(checkstr == '\u00a5') || // \記号
					(checkstr == '\u203e') || // ~記号
					(checkstr >= '\uff61' && checkstr <= '\uff9f') // 半角カナ
			)
				flg_error = flg_error + 1;
		}
		if (flg_error > 0) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 半角以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            hannkaku 全角文字
	 * @return boolean
	 */
	public static boolean isHannkaku(String hannkaku) {

		return !hannkaku.matches("[ -~｡-ﾟ]");
	}

	/**
	 * 半角カタカナ以外の文字が使われていた際にfalseを返す
	 *
	 * @param String
	 *            kana カタカナ
	 * @return boolean
	 */
	public static boolean isMail(String mail) {

		return mail
				.matches("[0-9a-zA-Z_\\-]+@[0-9a-zA-Z_\\-]+(\\.[0-9a-zA-Z_\\-]+){1,}");
	}

	/**
	 * 日付が正しい形式であり、存在する日付であることを検証します。 ただし使う値のフォーマットは yyyy-MM-dd hh:mm:ssにしてください。
	 *
	 * @param date
	 *            日付を示す文字列 yyyy-MM-dd hh:mm:ss
	 * @return 正しい日付の場合はtrue、そうでない場合はfalseを返します。
	 */
	public static boolean isDate(String date) {
		// 日付の書式を指定する
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

		// 日付解析を厳密に行う設定にする
		df.setLenient(false);
		try {
		  // 日付妥当性OK
		  df.parse(date);
		} catch (ParseException e) {
		  // 日付妥当性NG時の処理を記述
			return false;
		}
		return true;
	}

}
