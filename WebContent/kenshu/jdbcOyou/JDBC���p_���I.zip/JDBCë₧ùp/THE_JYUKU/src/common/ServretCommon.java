package common;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CLS002Bean;

/**
 * サーブレットで使う共通機能
 * ここの機能を使う場合は使用する画面名をJAVADOCに記載すること
 * @author n-kuraoka
 *
 */
public class ServretCommon {

	/**
	 * リストに格納された授業から現在行われている授業のみリストに入れなおす
	 * TOP画面、時間割画面で使用
	 * @param cls002Beans
	 * @return 現在行われている授業
	 */
	public static boolean checkEnableLecture (CLS002Bean cls002Bean, int year, int month, int day) {

		if (	cls002Bean.getStart_lecture().before(new Date(year, month, day))
			||	cls002Bean.getEnd_lecture().after(new Date(year, month, day))) {
			return true;
		}
		return false;
	}

	/**
	 * LoginSessionが切れていないか確認し、切れていた場合にはエラー画面に遷移します。
	 * @param request
	 * @param response
	 * @param session
	 * @throws ServletException
	 * @throws IOException
	 * @throws LoginException 
	 */
	public static void checkLoginSession (HttpServletRequest request,
									HttpServletResponse response,
									HttpSession session) throws ServletException, IOException, LoginException {
		if (session.getAttribute("loginSession") == null) {
				throw new LoginException();
		}
	}
}
