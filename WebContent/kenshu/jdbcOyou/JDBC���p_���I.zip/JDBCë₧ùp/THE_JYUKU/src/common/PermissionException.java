package common;


public class PermissionException extends Exception {

	public PermissionException() {
		super();
		System.out.println("権限がありません");
	}

	public PermissionException(String message) {
		super(message);
	}

	public PermissionException(Throwable cause) {
		super(cause);
	}

	public PermissionException(String message, Throwable cause) {
		super(message, cause);
	}


}
