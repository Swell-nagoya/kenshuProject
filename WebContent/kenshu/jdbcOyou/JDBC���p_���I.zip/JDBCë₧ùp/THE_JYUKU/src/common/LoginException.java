package common;

import javax.servlet.ServletException;


public class LoginException extends ServletException {

	public LoginException() {
		super();
		System.out.println("セッションが切れています");
	}

	public LoginException(String message) {
		super(message);
	}

	public LoginException(Throwable cause) {
		super(cause);
	}

	public LoginException(String message, Throwable cause) {
		super(message, cause);
	}


}
