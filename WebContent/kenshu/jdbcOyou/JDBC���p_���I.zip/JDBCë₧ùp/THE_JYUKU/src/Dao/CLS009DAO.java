package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS009Bean;
import bean.Mst016_GetCourseMstBean;
import bean.Trn001_ReportTrnBean;

public class CLS009DAO extends ConnectionManager {


    private String createSQLTrn001_ReportTrn(String[] reqstrs) {
        Trn001_ReportTrnDAO reportTrnDAO = new Trn001_ReportTrnDAO();
        String sql = "select " + reportTrnDAO.join(reportTrnDAO.getColumns(), ", ") + " from " + reportTrnDAO.getTableName();
        sql += " where ";
        for (int i = 0;i < reqstrs.length; i++) {
            sql += " ID_COURSE = " + reqstrs.toString();
            if (i == reqstrs.length - 1) {
                sql += " or ";
            }
        }
        if (reqstrs.length == 0) {
            sql += " where ";
        } else {
            sql += " and ";
        }
        sql += "DATE_LECTURE =(select max(DATE_LECTURE) from" + reportTrnDAO.getTableName() + ")";

        return sql;
    }

    private String createSQLPersonalSubjectTimeTableFindByuser() {
        Mst016_GetCourseMstDAO mst016_GetCourseMstDAO = new Mst016_GetCourseMstDAO();
        Mst011_CourseMeisaiMstDAO mst011_CourseMeisaiMstDAO = new Mst011_CourseMeisaiMstDAO();
        Mst013_SubjectMstDAO mst013_SubjectMstDAO = new Mst013_SubjectMstDAO();
        Mst001_UserMstDAO mst001_UserMstDAO = new Mst001_UserMstDAO();
        Trn001_ReportTrnDAO reportTrnDAO = new Trn001_ReportTrnDAO();
        Trn002_HomeworkTrnDAO homeworkTrnDAO = new Trn002_HomeworkTrnDAO();
        StringBuffer stringBuffer = new StringBuffer();

        stringBuffer.append("select")
                    .append("	M016.ID_USER")
                    .append(",	M016.ID_COURSE")
                    .append(",	M013.NAME_SUBJECT")
                    .append(",	M011.DAY_LECTURE")
                    .append(",	M011.START_LECTURE")
                    .append(",	M011.END_LECTURE")
                    .append(",	M01.NAME_USER as NAME_TEACHER")
                    .append(",	T01.DATE_LECTURE")
                    .append(",	T01.FLG_DELETE")
                    .append(",	T01.REPORT")
                    .append(",	T02.HOMEWORK")
                .append("	from")
                .append("	" + mst016_GetCourseMstDAO.getTableName() +" M016")
                .append(" left join ")
                .append("	" + reportTrnDAO.getTableName() + " T01")
                .append(" on " + "M016.ID_COURSE")
                .append(" = ")
                .append(" T01.ID_COURSE")
                .append(",	" + mst013_SubjectMstDAO.getTableName() +" M013")
                .append(",	" + mst011_CourseMeisaiMstDAO.getTableName() +" M011")
                .append(" left join ")
                .append("	" + mst001_UserMstDAO.getTableName() + " M01")
                .append(" on " + "M011.ID_TEACHER")
                .append(" = ")
                .append(" M01.ID_USER")
                .append(",	" + homeworkTrnDAO.getTableName() + " T02")
                .append("	where")
                    .append("	M016.ID_COURSE = M011.ID_COURSE")
                .append("	and")
                    .append("	M011.ID_SUBJECT = M013.ID_SUBJECT")
                .append("	and")
                    .append("	T01.DATE_LECTURE =(select max(DATE_LECTURE) from " + reportTrnDAO.getTableName())
                            .append("	where ID_COURSE = ?)")
                .append("	and")
                    .append("	T01.DATE_LECTURE = T02.DATE_LECTURE")
                .append(" and ")
                    .append("	M016.ID_COURSE = T02.ID_COURSE")
                .append(" and ")
                    .append("	M016.ID_USER = ?")
                .append("	and")
                    .append("	M016.ID_COURSE = ?");

        System.out.println(stringBuffer.toString());
        return stringBuffer.toString();
    }

    public String createSQLForId_UserofChildren() {
        Mst002_StudentMstDAO studentMstDAO = new Mst002_StudentMstDAO();

        StringBuffer sql = new StringBuffer();
        sql.append("select ID_USER from ")
        .append(studentMstDAO.getTableName())
        .append(" where ")
        .append("ID_FAMILY=?");
        return sql.toString();
    }
    /**
     * 保護者のファミリーIDから子供のIDを取得する。
     * @return　子供のIDリスト
     */
    public List<String> getId_UserofChildren(String id_Family) {
        List<String> list = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;

        sql = createSQLForId_UserofChildren();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, id_Family);
            rs = stmt.executeQuery();

            while (rs.next()) {
                String id_user = rs.getString("ID_USER");
                list.add(id_user);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return list;
    }
    /**
     * 指定ユーザID&コースIDの保護者向けレポートに必要な情報を取得する。
     *
     * 	 * @param id_user
     * @return 時間割用リスト
     */
    public CLS009Bean PersonalSubjectTimeTableFindByUser(String id_user , Mst016_GetCourseMstBean mst016_GetCourseMstBean) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        CLS009Bean bean = null;

        sql = createSQLPersonalSubjectTimeTableFindByuser();
        System.out.println(sql);

        try {
            stmt = getConnection().prepareStatement(sql);
            stmt.setString(1, mst016_GetCourseMstBean.getid_course());
            stmt.setString(2, id_user);
            stmt.setString(3, mst016_GetCourseMstBean.getid_course());
            rs = stmt.executeQuery();

            if (rs.next()) {
                bean = new CLS009Bean();
                bean.setId_user(rs.getString("ID_USER"));
                bean.setId_cource(rs.getString("ID_COURSE"));
                bean.setName_teacher(rs.getString("NAME_TEACHER"));
                bean.setName_subject(rs.getString("NAME_SUBJECT"));
                bean.setDate_lecture(rs.getTimestamp("DATE_LECTURE"));
                bean.setStart_lecture(rs.getTimestamp("START_LECTURE"));
                bean.setEnd_lecture(rs.getTimestamp("END_LECTURE"));
                bean.setFlg_delete(rs.getInt("FLG_DELETE"));
                bean.setReport(rs.getString("REPORT"));
                bean.setHomework(rs.getString("HOMEWORK"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return bean;
    }

    public List<Trn001_ReportTrnBean> listTrn001_ReportTrn(List<CLS009Bean> beans) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = null;
        List<Trn001_ReportTrnBean> reportTrnBeans = new ArrayList<>();
        String[] palams = new String[beans.size()];
        for (int i = 0; i < beans.size(); i++) {
            palams[i] = (beans.get(i).getId_cource());
        }
        sql = createSQLTrn001_ReportTrn(palams);
        System.out.println(sql);
        try {
            stmt = getConnection().prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                Trn001_ReportTrnBean bean = new Trn001_ReportTrnBean();
                bean.setid_course(rs.getString("ID_COURSE"));
                bean.setreport(rs.getString("REPORT"));
                bean.setdate_lecture(rs.getTimestamp("DATE_LECTURE"));
                reportTrnBeans.add(bean);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }


        }
        return reportTrnBeans;
    }

}