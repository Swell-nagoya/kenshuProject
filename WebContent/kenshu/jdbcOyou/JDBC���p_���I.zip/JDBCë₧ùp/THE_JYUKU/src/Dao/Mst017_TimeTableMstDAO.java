package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Mst017_TimeTableMstBean;

public class Mst017_TimeTableMstDAO extends DataAccessObject {

		/**
		 * ?o?^???????s??????B
		 * @param Mst017_TimeTableMst mst017_timetablemst
		 */
		public void create(Mst017_TimeTableMstBean mst017_timetablemst) {
			update(createSQLForCreate(),
				new Object[] {
				mst017_timetablemst.getday_lecture()
				,mst017_timetablemst.gettimetable_lecture()
				,mst017_timetablemst.getstart_lecture()
				,mst017_timetablemst.getend_lecture()
				,mst017_timetablemst.getflg_delete()
				,mst017_timetablemst.getid_lastupdate()
				,mst017_timetablemst.getdate_lastupdate()
				});
		}

		/**
		 * ?X?V???????s??????B
		 * @param Mst017_TimeTableMst mst017_timetablemst
		 */
		public void update(Mst017_TimeTableMstBean mst017_timetablemst) {
			update(createSQLForUpdate(),
				new Object[] {
				mst017_timetablemst.getday_lecture()
				,mst017_timetablemst.gettimetable_lecture()
				,mst017_timetablemst.getstart_lecture()
				,mst017_timetablemst.getend_lecture()
				,mst017_timetablemst.getflg_delete()
				,mst017_timetablemst.getid_lastupdate()
				,mst017_timetablemst.getdate_lastupdate()
				});
		}

		/**
		 * ??L?[???????s??????B
		 * @param DAY_LECTURE ?j??
		 * @return DAY_LECTURE
		 * @param TIMETABLE_LECTURE ?????
		 * @return TIMETABLE_LECTURE
		 */
		public Mst017_TimeTableMstBean findByPrimaryKey(java.lang.Integer userno) {
			return (Mst017_TimeTableMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst017_TimeTableMstBean.class);
		}

		@Override
		public String[] getPKColumns() {
			return new String[] {"DAY_LECTURE","TIMETABLE_LECTURE"};
		}

		@Override
		public String[] getColumns() {
			return new String[] {"DAY_LECTURE"
				,"TIMETABLE_LECTURE"
				,"START_LECTURE"
				,"END_LECTURE"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};
		}

		@Override
		public String getTableName() {
			return "MST017_TIMETABLEMST";
		}

		public String createSQLForSerchGIKANWARI(){

			String sql="SELECT TIMETABLE_LECTURE FROM MST017_TIMETABLEMST GROUP BY TIMETABLE_LECTURE";
			return sql;
		}
		public List<Integer> createSQLForGIKANWARI() {

			String sql = createSQLForSerchGIKANWARI();
			PreparedStatement stmt= null;
			ResultSet rs = null;
			List<Integer> list = new ArrayList<Integer>();

			try {
				stmt = getConnection().prepareStatement(sql);

				rs = stmt.executeQuery();
				while(rs.next()) {
					list.add(rs.getInt("TIMETABLE_LECTURE"));
				}
			} catch (SQLException exception) {
				throw new RuntimeException(exception);
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
			}
		return list;
		}

}
