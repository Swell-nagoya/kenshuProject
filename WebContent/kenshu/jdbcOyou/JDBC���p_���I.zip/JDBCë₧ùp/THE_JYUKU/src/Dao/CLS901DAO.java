package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import bean.CLS901Bean;
import bean.Mst010_CourseMstBean;
import bean.Mst011_CourseMeisaiMstBean;
import bean.Mst017_TimeTableMstBean;
import bean.Mst020_ConstantMstBean;
import bean.Trn001_ReportTrnBean;
import bean.Trn002_HomeworkTrnBean;
import bean.Trn004_SmalltestTrnBean;
import bean.Trn010_AttendanceTrnBean;

public class CLS901DAO extends ConnectionManager {

	public PreparedStatement stmt= null;
	public ResultSet rs = null;
	Mst020_ConstantMstBean mst020_bean = null;
	Mst017_TimeTableMstBean mst017_bean = null;

	private String id_course;
	private Timestamp start_lecture;
	private Timestamp end_lecture;


	private int target;
	private int day_lecture;
	private Timestamp start_time_lecture;
	private Timestamp end_time_lecture;
	private Timestamp date_lastupdate;

	public List<CLS901Bean>  SearchJisseki(CLS901Bean cls901d){

		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = null;

		//取得するパラメータ
		List<CLS901Bean> list = new ArrayList<CLS901Bean>();

		//検索対象のカラム
		List<String> palam = new ArrayList<String>();

		//検索対象のパラメータ
		List<Object> value = new ArrayList<Object>();

		//Beanの作成
		Mst010_CourseMstBean mst010_coursemst = cls901d.getMst010_CourseMstBean();
		Mst011_CourseMeisaiMstBean mst011_coursemeisaimst = cls901d.getMst011_CourseMeisaiMstBean();
		Trn001_ReportTrnBean trn001_reporttrn = null;
		Trn002_HomeworkTrnBean trn002_homeworktrn = null;
		Trn004_SmalltestTrnBean trn004_smalltesttrn = null;
		Trn010_AttendanceTrnBean trn010_attendancetrn = null;

		if (mst010_coursemst.getid_course() != null) {
			id_course = mst010_coursemst.getid_course();
			palam.add("MST010_COURSEMST.ID_COURSE");
			value.add(id_course);
		}
		if (mst011_coursemeisaimst.gettarget() != 0) {
			target = mst011_coursemeisaimst.gettarget();
			palam.add("MST011_COURSEMEISAIMST.TARGET");
			value.add(target);
		}
		if (mst011_coursemeisaimst.getday_lecture() != -1) {
			day_lecture = mst011_coursemeisaimst.getday_lecture();
			palam.add("MST011_COURSEMEISAIMST.DAY_LECTURE");
			value.add(day_lecture);
		}
		if (mst011_coursemeisaimst.getstart_time_lecture() != null ) {
			start_time_lecture = mst011_coursemeisaimst.getstart_time_lecture();
			palam.add("MST011_COURSEMEISAIMST.START_TIME_LECTURE");
			value.add(start_time_lecture);
		}
		if (mst011_coursemeisaimst.getend_time_lecture() != null ) {
			end_time_lecture = mst011_coursemeisaimst.getend_time_lecture();
			palam.add("MST011_COURSEMEISAIMST.END_TIME_LECTURE");
			value.add(end_time_lecture);
		}
		if (mst011_coursemeisaimst.getdate_lastupdate() != null) {
			date_lastupdate = mst011_coursemeisaimst.getdate_lastupdate();
			palam.add("MST011_COURSEMEISAIMST.DATE_LASTUPDATE");
			value.add(date_lastupdate);
		}
		//削除フラグ
		palam.add("TRN001_REPORTTRN.FLG_DELETE");
		value.add(0);

		//開催日のフラグ
		boolean between_flag = false;
		if (mst011_coursemeisaimst.getstart_lecture() != null) {
			start_lecture = mst011_coursemeisaimst.getstart_lecture();
			between_flag=true;
			value.add(start_lecture);
		}

		//開催日
//				palam.add("DATE_LECTURE");
//				value.add();

		sql = createSQLForSearchJisseki(palam,between_flag);

		System.out.println(sql);
		try {
			stmt = getConnection().prepareStatement(sql);

			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}

			rs = stmt.executeQuery();

			while (rs.next()) {
				CLS901Bean cls901d2 = new CLS901Bean();
				mst010_coursemst = new Mst010_CourseMstBean();
				mst011_coursemeisaimst = new Mst011_CourseMeisaiMstBean();
				trn001_reporttrn = new Trn001_ReportTrnBean();
				trn002_homeworktrn = new Trn002_HomeworkTrnBean();
				trn004_smalltesttrn = new Trn004_SmalltestTrnBean();
				trn010_attendancetrn = new Trn010_AttendanceTrnBean();

				mst010_coursemst.setid_course(rs.getString("ID_COURSE"));
				mst010_coursemst.setname_course(rs.getString("NAME_COURSE"));
				mst010_coursemst.setstart_lecture(rs.getTimestamp("START_LECTURE"));
				mst010_coursemst.setend_lecture(rs.getTimestamp("END_LECTURE"));
				mst010_coursemst.settuition(rs.getInt("TUITION"));
				mst010_coursemst.setdetails_course(rs.getString("DETAILS_COURSE"));
				mst010_coursemst.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst010_coursemst.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
				mst011_coursemeisaimst.setid_course(rs.getString("ID_COURSE"));
				mst011_coursemeisaimst.settarget(rs.getInt("TARGET"));
				mst011_coursemeisaimst.setid_subject(rs.getString("ID_SUBJECT"));
				mst011_coursemeisaimst.setday_lecture(rs.getInt("DAY_LECTURE"));
				mst011_coursemeisaimst.setstart_time_lecture(rs.getTimestamp("START_TIME_LECTURE"));
				mst011_coursemeisaimst.setend_time_lecture(rs.getTimestamp("END_TIME_LECTURE"));
				mst011_coursemeisaimst.setstart_lecture(rs.getTimestamp("START_LECTURE"));
				mst011_coursemeisaimst.setend_lecture(rs.getTimestamp("END_LECTURE"));
				mst011_coursemeisaimst.setid_teacher(rs.getString("ID_TEACHER"));
				mst011_coursemeisaimst.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst011_coursemeisaimst.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));

				trn001_reporttrn.setdate_lecture(rs.getTimestamp("DATE_LECTURE"));
				trn001_reporttrn.setreport(rs.getString("REPORT"));
				trn002_homeworktrn.setHomework(rs.getString("HOMEWORK"));
				trn004_smalltesttrn.setid_user(rs.getString("ID_USER"));
				trn010_attendancetrn.setid_user(rs.getString("ID_USER"));
				cls901d2.setMst010_CourseMstBean(mst010_coursemst);
				cls901d2.setMst011_CourseMeisaiMstBean(mst011_coursemeisaimst);
				cls901d2.setTrn001_ReportTrnBean(trn001_reporttrn);
				cls901d2.setTrn002_HomeworkTrnBean(trn002_homeworktrn);
				cls901d2.setTrn004_SmalltestTrnBean(trn004_smalltesttrn);
				cls901d2.setTrn010_AttendanceTrnBean(trn010_attendancetrn);
				list.add(cls901d2);
			}

		return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	public List<CLS901Bean>  Search(CLS901Bean cls901d){

		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = null;
		Mst010_CourseMstBean mst010_coursemst = null;
		Mst011_CourseMeisaiMstBean mst011_coursemeisaimst = null;
		//取得するパラメータ
		List<CLS901Bean> list = new ArrayList<CLS901Bean>();

		//検索対象のカラム
		List<String> palam = new ArrayList<String>();

		//検索対象のパラメータ
		List<Object> value = new ArrayList<Object>();

		mst010_coursemst = cls901d.getMst010_CourseMstBean();
		mst011_coursemeisaimst = cls901d.getMst011_CourseMeisaiMstBean();

		if (mst010_coursemst.getid_course() != null) {
			id_course = mst010_coursemst.getid_course();
			palam.add("MST010_COURSEMST.ID_COURSE");
			value.add(id_course);
		}
		if (mst011_coursemeisaimst.gettarget() != 0) {
			target = mst011_coursemeisaimst.gettarget();
			palam.add("TARGET");
			value.add(target);
		}
		if (mst011_coursemeisaimst.getday_lecture() != -1) {
			day_lecture = mst011_coursemeisaimst.getday_lecture();
			palam.add("DAY_LECTURE");
			value.add(day_lecture);
		}
		if (mst011_coursemeisaimst.getstart_time_lecture() != null) {
			start_time_lecture = mst011_coursemeisaimst.getstart_time_lecture();
			palam.add("START_TIME_LECTURE");
			value.add(start_time_lecture);
		}
		if (mst011_coursemeisaimst.getend_time_lecture() != null) {
			end_time_lecture = mst011_coursemeisaimst.getend_time_lecture();
			palam.add("END_TIMET_LECTURE");
			value.add(end_time_lecture);
		}

		//開催日のフラグ
		boolean between_flag = false;
		if (mst011_coursemeisaimst.getstart_lecture() != null) {
			start_lecture = mst011_coursemeisaimst.getstart_lecture();
			between_flag=true;
			value.add(start_lecture);
			value.add(start_lecture);
		}

		sql = createSQLForSearch(palam,between_flag);

		System.out.println(sql);
		try {
			stmt = getConnection().prepareStatement(sql);

			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}

			rs = stmt.executeQuery();

			while (rs.next()) {
				CLS901Bean cls901d2 = new CLS901Bean();
				mst010_coursemst = new Mst010_CourseMstBean();
				mst011_coursemeisaimst = new Mst011_CourseMeisaiMstBean();

				mst010_coursemst.setid_course(rs.getString("ID_COURSE"));
				mst010_coursemst.setname_course(rs.getString("NAME_COURSE"));
				mst010_coursemst.setstart_lecture(rs.getTimestamp("START_LECTURE"));
				mst010_coursemst.setend_lecture(rs.getTimestamp("END_LECTURE"));
				mst010_coursemst.settuition(rs.getInt("TUITION"));
				mst010_coursemst.setdetails_course(rs.getString("DETAILS_COURSE"));
				mst010_coursemst.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst010_coursemst.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
				mst011_coursemeisaimst.setid_course(rs.getString("ID_COURSE"));
				mst011_coursemeisaimst.settarget(rs.getInt("TARGET"));
				mst011_coursemeisaimst.setid_subject(rs.getString("ID_SUBJECT"));
				mst011_coursemeisaimst.setday_lecture(rs.getInt("DAY_LECTURE"));
				mst011_coursemeisaimst.setstart_time_lecture(rs.getTimestamp("START_TIME_LECTURE"));
				mst011_coursemeisaimst.setend_time_lecture(rs.getTimestamp("END_TIME_LECTURE"));
				mst011_coursemeisaimst.setstart_lecture(rs.getTimestamp("START_LECTURE"));
				mst011_coursemeisaimst.setend_lecture(rs.getTimestamp("END_LECTURE"));
				mst011_coursemeisaimst.setid_teacher(rs.getString("ID_TEACHER"));
				mst011_coursemeisaimst.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst011_coursemeisaimst.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
				cls901d2.setMst010_CourseMstBean(mst010_coursemst);
				cls901d2.setMst011_CourseMeisaiMstBean(mst011_coursemeisaimst);

				list.add(cls901d2);
			}

		return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}


		}


	}

	public String createSQLForSearchJisseki(List<String> palam,boolean between_flag){

		Mst010_CourseMstDAO mst010_coursemstdao = new Mst010_CourseMstDAO();
		Mst011_CourseMeisaiMstDAO mst011_coursemeisaimstdao = new Mst011_CourseMeisaiMstDAO();
		Trn001_ReportTrnDAO trn001_reporttrndao = new Trn001_ReportTrnDAO();;
		Trn002_HomeworkTrnDAO trn002_homeworktrndao = new Trn002_HomeworkTrnDAO();
		Trn004_SmalltestTrnDAO trn004_smalltesttrndao = new Trn004_SmalltestTrnDAO();
		Trn010_AttendanceTrnDAO trn010_Attendancetrndao = new Trn010_AttendanceTrnDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(mst010_coursemstdao.getTableName(), ".", mst010_coursemstdao.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(mst011_coursemeisaimstdao.getTableName(), ".", mst011_coursemeisaimstdao.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(trn001_reporttrndao.getTableName(), ".", trn001_reporttrndao.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(trn002_homeworktrndao.getTableName(), ".", trn002_homeworktrndao.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(trn004_smalltesttrndao.getTableName(), ".", trn004_smalltesttrndao.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(trn010_Attendancetrndao.getTableName(), ".", trn010_Attendancetrndao.getColumns()), ", "));
		sb.append(" from ((((");
		sb.append(mst010_coursemstdao.getTableName());
		sb.append(" left join ");
		sb.append(mst011_coursemeisaimstdao.getTableName());
		sb.append(" on ");
		sb.append(mst010_coursemstdao.getTableName() + "." + mst010_coursemstdao.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(mst011_coursemeisaimstdao.getTableName() + "." + mst011_coursemeisaimstdao.getPKColumns()[0]+") ");
		sb.append(" left join ");
		sb.append(trn001_reporttrndao.getTableName());
		sb.append(" on ");
		sb.append(mst011_coursemeisaimstdao.getTableName() + "." + mst011_coursemeisaimstdao.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(trn001_reporttrndao.getTableName() + "." + trn001_reporttrndao.getPKColumns()[0]+") ");
		sb.append(" left join ");
		sb.append(trn002_homeworktrndao.getTableName());
		sb.append(" on ");
		sb.append(trn001_reporttrndao.getTableName() + "." + trn001_reporttrndao.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(trn002_homeworktrndao.getTableName() + "." + trn002_homeworktrndao.getPKColumns()[0]);
		sb.append(" AND ");
		sb.append(trn001_reporttrndao.getTableName() + "." + trn001_reporttrndao.getPKColumns()[1]);
		sb.append(" = ");
		sb.append(trn002_homeworktrndao.getTableName() + "." + trn002_homeworktrndao.getPKColumns()[1]+") ");
		sb.append(" left join ");
		sb.append(trn004_smalltesttrndao.getTableName());
		sb.append(" on ");
		sb.append(trn002_homeworktrndao.getTableName() + "." + trn002_homeworktrndao.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(trn004_smalltesttrndao.getTableName() + "." + trn004_smalltesttrndao.getPKColumns()[0]+") ");
		sb.append(" left join ");
		sb.append(trn010_Attendancetrndao.getTableName());
		sb.append(" on ");
		sb.append(trn004_smalltesttrndao.getTableName() + "." + trn004_smalltesttrndao.getPKColumns()[2]);
		sb.append(" = ");
		sb.append(trn010_Attendancetrndao.getTableName() + "." + trn010_Attendancetrndao.getPKColumns()[0]);

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		if(between_flag){
			sb.append(" AND " + trn001_reporttrndao.getTableName() + ".DATE_LECTURE >= ? ");
		}
		sb.append(" GROUP BY ");
		sb.append(trn001_reporttrndao.getTableName() + "." + trn001_reporttrndao.getPKColumns()[1]);
		sb.append(" ORDER BY ");
		sb.append(trn001_reporttrndao.getTableName() + "." + "DATE_LECTURE DESC,");
		sb.append(mst011_coursemeisaimstdao.getTableName() + "." + "START_TIME_LECTURE");

		return sb.toString();
	}

	public String createSQLForSearch(List<String> palam,boolean between_flag) {

		Mst010_CourseMstDAO mst010_coursemstdao = new Mst010_CourseMstDAO();
		Mst011_CourseMeisaiMstDAO mst011_coursemeisaimstdao = new Mst011_CourseMeisaiMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(mst010_coursemstdao.getTableName(), ".", mst010_coursemstdao.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst010_coursemstdao.join(mst010_coursemstdao.add(mst011_coursemeisaimstdao.getTableName(), ".", mst011_coursemeisaimstdao.getColumns()), ", "));
		sb.append(" from ");
		sb.append(mst010_coursemstdao.getTableName());
		sb.append(" inner join ");
		sb.append(mst011_coursemeisaimstdao.getTableName());
		sb.append(" on ");
		sb.append(mst010_coursemstdao.getTableName() + "." + mst010_coursemstdao.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(mst011_coursemeisaimstdao.getTableName() + "." + mst011_coursemeisaimstdao.getPKColumns()[0]);

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		if(between_flag){
			sb.append(" AND " + mst011_coursemeisaimstdao.getTableName() + ".START_LECTURE < ? AND " + mst011_coursemeisaimstdao.getTableName() + ".END_LECTURE > ?");
		}
		sb.append(" order by ");
		sb.append(mst011_coursemeisaimstdao.getTableName() + "." + "DAY_LECTURE,");
		sb.append(mst011_coursemeisaimstdao.getTableName() + "." + "START_TIME_LECTURE");
		return sb.toString();

	}
}

