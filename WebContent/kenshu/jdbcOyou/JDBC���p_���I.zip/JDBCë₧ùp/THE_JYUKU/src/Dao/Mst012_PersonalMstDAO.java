package Dao;

import bean.Mst012_PersonalMstBean;

public class Mst012_PersonalMstDAO extends DataAccessObject {

		/**
		 * ?o?^???????s??????B
		 * @param Mst012_PersonalMst mst012_personalmst
		 */
		public void create(Mst012_PersonalMstBean mst012_personalmst) {
			update(createSQLForCreate(),
				new Object[] {
				mst012_personalmst.getid_user()
				,mst012_personalmst.getid_subject1()
				,mst012_personalmst.getday_lecture1()
				,mst012_personalmst.getstart_time_lecture1()
				,mst012_personalmst.getend_time_lecture1()
				,mst012_personalmst.getid_subject2()
				,mst012_personalmst.getday_lecture2()
				,mst012_personalmst.getstart_time_lecture2()
				,mst012_personalmst.getend_time_lecture2()
				,mst012_personalmst.getid_subject3()
				,mst012_personalmst.getday_lecture3()
				,mst012_personalmst.getstart_time_lecture3()
				,mst012_personalmst.getend_time_lecture3()
				,mst012_personalmst.getid_subject4()
				,mst012_personalmst.getday_lecture4()
				,mst012_personalmst.getstart_time_lecture4()
				,mst012_personalmst.getend_time_lecture4()
				,mst012_personalmst.getid_subject5()
				,mst012_personalmst.getday_lecture5()
				,mst012_personalmst.getstart_time_lecture5()
				,mst012_personalmst.getend_time_lecture5()
				,mst012_personalmst.getflg_delete()
				,mst012_personalmst.getid_lastupdate()
				,mst012_personalmst.getdate_lastupdate()
				});
		}

		/**
		 * ?X?V???????s??????B
		 * @param Mst012_PersonalMst mst012_personalmst
		 */
		public void update(Mst012_PersonalMstBean mst012_personalmst) {
			update(createSQLForUpdate(),
				new Object[] {
				mst012_personalmst.getid_user()
				,mst012_personalmst.getid_subject1()
				,mst012_personalmst.getday_lecture1()
				,mst012_personalmst.getstart_time_lecture1()
				,mst012_personalmst.getend_time_lecture1()
				,mst012_personalmst.getid_subject2()
				,mst012_personalmst.getday_lecture2()
				,mst012_personalmst.getstart_time_lecture2()
				,mst012_personalmst.getend_time_lecture2()
				,mst012_personalmst.getid_subject3()
				,mst012_personalmst.getday_lecture3()
				,mst012_personalmst.getstart_time_lecture3()
				,mst012_personalmst.getend_time_lecture3()
				,mst012_personalmst.getid_subject4()
				,mst012_personalmst.getday_lecture4()
				,mst012_personalmst.getstart_time_lecture4()
				,mst012_personalmst.getend_time_lecture4()
				,mst012_personalmst.getid_subject5()
				,mst012_personalmst.getday_lecture5()
				,mst012_personalmst.getstart_time_lecture5()
				,mst012_personalmst.getend_time_lecture5()
				,mst012_personalmst.getflg_delete()
				,mst012_personalmst.getid_lastupdate()
				,mst012_personalmst.getdate_lastupdate()
				});
		}

		/**
		 * ??L?[???????s??????B
		 * @param ID_USER ???[?UID
		 * @return ID_USER
		 */
		public Mst012_PersonalMstBean findByPrimaryKey(java.lang.Integer userno) {
			return (Mst012_PersonalMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst012_PersonalMstBean.class);
		}

		@Override
		public String[] getPKColumns() {
			return new String[] {"ID_USER"};
		}

		@Override
		public String[] getColumns() {
			return new String[] {"ID_USER"
				,"ID_SUBJECT1"
				,"DAY_LECTURE1"
				,"START_TIMETABLE_LECTURE1"
				,"END_TIMETABLE_LECTURE1"
				,"ID_SUBJECT2"
				,"DAY_LECTURE2"
				,"START_TIMETABLE_LECTURE2"
				,"END_TIMETABLE_LECTURE2"
				,"ID_SUBJECT3"
				,"DAY_LECTURE3"
				,"START_TIMETABLE_LECTURE3"
				,"END_TIMETABLE_LECTURE3"
				,"ID_SUBJECT4"
				,"DAY_LECTURE4"
				,"START_TIMETABLE_LECTURE4"
				,"END_TIMETABLE_LECTURE4"
				,"ID_SUBJECT5"
				,"DAY_LECTURE5"
				,"START_TIMETABLE_LECTURE5"
				,"END_TIMETABLE_LECTURE5"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};
		}

		@Override
		public String getTableName() {
			return "MST012_PERSONALMST";
		}

}
