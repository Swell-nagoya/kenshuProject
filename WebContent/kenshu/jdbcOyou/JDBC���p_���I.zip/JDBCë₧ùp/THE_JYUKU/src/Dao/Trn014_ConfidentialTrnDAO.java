package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Trn014_ConfidentialTrnBean;

public class Trn014_ConfidentialTrnDAO extends DataAccessObject {

	/**
	 * PKで検索するSQL
	 */
	String SQL_FIND_BY_PK =
			"select " +
					join(getColumns(),",") +
			" from " +
				getTableName() +
			" where " +
				"ID_USER=?" +
			" and " +
				"FISCAL_YEAR=?" +
			" and " +
				"TIMES=?";

	/**
	 * 登録処理を行います。
	 * @param Trn014_ConfidentialTrnBean Trn014_ConfidentialTrnBean
	 */
	public void create(Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean) {
		update(createSQLForCreate(),
			new Object[] {
			trn014_ConfidentialTrnBean.getid_user()
			,trn014_ConfidentialTrnBean.getfiscal_year()
			,trn014_ConfidentialTrnBean.gettimes()
			,trn014_ConfidentialTrnBean.gettype_evaluation()
			,trn014_ConfidentialTrnBean.getconf_jap()
			,trn014_ConfidentialTrnBean.getconf_math()
			,trn014_ConfidentialTrnBean.getconf_siec()
			,trn014_ConfidentialTrnBean.getconf_scty()
			,trn014_ConfidentialTrnBean.getconf_eng()
			,trn014_ConfidentialTrnBean.getconf_tech()
			,trn014_ConfidentialTrnBean.getconf_gmst()
			,trn014_ConfidentialTrnBean.getconf_music()
			,trn014_ConfidentialTrnBean.getconf_arts()
			,trn014_ConfidentialTrnBean.getflg_delete()
			,trn014_ConfidentialTrnBean.getid_lastupdate()
			,trn014_ConfidentialTrnBean.getdate_lastupdate()
			});
	}

	/**
	 * 更新処理を行います。
	 * @param trn014_confidentialtrn trn014_confidentialtrn
	 */
	public void update(Trn014_ConfidentialTrnBean trn014_confidentialtrn) {
		update(createSQLForUpdate(),
			new Object[] {
			trn014_confidentialtrn.getid_user()
			,trn014_confidentialtrn.getfiscal_year()
			,trn014_confidentialtrn.gettimes()
			,trn014_confidentialtrn.gettype_evaluation()
			,trn014_confidentialtrn.getconf_jap()
			,trn014_confidentialtrn.getconf_math()
			,trn014_confidentialtrn.getconf_siec()
			,trn014_confidentialtrn.getconf_scty()
			,trn014_confidentialtrn.getconf_eng()
			,trn014_confidentialtrn.getconf_tech()
			,trn014_confidentialtrn.getconf_gmst()
			,trn014_confidentialtrn.getconf_music()
			,trn014_confidentialtrn.getconf_arts()
			,trn014_confidentialtrn.getflg_delete()
			,trn014_confidentialtrn.getid_lastupdate()
			,trn014_confidentialtrn.getdate_lastupdate()
			,trn014_confidentialtrn.getid_user()
			,trn014_confidentialtrn.getfiscal_year()
			,trn014_confidentialtrn.gettimes()
			});
	}

	/**
	 * 主キー検索を行います。
	 * @param ID_USER ユーザーID
	 * @param FISCAL_YEAR 年度
	 * @param TIMES 回次
	 * @return Trn014_ConfidentialTrnBean
	 */
	public Trn014_ConfidentialTrnBean findByPrimaryKey(java.lang.Integer userno) {
		return (Trn014_ConfidentialTrnBean) query(createSQLForFindByPK(), new Object[]{userno}, Trn014_ConfidentialTrnBean.class);
	}

	@Override
	public String[] getPKColumns() {
		return new String[] {"ID_USER"
				,"FISCAL_YEAR"
				,"TIMES"
				};
	}

	@Override
	public String[] getColumns() {
		return new String[] {"ID_USER"
			,"FISCAL_YEAR"
			,"TIMES"
			,"TYPE_EVALUATION"
			,"CONF_JAP"
			,"CONF_MATH"
			,"CONF_SIEC"
			,"CONF_SCTY"
			,"CONF_ENG"
			,"CONF_TECH"
			,"CONF_GMST"
			,"CONF_MUSIC"
			,"CONF_ARTS"
			,"FLG_DELETE"
			,"ID_LASTUPDATE"
			,"DATE_LASTUPDATE"
		};
	}

	@Override
	public String getTableName() {
		return "TRN014_CONFIDENTIALTRN";
	}

	/**
	 * キーで一致する行を取得します。
	 * @param user_id
	 * @param fiscal_year
	 * @param times
	 * @return Trn014_ConfidentialTrnBean
	 */
	public Trn014_ConfidentialTrnBean findByKey(String id_user
													,int  fiscal_year
													,int times
													) {

		Trn014_ConfidentialTrnBean trn014_confidentialtrnBean = new Trn014_ConfidentialTrnBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_FIND_BY_PK);
			System.out.println(SQL_FIND_BY_PK);
			System.out.println("id:" + id_user);
			System.out.println("fiscal_year:" + fiscal_year);
			System.out.println("times:" + times);
			fillPreparedStatement(stmt, 1, id_user);
			fillPreparedStatement(stmt, 2, fiscal_year);
			fillPreparedStatement(stmt, 3, times);

			rs = stmt.executeQuery();

			if (rs.next()) {
				trn014_confidentialtrnBean.setid_user(rs.getString("ID_USER"));
				trn014_confidentialtrnBean.setfiscal_year(rs.getInt("FISCAL_YEAR"));
				trn014_confidentialtrnBean.settimes(rs.getInt("TIMES"));
				trn014_confidentialtrnBean.settype_evaluation(rs.getInt("TYPE_EVALUATION"));
				trn014_confidentialtrnBean.setconf_jap(rs.getInt("CONF_JAP"));
				trn014_confidentialtrnBean.setconf_math(rs.getInt("CONF_MATH"));
				trn014_confidentialtrnBean.setconf_siec(rs.getInt("CONF_SIEC"));
				trn014_confidentialtrnBean.setconf_scty(rs.getInt("CONF_SCTY"));
				trn014_confidentialtrnBean.setconf_eng(rs.getInt("CONF_ENG"));
				trn014_confidentialtrnBean.setconf_tech(rs.getInt("CONF_TECH"));
				trn014_confidentialtrnBean.setconf_gmst(rs.getInt("CONF_GMST"));
				trn014_confidentialtrnBean.setconf_music(rs.getInt("CONF_MUSIC"));
				trn014_confidentialtrnBean.setconf_arts(rs.getInt("CONF_ARTS"));
				trn014_confidentialtrnBean.setflg_delete(rs.getInt("FLG_DELETE"));
				trn014_confidentialtrnBean.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				trn014_confidentialtrnBean.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
			};

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return trn014_confidentialtrnBean;
	}
}
