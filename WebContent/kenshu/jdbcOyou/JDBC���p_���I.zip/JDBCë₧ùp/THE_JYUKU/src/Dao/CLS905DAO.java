package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS905_SearchBean;
import bean.CLS905_SearchResultBean;


public class CLS905DAO extends DataAccessObject implements ITestDao {

	public static final CLS905DAO instance = new CLS905DAO();

	public static CLS905DAO getInstance() {
		return instance;
	}

	@Override
	public String[] getPKColumns() {
		return new String[] {
				"ID_USER",
				"FISCAL_YEAR",
				"TIMES"
		};
	}

	@Override
	public String[] getColumns() {
		return new String[] {
				"ID_TEST",
				"FISCAL_YEAR",
				"TIMES",
				"TEST_TYPE",
				"DATE_HOLD",
				"AVERAGE_JAP",
				"AVERAGE_MATH",
				"AVERAGE_SIEC",
				"AVERAGE_SCTY",
				"AVERAGE_ENG",
				"FLG_DELETE",
				"ID_LASTUPDATE",
				"DATE_LASTUPDATE"
		};
	}

	@Override
	public String getTableName() {
		return "TRN015_TESTTRN";
	}

	@Override
	public List<? extends Object> getTestResult(Object info) {

		// テスト検索SQLの作成
		StringBuffer selectQuery =
				new StringBuffer("SELECT ")
							.append(CLS905DAO.getInstance().join(instance.getColumns(),","))
							.append(" FROM ")
							.append(instance.getTableName())
							.append(" WHERE 1 ")
							.append("AND ")
							.append("FLG_DELETE = 0 ")
							.append("AND ")
							.append("(`DATE_HOLD` >= ? OR ?='') ")
							.append("AND ")
							.append("(`DATE_HOLD` <= ? OR ? = '') ")
							.append("AND ")
							.append("(`ID_TEST` = ? OR ? = '') ")
							.append("AND ")
							.append("(`TIMES` = ? OR ? = '') ")
							.append(" ORDER BY ID_TEST, FISCAL_YEAR;");

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		List<CLS905_SearchResultBean> list = null;

		ResultSet set = null;

		try (PreparedStatement state = conn.prepareStatement(selectQuery.toString())) {

			CLS905_SearchBean searchInfo = (CLS905_SearchBean) info;

			state.setString(1, searchInfo.getStart());
			state.setString(2, searchInfo.getStart());
			state.setString(3, searchInfo.getEnd());
			state.setString(4, searchInfo.getEnd());
			state.setString(5, searchInfo.getTestID());
			state.setString(6, searchInfo.getTestID());
			state.setString(7, searchInfo.getTimes());
			state.setString(8, searchInfo.getTimes());

			set = state.executeQuery();

			list = new ArrayList<>();

			while(set.next()) {

				CLS905_SearchResultBean bean = new CLS905_SearchResultBean();

				bean.setTestID(set.getString("ID_TEST"));
				bean.setFiscal_year(set.getString("FISCAL_YEAR"));
				bean.setTimes(set.getString("TIMES"));
				bean.setTest_type(set.getString("TEST_TYPE"));
				bean.setDate_hold(set.getDate("DATE_HOLD"));
				bean.setAverage_jap(defaultToBlank(set.getString("AVERAGE_JAP")));
				bean.setAverage_math(defaultToBlank(set.getString("AVERAGE_MATH")));
				bean.setAverage_siec(defaultToBlank(set.getString("AVERAGE_SIEC")));
				bean.setAverage_scty(defaultToBlank(set.getString("AVERAGE_SCTY")));
				bean.setAverage_eng(defaultToBlank(set.getString("AVERAGE_ENG")));
				bean.setLast_up_user(set.getString("ID_LASTUPDATE"));
				bean.setLast_update(set.getTimestamp("DATE_LASTUPDATE"));

				list.add(bean);
			}

			ConnectionManager.close();

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				ConnectionManager.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return list;
	}
	
	/*
	 * DBに格納されている平均点のデフォルト情報を
	 * 画面表示用に空文字に変換する。
	 * 平均点：-10.00→空文字
	 * @param param dbから取得したデータ
	 * @return "" or param 変換済または変換不要データ
	 */
	public static String defaultToBlank(String param) {

		// デフォルト値ならば空文字返却
		if ("-10.00".equals(param)) {
			return "";
		// デフォルト値でないならばそのまま引数の値を返却。
		} else {
			return param;
		}
	}
}
