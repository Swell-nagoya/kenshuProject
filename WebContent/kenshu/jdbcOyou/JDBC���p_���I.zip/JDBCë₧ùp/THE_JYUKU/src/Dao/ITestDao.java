package Dao;

import java.util.List;

/**
 * テスト登録、テスト結果登録のインターフェース
 * @author kume
 *
 */
public interface ITestDao {

	/**
	 * テスト及び成績の検索を行う。
	 * @param searchInfo 検索条件
	 * @return 検索結果一覧
	 */
	List<? extends Object> getTestResult(Object obj);

}
