
package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Trn005_SubstituteTrnBean;

public class Trn005_SubstituteTrnDAO extends DataAccessObject {

	/**
	 * PKで検索するSQL
	 */
	String SQL_FIND_BY_PK =
			"select " +
					join(getColumns(),",") +
			" from " +
				getTableName() +
			" where " +
				"ID_USER=?" +
			" and " +
				"ID_COURSE=?" +
			" and " +
				"START_LECTURE=?";

	/**
	 * PKで検索するSQL
	 */
	String SQL_FIND_BY_USER_AND_COURSE =
			"select " +
					join(getColumns(),",") +
			" from " +
				getTableName() +
			" where " +
				"ID_USER=?" +
			" and " +
				"ID_COURSE=?";

	/**
	 * 登録処理を行います。
	 * @param trn005_SubstituteTrnBean trn005_SubstituteTrnBean
	 */
	public void create(Trn005_SubstituteTrnBean trn005_SubstituteTrnBean) {
		update(createSQLForCreate(),
			new Object[] {
		trn005_SubstituteTrnBean.getid_user()
		,trn005_SubstituteTrnBean.getid_course()
		,trn005_SubstituteTrnBean.getflg_absence()
		,trn005_SubstituteTrnBean.getflg_late()
		,trn005_SubstituteTrnBean.getflg_early()
		,trn005_SubstituteTrnBean.getflg_substitute()
		,trn005_SubstituteTrnBean.getstart_lecture()
		,trn005_SubstituteTrnBean.getend_lecture()
		,trn005_SubstituteTrnBean.getstart_substitute()
		,trn005_SubstituteTrnBean.getend_substitute()
		,trn005_SubstituteTrnBean.getflg_delete()
		,trn005_SubstituteTrnBean.getid_lastupdate()
		,trn005_SubstituteTrnBean.getdate_lastupdate()
		});
	}

	/**
	 * 更新処理を行います。
	 * @param trn005_substitutetrn trn005_substitutetrn
	 */
	public void update(Trn005_SubstituteTrnBean trn005_SubstituteTrnBean) {
		update(createSQLForUpdate(),
			new Object[] {
		trn005_SubstituteTrnBean.getid_user()
		,trn005_SubstituteTrnBean.getid_course()
		,trn005_SubstituteTrnBean.getflg_absence()
		,trn005_SubstituteTrnBean.getflg_late()
		,trn005_SubstituteTrnBean.getflg_early()
		,trn005_SubstituteTrnBean.getflg_substitute()
		,trn005_SubstituteTrnBean.getstart_lecture()
		,trn005_SubstituteTrnBean.getend_lecture()
		,trn005_SubstituteTrnBean.getstart_substitute()
		,trn005_SubstituteTrnBean.getend_substitute()
		,trn005_SubstituteTrnBean.getflg_delete()
		,trn005_SubstituteTrnBean.getid_lastupdate()
		,trn005_SubstituteTrnBean.getdate_lastupdate()
		,trn005_SubstituteTrnBean.getid_user()
		,trn005_SubstituteTrnBean.getid_course()
		,trn005_SubstituteTrnBean.getstart_lecture()
		});
	}

	/**
	 * 主キー検索を行います。
	 * @param id_user ユーザID
	 * @return id_user
	 * @param id_course コースID
	 * @return id_course
	 */
	public Trn005_SubstituteTrnBean findByPrimaryKey(java.lang.Integer userno) {
		return (Trn005_SubstituteTrnBean) query(createSQLForFindByPK(), new Object[]{userno}, Trn005_SubstituteTrnBean.class);
	}

	@Override
	public String[] getPKColumns() {
		return new String[] {"ID_USER","ID_COURSE","START_LECTURE"};
	}

	@Override
	public String[] getColumns() {
		return new String[] {
			"ID_USER"
			,"ID_COURSE"
			,"FLG_ABSENCE"
			,"FLG_LATE"
			,"FLG_EARLY"
			,"FLG_SUBSTITUTE"
			,"START_LECTURE"
			,"END_LECTURE"
			,"START_SUBSTITUTE"
			,"END_SUBSTITUTE"
			,"FLG_DELETE"
			,"ID_LASTUPDATE"
			,"DATE_LASTUPDATE"
		};
	}

	@Override
	public String getTableName() {
		return "TRN005_SUBSTITUTETRN";
	}

	/**
	 * キーで一致する行を取得します。
	 * @param user_id
	 * @param id_course
	 * @param start_lecture
	 * @return Trn005_SubstituteTrnBean
	 */
	public Trn005_SubstituteTrnBean findByKey(String id_user
												,String  id_course
												,String  start_lecture) {

		Trn005_SubstituteTrnBean trn005_SubstituteTrnBean = new Trn005_SubstituteTrnBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			if (start_lecture == null){
				System.out.println(SQL_FIND_BY_USER_AND_COURSE);
				stmt = getConnection().prepareStatement(SQL_FIND_BY_USER_AND_COURSE);
				System.out.println("id:" + id_user);
				System.out.println("id_course:" + id_course);
				fillPreparedStatement(stmt, 1, id_user);
				fillPreparedStatement(stmt, 2, id_course);
				rs = stmt.executeQuery();
			} else {
				System.out.println(SQL_FIND_BY_PK);
				stmt = getConnection().prepareStatement(SQL_FIND_BY_PK);
				System.out.println("id:" + id_user);
				System.out.println("id_course:" + id_course);
				System.out.println("start_lecture:" + start_lecture);
				fillPreparedStatement(stmt, 1, id_user);
				fillPreparedStatement(stmt, 2, id_course);
				fillPreparedStatement(stmt, 3, start_lecture);
				rs = stmt.executeQuery();
			}

			if (rs.next()) {
				trn005_SubstituteTrnBean.setid_user(rs.getString("ID_USER"));
				trn005_SubstituteTrnBean.setid_course(rs.getString("ID_COURSE"));
				trn005_SubstituteTrnBean.setflg_absence(rs.getInt("FLG_ABSENCE"));
				trn005_SubstituteTrnBean.setflg_late(rs.getInt("FLG_LATE"));
				trn005_SubstituteTrnBean.setflg_early(rs.getInt("FLG_EARLY"));
				trn005_SubstituteTrnBean.setflg_substitute(rs.getInt("FLG_SUBSTITUTE"));
				trn005_SubstituteTrnBean.setstart_lecture(rs.getTimestamp("START_LECTURE"));
				trn005_SubstituteTrnBean.setend_lecture(rs.getTimestamp("END_LECTURE"));
				trn005_SubstituteTrnBean.setstart_substitute(rs.getTimestamp("START_SUBSTITUTE"));
//				trn005_SubstituteTrnBean.settimetable_substitute(rs.getString("TIMETABLE_SUBSTITUTE"));
				trn005_SubstituteTrnBean.setend_substitute(rs.getTimestamp("END_SUBSTITUTE"));
				trn005_SubstituteTrnBean.setflg_delete(rs.getInt("FLG_DELETE"));
				trn005_SubstituteTrnBean.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				trn005_SubstituteTrnBean.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
			};

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return trn005_SubstituteTrnBean;
	}

}
