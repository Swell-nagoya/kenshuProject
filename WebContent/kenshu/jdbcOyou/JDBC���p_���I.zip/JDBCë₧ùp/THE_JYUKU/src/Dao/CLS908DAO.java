package Dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import bean.CLS907_SearchResutlBean;
import bean.CLS908_InsertBean;

/**
 * 個人成績の新規登録及び修正を行うクラス。
 */
public class CLS908DAO {

	/**
	 * 成績登録時のデータに付随するユーザーIDが
	 * マスタに存在するかチェックを行う。
	 * @param userID 検索条件
	 * @return 判定結果
	 */
	public static boolean getUserCount(String userID) {

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();
		// 実行結果
		int result = 0;

		try (CallableStatement stmt = conn.prepareCall("{call getUserCount(?,?)}")) {

			stmt.setString(1, userID);
			stmt.registerOutParameter(2, Types.INTEGER);

			// 検索スクリプト実行
			stmt.executeQuery();

			// スクリプトから出力パラメーターを取得
			result = stmt.getInt("result");
			ConnectionManager.close();

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				ConnectionManager.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		if (result == 0) {
			return false;
		}
		return true;
	}

	/**
	 * 個人成績の登録を行う
	 * @param bean 個人成績登録情報
	 * @return result SQLエラーコード
	 */
	public static int testInsert(CLS908_InsertBean bean) {

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		CallableStatement stmt = null;

		// SQL実行結果
		int result = 0;

		try {
			stmt = conn.prepareCall("{call insertTestInfo(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setString(1, bean.getTestCategory());
			stmt.setString(2, bean.getUserID());
			stmt.setString(3, bean.getTestID());
			stmt.setString(4, bean.getMarks_jap());
			stmt.setString(5, bean.getMarks_math());
			stmt.setString(6, bean.getMarks_siec());
			stmt.setString(7, bean.getMarks_scty());
			stmt.setString(8, bean.getMarks_eng());
			stmt.setString(9, blankToDefault(bean.getDeviation_jap()));
			stmt.setString(10, blankToDefault(bean.getDeviation_math()));
			stmt.setString(11, blankToDefault(bean.getDeviation_siec()));
			stmt.setString(12, blankToDefault(bean.getDeviation_scty()));
			stmt.setString(13, blankToDefault(bean.getDeviation_eng()));
			stmt.setString(14, blankToDefault(bean.getDeviation_five()));
			stmt.setString(15, blankToDefault(bean.getLast_up_user()));

			// 個人成績登録スクリプト実行
			result = stmt.executeUpdate();

		} catch (SQLException e) {
			// エラー発生時、ロールバック実行
			ConnectionManager.rollback();
			System.out.println("SQLError Code = " + e.getErrorCode());
			// SQLエラーコードを格納
			result = e.getErrorCode();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					result = e.getErrorCode();
					e.printStackTrace();
				} finally{
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
							result = e.getErrorCode();
							e.printStackTrace();
						}
					}
				}
			}
		}
		return result;
	}

	/**
	 * 個人成績の修正を行う
	 * @param bean 個人成績登録情報
	 * @return result SQLエラーコード
	 */
	public static int testUpdate(CLS908_InsertBean bean) {

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		CallableStatement stmt = null;

		// SQL実行結果
		int result = 0;

		try {
			stmt = conn.prepareCall("{call updateTestInfo(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setString(1, bean.getTestCategory());
			stmt.setString(2, bean.getUserID());
			stmt.setString(3, bean.getTestID());
			stmt.setString(4, bean.getMarks_jap());
			stmt.setString(5, bean.getMarks_math());
			stmt.setString(6, bean.getMarks_siec());
			stmt.setString(7, bean.getMarks_scty());
			stmt.setString(8, bean.getMarks_eng());
			stmt.setString(9, blankToDefault(bean.getDeviation_jap()));
			stmt.setString(10, blankToDefault(bean.getDeviation_math()));
			stmt.setString(11, blankToDefault(bean.getDeviation_siec()));
			stmt.setString(12, blankToDefault(bean.getDeviation_scty()));
			stmt.setString(13, blankToDefault(bean.getDeviation_eng()));
			stmt.setString(14, blankToDefault(bean.getDeviation_five()));
			stmt.setString(15, bean.getLast_up_user());
			stmt.setString(16, bean.getLast_update());
			stmt.registerOutParameter(17, Types.INTEGER);

			// 個人成績修正スクリプト実行
			stmt.executeUpdate();

			// スクリプトから出力パラメーターを取得
			result = stmt.getInt("result");

			ConnectionManager.commit();
		} catch (SQLException e) {
			// エラー発生時、ロールバック実行
			ConnectionManager.rollback();
			System.out.println("SQLError Code = " + e.getErrorCode());
			// SQLエラーコードを格納
			result = e.getErrorCode();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					result = e.getErrorCode();
					e.printStackTrace();
				} finally{
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
							result = e.getErrorCode();
							e.printStackTrace();
						}
					}
				}
			}
		}
		return result;
	}

	/**
	 * 個人成績の削除を行う
	 * @param bean 個人成績登録情報
	 * @return result SQLエラーコード
	 */
	public static int testDelete(CLS907_SearchResutlBean bean) {

		// トランザクションの開始
		ConnectionManager.beginTransaction();
		// 接続開始
		Connection conn = ConnectionManager.getConnection();

		CallableStatement stmt = null;

		// SQL実行結果
		int result = 0;

		try {
			stmt = conn.prepareCall("{call deleteTestInfo(?,?,?,?,?)}");

			stmt.setString(1, bean.getTestCategory());
			stmt.setString(2, bean.getUserID());
			stmt.setString(3, bean.getTestID());
			stmt.setString(4, bean.getLast_up_user());
			stmt.registerOutParameter(5, Types.INTEGER);

			// 個人成績削除スクリプト実行
			stmt.executeUpdate();

			// スクリプトから出力パラメーターを取得
			result = stmt.getInt("result");

			ConnectionManager.commit();

		} catch (SQLException e) {
			// エラー発生時、ロールバック実行
			ConnectionManager.rollback();
			System.out.println("SQLError Code = " + e.getErrorCode());
			// SQLエラーコードを格納
			result = e.getErrorCode();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					result = e.getErrorCode();
					e.printStackTrace();
				} finally{
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
							result = e.getErrorCode();
							e.printStackTrace();
						}
					}
				}
			}
		}
		return result;
	}

	/**
	 * フォームから取得した偏差値が空文字の場合、
	 * DB格納用にデフォルト値(-10.00)に変換する。
	 * ■補足：点数と同様に偏差値の変換もプロシージャで行おうとしたが、
	 *         処理出来なかった為、javaロジックに組み込みました。
	 * @param param フォームから取得したデータ
	 * @return デフォルト値に変換済または変換不要データ
	 */
	public static String blankToDefault(String param) {

		// 空文字ならデフォルト値に変換
		if ("".equals(param)) {
			return "-10.00";
		// 空文字でないならばそのまま引数の値を返却。
		} else {
			return param;
		}
	}
}
