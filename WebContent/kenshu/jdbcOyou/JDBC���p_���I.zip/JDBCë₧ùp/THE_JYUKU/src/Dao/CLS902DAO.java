package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Mst001_UserMstBean;

public class CLS902DAO extends ConnectionManager{

	/*
	 * USER_IDとユーザー名取得
	 */
	private static final String SQL_GET_NAME_USER =
			"SELECT " +
			"	MST001_USERMST.ID_USER" +
			"	,MST001_USERMST.NAME_USER" +
			" FROM " +
			"	MST016_GETCOURSEMST" +
			"	 LEFT JOIN MST001_USERMST" +
			"	 ON MST016_GETCOURSEMST.ID_USER = MST001_USERMST.ID_USER" +
			" WHERE" +
			"	 ID_COURSE = ? " +
			"AND " +
			"	MST001_USERMST.FLG_DELETE = 0" +
			" ORDER BY KANA_NAME_USER";

	private static final String SQL_GET_NAME_FOR_TRN004 =
			"SELECT MST001_USERMST.ID_USER,NAME_USER FROM TRN004_SMALLTESTTRN LEFT JOIN MST001_USERMST ON TRN004_SMALLTESTTRN.ID_USER = MST001_USERMST.ID_USER WHERE ID_COURSE = ? AND DATE_LECTURE = ? AND MST001_USERMST.FLG_DELETE = 0 ORDER BY KANA_NAME_USER";


	/**
	 * 指定したIDコースに登録してあるUSER_IDとユーザー名取得
	 * @param id_course
	 * @return List<Mst001_UserMstBean>
	 */
	public List<Mst001_UserMstBean> getNAME (String id_course) {

		//リストの作成
		List<Mst001_UserMstBean> list = new ArrayList<Mst001_UserMstBean>();
		Mst001_UserMstBean mst001_usermst = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_GET_NAME_USER);
			System.out.println(SQL_GET_NAME_USER);
			stmt.setObject(1,id_course);
			rs = stmt.executeQuery();
		while (rs.next()) {
			mst001_usermst = new Mst001_UserMstBean();
			mst001_usermst.setId_user(rs.getString("ID_USER"));
			mst001_usermst.setName(rs.getString("NAME_USER"));
			list.add(mst001_usermst);
		}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;

	}

	public List<Mst001_UserMstBean> getNameforTrn004 (String id_course,String date_lecture) {

		//リストの作成
		List<Mst001_UserMstBean> list = new ArrayList<Mst001_UserMstBean>();
		Mst001_UserMstBean mst001_usermst = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_GET_NAME_FOR_TRN004);
			System.out.println(SQL_GET_NAME_FOR_TRN004);
			stmt.setObject(1,id_course);
			stmt.setObject(2,date_lecture);
			rs = stmt.executeQuery();
		while (rs.next()) {
			mst001_usermst = new Mst001_UserMstBean();
			mst001_usermst.setId_user(rs.getString("ID_USER"));
			mst001_usermst.setName(rs.getString("NAME_USER"));
			list.add(mst001_usermst);
		}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;

	}

}
