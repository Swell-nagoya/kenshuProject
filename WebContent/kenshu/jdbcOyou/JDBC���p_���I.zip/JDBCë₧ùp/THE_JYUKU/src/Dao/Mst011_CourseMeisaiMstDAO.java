package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Mst011_CourseMeisaiMstBean;

public class Mst011_CourseMeisaiMstDAO extends DataAccessObject {

	/**
	 * �o�^�������s���܂��B
	 * 
	 * @param Mst011_CourseMeisaiMst
	 *            mst011_coursemeisaimst
	 */
	public void create(Mst011_CourseMeisaiMstBean mst011_coursemeisaimst) {
		update(createSQLForCreate(),
				new Object[] {
						mst011_coursemeisaimst.getid_course(),
						mst011_coursemeisaimst.gettarget(),
						mst011_coursemeisaimst.getid_subject(),
						mst011_coursemeisaimst.getday_lecture()
						// ,mst011_coursemeisaimst.gettimetable_lecture()
						, mst011_coursemeisaimst.getstart_time_lecture(),
						mst011_coursemeisaimst.getend_time_lecture(),
						mst011_coursemeisaimst.getstart_lecture(),
						mst011_coursemeisaimst.getend_lecture(),
						mst011_coursemeisaimst.getid_teacher(),
						mst011_coursemeisaimst.getid_lastupdate(),
						mst011_coursemeisaimst.getdate_lastupdate() });
	}

	/**
	 * �X�V�������s���܂��B
	 * 
	 * @param Mst011_CourseMeisaiMst
	 *            mst011_coursemeisaimst
	 */
	public void update(Mst011_CourseMeisaiMstBean mst011_coursemeisaimst) {
		update(createSQLForUpdate(),
				new Object[] { mst011_coursemeisaimst.getid_course(),
						mst011_coursemeisaimst.gettarget(),
						mst011_coursemeisaimst.getid_subject(),
						mst011_coursemeisaimst.getday_lecture(),
						mst011_coursemeisaimst.getstart_time_lecture(),
						mst011_coursemeisaimst.getend_time_lecture(),
						mst011_coursemeisaimst.getstart_lecture(),
						mst011_coursemeisaimst.getend_lecture(),
						mst011_coursemeisaimst.getid_teacher(),
						mst011_coursemeisaimst.getid_lastupdate(),
						mst011_coursemeisaimst.getdate_lastupdate(),
						mst011_coursemeisaimst.getid_course(),
						mst011_coursemeisaimst.getbeforetarget(),
						mst011_coursemeisaimst.getbeforeid_subject(),
						mst011_coursemeisaimst.getbeforeday_lecture() });
	}

	/**
	 * ��L�[�������s���܂��B
	 * 
	 * @param ID_COURSE
	 *            �R�[�XID
	 * @return ID_COURSE
	 * @param TARGET
	 *            �Ώۊw�N
	 * @return TARGET
	 * @param ID_SUBJECT
	 *            �Ȗ�ID
	 * @return ID_SUBJECT
	 * @param DAY_LECTURE
	 *            �J�×j��
	 * @return DAY_LECTURE
	 * @param TIMETABLE_LECTURE
	 *            �J�Î��Ԋ�
	 * @return TIMETABLE_LECTURE
	 */
	public Mst011_CourseMeisaiMstBean findByPrimaryKey(java.lang.Integer userno) {
		return (Mst011_CourseMeisaiMstBean) query(createSQLForFindByPK(),
				new Object[] { userno }, Mst011_CourseMeisaiMstBean.class);
	}

	@Override
	public String[] getPKColumns() {
		return new String[] { "ID_COURSE", "TARGET", "ID_SUBJECT",
				"DAY_LECTURE" };
	}

	@Override
	public String[] getColumns() {
		return new String[] { "ID_COURSE", "TARGET", "ID_SUBJECT",
				"DAY_LECTURE", "START_TIME_LECTURE", "END_TIME_LECTURE",
				"START_LECTURE", "END_LECTURE", "ID_TEACHER", "ID_LASTUPDATE",
				"DATE_LASTUPDATE" };
	}

	@Override
	public String getTableName() {
		return "MST011_COURSEMEISAIMST";
	}

	// 林田追加 Mst011テーブルで検索するように入れ替える

	/**
	 * コースIDでの検索用SQL
	 */
	private static final String SQL_FIND_BY_ID_COURSE = "SELECT" + "	ID_COURSE"
			+ "	,TARGET"
			+ "	,ID_SUBJECT"
			+ "	,DAY_LECTURE"
			+
			// "	,TIMETABLE_LECTURE" +
			"	,START_TIME_LECTURE" + "	,END_TIME_LECTURE" + "	,START_LECTURE"
			+ "	,END_LECTURE" + "	,ID_TEACHER" + "	,ID_LASTUPDATE"
			+ "	,DATE_LASTUPDATE" + " FROM" + "	MST011_COURSEMEISAIMST"
			+ " WHERE" + "	ID_COURSE = ?";

	/**
	 * 特定のコースIDと一致する行数を取得します。
	 */
	private static final String SQL_GET_COUNT_BY_ID_COURSE = "SELECT"
			+ "	COUNT(*)" + " FROM" + "	MST011_COURSEMST" + " WHERE"
			+ "	ID_COURSE = ?";

	/**
	 * USER表からユーザIDと一致する行数を検索します。
	 * 
	 * @param id
	 *            ユーザーID
	 * @return Integer 行数
	 */
	public int getCountById(String id) {
		int num = -1;

		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_GET_COUNT_BY_ID_COURSE);
			System.out.println(SQL_GET_COUNT_BY_ID_COURSE);
			System.out.println("id:" + id);
			fillPreparedStatement(stmt, 1, id);
			rs = stmt.executeQuery();

			if (rs.next()) {
				num = rs.getInt("count(*)");
			} else {
				System.out.println("カウントが正しく取得できていません。");
			}
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return num;

	}

	/**
	 * コースIDでコースマスタを検索します。
	 * 
	 * @param id
	 *            コースID
	 * @return Mst011_CourseMeisaiMst
	 */
	// PKのため検索結果は1人
	public Mst011_CourseMeisaiMstBean findById(String id) {
		Mst011_CourseMeisaiMstBean mst011_CourseMeisaiMst = new Mst011_CourseMeisaiMstBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_COURSE);
			System.out.println(SQL_FIND_BY_ID_COURSE);
			System.out.println("id:" + id);
			fillPreparedStatement(stmt, 1, id);
			rs = stmt.executeQuery();

			if (rs.next()) {
				mst011_CourseMeisaiMst.setid_course(rs.getString("ID_COURSE"));
				mst011_CourseMeisaiMst.settarget(rs.getInt("TARGET"));
				mst011_CourseMeisaiMst
						.setid_subject(rs.getString("ID_SUBJECT"));
				mst011_CourseMeisaiMst.setday_lecture(rs.getInt("DAY_LECTURE"));
				// mst011_CourseMeisaiMst.settimetable_lecture(rs.getInt("TIMETABLE_LECTURE"));
				mst011_CourseMeisaiMst.setstart_time_lecture(rs
						.getTimestamp("START_TIME_LECTURE"));
				mst011_CourseMeisaiMst.setend_time_lecture(rs
						.getTimestamp("END_TIME_LECTURE"));
				mst011_CourseMeisaiMst.setstart_lecture(rs
						.getTimestamp("START_LECTURE"));
				mst011_CourseMeisaiMst.setend_lecture(rs
						.getTimestamp("END_LECTURE"));
				mst011_CourseMeisaiMst
						.setid_teacher(rs.getString("ID_TEACHER"));
				mst011_CourseMeisaiMst.setid_lastupdate(rs
						.getString("ID_LASTUPDATE"));
				mst011_CourseMeisaiMst.setdate_lastupdate(rs
						.getTimestamp("DATE_LASTUPDATE"));

			}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return mst011_CourseMeisaiMst;
	}
}
