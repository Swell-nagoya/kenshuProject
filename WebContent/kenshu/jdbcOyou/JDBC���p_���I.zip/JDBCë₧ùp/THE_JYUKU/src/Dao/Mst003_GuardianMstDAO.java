package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Mst003_GuardianMstBean;

public class Mst003_GuardianMstDAO extends DataAccessObject {

	/**
	 * ユーザーIDで検索するSQL
	 */

	String SQL_FIND_BY_ID_USER =
			"select " +
			join(getColumns(),",") +
			" from " +
			getTableName() +
			" where " +
			"ID_USER=?";

	/**
	 * 登録処理を行います。
	 * @param guardian guardian
	 */
	public void create(Mst003_GuardianMstBean guardian) {
		update(createSQLForCreate(),
			new Object[] {
			guardian.getId_user()
			,guardian.getId_family()
			,guardian.getAddress()
			,guardian.getFlg_delete()
			,guardian.getLastupdate_id()
			,guardian.getLastupdate_date()
			});
	}

	/**
	 * 更新処理を行います。
	 * @param guardian guardian
	 */
	public void update(Mst003_GuardianMstBean guardian) {
		update(createSQLForUpdate(),
			new Object[] {
			guardian.getId_user()
			,guardian.getId_family()
			,guardian.getAddress()
			,guardian.getFlg_delete()
			,guardian.getLastupdate_id()
			,guardian.getLastupdate_date()
			,guardian.getId_user()
			});
	}

	/**
	 * 主キー検索を行います。
	 * @param guardian 生徒
	 * @return id_user
	 */
	public Mst003_GuardianMstBean findByPrimaryKey(java.lang.Integer userno) {
		return (Mst003_GuardianMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst003_GuardianMstBean.class);
	}


	@Override
	public String[] getPKColumns() {
		return new String[] {"ID_USER"};
	}

	@Override
	public String[] getColumns() {
		return new String[] {
				"ID_USER"
				,"ID_FAMILY"
				,"ADDRESS"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
		};
	}

	@Override
	public String getTableName() {
		return "MST003_GUARDIANMST";
	}

	/**
	 * ユーザIDで一致する行を取得します。
	 * @param user_id
	 * @return Mst003_GuardianMstDAO
	 */

	public Mst003_GuardianMstBean findById_user(String id_user) {

		Mst003_GuardianMstBean mst003_GuardianMstBean = new Mst003_GuardianMstBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_USER);
			System.out.println(SQL_FIND_BY_ID_USER);
			System.out.println("id:" + id_user);
			fillPreparedStatement(stmt, 1, id_user);
			rs = stmt.executeQuery();

			if (rs.next()) {
				mst003_GuardianMstBean.setId_user(rs.getString("ID_USER"));
				mst003_GuardianMstBean.setId_family(rs.getString("ID_FAMILY"));
				mst003_GuardianMstBean.setAddress(rs.getString("ADDRESS"));
				mst003_GuardianMstBean.setFlg_delete(rs.getInt("FLG_DELETE"));
				mst003_GuardianMstBean.setId_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst003_GuardianMstBean.setDate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));

			}
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return mst003_GuardianMstBean;
	}

}
