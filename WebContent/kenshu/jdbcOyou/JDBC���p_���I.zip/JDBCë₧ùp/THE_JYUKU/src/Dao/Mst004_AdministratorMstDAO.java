package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Mst004_AdministratorMstBean;

public class Mst004_AdministratorMstDAO extends DataAccessObject {


	/**
	 * ユーザーIDで検索するSQL
	 */
	String SQL_FIND_BY_ID_USER =
			"select " +
			join(getColumns(),",") +
			" from " +
			getTableName() +
			" where " +
			"ID_USER=?";


	/**
	 * 登録処理を行います。
	 * @param administrator administrator
	 */
	public void create(Mst004_AdministratorMstBean administrator) {
		update(createSQLForCreate(),
			new Object[] {
			administrator.getId_user(),
			administrator.getGrade(),
			administrator.getAddress(),
			administrator.getId_elementary(),
			administrator.getId_junior_high_school(),
			administrator.getId_high_school(),
			administrator.getId_university(),
			administrator.getIn_crammer(),
			administrator.getOut_crammer(),
			administrator.getLastupdate_id(),
			administrator.getLastupdate_date()
			});
	}

	/**
	 * 更新処理を行います。
	 * @param administrator administrator
	 */
	public void update(Mst004_AdministratorMstBean administrator) {
		update(createSQLForUpdate(),
			new Object[] {
			administrator.getId_user(),
			administrator.getGrade(),
			administrator.getAddress(),
			administrator.getId_elementary(),
			administrator.getId_junior_high_school(),
			administrator.getId_high_school(),
			administrator.getId_university(),
			administrator.getIn_crammer(),
			administrator.getOut_crammer(),
			administrator.getLastupdate_id(),
			administrator.getLastupdate_date(),
			administrator.getId_user()
			});
	}

	/**
	 * 主キー検索を行います。
	 * @param administrator 生徒
	 * @return id_user
	 */
	public Mst004_AdministratorMstBean findByPrimaryKey(java.lang.Integer userno) {
		return (Mst004_AdministratorMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst004_AdministratorMstBean.class);
	}

	/**
	 * 削除処理を行います。
	 * @param ID_USER ユーザID
	 */
	public void delete(java.lang.Integer ID_USER) {
 		update(createSQLForDelete(), new Object[]{ID_USER});
	}

	@Override
	public String[] getPKColumns() {
		return new String[] {"ID_USER"};
	}

	@Override
	public String[] getColumns() {
		return new String[] {
				"ID_USER",
				"GRADE",
				"ADDRESS",
				"ID_ELEMENTARY_SCHOOL",
				"ID_JUNIOR_HIGH_SCHOOL",
				"ID_HIGH_SCHOOL",
				"ID_UNIVERSITY",
				"IN_CRAMMER",
				"OUT_CRAMMER",
				"ID_LASTUPDATE",
				"DATE_LASTUPDATE"
		};
	}

	@Override
	public String getTableName() {
		return "MST004_ADMINISTRATORMST";
	}

	/**
	 * ユーザIDで一致する行を取得します。
	 * @param user_id
	 * @return Mst004_AdministratorMstBean
	 */

	public Mst004_AdministratorMstBean findById_user(String id_user) {

		Mst004_AdministratorMstBean mst004_AdministratorMstBean = new Mst004_AdministratorMstBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_USER);
			System.out.println(SQL_FIND_BY_ID_USER);
			System.out.println("id:" + id_user);
			fillPreparedStatement(stmt, 1, id_user);
			rs = stmt.executeQuery();

			if (rs.next()) {
				mst004_AdministratorMstBean.setId_user(rs.getString("ID_USER"));
				mst004_AdministratorMstBean.setAddress(rs.getString("ADDRESS"));
				mst004_AdministratorMstBean.setGrade(rs.getInt("GRADE"));
				mst004_AdministratorMstBean.setId_elementary(rs.getString("ID_ELEMENTARY_SCHOOL"));
				mst004_AdministratorMstBean.setId_junior_high_school(rs.getString("ID_JUNIOR_HIGH_SCHOOL"));
				mst004_AdministratorMstBean.setId_high_school(rs.getString("ID_HIGH_SCHOOL"));
				mst004_AdministratorMstBean.setId_university(rs.getString("ID_UNIVERSITY"));
				mst004_AdministratorMstBean.setIn_crammer(rs.getTimestamp("IN_CRAMMER"));
				mst004_AdministratorMstBean.setOut_crammer(rs.getTimestamp("OUT_CRAMMER"));
				mst004_AdministratorMstBean.setId_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst004_AdministratorMstBean.setDate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));

			}
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return mst004_AdministratorMstBean;
	}

}
