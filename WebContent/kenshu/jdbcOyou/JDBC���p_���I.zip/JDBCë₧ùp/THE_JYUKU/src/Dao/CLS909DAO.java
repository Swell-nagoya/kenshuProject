package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CLS909Bean;
import bean.Mst001_UserMstBean;
import bean.Trn014_ConfidentialTrnBean;

public class CLS909DAO extends ConnectionManager {

	private String id_user;
	private int fiscal_year;
	private int times;
	private int start;
	private int end;
	private String sql;


	/**
	 * 内申点情報
	 * を取得するSQL文を作成します。
	 * palam長が0の際は全検索を行います。
	 * @param palam 条件にするカラム名
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchConfidential(List<String> palam) {

		Trn014_ConfidentialTrnDAO trn14_ConfidentialDAO = new Trn014_ConfidentialTrnDAO();
		Mst001_UserMstDAO mst001_UserMstDAO = new Mst001_UserMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(trn14_ConfidentialDAO.join(trn14_ConfidentialDAO.add(
				trn14_ConfidentialDAO.getTableName(), ".",
				trn14_ConfidentialDAO.getColumns()), ", "));
		sb.append(", ");
		sb.append(mst001_UserMstDAO.join(mst001_UserMstDAO.add(
				mst001_UserMstDAO.getTableName(), ".",
				mst001_UserMstDAO.getColumns()), ", "));
		sb.append(" from ");
		sb.append(trn14_ConfidentialDAO.getTableName());
		sb.append(" left join ");
		sb.append(mst001_UserMstDAO.getTableName());
		sb.append(" on ");
		sb.append(mst001_UserMstDAO.getTableName() + "."
				+ mst001_UserMstDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(trn14_ConfidentialDAO.getTableName() + "."
				+ trn14_ConfidentialDAO.getPKColumns()[0]);

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}

		sb.append(" order by ");
		sb.append(trn14_ConfidentialDAO.join(trn14_ConfidentialDAO.add(
				trn14_ConfidentialDAO.getTableName(), ".",
				trn14_ConfidentialDAO.getColumns()), ", "));

		return sb.toString();
	}

	public String createSQLForSearchStudentInFISCAL_YEAR(List<String> palam,
			int start, int end) {

		Trn014_ConfidentialTrnDAO ConfidentialDAO = new Trn014_ConfidentialTrnDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(ConfidentialDAO.join(ConfidentialDAO.add(
				ConfidentialDAO.getTableName(), ".",
				ConfidentialDAO.getColumns()), ", "));
		sb.append(" from ");
		sb.append(ConfidentialDAO.getTableName());

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ");
				sb.append(String.valueOf(id_user));
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		if (start != 0) {
			if (palam.size() == 0) {
				sb.append(" where ");
				sb.append("FISCAL_YEAR >= ");
				sb.append(String.valueOf(start));

			} else {
				sb.append(" and FISCAL_YEAR >= ");
				sb.append(String.valueOf(start));
			}
		}
		if (end != 0) {
			if (palam.size() == 0 && start == 0) {
				sb.append(" where ");
				sb.append("FISCAL_YEAR <= ");
				sb.append(String.valueOf(end));
			} else {
				sb.append(" and FISCAL_YEAR <= ");
				sb.append(String.valueOf(end));
			}
		}
		sb.append(" order by ");
		sb.append(ConfidentialDAO.join(ConfidentialDAO.add(
				ConfidentialDAO.getTableName(), ".",
				ConfidentialDAO.getColumns()), ", "));

		return sb.toString();
	}

	/**
	 * 内申点トランからデータを取得します。
	 * 
	 * @param cls909
	 * @return List<CLS909Bean>
	 */

	public List<CLS909Bean> Search(CLS909Bean cls909) {

		PreparedStatement stmt = null;
		ResultSet rs = null;

		Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean = null;

		//取得するパラメータ
		List<CLS909Bean> list = new ArrayList<CLS909Bean>();

		//検索対象のカラム
		List<String> palam = new ArrayList<String>();

		//検索対象のパラメータ
		List<Object> value = new ArrayList<Object>();

		//共通で取得するユーザテーブルのBean
		trn014_ConfidentialTrnBean = cls909.getTrn014_ConfidentialTrnBean();

		//パラメーターの設定（ユーザーマスタ）
		if (trn014_ConfidentialTrnBean.getid_user() != null) {
			id_user = trn014_ConfidentialTrnBean.getid_user();
			palam.add("ID_USER");
			value.add(id_user);
		}

		if (trn014_ConfidentialTrnBean.getKikan_start() != 0) {
			start = trn014_ConfidentialTrnBean.getKikan_start();
			value.add(start);
		}
		if (trn014_ConfidentialTrnBean.getKikan_end() != 0) {
			end = trn014_ConfidentialTrnBean.getKikan_end();
			value.add(end);
		}
		if (trn014_ConfidentialTrnBean.getfiscal_year() != 0) {
			fiscal_year = trn014_ConfidentialTrnBean.getfiscal_year();
			value.add(fiscal_year);
		}

		if (trn014_ConfidentialTrnBean.gettimes() != 0) {
			times = trn014_ConfidentialTrnBean.gettimes();
			palam.add("TIMES");
			value.add(times);
		}

		if (trn014_ConfidentialTrnBean.getfiscal_year() != 0
				|| (start == 0 && end == 0)) {
			sql = createSQLForSearchConfidential(palam);
			System.out.println(sql);
		} else {
			sql = createSQLForSearchStudentInFISCAL_YEAR(palam, start, end);
		}

		try {
			System.out.println(sql);
			stmt = getConnection().prepareStatement(sql);

			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}

			rs = stmt.executeQuery();

			while (rs.next()) {
				CLS909Bean cls909b2 = new CLS909Bean();
				Trn014_ConfidentialTrnBean trn014_ConfidentialTrnBean2 = new Trn014_ConfidentialTrnBean();
				Mst001_UserMstBean mst001_UserMstBean2 = new Mst001_UserMstBean();

				trn014_ConfidentialTrnBean2.setid_user(rs.getString("ID_USER"));
				trn014_ConfidentialTrnBean2.setfiscal_year(rs
						.getInt("FISCAL_YEAR"));
				trn014_ConfidentialTrnBean2.settimes(rs.getInt("TIMES"));
				trn014_ConfidentialTrnBean2.setconf_jap(rs.getInt("CONF_JAP"));
				trn014_ConfidentialTrnBean2
						.setconf_math(rs.getInt("CONF_MATH"));
				trn014_ConfidentialTrnBean2
						.setconf_siec(rs.getInt("CONF_SIEC"));
				trn014_ConfidentialTrnBean2
						.setconf_scty(rs.getInt("CONF_SCTY"));
				trn014_ConfidentialTrnBean2.setconf_eng(rs.getInt("CONF_ENG"));
				trn014_ConfidentialTrnBean2
						.setconf_tech(rs.getInt("CONF_TECH"));
				trn014_ConfidentialTrnBean2
						.setconf_gmst(rs.getInt("CONF_GMST"));
				trn014_ConfidentialTrnBean2.setconf_music(rs
						.getInt("CONF_MUSIC"));
				trn014_ConfidentialTrnBean2
						.setconf_arts(rs.getInt("CONF_ARTS"));
				trn014_ConfidentialTrnBean2.setflg_delete(rs
						.getInt("FLG_DELETE"));
				trn014_ConfidentialTrnBean2.setid_lastupdate(rs
						.getString("ID_LASTUPDATE"));
				trn014_ConfidentialTrnBean2.setdate_lastupdate(rs
						.getTimestamp("DATE_LASTUPDATE"));
				mst001_UserMstBean2.setName(rs.getString("NAME_USER"));

				cls909b2.setTrn014_ConfidentialTrnBean(trn014_ConfidentialTrnBean2);
				cls909b2.setMst001_UserMstBean(mst001_UserMstBean2);

				list.add(cls909b2);
			}
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
}
