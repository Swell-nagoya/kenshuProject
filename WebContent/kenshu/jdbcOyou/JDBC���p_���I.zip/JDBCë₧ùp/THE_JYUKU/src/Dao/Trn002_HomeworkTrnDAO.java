
package Dao;

import java.sql.Timestamp;

import bean.Trn002_HomeworkTrnBean;

public class Trn002_HomeworkTrnDAO extends DataAccessObject {

        /**
         * 登録処理を行います。
         * @param Trn002_HomeworkTrn trn002_homeworktrn
         */
        public void create(Trn002_HomeworkTrnBean trn002_homeworktrn) {
            update(createSQLForCreate(),
                new Object[] {
                trn002_homeworktrn.getId_course()
                ,trn002_homeworktrn.getDate_lecture()
                ,trn002_homeworktrn.getHomework()
                ,trn002_homeworktrn.getFlg_delete()
                ,trn002_homeworktrn.getId_lastupdate()
                ,trn002_homeworktrn.getDate_lastupdate()
                });
        }

        /**
         * 更新処理を行います。
         * @param Trn002_HomeworkTrn trn002_homeworktrn
         */
        public void update(Trn002_HomeworkTrnBean trn002_homeworktrn) {
            update(createSQLForUpdate(),
                new Object[] {
                trn002_homeworktrn.getId_course()
                ,trn002_homeworktrn.getDate_lecture()
                ,trn002_homeworktrn.getHomework()
                ,trn002_homeworktrn.getFlg_delete()
                ,trn002_homeworktrn.getId_lastupdate()
                ,trn002_homeworktrn.getDate_lastupdate()
                ,trn002_homeworktrn.getId_course()
                ,trn002_homeworktrn.getDate_lecture()
                });
        }

        /**
         * PKを条件に更新処理を行います。
         * @param Trn002_HomeworkTrn trn002_homeworktrn
         */
        public void update_PK(Trn002_HomeworkTrnBean trn002_homeworktrn,Timestamp date_lecture) {
            update(createSQLForUpdate(),
                new Object[] {
                trn002_homeworktrn.getId_course()
                ,trn002_homeworktrn.getDate_lecture()
                ,trn002_homeworktrn.getHomework()
                ,trn002_homeworktrn.getFlg_delete()
                ,trn002_homeworktrn.getId_lastupdate()
                ,trn002_homeworktrn.getDate_lastupdate()
                ,trn002_homeworktrn.getId_course()
                ,date_lecture
                });
        }

        /**
         * 主キー検索を行います。
         * @param id_course コースID
         * @return id_course
         * @param date_lecture 開催日
         * @return date_lecture
         */
        public Trn002_HomeworkTrnBean findByPrimaryKey(String userno,Timestamp date) {
            return (Trn002_HomeworkTrnBean) query(createSQLForFindByPK(), new Object[]{userno, date}, Trn002_HomeworkTrnBean.class);
        }

        @Override
        public String[] getPKColumns() {
            return new String[] {"id_course","date_lecture"};
        }

        @Override
        public String[] getColumns() {
            return new String[] {"ID_COURSE"
                ,"DATE_LECTURE"
                ,"HOMEWORK"
                ,"FLG_DELETE"
                ,"ID_LASTUPDATE"
                ,"DATE_LASTUPDATE"
            };
        }

        @Override
        public String getTableName() {
            return "TRN002_HOMEWORKTRN";
        }

}
