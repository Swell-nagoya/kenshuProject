				
package Dao;				
				
import bean.Trn003_PersonalhomeworkTrnBean;				
				
public class Trn003_PersonalhomeworkTrnDAO extends DataAccessObject {				
				
		/**		
		 * �o�^�������s���܂��B		
		 * @param Trn003_PersonalhomeworkTrn trn003_personalhomeworktrn		
		 */		
		public void create(Trn003_PersonalhomeworkTrnBean trn003_personalhomeworktrn) {		
			update(createSQLForCreate(),	
				new Object[] {
				trn003_personalhomeworktrn.getid_user()
				,trn003_personalhomeworktrn.gethomework()
				,trn003_personalhomeworktrn.getday_lecture()
				,trn003_personalhomeworktrn.gettimetable_lecture()
				,trn003_personalhomeworktrn.getflg_delete()
				,trn003_personalhomeworktrn.getid_lastupdate()
				,trn003_personalhomeworktrn.getdate_lastupdate()
				});
		}		

		/**		
		 * �X�V�������s���܂��B		
		 * @param Trn003_PersonalhomeworkTrn trn003_personalhomeworktrn		
		 */		
		public void update(Trn003_PersonalhomeworkTrnBean trn003_personalhomeworktrn) {		
			update(createSQLForUpdate(),	
				new Object[] {
				trn003_personalhomeworktrn.getid_user()
				,trn003_personalhomeworktrn.gethomework()
				,trn003_personalhomeworktrn.getday_lecture()
				,trn003_personalhomeworktrn.gettimetable_lecture()
				,trn003_personalhomeworktrn.getflg_delete()
				,trn003_personalhomeworktrn.getid_lastupdate()
				,trn003_personalhomeworktrn.getdate_lastupdate()
				});
		}		

		/**		
		 * ��L�[�������s���܂��B		
		 * @param id_user ���[�UID		
		 * @return id_user		
		 */		
		public Trn003_PersonalhomeworkTrnBean findByPrimaryKey(java.lang.Integer userno) {		
			return (Trn003_PersonalhomeworkTrnBean) query(createSQLForFindByPK(), new Object[]{userno}, Trn003_PersonalhomeworkTrnBean.class);	
		}		

		@Override		
		public String[] getPKColumns() {		
			return new String[] {"id_user"};	
		}		

		@Override		
		public String[] getColumns() {		
			return new String[] {"ID_USER"	
				,"HOMEWORK"
				,"DAY_LECTURE"
				,"TIMETABLE_LECTURE"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};	
		}		

		@Override		
		public String getTableName() {	
			return "TRN003_PERSONALHOMEWORKTRN";
		}	

}			
