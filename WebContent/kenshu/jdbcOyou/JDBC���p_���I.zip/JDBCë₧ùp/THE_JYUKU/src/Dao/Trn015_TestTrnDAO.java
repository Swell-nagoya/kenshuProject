				
package Dao;				
				
import bean.Trn015_TestTrnBean;
				
public class Trn015_TestTrnDAO extends DataAccessObject {				
				
		/**		
		 * �o�^�������s���܂��B		
		 * @param Trn015_TestTrn trn015_testtrn		
		 */		
		public void create(Trn015_TestTrnBean trn015_testtrn) {		
			update(createSQLForCreate(),	
				new Object[] {
				trn015_testtrn.getid_test()
				,trn015_testtrn.getfiscal_year()
				,trn015_testtrn.gettimes()
				,trn015_testtrn.gettest_type()
				,trn015_testtrn.getdate_hold()
				,trn015_testtrn.getaverage_jap()
				,trn015_testtrn.getaverage_math()
				,trn015_testtrn.getaverage_siec()
				,trn015_testtrn.getaverage_scty()
				,trn015_testtrn.getaverage_eng()
				,trn015_testtrn.getflg_delete()
				,trn015_testtrn.getid_lastupdate()
				,trn015_testtrn.getdate_lastupdate()
				});
		}		

		/**		
		 * �X�V�������s���܂��B		
		 * @param Trn015_TestTrn trn015_testtrn		
		 */		
		public void update(Trn015_TestTrnBean trn015_testtrn) {		
			update(createSQLForUpdate(),	
				new Object[] {
				trn015_testtrn.getid_test()
				,trn015_testtrn.getfiscal_year()
				,trn015_testtrn.gettimes()
				,trn015_testtrn.gettest_type()
				,trn015_testtrn.getdate_hold()
				,trn015_testtrn.getaverage_jap()
				,trn015_testtrn.getaverage_math()
				,trn015_testtrn.getaverage_siec()
				,trn015_testtrn.getaverage_scty()
				,trn015_testtrn.getaverage_eng()
				,trn015_testtrn.getflg_delete()
				,trn015_testtrn.getid_lastupdate()
				,trn015_testtrn.getdate_lastupdate()
				});
		}		

		/**		
		 * ��L�[�������s���܂��B		
		 * @param id_test �e�X�gID		
		 * @return id_test		
		 * @param fiscal_year �N�x		
		 * @return fiscal_year		
		 * @param times ��		
		 * @return times		
		 */		
		public Trn015_TestTrnBean findByPrimaryKey(java.lang.Integer userno) {		
			return (Trn015_TestTrnBean) query(createSQLForFindByPK(), new Object[]{userno}, Trn015_TestTrnBean.class);	
		}		

		@Override		
		public String[] getPKColumns() {		
			return new String[] {"id_test","fiscal_year","times"};	
		}		

		@Override		
		public String[] getColumns() {		
			return new String[] {"ID_TEST"	
				,"FISCAL_YEAR"
				,"TIMES"
				,"TEST_TYPE"
				,"DATE_HOLD"
				,"AVERAGE_JAP"
				,"AVERAGE_MATH"
				,"AVERAGE_SIEC"
				,"AVERAGE_SCTY"
				,"AVERAGE_ENG"
				,"FLG_DELETE"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
			};	
		}		

		@Override		
		public String getTableName() {	
			return "TRN015_TESTTRN";
		}	

}			
