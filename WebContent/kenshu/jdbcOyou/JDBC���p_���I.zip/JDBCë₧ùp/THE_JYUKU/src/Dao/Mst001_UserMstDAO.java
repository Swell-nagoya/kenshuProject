package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import bean.Mst001_UserMstBean;

public class Mst001_UserMstDAO extends DataAccessObject {

	/**
	 * �o�^�������s���܂��B
	 * @param mst001_UserMst Mst001_UserMst
	 */
	public void create(Mst001_UserMstBean mst001_UserMst) {
		update(createSQLForCreate(),
			new Object[] {
				mst001_UserMst.getId_user()
				,mst001_UserMst.getiD_Card()
				,mst001_UserMst.getPass()
				,mst001_UserMst.getName()
				,mst001_UserMst.getKana_name()
				,mst001_UserMst.getSex()
				,mst001_UserMst.getNickname()
				,mst001_UserMst.getBirthday()
				,mst001_UserMst.getPhone()
				,mst001_UserMst.getMail()
				,mst001_UserMst.getPermission()
				,mst001_UserMst.getId_lastupdate()
				,mst001_UserMst.getDate_lastupdate()
				,mst001_UserMst.getFlg_delete()
			});
	}

	/**
	 * �X�V�������s���܂��B
	 * @param mst001_UserMst user
	 */
	public void update(Mst001_UserMstBean mst001_UserMst) {
		update(createSQLForUpdate(),
			new Object[] {
				mst001_UserMst.getId_user()
				,mst001_UserMst.getiD_Card()
				,mst001_UserMst.getPass()
				,mst001_UserMst.getName()
				,mst001_UserMst.getKana_name()
				,mst001_UserMst.getSex()
				,mst001_UserMst.getNickname()
				,mst001_UserMst.getBirthday()
				,mst001_UserMst.getPhone()
				,mst001_UserMst.getMail()
				,mst001_UserMst.getPermission()
				,mst001_UserMst.getId_lastupdate()
				,mst001_UserMst.getDate_lastupdate()
				,mst001_UserMst.getFlg_delete()
				,mst001_UserMst.getId_user()
			});
	}

	/**
	 * ��L�[�������s���܂��B
	 * @param userno ����ԍ�
	 * @return user
	 */
	public Mst001_UserMstBean findByPrimaryKey(java.lang.Integer userno) {
		return (Mst001_UserMstBean) query(createSQLForFindByPK(), new Object[]{userno}, Mst001_UserMstBean.class);
	}

	//��L�[���擾
	@Override
	public String[] getPKColumns() {
		return new String[] {"ID_USER"};
	}

	//�J���������擾
	@Override
	public String[] getColumns() {
		return new String[] {
				"ID_USER"
				,"ID_CARD"
				,"PASSWORD"
				,"NAME_USER"
				,"KANA_NAME_USER"
				,"SEX"
				,"NICKNAME"
				,"BIRTHDAY"
				,"PHONE_NUMBER"
				,"MAIL_ADDRESS"
				,"PERMISSION"
				,"ID_LASTUPDATE"
				,"DATE_LASTUPDATE"
				,"FLG_DELETE"
		};
	}

	//�e�[�u�������擾
	@Override
	public String getTableName() {
		return "MST001_USERMST";
	}


	/**
	 * ���[�UID�ł̌����pSQL
	 */
	private static final String SQL_FIND_BY_ID_USER =
		"SELECT" +
		"	ID_USER" +
		"	,ID_CARD" +
		"	,PASSWORD" +
		"	,NAME_USER" +
		"	,KANA_NAME_USER" +
		"	,SEX" +
		"	,NICKNAME" +
		"	,BIRTHDAY" +
		"	,PHONE_NUMBER" +
		"	,MAIL_ADDRESS" +
		"	,PERMISSION" +
		"	,ID_LASTUPDATE" +
		"	,DATE_LASTUPDATE" +
		"	,FLG_DELETE" +
		" FROM" +
		"	MST001_USERMST" +
		" WHERE" +
		"	ID_USER = ?";

	/**
	 * ����̃��[�UID�ƈ�v����s�����擾���܂��B
	 */
	private static final String SQL_GET_COUNT_BY_ID_USER =
			"SELECT" +
			"	COUNT(*)" +
			" FROM" +
			"	MST001_USERMST" +
			" WHERE" +
			"	ID_USER = ?";


	/**
	 * �e���[�U�̍X�V�����擾
	 */
	private static final String SQL_GET_LASTUPDATE_DATE =
			"SELECT" +
			"	DATE_LASTUPDATE" +
			" FROM" +
			"	MST001_USERMST";

	/**
	 * USER�\���烆�[�UID�ƈ�v����s�����������܂��B
	 * @param id ���[�U�[ID
	 * @return Integer �s��
	 */
	public int getCountById (String id) {

		int num = -1;

		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			stmt = getConnection().prepareStatement(SQL_GET_COUNT_BY_ID_USER);
			System.out.println(SQL_GET_COUNT_BY_ID_USER);
			System.out.println("id:" + id);
			fillPreparedStatement(stmt, 1, id);
			rs = stmt.executeQuery();

			if(rs.next()) {
				num = rs.getInt("count(*)");
			} else {
				System.out.println("�J�E���g���������擾�ł��Ă��܂���B");
			}
		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

			return num;

	}

	/**
	 * ���[�UID��USER�\���������܂��B
	 * @param id ���[�U�[ID
	 * @return Mst001_UserMst
	 */
	//PK�̂��ߌ������ʂ�1�l
	public Mst001_UserMstBean findById(String id) {
		Mst001_UserMstBean mst001_UserMst = new Mst001_UserMstBean();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_FIND_BY_ID_USER);
			System.out.println(SQL_FIND_BY_ID_USER);
			System.out.println("id:" + id);
			fillPreparedStatement(stmt, 1, id);
			rs = stmt.executeQuery();

			if (rs.next()) {
				mst001_UserMst.setId_user(rs.getString("ID_USER"));
				mst001_UserMst.setiD_Card(rs.getString("ID_CARD"));
				mst001_UserMst.setPass(rs.getString("PASSWORD"));
				mst001_UserMst.setName(rs.getString("NAME_USER"));
				mst001_UserMst.setKana_name(rs.getString("KANA_NAME_USER"));
				mst001_UserMst.setSex(rs.getInt("SEX"));
				mst001_UserMst.setNickname(rs.getString("NICKNAME"));
				mst001_UserMst.setBirthday(rs.getTimestamp("BIRTHDAY"));
				mst001_UserMst.setPhone(rs.getString("PHONE_NUMBER"));
				mst001_UserMst.setMail(rs.getString("MAIL_ADDRESS"));
				mst001_UserMst.setPermission(rs.getInt("PERMISSION"));
				mst001_UserMst.setId_lastupdate(rs.getString("ID_LASTUPDATE"));
				mst001_UserMst.setDate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
				mst001_UserMst.setFlg_delete(rs.getInt("FLG_DELETE"));
			}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return mst001_UserMst;


	}

	/**
	 * �ŏI�X�V�����擾���܂��B
	 * @return List<TimeStamp> �ŏI�X�V�����X�g(LASTUPDATE_DATE)
	 */

	public List<Timestamp> getLastUpDate_Date () {

		//���X�g�̍쐬
		ArrayList<Timestamp> list = new ArrayList<Timestamp>();

		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_GET_LASTUPDATE_DATE);
			System.out.println(SQL_GET_LASTUPDATE_DATE);
			rs = stmt.executeQuery();
		while (rs.next()) {
			if(!rs.getString("DATE_LASTUPDATE").equals("NULL")) {
				Timestamp timestamp = Timestamp.valueOf(rs.getString("DATE_LASTUPDATE"));
				list.add(timestamp);
			}

		}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;

	}
	
	/**
	 * �e���[�U�̍X�V�����擾
	 */
	private static final String SQL_GET_NAME_USER =
			"SELECT ID_USER,NAME_USER FROM MST001_USERMST ORDER BY KANA_NAME_USER";
	/**
	 * �������擾���܂��B
	 * @return List<Mst001_UserMstBean> �������X�g(NAME_USER,KANA_NAME_USER)
	 */
	public List<Mst001_UserMstBean> getNAME () {

		//���X�g�̍쐬
		List<Mst001_UserMstBean> list = new ArrayList<Mst001_UserMstBean>();
		Mst001_UserMstBean mst001_usermst = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(SQL_GET_NAME_USER);
			System.out.println(SQL_GET_NAME_USER);
			rs = stmt.executeQuery();
		while (rs.next()) {
			mst001_usermst = new Mst001_UserMstBean();
			mst001_usermst.setId_user(rs.getString("ID_USER"));
			mst001_usermst.setName(rs.getString("NAME_USER"));
			list.add(mst001_usermst);
		}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;

	}

	/**
	 * ���[�UID�ƃp�X���[�h�Ń��O�C�����܂��B
	 * @param session HttpSession
	 * @param id ���[�UID
	 * @param pass �p�X���[�h
	 * @return HttpSession
	 */
	public HttpSession getLogin(HttpSession session, String palamID, String palamPass) {


		Mst001_UserMstBean mst001_UserMst = new Mst001_UserMstBean();

		ConnectionManager.beginTransaction();

		Connection conn = ConnectionManager.getConnection();

		try {

			if(palamID.equals("")) {
				mst001_UserMst.setComment("ID���L�����Ă�������");
				session.setAttribute("alertmessage", mst001_UserMst);
			} else if (palamPass.equals("")) {
				mst001_UserMst.setComment("�p�X���[�h���L�����Ă�������");
				session.setAttribute("alertmessage", mst001_UserMst);
			} else {

				mst001_UserMst = findById(palamID);
				conn.commit();

				if (mst001_UserMst.getName() != null) {
					if (mst001_UserMst.getPass().equals(palamPass)) {
						session.setAttribute("loginSession", mst001_UserMst);
					} else {
						System.out.println("�p�X���[�h���Ԉ���Ă��܂�");
						mst001_UserMst.setComment("���[�UID���p�X���[�h���Ԉ���Ă��܂��B");
						session.setAttribute("alertmessage", mst001_UserMst);}
				} else {
					System.out.println("���[�UID���Ԉ���Ă��邩���݂��܂���B");
					System.out.print("���[�UID�F");
					System.out.print(mst001_UserMst.getName());
					mst001_UserMst.setComment("���[�UID���p�X���[�h���Ԉ���Ă��܂��B");
					session.setAttribute("alertmessage", mst001_UserMst);
				}
			}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return session;
	}


}