package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import bean.CLS903Bean;
import bean.CLS903_SearchResultBean;
import bean.Mst001_UserMstBean;
import bean.Mst002_StudentMstBean;
import bean.Mst003_GuardianMstBean;
import bean.Mst004_AdministratorMstBean;
import bean.Mst010_CourseMstBean;
import bean.Mst014_SchoolMstBean;
import bean.Mst016_GetCourseMstBean;

/**
 * @author n-kuraoka
 * 
 */
public class CLS903DAO extends ConnectionManager {

	static CLS903DAO cls903dao;

	private String id_user;
	private String name_user;
	private String kana_name;
	private int sex;
	private int grade;
	private String id_elementary;
	private String id_junior_high_school;
	private String id_high_school;
	private String id_university;

	/**
	 * 本来staticで参照すべきと思うが、ないため静的参照するメソッドを作成。
	 * 
	 * @return
	 */
	public static CLS903DAO getInstance() {
		if (cls903dao == null) {
			cls903dao = new CLS903DAO();
		}
		return cls903dao;
	}

	/**
	 * ID_COURSEからコース名を取得するSQL文を作成します。 使用するテーブル⇒MST010_COURSEMST
	 * 
	 * @return String
	 */
	public String createSQLForGetNAME_COURSEByID_COURSE() {
		String sql = "select" + " NAME_COURSE" + ", START_LECTURE"
				+ ", END_LECTURE" + " from" + " MST010_COURSEMST" + " where"
				+ " ID_COURSE = ?";
		return sql;
	}

	public String createSQLSearchMST014_SCHOOLMST() {
		String sql = "select" + " ID_SCHOOL" + ", NAME_SCHOOL" + ", FLG_DELETE"
				+ ", ID_LASTUPDATE" + ", DATE_LASTUPDATE" + " from"
				+ " MST014_SCHOOLMST" + " where" + " CATEGORIZE_SCHOOL=?"
				+ " and " + " FLG_DELETE<>?";

		return sql;
	}

	private String createSQLSearchMST014_SCHOOLMST(List<String> palam) {
		String sql = "select" + " NAME_SCHOOL" + ", CATEGORIZE_SCHOOL"
				+ ", ADDRESS_SCHOOL" + ", DISTRICT_SCHOOL" + ", TERM"
				+ ", TYPE_EVALUATION" + ", FLG_DELETE" + ", ID_LASTUPDATE"
				+ ", DATE_LASTUPDATE" + " from " + " MST014_SCHOOLMST ";
		if (palam.size() > 0) {
			for (int n = 0; n < palam.size(); n++) {
				sql += palam.get(n) + " = ?";
				if (n != palam.size() - 1) {
					sql += "and ";
				}
			}
		}
		return sql;
	}

	public String createSQLSearchMST016_GETCOURSEMSTByID_USERAndID_COURSE() {
		Mst016_GetCourseMstDAO mst016_GetCourseMstDAO = new Mst016_GetCourseMstDAO();
		String sql = "select "
				+ mst016_GetCourseMstDAO.join(
						mst016_GetCourseMstDAO.getColumns(), ",") + " from "
				+ mst016_GetCourseMstDAO.getTableName() + " where "
				+ "ID_USER=?" + " and " + "ID_COURSE=?";
		return sql;
	}

	/**
	 * 生徒のユーザ情報と生徒情報を取得するSQL文を作成します。 palam長が0の際は全検索を行います。
	 * 
	 * @param palam
	 *            条件にするカラム名
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchStudent(List<String> palam) {

		Mst001_UserMstDAO userDAO = new Mst001_UserMstDAO();
		Mst002_StudentMstDAO studentDAO = new Mst002_StudentMstDAO();
		Mst014_SchoolMstDAO mst014_SchoolMstDAO = new Mst014_SchoolMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(userDAO.join(
				userDAO.add(userDAO.getTableName(), ".", userDAO.getColumns()),
				", "));
		sb.append(", ");
		sb.append(userDAO.join(
				userDAO.add(studentDAO.getTableName(), ".",
						studentDAO.getColumns()), ", "));
		sb.append(", ");
		sb.append("elementary_school.NAME_SCHOOL as NAME_ELEMENTARY_SCHOOL");
		sb.append(", ");
		sb.append("junior_high_school.NAME_SCHOOL as NAME_JUNIOR_HIGH_SCHOOL");
		sb.append(", ");
		sb.append("high_school.NAME_SCHOOL as NAME_HIGH_SCHOOL");
		sb.append(", ");
		sb.append("university.NAME_SCHOOL as NAME_UNIVERSITY");
		sb.append(" from ");
		sb.append(userDAO.getTableName());

		sb.append(" inner join ");
		sb.append(studentDAO.getTableName());
		sb.append(" on ");
		sb.append(userDAO.getTableName() + "." + userDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(studentDAO.getTableName() + "."
				+ studentDAO.getPKColumns()[0]);

		sb.append(" left join ");
		sb.append(mst014_SchoolMstDAO.getTableName() + " as elementary_school");
		sb.append(" on ");
		sb.append("elementary_school.ID_SCHOOL");
		sb.append(" = ");
		sb.append(studentDAO.getTableName() + ".ID_ELEMENTARY_SCHOOL");

		sb.append(" left join ");
		sb.append(mst014_SchoolMstDAO.getTableName() + " as junior_high_school");
		sb.append(" on ");
		sb.append("junior_high_school.ID_SCHOOL");
		sb.append(" = ");
		sb.append(studentDAO.getTableName() + ".ID_JUNIOR_HIGH_SCHOOL");

		sb.append(" left join ");
		sb.append(mst014_SchoolMstDAO.getTableName() + " as high_school");
		sb.append(" on ");
		sb.append("high_school.ID_SCHOOL");
		sb.append(" = ");
		sb.append(studentDAO.getTableName() + ".ID_HIGH_SCHOOL");

		sb.append(" left join ");
		sb.append(mst014_SchoolMstDAO.getTableName() + " as university");
		sb.append(" on ");
		sb.append("university.ID_SCHOOL");
		sb.append(" = ");
		sb.append(studentDAO.getTableName() + ".ID_UNIVERSITY");

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		sb.append(" order by ");
		sb.append(userDAO.getTableName() + "." + "KANA_NAME_USER");

		return sb.toString();
	}

	/**
	 * 条件文の中に学校を含む、生徒のユーザ情報と生徒情報を取得するSQL文を作成します。 Palm長が0の際は全検索を行います。
	 * 
	 * このメソッドは学校を意味する2の位の値での範囲を条件文に追加します。
	 * 同じ条件文の中に学年を含む場合は範囲指定ではなくなりますので、このメソッドを使用しないでください。
	 * また、同じく引数のString配列のパラメータにGRADEを持つ場合も使用しないでください。 値はnotnullです。
	 * 
	 * @param palam
	 *            条件にするカラム名
	 * @param school
	 *            学校名(小学校、中学校、高校、その他）
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchStudentInSchool(List<String> palam,
			int school) {

		Mst001_UserMstDAO userDAO = new Mst001_UserMstDAO();
		Mst002_StudentMstDAO studentDAO = new Mst002_StudentMstDAO();
		Mst014_SchoolMstDAO schoolDAO = new Mst014_SchoolMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(userDAO.join(
				userDAO.add(userDAO.getTableName(), ".", userDAO.getColumns()),
				", "));
		sb.append(", ");
		sb.append(userDAO.join(
				userDAO.add(studentDAO.getTableName(), ".",
						studentDAO.getColumns()), ", "));
		if (school == 10) {
			sb.append(", ");
			sb.append("elementary_school.NAME_SCHOOL as NAME_ELEMENTARY_SCHOOL");
		} else if (school == 20) {
			sb.append(", ");
			sb.append("junior_high_school.NAME_SCHOOL as NAME_JUNIOR_HIGH_SCHOOL");
		} else if (school == 30) {
			sb.append(", ");
			sb.append("high_school.NAME_SCHOOL as NAME_HIGH_SCHOOL");
		} else if (school == 40) {
			sb.append(", ");
			sb.append("university.NAME_SCHOOL as NAME_UNIVERSITY");
		}
		sb.append(" from ");
		sb.append(studentDAO.getTableName());

		sb.append(" left join ");
		sb.append(userDAO.getTableName()); // ユーザマスタ
		sb.append(" on ");
		sb.append(userDAO.getTableName() + "." + userDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(studentDAO.getTableName() + "."
				+ studentDAO.getPKColumns()[0]);

		if (school == 10) {
			sb.append(" left join ");
			sb.append(schoolDAO.getTableName() + " as elementary_school");// 小学校
			sb.append(" on ");
			sb.append("elementary_school.ID_SCHOOL");
			sb.append(" = ");
			sb.append(studentDAO.getTableName() + "." + "ID_ELEMENTARY_SCHOOL");
		} else if (school == 20) {
			sb.append(" left join ");
			sb.append(schoolDAO.getTableName() + " as junior_high_school");// 中学校
			sb.append(" on ");
			sb.append("junior_high_school.ID_SCHOOL");
			sb.append(" = ");
			sb.append(studentDAO.getTableName() + ".ID_JUNIOR_HIGH_SCHOOL");
		} else if (school == 30) {
			sb.append(" left join ");
			sb.append(schoolDAO.getTableName() + " as high_school");// 高校
			sb.append(" on ");
			sb.append("high_school.ID_SCHOOL");
			sb.append(" = ");
			sb.append(studentDAO.getTableName() + ".ID_HIGH_SCHOOL");
		} else if (school == 40) {
			sb.append(" left join ");
			sb.append(schoolDAO.getTableName() + " as university");// 大学
			sb.append(" on ");
			sb.append("university.ID_SCHOOL");
			sb.append(" = ");
			sb.append(studentDAO.getTableName() + ".ID_UNIVERSITY");
		}
		sb.append(" where ");
		for (int n = 0; n < palam.size(); n++) {
			sb.append(palam.get(n));
			sb.append(" = ?");
			if (n != (palam.size() - 1)) {
				sb.append(" and ");
			}
		}
		if (palam.size() != 0) {
			sb.append(" and ");
		}
		sb.append(" GRADE > ");
		sb.append(Integer.toString(school));
		sb.append(" and GRADE < ");
		sb.append(Integer.toString(school + 9));

		sb.append(" order by ");
		sb.append(userDAO.getTableName() + "." + "KANA_NAME_USER");

		return sb.toString();

	}

	/**
	 * 保護者のユーザ情報と保護者情報を取得するSQL文を作成します。 palam長が０の場合は、全検索を行います。
	 * 
	 * @param palam
	 *            条件にするカラム名
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchGuardian(List<String> palam) {

		Mst001_UserMstDAO userDAO = new Mst001_UserMstDAO();
		Mst003_GuardianMstDAO guardianMstDAO = new Mst003_GuardianMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(userDAO.join(
				userDAO.add(userDAO.getTableName(), ".", userDAO.getColumns()),
				", "));
		sb.append(", ");
		sb.append(userDAO.join(
				userDAO.add(guardianMstDAO.getTableName(), ".",
						guardianMstDAO.getColumns()), ", "));
		sb.append(" from ");
		sb.append(userDAO.getTableName());
		sb.append(" inner join ");
		sb.append(guardianMstDAO.getTableName());
		sb.append(" on ");
		sb.append(userDAO.getTableName() + "." + userDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(guardianMstDAO.getTableName() + "."
				+ guardianMstDAO.getPKColumns()[0]);

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		sb.append(" order by ");
		sb.append(userDAO.getTableName() + "." + "KANA_NAME_USER");

		return sb.toString();
	}

	/**
	 * 管理者のユーザ情報と管理者情報を取得するSQL文を作成します。 palam長が０の場合は、全検索を行います。
	 * 
	 * @param palam
	 *            条件にするカラム名(頭にテーブル名を記載してください）
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchAdministrator(List<String> palam) {

		Mst001_UserMstDAO userDAO = new Mst001_UserMstDAO();
		Mst004_AdministratorMstDAO mst004_AdministratorMstDAO = new Mst004_AdministratorMstDAO();
		Mst014_SchoolMstDAO mst014_SchoolMstDAO = new Mst014_SchoolMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(userDAO.join(
				userDAO.add(userDAO.getTableName(), ".", userDAO.getColumns()),
				", "));
		sb.append(", ");
		sb.append(userDAO.join(userDAO.add(
				mst004_AdministratorMstDAO.getTableName(), ".",
				mst004_AdministratorMstDAO.getColumns()), ", "));
		sb.append(" from ");
		sb.append(userDAO.getTableName());
		sb.append(" inner join ");
		sb.append(mst004_AdministratorMstDAO.getTableName());
		sb.append(" on ");
		sb.append(userDAO.getTableName() + "." + userDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(mst004_AdministratorMstDAO.getTableName() + "."
				+ mst004_AdministratorMstDAO.getPKColumns()[0]);

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}

		}
		sb.append(" order by ");
		sb.append(userDAO.getTableName() + "." + "KANA_NAME_USER");

		return sb.toString();
	}

	/**
	 * 条件文の中に学校を含む、生徒のユーザ情報と生徒情報を取得するSQL文を作成します。 palam長が0の際は全検索を行います。
	 * 
	 * このメソッドは学校を意味する2の位の値での範囲を条件文に追加します。
	 * 同じ条件文の中に学年を含む場合は範囲指定ではなくなりますので、このメソッドを使用しないでください。
	 * また、同じく引数のString配列のパラメータにGRADEを持つ場合も使用しないでください。 値はnotnullです。
	 * 
	 * @param palam
	 *            条件にするカラム名
	 * @param school
	 *            学校名(小学校、中学校、高校、その他）
	 * @return 作成するSQL文
	 */

	public String createSQLForSearchAdministratorInSchool(List<String> palam,
			int school) {

		Mst001_UserMstDAO userDAO = new Mst001_UserMstDAO();
		Mst004_AdministratorMstDAO mst004_AdministratorMstDAO = new Mst004_AdministratorMstDAO();

		StringBuffer sb = new StringBuffer();

		sb.append("select ");
		sb.append(userDAO.join(
				userDAO.add(userDAO.getTableName(), ".", userDAO.getColumns()),
				", "));
		sb.append(", ");
		sb.append(userDAO.join(userDAO.add(
				mst004_AdministratorMstDAO.getTableName(), ".",
				mst004_AdministratorMstDAO.getColumns()), ", "));
		sb.append(" from ");
		sb.append(userDAO.getTableName());
		sb.append(" inner join ");
		sb.append(mst004_AdministratorMstDAO.getTableName());
		sb.append(" on ");
		sb.append(userDAO.getTableName() + "." + userDAO.getPKColumns()[0]);
		sb.append(" = ");
		sb.append(mst004_AdministratorMstDAO.getTableName() + "."
				+ mst004_AdministratorMstDAO.getPKColumns()[0]);

		if (palam.size() != 0) {
			sb.append(" where ");
			for (int n = 0; n < palam.size(); n++) {
				sb.append(palam.get(n));
				sb.append(" = ?");
				if (n != (palam.size() - 1)) {
					sb.append(" and ");
				}
			}
		}
		sb.append("and GRADE > ");
		sb.append(Integer.toString(school));
		sb.append("and GRADE < ");
		sb.append(Integer.toString(school + 9));

		sb.append(" order by ");
		sb.append(userDAO.getTableName() + "." + "KANA_NAME_USER");

		return sb.toString();

	}

	/**
	 * 生徒または管理者の取得授業を検索するSQL文を取得します。
	 * 
	 * @return String
	 */

	public String createSQLForSearchMst016ById_user() {

		String sql = "select " + " ID_COURSE" + ", DATE_START" + ", DATE_END"
				+ ", FLG_DELETE" + ", ID_LASTUPDATE" + ", DATE_LASTUPDATE"
				+ " from" + " MST016_GETCOURSEMST" + " where" + " ID_USER = ?";
		return sql;
	}

	public String createSQLForDistinctFamilyIdList(DataAccessObject dao) {
		return "select distinct ID_FAMILY from " + dao.getTableName();
	}

	public Set<String> getFamilyIdList(DataAccessObject dao) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Set<String> familyIdList = new HashSet<>();

		String sql = createSQLForDistinctFamilyIdList(dao);
		try {
			stmt = getConnection().prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {
				familyIdList.add(rs.getString("ID_FAMILY"));
			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		return familyIdList;
	}

	public List<Mst014_SchoolMstBean> SerchMST014_SCHOOLMST(
			Mst014_SchoolMstBean mst014_SchoolMstBean) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		// 取得対象のパラメータ
		List<Mst014_SchoolMstBean> list = new ArrayList<>();
		// 検索対象のパラむ
		List<String> palam = new ArrayList<>();
		// 検索対象の値
		List<String> value = new ArrayList<>();

		// パラメーターの設定（ユーザーマスタ）
		if (mst014_SchoolMstBean.getid_school() != null) {
			palam.add("ID_SCHOOL");
			value.add(mst014_SchoolMstBean.getid_school());
		}
		if (mst014_SchoolMstBean.getname_school() != null) {
			palam.add("NAME_SCHOOL");
			value.add(mst014_SchoolMstBean.getname_school());
		}
		if (mst014_SchoolMstBean.getCategorize_school() != 0) {
			palam.add("CATEGORIZE_SCHOOL");
			value.add(String.valueOf(mst014_SchoolMstBean
					.getCategorize_school()));
		}
		if (mst014_SchoolMstBean.getaddress_school() != null) {
			palam.add("ADDRESS_SCHOOL");
			value.add(mst014_SchoolMstBean.getaddress_school());
		}
		if (mst014_SchoolMstBean.getdistrict_school() != null) {
			palam.add("DISTRICT_SCHOOL");
			value.add(mst014_SchoolMstBean.getdistrict_school());
		}
		if (mst014_SchoolMstBean.getterm() != 0) {
			palam.add("TERM");
			value.add(String.valueOf(mst014_SchoolMstBean.getterm()));
		}
		if (mst014_SchoolMstBean.gettype_evaluation() != 0) {
			palam.add("TYPE_EVALUATION");
			value.add(String.valueOf(mst014_SchoolMstBean.gettype_evaluation()));
		}

		String sql = createSQLSearchMST014_SCHOOLMST(palam);
		try {
			stmt = getConnection().prepareStatement(sql);

			for (int n = 0; n < value.size(); n++) {
				stmt.setObject(n + 1, value.get(n));
			}

			rs = stmt.executeQuery();

			while (rs.next()) {
				Mst014_SchoolMstBean bean = new Mst014_SchoolMstBean();
				bean.setid_school(rs.getString("ID_SCHOOL"));
				bean.setname_school(rs.getString("NAME_SCHOOL"));
				bean.setcategorize_school(rs.getInt("CATEGORIZE_SCHOOL"));
				bean.setaddress_school(rs.getString("ADDRESS_SCHOOL"));
				bean.setdistrict_school(rs.getString("DISTRICT_SCHOOL"));
				bean.setterm(rs.getInt("TERM"));
				bean.settype_evaluation(rs.getInt("TYPE_EVALUATION"));
				bean.setflg_delete(rs.getInt("FLG_DELETE"));
				bean.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				bean.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
				list.add(bean);
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return list;
	}

	/**
	 * 学校を一覧表示します。
	 * 
	 * @return list
	 */

	public List<Mst014_SchoolMstBean> SearchMST014_SCHOOLMST(
			int categorize_school) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Mst014_SchoolMstBean> list = new ArrayList<>();
		String sql = createSQLSearchMST014_SCHOOLMST();
		try {
			stmt = getConnection().prepareStatement(sql);

			stmt.setInt(1, categorize_school);
			stmt.setInt(2, 1);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Mst014_SchoolMstBean bean = new Mst014_SchoolMstBean();
				bean.setid_school(rs.getString("ID_SCHOOL"));
				bean.setname_school(rs.getString("NAME_SCHOOL"));
				bean.setflg_delete(rs.getInt("FLG_DELETE"));
				bean.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				bean.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));

				list.add(bean);

			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}

		}
		return list;
	}

	/**
	 * 生徒のコースIDで取得コースデータを取得します。
	 * 
	 * @param id_user
	 * @param id_course
	 * @return mst016
	 */
	public Mst016_GetCourseMstBean SearchMST016_GETCOURSEMSTByID_USERAndID_COURSE(
			String id_user, String id_course) {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Mst016_GetCourseMstBean mst016_GetCourseMstBean = new Mst016_GetCourseMstBean();
		String sql = createSQLSearchMST016_GETCOURSEMSTByID_USERAndID_COURSE();

		try {
			stmt = getConnection().prepareStatement(sql);

			stmt.setString(1, id_user);
			stmt.setString(2, id_course);

			rs = stmt.executeQuery();
			if (rs.next()) {
				mst016_GetCourseMstBean.setid_user(rs.getString("ID_USER"));
				mst016_GetCourseMstBean.setid_course(rs.getString("ID_COURSE"));
				mst016_GetCourseMstBean.setDate_start(rs
						.getTimestamp("DATE_START"));
				mst016_GetCourseMstBean
						.setDate_end(rs.getTimestamp("DATE_END"));
				mst016_GetCourseMstBean.setflg_delete(rs.getInt("FLG_DELETE"));
				mst016_GetCourseMstBean.setid_lastupdate(rs
						.getString("ID_LASTUPDATE"));
				mst016_GetCourseMstBean.setdate_lastupdate(rs
						.getTimestamp("DATE_LASTUPDATE"));
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}

		}
		return mst016_GetCourseMstBean;
	}

	/**
	 * コースIDリストから対応するコース名をリストでそれぞれ取得します。
	 * 
	 * @param beans
	 *            List<Mst016_GetCourseMstBean>
	 * @return List<Mst010_CourseMstBean>
	 */
	PreparedStatement stmt = null;

	public List<Mst010_CourseMstBean> GetNAME_COURSEByID_COURSE(
			List<Mst016_GetCourseMstBean> beans) {
		ResultSet rs = null;

		// 取得するパラメータ
		List<Mst010_CourseMstBean> list = new ArrayList<Mst010_CourseMstBean>();
		String sql = createSQLForGetNAME_COURSEByID_COURSE();

		for (int i = 0; i < beans.size(); i++) {
			try {
				stmt = getConnection().prepareStatement(sql);

				stmt.setString(1, beans.get(i).getid_course());

				rs = stmt.executeQuery();

				// JSP側の処理の事情でこういう実装にしている
				// ここに関しては編集不可
				Mst010_CourseMstBean bean = new Mst010_CourseMstBean();
				if (rs.next()) {
					bean.setname_course(rs.getString("NAME_COURSE"));
					bean.setstart_lecture(rs.getTimestamp("START_LECTURE"));
					bean.setend_lecture(rs.getTimestamp("END_LECTURE"));
				}
				list.add(bean);
			} catch (SQLException exception) {
				throw new RuntimeException(exception);
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}

			}
		}
		return list;
	}

	/**
	 * 現在、生徒または管理者が取得している授業を取得します。
	 * 
	 * @param id_user
	 * @return List<MST016_GETCOURSTMST> list
	 */
	public List<Mst016_GetCourseMstBean> SearchMst016ById_user(String id_user) {
		PreparedStatement stmt = null;
		ResultSet rs = null;

		// 取得するパラメータ
		List<Mst016_GetCourseMstBean> list = new ArrayList<Mst016_GetCourseMstBean>();
		String sql = createSQLForSearchMst016ById_user();
		try {
			stmt = getConnection().prepareStatement(sql);

			stmt.setString(1, id_user);

			rs = stmt.executeQuery();

			while (rs.next()) {
				Mst016_GetCourseMstBean bean = new Mst016_GetCourseMstBean();
				bean.setid_course(rs.getString("ID_COURSE"));
				bean.setDate_start(rs.getTimestamp("DATE_START"));
				bean.setDate_end(rs.getTimestamp("DATE_END"));
				bean.setflg_delete(rs.getInt("FLG_DELETE"));
				bean.setid_lastupdate(rs.getString("ID_LASTUPDATE"));
				bean.setdate_lastupdate(rs.getTimestamp("DATE_LASTUPDATE"));
				list.add(bean);
			}
		} catch (SQLException exception) {
			throw new RuntimeException(exception);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			}

		}

		return list;
	}

	/**
	 * 生徒データ、保護者データ、管理者データのいずれかを含むユーザデータを取得します。
	 * 
	 * @param cls903d
	 * @return List<CLS903Bean>
	 */

	public List<CLS903Bean> Search(CLS903Bean cls903d) {

		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = null;
		Mst001_UserMstBean mst001_UserMst = null;
		Mst002_StudentMstBean mst002_StudentMst = null;
		Mst004_AdministratorMstBean mst004_AdministratorMst = null;

		// 取得するパラメータ
		List<CLS903Bean> list = new ArrayList<CLS903Bean>();

		// 検索対象のカラム
		List<String> palam = new ArrayList<String>();

		// 検索対象のパラメータ
		List<Object> value = new ArrayList<Object>();

		// 共通で取得するユーザテーブルのBean
		mst001_UserMst = cls903d.getMst001_UserMstBean();

		// 権限に対応するテーブルがあるかを確認する。
		int permission = mst001_UserMst.getPermission();

		// パラメーターの設定（ユーザーマスタ）
		if (mst001_UserMst.getId_user() != null) {
			id_user = mst001_UserMst.getId_user();
			palam.add("ID_USER");
			value.add(id_user);
		}

		if (mst001_UserMst.getName() != null) {
			name_user = mst001_UserMst.getName();
			palam.add("NAME_USER");
			value.add(name_user);
		}

		if (mst001_UserMst.getKana_name() != null) {
			kana_name = mst001_UserMst.getKana_name();
			palam.add("KANA_NAME_USER");
			value.add(kana_name);
		}

		if (mst001_UserMst.getSex() != 0) {
			sex = mst001_UserMst.getSex();
			palam.add("SEX");
			value.add(sex);
		}
		// 削除フラグ
		palam.add("IFNULL(MST001_USERMST.FLG_DELETE,0)");
		value.add("0");

		// 権限が「1：生徒」
		if (permission == 1) {
			/*
			 * 生徒の場合の検索を行う 入力されたパラメータに応じてSQLの作成を行う
			 */

			mst002_StudentMst = cls903d.getMst002_StudentMstBean();

			if (mst002_StudentMst.getGrade() != 0) {
				// 1の位が0の場合、学校全体の検索になるので、valueに渡さない、
				if (mst002_StudentMst.getGrade() % 10 != 0
						&& mst002_StudentMst.getGrade() != 0) {
					grade = mst002_StudentMst.getGrade();
					palam.add("GRADE");
					value.add(grade);
				}
			}

			if (mst002_StudentMst.getId_elementary() != null) {
				id_elementary = mst002_StudentMst.getId_elementary();
				palam.add("ID_ELEMENTARY_SCHOOL");
				value.add(id_elementary);
			}

			if (mst002_StudentMst.getId_junior_high_school() != null) {
				id_junior_high_school = mst002_StudentMst
						.getId_junior_high_school();
				palam.add("ID_JUNIOR_HIGH_SCHOOL");
				value.add(id_junior_high_school);
			}

			if (mst002_StudentMst.getId_high_school() != null) {
				id_high_school = mst002_StudentMst.getId_high_school();
				palam.add("ID_HIGH_SCHOOL");
				value.add(id_high_school);
			}

			if (mst002_StudentMst.getId_university() != null) {
				id_university = mst002_StudentMst.getId_university();
				palam.add("ID_UNIVERSITY");
				value.add(id_university);
			}

			if (mst002_StudentMst.getGrade() != 0
					&& mst002_StudentMst.getGrade() % 10 == 0) {
				sql = createSQLForSearchStudentInSchool(palam,
						mst002_StudentMst.getGrade());
			} else {
				sql = createSQLForSearchStudent(palam);
			}

			System.out.println(sql);

			try {
				stmt = getConnection().prepareStatement(sql);

				for (int n = 0; n < value.size(); n++) {
					stmt.setObject(n + 1, value.get(n));
				}

				rs = stmt.executeQuery();

				while (rs.next()) {
					CLS903Bean cls903d2 = new CLS903Bean();
					Mst001_UserMstBean mst001_UserMst2 = new Mst001_UserMstBean();
					Mst002_StudentMstBean mst002_StudentMst2 = new Mst002_StudentMstBean();
					CLS903_SearchResultBean cls903_SearchResultBean = new CLS903_SearchResultBean();

					mst001_UserMst2.setId_user(rs.getString("ID_USER"));
					mst001_UserMst2.setPass(rs.getString("PASSWORD"));
					mst001_UserMst2.setName(rs.getString("NAME_USER"));
					mst001_UserMst2
							.setKana_name(rs.getString("KANA_NAME_USER"));
					mst001_UserMst2.setSex(rs.getInt("SEX"));
					mst001_UserMst2.setNickname(rs.getString("NICKNAME"));
					mst001_UserMst2.setBirthday(rs.getTimestamp("BIRTHDAY"));
					mst001_UserMst2.setPhone(rs.getString("PHONE_NUMBER"));
					mst001_UserMst2.setMail(rs.getString("MAIL_ADDRESS"));
					mst001_UserMst2.setPermission(rs.getInt("PERMISSION"));
					mst001_UserMst2.setId_lastupdate(rs
							.getString("ID_LASTUPDATE"));
					mst001_UserMst2.setDate_lastupdate(rs
							.getTimestamp("DATE_LASTUPDATE"));
					mst001_UserMst2.setFlg_delete(rs.getInt("FLG_DELETE"));
					mst002_StudentMst2.setId_user(rs.getString("ID_USER"));
					mst002_StudentMst2.setId_family(rs.getString("ID_FAMILY"));
					mst002_StudentMst2.setGrade(rs.getInt("GRADE"));
					mst002_StudentMst2.setId_elementary(rs
							.getString("ID_ELEMENTARY_SCHOOL"));
					mst002_StudentMst2.setId_junior_high_school(rs
							.getString("ID_JUNIOR_HIGH_SCHOOL"));
					mst002_StudentMst2.setId_high_school(rs
							.getString("ID_HIGH_SCHOOL"));
					mst002_StudentMst2.setId_university(rs
							.getString("ID_UNIVERSITY"));
					mst002_StudentMst2.setIn_crammer(rs
							.getTimestamp("IN_CRAMMER"));
					mst002_StudentMst2.setOut_crammer(rs
							.getTimestamp("OUT_CRAMMER"));
					mst002_StudentMst2.setFlg_sendentermail(rs
							.getInt("FLG_SENDENTERMAIL"));
					mst002_StudentMst2.setFlg_sendexitmail(rs
							.getInt("FLG_SENDEXITMAIL"));
					mst002_StudentMst2.setId_lastupdate(rs
							.getString("ID_LASTUPDATE"));
					mst002_StudentMst2.setDate_lastupdate(rs
							.getTimestamp("DATE_LASTUPDATE"));
					// 学校指定時
					if (mst002_StudentMst.getGrade() != 0
							&& mst002_StudentMst.getGrade() % 10 == 0) {
						// Tanaka とりあえずこれで学校指定で検索出来る
						if (mst002_StudentMst2.getId_elementary() != "0"
								&& mst002_StudentMst.getGrade() == 10) {
							cls903_SearchResultBean
									.setName_elementary_school(rs
											.getString("NAME_ELEMENTARY_SCHOOL"));
						} else if (mst002_StudentMst2
								.getId_junior_high_school() != "0"
								&& mst002_StudentMst.getGrade() == 20) {
							cls903_SearchResultBean
									.setName_junior_high_school(rs
											.getString("NAME_JUNIOR_HIGH_SCHOOL"));
						} else if (mst002_StudentMst2.getId_high_school() != "0"
								&& mst002_StudentMst.getGrade() == 30) {
							cls903_SearchResultBean.setName_high_school(rs
									.getString("NAME_HIGH_SCHOOL"));
						} else if (mst002_StudentMst2.getId_university() != "0"
								&& mst002_StudentMst.getGrade() == 40) {
							cls903_SearchResultBean.setName_university(rs
									.getString("NAME_UNIVERSITY"));
						}
					}
					// 学校未指定時
					else {
						cls903_SearchResultBean.setName_elementary_school(rs
								.getString("NAME_ELEMENTARY_SCHOOL"));
						cls903_SearchResultBean.setName_junior_high_school(rs
								.getString("NAME_JUNIOR_HIGH_SCHOOL"));
						cls903_SearchResultBean.setName_high_school(rs
								.getString("NAME_HIGH_SCHOOL"));
						cls903_SearchResultBean.setName_university(rs
								.getString("NAME_UNIVERSITY"));
					}

					cls903d2.setMst001_UserMstBean(mst001_UserMst2);
					cls903d2.setMst002_StudentMstBean(mst002_StudentMst2);
					cls903d2.setCls903_SearchResultBean(cls903_SearchResultBean);

					list.add(cls903d2);
				}

				return list;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}

			}

			// 権限が「2：保護者」
		} else if (permission == 2) {

			// 保護者の場合の検索を行う

			/*
			 * 保護者に関しては共通データのみ 入力されたパラメータに応じてSQLの作成を行う
			 */
			sql = createSQLForSearchGuardian(palam);
			System.out.println(sql);

			try {
				stmt = getConnection().prepareStatement(sql);

				for (int n = 0; n < value.size(); n++) {
					stmt.setObject(n + 1, value.get(n));
				}

				rs = stmt.executeQuery();

				while (rs.next()) {
					CLS903Bean cls903d2 = new CLS903Bean();
					Mst001_UserMstBean mst001_UserMst2 = new Mst001_UserMstBean();
					Mst003_GuardianMstBean mst003_GuardianMstBean = new Mst003_GuardianMstBean();

					mst001_UserMst2.setId_user(rs.getString("ID_USER"));
					mst001_UserMst2.setPass(rs.getString("PASSWORD"));
					mst001_UserMst2.setName(rs.getString("NAME_USER"));
					mst001_UserMst2
							.setKana_name(rs.getString("KANA_NAME_USER"));
					mst001_UserMst2.setSex(rs.getInt("SEX"));
					mst001_UserMst2.setNickname(rs.getString("NICKNAME"));
					mst001_UserMst2.setBirthday(rs.getTimestamp("BIRTHDAY"));
					mst001_UserMst2.setPhone(rs.getString("PHONE_NUMBER"));
					mst001_UserMst2.setMail(rs.getString("MAIL_ADDRESS"));
					mst001_UserMst2.setPermission(rs.getInt("PERMISSION"));
					mst001_UserMst2.setId_lastupdate(rs
							.getString("ID_LASTUPDATE"));
					mst001_UserMst2.setDate_lastupdate(rs
							.getTimestamp("DATE_LASTUPDATE"));
					mst001_UserMst2.setFlg_delete(rs.getInt("FLG_DELETE"));
					mst003_GuardianMstBean.setId_user(rs.getString("ID_USER"));
					mst003_GuardianMstBean.setId_family(rs
							.getString("ID_FAMILY"));
					mst003_GuardianMstBean.setAddress(rs.getString("ADDRESS"));
					mst003_GuardianMstBean.setFlg_delete(rs
							.getInt("FLG_DELETE"));
					mst003_GuardianMstBean.setId_lastupdate(rs
							.getString("ID_LASTUPDATE"));
					mst003_GuardianMstBean.setDate_lastupdate(rs
							.getTimestamp("DATE_LASTUPDATE"));
					cls903d2.setMst001_UserMstBean(mst001_UserMst2);
					cls903d2.setMst003_GuardianMstBean(mst003_GuardianMstBean);
					list.add(cls903d2);
				}

				return list;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}

			}

			// 権限が「3：管理者」
		} else if (permission == 3) {

			/*
			 * 管理者の場合の検索を行う, 入力されたパラメータに応じてSQLの作成を行う
			 */
			mst004_AdministratorMst = cls903d.getMst004_AdministratorMstBean();

			if (mst004_AdministratorMst.getGrade() != 0) {

				if (mst004_AdministratorMst.getGrade() % 10 != 0
						&& mst004_AdministratorMst.getGrade() != 0) {
					grade = mst004_AdministratorMst.getGrade();
					palam.add("GRADE");
					value.add(grade);
				}
			}
			if (mst004_AdministratorMst.getId_elementary() != null) {
				id_elementary = mst004_AdministratorMst.getId_elementary();
				palam.add("ID_ELEMENTARY_SCHOOL");
				value.add(id_elementary);
			}

			if (mst004_AdministratorMst.getId_junior_high_school() != null) {
				id_junior_high_school = mst004_AdministratorMst
						.getId_junior_high_school();
				palam.add("ID_JUNIOR_HIGH_SCHOOL");
				value.add(id_junior_high_school);
			}

			if (mst004_AdministratorMst.getId_high_school() != null) {
				id_high_school = mst004_AdministratorMst.getId_high_school();
				palam.add("ID_HIGH_SCHOOL");
				value.add(id_high_school);
			}

			if (mst004_AdministratorMst.getId_university() != null) {
				id_university = mst004_AdministratorMst.getId_university();
				palam.add("ID_UNIVERSITY");
				value.add(id_university);
			}

			if (mst004_AdministratorMst.getGrade() % 10 == 0
					&& mst004_AdministratorMst.getGrade() != 0) {
				sql = createSQLForSearchAdministratorInSchool(palam,
						mst004_AdministratorMst.getGrade());
			} else {
				sql = createSQLForSearchAdministrator(palam);
			}
			System.out.println(sql);

			try {
				stmt = getConnection().prepareStatement(sql);

				for (int n = 0; n < value.size(); n++) {
					stmt.setObject(n + 1, value.get(n));
				}

				rs = stmt.executeQuery();

				while (rs.next()) {
					CLS903Bean cls903d2 = new CLS903Bean();
					Mst001_UserMstBean mst001_UserMst2 = new Mst001_UserMstBean();
					Mst004_AdministratorMstBean mst004_AdministratorMstBean = new Mst004_AdministratorMstBean();
					CLS903_SearchResultBean cls903_SearchResultBean = new CLS903_SearchResultBean();

					mst001_UserMst2.setId_user(rs.getString("ID_USER"));
					mst001_UserMst2.setPass(rs.getString("PASSWORD"));
					mst001_UserMst2.setName(rs.getString("NAME_USER"));
					mst001_UserMst2
							.setKana_name(rs.getString("KANA_NAME_USER"));
					mst001_UserMst2.setSex(rs.getInt("SEX"));
					mst001_UserMst2.setNickname(rs.getString("NICKNAME"));
					mst001_UserMst2.setBirthday(rs.getTimestamp("BIRTHDAY"));
					mst001_UserMst2.setPhone(rs.getString("PHONE_NUMBER"));
					mst001_UserMst2.setMail(rs.getString("MAIL_ADDRESS"));
					mst001_UserMst2.setPermission(rs.getInt("PERMISSION"));
					mst001_UserMst2.setId_lastupdate(rs
							.getString("ID_LASTUPDATE"));
					mst001_UserMst2.setDate_lastupdate(rs
							.getTimestamp("DATE_LASTUPDATE"));
					mst001_UserMst2.setFlg_delete(rs.getInt("FLG_DELETE"));
					mst004_AdministratorMstBean.setId_user(rs
							.getString("ID_USER"));
					mst004_AdministratorMstBean.setAddress(rs
							.getString("ADDRESS"));
					mst004_AdministratorMstBean.setGrade(rs.getInt("GRADE"));
					mst004_AdministratorMstBean.setId_elementary(rs
							.getString("ID_ELEMENTARY_SCHOOL"));
					mst004_AdministratorMstBean.setId_junior_high_school(rs
							.getString("ID_JUNIOR_HIGH_SCHOOL"));
					mst004_AdministratorMstBean.setId_high_school(rs
							.getString("ID_HIGH_SCHOOL"));
					mst004_AdministratorMstBean.setId_university(rs
							.getString("ID_UNIVERSITY"));
					mst004_AdministratorMstBean.setIn_crammer(rs
							.getTimestamp("IN_CRAMMER"));
					mst004_AdministratorMstBean.setOut_crammer(rs
							.getTimestamp("OUT_CRAMMER"));
					mst004_AdministratorMstBean.setId_lastupdate(rs
							.getString("ID_LASTUPDATE"));
					mst004_AdministratorMstBean.setDate_lastupdate(rs
							.getTimestamp("DATE_LASTUPDATE"));
					// cls903_SearchResultBean.setName_elementary_school(rs
					// .getString("NAME_ELEMENTARY_SCHOOL"));
					// cls903_SearchResultBean.setName_junior_high_school(rs
					// .getString("NAME_JUNIOR_HIGH_SCHOOL"));
					// cls903_SearchResultBean.setName_high_school(rs
					// .getString("NAME_HIGH_SCHOOL"));
					// cls903_SearchResultBean.setName_university(rs
					// .getString("NAME_UNIVERSITY"));

					cls903d2.setMst001_UserMstBean(mst001_UserMst2);
					cls903d2.setMst004_AdministratorMstBean(mst004_AdministratorMstBean);
					cls903d2.setCls903_SearchResultBean(cls903_SearchResultBean);
					list.add(cls903d2);
				}

				return list;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			} finally {
				if (stmt != null) {
					try {
						stmt.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						throw new RuntimeException(e);
					}
				}
			}
		}
		return null;
	}
}
