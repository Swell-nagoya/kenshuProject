package Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Mst001_UserMstBean;
import bean.Trn900_NfcTrnBean;

public class Trn900_nfctrnDAO extends DataAccessObject {
	Trn900_NfcTrnBean trn900Bean =new Trn900_NfcTrnBean();
	/**
	 * 登録処理を行います。
	 * @param mst001_UserMst Mst001_UserMst
	 */
	public void create(Trn900_NfcTrnBean bean) {
		update(createSQLForCreate(),
			new Object[] {
				bean.getId_user()
				,bean.getDate_access()
				,bean.getTime_incrammer()
				,bean.getTime_outcrammer()
				,bean.getFlag_delete()
		});
	}

	/**
	 * 更新処理を行います。
	 * @param mst001_UserMst user
	 * PK
	 * ID_USER
	 * DATE_ACCESS
	 */
	public void update(Trn900_NfcTrnBean bean) {
		update(createSQLForUpdate(),
			new Object[] {
			bean.getId_user()
			,bean.getDate_access()
			,bean.getTime_incrammer()
			,bean.getTime_outcrammer()
			,bean.getFlag_delete()
			,bean.getId_user()
			,bean.getDate_access()
			});
	}

	/**
	 * 削除処理を行います。
	 */
	public void delete(Trn900_NfcTrnBean bean) {
		update(createSQLForDelete(),
			new Object[] {
			bean.getId_user()
			,bean.getDate_access()
		});
	}

	@Override
	public String[] getPKColumns() {
		return new String[] {
				"ID_USER"
				,"DATE_ACCESS"
		};
	}

	@Override
	public String[] getColumns() {
		return new String[] {
				"ID_USER"
				,"DATE_ACCESS"
				,"TIME_INCRAMMER"
				,"TIME_OUTCRAMMER"
				,"FLAG_DELETE"
		};
	}

	@Override
	public String getTableName() {
		return "TRN900_NFCTRN";
	}
	public String getSQLfindByID() {
		String sql = "select ID_USER" +
			", DATE_ACCESS" +
			", TIME_INCRAMMER" +
			", TIME_OUTCRAMMER" +
			", FLAG_DELETE" +
			" from " +
			"TRN900_NFCTRN" +
			" where " +
			"ID_USER=?";
		return sql;
	}
	public List<Trn900_NfcTrnBean> findByID(String iD_USER) {
		List<Trn900_NfcTrnBean> list = new ArrayList<>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement(getSQLfindByID());
			System.out.println(getSQLfindByID());
			System.out.println("id:" + iD_USER);
			fillPreparedStatement(stmt, 1, iD_USER);
			rs = stmt.executeQuery();
			if (rs.next()) {
				Trn900_NfcTrnBean trn900Bean = new Trn900_NfcTrnBean();
				trn900Bean.setId_user(rs.getString("ID_USER"));
				trn900Bean.setDate_access(rs.getTimestamp("DATE_ACCESS"));
				trn900Bean.setTime_incrammer(rs.getInt("TIME_INCRAMMER"));
				trn900Bean.setTime_outcrammer(rs.getInt("TIME_OUTCRAMMER"));
				trn900Bean.setFlag_delete(rs.getInt("FLAG_DELETE"));
				list.add(trn900Bean);
			}

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}
}
